<?php

/*
	[Discuz!] (C)2001-2007 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: forums.inc.php 13772 2008-05-23 03:09:33Z liuqiang $
*/

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
}

cpheader();

if(!$operation) {

	if(!submitcheck('editsubmit')) {
		shownav('forum', 'nav_forums');
		showsubmenu('nav_forums');
		showtips('forums_tips');

		$projectselect = '<option value="0" selected="selected">'.$lang['none'].'</option>';
		$query = $db->query("SELECT id, name FROM {$tablepre}projects WHERE type='forum'");
		while($project = $db->fetch_array($query)) {
			$projectselect .= '<option value="'.$project['id'].'">'.$project['name'].'</option>';
		}

?>
<script type="text/JavaScript">
var rowtypedata = [
	[[1,'<input type="text" class="txt" name="newcatorder[]" value="0" />', 'td25'], [3, '<input name="newcat[]" value="<?=$lang['forums_add_category_name']?>" size="20" type="text" class="txt" />']],
	[[1,'<input type="text" class="txt" name="neworder[{1}][]" value="0" />', 'td25'], [3, '<div class="board"><input name="newforum[{1}][]" value="<?=$lang['forums_add_forum_name']?>" size="20" type="text" class="txt" /><select name="projectid[{1}][]"><?=$projectselect?></select></div>']],
	[[1,'<input type="text" class="txt" name="neworder[{1}][]" value="0" />', 'td25'], [3, '<div class="childboard"><input name="newforum[{1}][]" value="<?=$lang['forums_add_forum_name']?>" size="20" type="text" class="txt" /><select name="projectid[{1}][]"><?=$projectselect?></select></div>']],
];
</script>
<?
		showformheader('forums');
		showtableheader('');
		showsubtitle(array('display_order', 'forums_name', 'forums_moderators', ''));

		$forums = $showedforums = array();
		$query = $db->query("SELECT f.fid, f.type, f.status, f.name, f.fup, f.displayorder, f.inheritedmod, ff.moderators, ff.password, ff.redirect
			FROM {$tablepre}forums f LEFT JOIN {$tablepre}forumfields ff USING(fid)
			ORDER BY f.type<>'group', f.displayorder");

		while($forum = $db->fetch_array($query)) {
			$forums[] = $forum;
		}
		for($i = 0; $i < count($forums); $i++) {
			if($forums[$i]['type'] == 'group') {
				echo showforum($i, 'group');
				for($j = 0; $j < count($forums); $j++) {
					if($forums[$j]['fup'] == $forums[$i]['fid'] && $forums[$j]['type'] == 'forum') {
						echo showforum($j);
						$lastfid = 0;
						for($k = 0; $k < count($forums); $k++) {
							if($forums[$k]['fup'] == $forums[$j]['fid'] && $forums[$k]['type'] == 'sub') {
								echo showforum($k, 'sub');
								$lastfid = $forums[$k]['fid'];
							}
						}
						echo showforum($j, $lastfid, 'lastchildboard');
					}
				}
				echo showforum($i, '', 'lastboard');
			} elseif(!$forums[$i]['fup'] && $forums[$i]['type'] == 'forum') {
				echo showforum($i);
				for($j = 0; $j < count($forums); $j++) {
					if($forums[$j]['fup'] == $forums[$i]['fid'] && $forums[$j]['type'] == 'sub') {
						echo showforum($j, 'sub');
					}
				}
				echo showforum($i, '', 'lastchildboard');
			}
		}

		foreach($forums as $key => $forum) {
			if(!in_array($key, $showedforums)) {
				$db->query("UPDATE {$tablepre}forums SET fup='0', type='forum' WHERE fid='$forum[fid]'");
				echo showforum($key);
			}
		}

		echo showforum($i, '', 'last');

		showsubmit('editsubmit');
		showtablefooter();
		showformfooter();

	} else {

		// read from groups
		$usergroups = array();
		$query = $db->query("SELECT groupid, type, creditshigher, creditslower FROM {$tablepre}usergroups");
		while($group = $db->fetch_array($query)) {
			$usergroups[$group['groupid']] = $group;
		}

		if(is_array($order)) {
			foreach($order as $fid => $value) {
				$db->query("UPDATE {$tablepre}forums SET name='$name[$fid]', displayorder='$order[$fid]' WHERE fid='$fid'");
			}
		}

		if(is_array($newcat)) {
			foreach($newcat as $key => $forumname) {
				if(empty($forumname)) {
					continue;
				}
				$db->query("INSERT INTO {$tablepre}forums (type, name, status, displayorder)
					VALUES ('group', '$forumname', '1', '$newcatorder[$key]')");
				$fid = $db->insert_id();
				$db->query("INSERT INTO {$tablepre}forumfields (fid)
					VALUES ('$fid')");
			}
		}

		$table_forum_columns = array('fup', 'type', 'name', 'status', 'displayorder', 'styleid', 'allowsmilies', 'allowhtml', 'allowbbcode', 'allowimgcode', 'allowanonymous', 'allowshare', 'allowpostspecial', 'alloweditrules', 'alloweditpost', 'modnewposts', 'recyclebin', 'jammer', 'forumcolumns', 'threadcaches', 'disablewatermark', 'autoclose', 'simple');
		$table_forumfield_columns = array('fid', 'attachextensions', 'threadtypes', 'postcredits', 'replycredits', 'digestcredits', 'postattachcredits', 'getattachcredits', 'viewperm', 'postperm', 'replyperm', 'getattachperm', 'postattachperm');
		$projectdata = array();

		if(is_array($newforum)) {
			foreach($newforum as $fup => $forums) {
				$forum = $db->fetch_first("SELECT * FROM {$tablepre}forums WHERE fid='$fup'");
				foreach($forums as $key => $forumname) {
					if(empty($forumname)) {
						continue;
					}
					$forumfields = array();
					$id = $projectid[$fup][$key];
					if(!empty($id)) {
						$projectdata[$id] = empty($projectdata[$id]) ? unserialize($db->result_first("SELECT value FROM {$tablepre}projects WHERE id='$id'")) : $projectdata[$id];

						foreach($table_forum_columns as $field) {
							$forumfields[$field] = $projectdata[$id][$field];
						}

						foreach($table_forumfield_columns as $field) {
							$forumfields[$field] = $projectdata[$id][$field];
						}
					} else {
						$forumfields['allowsmilies'] = $forumfields['allowbbcode'] = $forumfields['allowimgcode'] = $forumfields['allowshare'] = 1;
						$forumfields['allowpostspecial'] = 127;
					}

					$forumfields['fup'] = $forum ? $fup : 0;
					$forumfields['type'] = $forum['type'] == 'forum' ? 'sub' : 'forum';
					$forumfields['name'] = $forumname;
					$forumfields['status'] = 1;
					$forumfields['displayorder'] = $neworder[$fup][$key];

					$sql1 = $sql2 = $comma = '';

					foreach($table_forum_columns as $field) {
						if(isset($forumfields[$field])) {
							$sql1 .= "$comma$field";
							$sql2 .= "$comma'{$forumfields[$field]}'";
							$comma = ', ';
						}
					}

					$db->query("INSERT INTO {$tablepre}forums ($sql1) VALUES ($sql2)");
					$forumfields['fid'] = $fid = $db->insert_id();

					$sql1 = $sql2 = $comma = '';
					foreach($table_forumfield_columns as $field) {
						if(isset($forumfields[$field])) {
							$sql1 .= "$comma$field";
							$sql2 .= "$comma'{$forumfields[$field]}'";
							$comma = ', ';
						}
					}

					$db->query("INSERT INTO {$tablepre}forumfields ($sql1) VALUES ($sql2)");

					$query = $db->query("SELECT uid, inherited FROM {$tablepre}moderators WHERE fid='$fup'");
					while($mod = $db->fetch_array($query)) {
						if($mod['inherited'] || $forum['inheritedmod']) {
							$db->query("REPLACE INTO {$tablepre}moderators (uid, fid, inherited)
								VALUES ('$mod[uid]', '$fid', '1')");
						}
					}
				}
			}
		}


		updatecache('forums');

		cpmsg('forums_update_succeed', 'admincp.php?action=forums', 'succeed');
	}

} elseif($operation == 'moderators' && $fid) {

	if(!submitcheck('modsubmit')) {

		shownav('forum', 'forums_moderators_edit');
		showsubmenu(lang('forums_moderators_edit').' - '.$forum['name']);
		showtips('forums_moderators_tips');
		showformheader("forums&operation=moderators&fid=$fid&");
		showtableheader('', 'fixpadding');
		showsubtitle(array('', 'display_order', 'username', 'forums_moderators_inherited'));

		$query = $db->query("SELECT m.username, mo.* FROM {$tablepre}members m, {$tablepre}moderators mo WHERE mo.fid='$fid' AND m.uid=mo.uid ORDER BY mo.inherited, mo.displayorder");
		while($mod = $db->fetch_array($query)) {
			showtablerow('', array('class="td25"', 'class="td28"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$mod[uid].'"'.($mod['inherited'] ? ' disabled' : '').' />',
				'<input type="text" class="txt" name="displayordernew['.$mod[uid].']" value="'.$mod[displayorder].'" size="2" />',
				"<a href=\"space.php?uid=$mod[uid]\" target=\"_blank\">$mod[username]</a>",
				lang($mod['inherited'] ? 'yes' : 'no'),
			));
		}

		if($forum['type'] == 'group' || $forum['type'] == 'sub') {
			$checked = $forum['type'] == 'group' ? 'checked' : '';
			$disabled = 'disabled';
		} else {
			$checked = $forum['inheritedmod'] ? 'checked' : '';
			$disabled = '';
		}

		showtablerow('', array('class="td25"', 'class="td28"'), array(
			lang('add_new'),
			'<input type="text" class="txt" name="newdisplayorder" value="0" size="2" />',
			'<input type="text" class="txt" name="newmoderator" value="" size="20" />',
			''
		));

		showsubmit('modsubmit', 'submit', 'del', '<input class="checkbox" type="checkbox" name="inheritedmodnew" value="1" '.$checked.' '.$disabled.' id="inheritedmodnew" /><label for="inheritedmodnew">'.lang('forums_moderators_inherit').'</label>');
		showtablefooter();
		showformfooter();

	} else {

		if($forum['type'] == 'group') {
			$inheritedmodnew = 1;
		} elseif($forum['type'] == 'sub') {
			$inheritedmodnew = 0;
		}

		if(!empty($delete) || $newmoderator || (bool)$forum['inheritedmod'] != (bool)$inheritedmodnew) {

			$fidarray = $newmodarray = $origmodarray = array();

			if($forum['type'] == 'group') {
				$query = $db->query("SELECT fid FROM {$tablepre}forums WHERE type='forum' AND fup='$fid'");
				while($sub = $db->fetch_array($query)) {
					$fidarray[] = $sub['fid'];
				}
				$query = $db->query("SELECT fid FROM {$tablepre}forums WHERE type='sub' AND fup IN ('".implode('\',\'', $fidarray)."')");
				while($sub = $db->fetch_array($query)) {
					$fidarray[] = $sub['fid'];
				}
			} elseif($forum['type'] == 'forum') {
				$query = $db->query("SELECT fid FROM {$tablepre}forums WHERE type='sub' AND fup='$fid'");
				while($sub = $db->fetch_array($query)) {
					$fidarray[] = $sub['fid'];
				}
			}

			if(is_array($delete)) {
				foreach($delete as $uid) {
					$db->query("DELETE FROM {$tablepre}moderators WHERE uid='$uid' AND ((fid='$fid' AND inherited='0') OR (fid IN ('".implode('\',\'', $fidarray)."') AND inherited='1'))");
				}

				$excludeuids = 0;
				$deleteuids = '\''.implode('\',\'', $delete).'\'';
				$query = $db->query("SELECT uid FROM {$tablepre}moderators WHERE uid IN ($deleteuids)");
				while($mod = $db->fetch_array($query)) {
					$excludeuids .= ','.$mod['uid'];
				}

				$usergroups = array();
				$query = $db->query("SELECT groupid, type, radminid, creditshigher, creditslower FROM {$tablepre}usergroups");
				while($group = $db->fetch_array($query)) {
					$usergroups[$group['groupid']] = $group;
				}

				$query = $db->query("SELECT uid, groupid, credits FROM {$tablepre}members WHERE uid IN ($deleteuids) AND uid NOT IN ($excludeuids) AND adminid NOT IN (1,2)");
				while($member = $db->fetch_array($query)) {
					if($usergroups[$member['groupid']]['type'] == 'special' && $usergroups[$member['groupid']]['radminid'] != 3) {
						$adminidnew = -1;
						$groupidnew = $member['groupid'];
					} else {
						$adminidnew = 0;
						foreach($usergroups as $group) {
							if($group['type'] == 'member' && $member['credits'] >= $group['creditshigher'] && $member['credits'] < $group['creditslower']) {
								$groupidnew = $group['groupid'];
								break;
							}
						}
					}
					$db->query("UPDATE {$tablepre}members SET adminid='$adminidnew', groupid='$groupidnew' WHERE uid='$member[uid]'");
				}
			}

			if((bool)$forum['inheritedmod'] != (bool)$inheritedmodnew) {
				$query = $db->query("SELECT uid FROM {$tablepre}moderators WHERE fid='$fid' AND inherited='0'");
				while($mod = $db->fetch_array($query)) {
					$origmodarray[] = $mod['uid'];
					if(!$forum['inheritedmod'] && $inheritedmodnew) {
						$newmodarray[] = $mod['uid'];
					}
				}
				if($forum['inheritedmod'] && !$inheritedmodnew) {
					$db->query("DELETE FROM {$tablepre}moderators WHERE uid IN ('".implode('\',\'', $origmodarray)."') AND fid IN ('".implode('\',\'', $fidarray)."') AND inherited='1'");
				}
			}

			if($newmoderator) {
				$member = $db->fetch_first("SELECT uid FROM {$tablepre}members WHERE username='$newmoderator'");
				if(!$member) {
					cpmsg('members_edit_nonexistence', '', 'error');
				} else {
					$newmodarray[] = $member['uid'];
					$db->query("UPDATE {$tablepre}members SET groupid='3' WHERE uid='$member[uid]' AND adminid NOT IN (1,2,3,4,5,6,7,8,-1)");
					$db->query("UPDATE {$tablepre}members SET adminid='3' WHERE uid='$member[uid]' AND adminid NOT IN (1,2)");
					$db->query("REPLACE INTO {$tablepre}moderators (uid, fid, displayorder, inherited)
						VALUES ('$member[uid]', '$fid', '$newdisplayorder', '0')");
				}
			}

			foreach($newmodarray as $uid) {
				$db->query("REPLACE INTO {$tablepre}moderators (uid, fid, displayorder, inherited)
					VALUES ('$uid', '$fid', '$newdisplayorder', '0')");

				if($inheritedmodnew) {
					foreach($fidarray as $ifid) {
						$db->query("REPLACE INTO {$tablepre}moderators (uid, fid, inherited)
							VALUES ('$uid', '$ifid', '1')");
					}
				}
			}

			if($forum['type'] == 'group') {
				$inheritedmodnew = 1;
			} elseif($forum['type'] == 'sub') {
				$inheritedmodnew = 0;
			}
			$db->query("UPDATE {$tablepre}forums SET inheritedmod='$inheritedmodnew' WHERE fid='$fid'");

		}

		if(is_array($displayordernew)) {
			foreach($displayordernew as $uid => $order) {
				$db->query("UPDATE {$tablepre}moderators SET displayorder='$order' WHERE fid='$fid' AND uid='$uid'");
			}
		}

		$moderators = $tab = '';
		$query = $db->query("SELECT m.username FROM {$tablepre}members m, {$tablepre}moderators mo WHERE mo.fid='$fid' AND mo.inherited='0' AND m.uid=mo.uid ORDER BY mo.displayorder");
		while($mod = $db->fetch_array($query)) {
			$moderators .= $tab.addslashes($mod['username']);
			$tab = "\t";
		}
		$db->query("UPDATE {$tablepre}forumfields SET moderators='$moderators' WHERE fid='$fid'");

		cpmsg('forums_moderators_update_succeed', "admincp.php?action=forums&operation=moderators&fid=$fid", 'succeed');

	}

} elseif($operation == 'merge') {

	if(!submitcheck('mergesubmit') || $source == $target) {

		require_once DISCUZ_ROOT.'./include/forum.func.php';
		require_once DISCUZ_ROOT.'./forumdata/cache/cache_forums.php';
		$forumselect = "<select name=\"%s\">\n<option value=\"\">&nbsp;&nbsp;> $lang[select]</option><option value=\"\">&nbsp;</option>".str_replace('%', '%%', forumselect()).'</select>';
		shownav('forum', 'nav_forums_merge');
		showsubmenu('nav_forums_merge');
		showformheader('forums&operation=merge');
		showtableheader();
		showsetting('forums_merge_source', '', '', sprintf($forumselect, 'source'));
		showsetting('forums_merge_target', '', '', sprintf($forumselect, 'target'));
		showsubmit('mergesubmit');
		showtablefooter();
		showformfooter();

	} else {

		if($db->result_first("SELECT COUNT(*) FROM {$tablepre}forums WHERE fid IN ('$source', '$target') AND type<>'group'") != 2) {
			cpmsg('forums_nonexistence', '', 'error');
		}

		if($db->result_first("SELECT COUNT(*) FROM {$tablepre}forums WHERE fup='$source'")) {
			cpmsg('forums_merge_source_sub_notnull', '', 'error');
		}

		$db->query("UPDATE {$tablepre}threads SET fid='$target' WHERE fid='$source'");
		$db->query("UPDATE {$tablepre}posts SET fid='$target' WHERE fid='$source'");

		$sourceforum = $db->fetch_first("SELECT threads, posts FROM {$tablepre}forums WHERE fid='$source'");

		$db->query("UPDATE {$tablepre}forums SET threads=threads+$sourceforum[threads], posts=posts+$sourceforum[posts] WHERE fid='$target'");
		$db->query("DELETE FROM {$tablepre}forums WHERE fid='$source'");
		$db->query("DELETE FROM {$tablepre}forumfields WHERE fid='$source'");
		$db->query("DELETE FROM {$tablepre}moderators WHERE fid='$source'");

		$query = $db->query("SELECT * FROM {$tablepre}access WHERE fid='$source'");
		while($access = $db->fetch_array($query)) {
			$db->query("INSERT INTO {$tablepre}access (uid, fid, allowview, allowpost, allowreply, allowgetattach)
				VALUES ('$access[uid]', '$target', '$access[allowview]', '$access[allowpost]', '$access[allowreply]', '$access[allowgetattach]')", 'SILENT');
		}
		$db->query("DELETE FROM {$tablepre}access WHERE fid='$source'");

		updatecache('forums');

		cpmsg('forums_merge_succeed', 'admincp.php?action=forums', 'succeed');
	}

} elseif($operation == 'edit') {

	$perms = array('viewperm', 'postperm', 'replyperm', 'getattachperm', 'postattachperm');

	$forum = $db->fetch_first("SELECT *, f.fid AS fid FROM {$tablepre}forums f
		LEFT JOIN {$tablepre}forumfields ff USING (fid)
		WHERE f.fid='$fid'");

	if(!$forum) {
		cpmsg('forums_nonexistence', '', 'error');
	}

	$query = $db->query("SELECT disabledactions FROM {$tablepre}adminactions WHERE admingid='$groupid'");
	$dactionarray = ($dactionarray = unserialize($db->result($query, 0))) ? $dactionarray : array();
	$allowthreadtypes = !in_array('threadtypes', $dactionarray);

	if(!empty($projectid)) {
		$query = $db->query("SELECT value FROM {$tablepre}projects WHERE id='$projectid'");
		$forum = @array_merge($forum, unserialize($db->result($query, 0)));
	}

	if(!submitcheck('detailsubmit') && !submitcheck('saveconfigsubmit')) {
		$anchor = in_array($anchor, array('basic', 'extend', 'posts', 'credits', 'threadtypes', 'perm')) ? $anchor : 'basic';
		shownav('forum', 'nav_forums_edit');
		if($forum['type'] == 'group') {
			showsubmenu("$lang[forums_cat_detail] - $forum[name]");
		} else {
			showsubmenuanchors(lang('nav_forums_edit').' - '.$forum['name'], array(
				array('forums_edit_basic', 'basic', $anchor == 'basic'),
				array('forums_edit_extend', 'extend', $anchor == 'extend'),
				array('forums_edit_posts', 'posts', $anchor == 'posts'),
				array('forums_edit_credits', 'credits', $anchor == 'credits'),
				array('forums_edit_threadtypes', 'threadtypes', $anchor == 'threadtypes'),
				array('forums_edit_perm', 'perm', $anchor == 'perm')
			));
		}
		showtips('forums_edit_tips');
		showformheader("forums&operation=edit&fid=$fid&");
		showhiddenfields(array('type' => $forum['type']));

		if($forum['type'] == 'group') {

			showtableheader();
			showsetting('forums_cat_name', 'namenew', $forum['name'], 'text');
			showsetting('forums_sub_horizontal', 'forumcolumnsnew', $forum['forumcolumns'], 'text');
			showsubmit('detailsubmit');
			showtablefooter();

		} else {

			require_once DISCUZ_ROOT.'./include/editor.func.php';

			$projectselect = "<select name=\"projectid\" onchange=\"window.location='admincp.php?action=forums&operation=edit&fid=$fid&projectid='+this.options[this.options.selectedIndex].value\"><option value=\"0\" selected=\"selected\">".$lang['none']."</option>";
			$query = $db->query("SELECT id, name FROM {$tablepre}projects WHERE type='forum'");
			while($project = $db->fetch_array($query)) {
				$projectselect .= "<option value=\"$project[id]\" ".($project['id'] == $projectid ? 'selected="selected"' : NULL).">$project[name]</option>\n";
			}
			$projectselect .= '</select>';

			$fupselect = "<select name=\"fupnew\">\n";
			$query = $db->query("SELECT fid, type, name, fup FROM {$tablepre}forums WHERE fid<>'$fid' AND type<>'sub' ORDER BY displayorder");
			while($fup = $db->fetch_array($query)) {
				$fups[] = $fup;
			}
			if(is_array($fups)) {
				foreach($fups as $forum1) {
					if($forum1['type'] == 'group') {
						$selected = $forum1['fid'] == $forum['fup'] ? "selected=\"selected\"" : NULL;
						$fupselect .= "<option value=\"$forum1[fid]\" $selected>$forum1[name]</option>\n";
						foreach($fups as $forum2) {
							if($forum2['type'] == 'forum' && $forum2['fup'] == $forum1['fid']) {
								$selected = $forum2['fid'] == $forum['fup'] ? "selected=\"selected\"" : NULL;
								$fupselect .= "<option value=\"$forum2[fid]\" $selected>&nbsp; &gt; $forum2[name]</option>\n";
							}
						}
					}
				}
				foreach($fups as $forum0) {
					if($forum0['type'] == 'forum' && $forum0['fup'] == 0) {
						$selected = $forum0['fid'] == $forum['fup'] ? "selected=\"selected\"" : NULL;
						$fupselect .= "<option value=\"$forum0[fid]\" $selected>$forum0[name]</option>\n";
					}
				}
			}
			$fupselect .= '</select>';

			$groups = array();
			$query = $db->query("SELECT groupid, grouptitle FROM {$tablepre}usergroups");
			while($group = $db->fetch_array($query)) {
				$groups[] = $group;
			}

			$styleselect = "<select name=\"styleidnew\"><option value=\"0\">$lang[use_default]</option>";
			$query = $db->query("SELECT styleid, name FROM {$tablepre}styles");
			while($style = $db->fetch_array($query)) {
				$styleselect .= "<option value=\"$style[styleid]\" ".
					($style['styleid'] == $forum['styleid'] ? 'selected="selected"' : NULL).
					">$style[name]</option>\n";
			}
			$styleselect .= '</select>';

			if($forum['autoclose']) {
				$forum['autoclosetime'] = abs($forum['autoclose']);
				$forum['autoclose'] = $forum['autoclose'] / abs($forum['autoclose']);
			}

			$viewaccess = $postaccess = $replyaccess = $getattachaccess = $postattachaccess = '';

			$query = $db->query("SELECT m.username, a.* FROM {$tablepre}access a LEFT JOIN {$tablepre}members m USING (uid) WHERE a.fid='$fid'");
			while($access = $db->fetch_array($query)) {
				$member = ", <a href=\"admincp.php?action=access&uid=$access[uid]\" target=\"_blank\">$access[username]</a>";
				$viewaccess .= $access['allowview'] > 0 ? $member : NULL;
				$postaccess .= $access['allowpost'] > 0  ? $member : NULL;
				$replyaccess .= $access['allowreply'] > 0  ? $member : NULL;
				$getattachaccess .= $access['allowgetattach'] > 0  ? $member : NULL;
				$postattachaccess .= $access['allowpostattach'] > 0  ? $member : NULL;
			}
			unset($member);

                	$forum['typemodels'] = unserialize($forum['typemodels']);
			if($forum['threadtypes']) {
				$forum['threadtypes'] = unserialize($forum['threadtypes']);
				$forum['threadtypes']['status'] = 1;
			} else {
				$forum['threadtypes'] = array('status' => 0, 'required' => 0, 'listable' => 0, 'prefix' => 0, 'options' => array());
			}

			$typeselect = '';
			$typemodelid = array();

			$query = $db->query("SELECT * FROM {$tablepre}threadtypes ORDER BY displayorder");
			while($type = $db->fetch_array($query)) {
				$typemodelid[] = $type['modelid'];
				$typeselected = array();
				$enablechecked = '';
				if(isset($forum['threadtypes']['flat'][$type['typeid']])) {
					$enablechecked = ' checked="checked"';
					$typeselected[1] = ' selected="selected"';
				} elseif(isset($forum['threadtypes']['selectbox'][$type['typeid']])) {
					$enablechecked = ' checked="checked"';
					$typeselected[2] = ' selected="selected"';
				} else {
					$typeselected[1] = ' selected="selected"';
				}
				$typeselected[3] = $forum['threadtypes']['show'][$type['typeid']] ? ' checked="checked"' : '';

				$showtype = TRUE;
				if($type['special'] && !@include_once DISCUZ_ROOT.'./forumdata/cache/threadtype_'.$type['typeid'].'.php') {
					$showtype = FALSE;
				}
				$typeselect .= $showtype ? showtablerow('', array('class="td25"'), array(
					'<input type="checkbox" name="threadtypesnew[options][enable]['.$type[typeid].']" value="1" class="checkbox"'.$enablechecked.' />',
					$type['name'],
					$type['description'].($type['special'] ? '&nbsp;&nbsp;'.$lang['nav_forums_types'] : ''),
					"<select name=\"threadtypesnew[options][{$type[typeid]}]\"><option value=\"1\" $typeselected[1]>$lang[forums_threadtypes_use_cols]</option><option value=\"2\" $typeselected[2]>$lang[forums_threadtypes_use_choice]</option></select>",
					"<input class=\"checkbox\" type=\"checkbox\" name=\"threadtypesnew[options][show][{$type[typeid]}]\" value=\"3\" $typeselected[3] ".(!$type['special'] ? 'disabled' : '')." />"
				), TRUE) : '';
			}

                	$num = 0;
			$query = $db->query("SELECT * FROM {$tablepre}typemodels ORDER BY displayorder");
			$typemodelselect = '<ul class="nofloat" onmouseover="altStyle(this);">';
			while($model = $db->fetch_array($query)) {
				$num++;
       				$modelchecked = $forum['typemodels'][$model['id']] ? 'checked' : '';
				$typemodelselect .= in_array($model['id'], $typemodelid) ? "<li".($modelchecked ? ' class="checked"' : '')."><input class=\"checkbox\" type=\"checkbox\" name=\"typemodel[]\" value=\"$model[id]\" $modelchecked>$model[name]</li>" : '';
       			}
       			$typemodelselect .= '</ul>';

			$forum['postcredits'] = $forum['postcredits'] ? unserialize($forum['postcredits']) : array();
			$forum['replycredits'] = $forum['replycredits'] ? unserialize($forum['replycredits']) : array();
			$forum['digestcredits'] = $forum['digestcredits'] ? unserialize($forum['digestcredits']) : array();
			$forum['postattachcredits'] = $forum['postattachcredits'] ? unserialize($forum['postattachcredits']) : array();
			$forum['getattachcredits'] = $forum['getattachcredits'] ? unserialize($forum['getattachcredits']) : array();
			$simplebin = sprintf('%08b', $forum['simple']);
			$forum['defaultorderfield'] = bindec(substr($simplebin, 0, 2));
			$forum['defaultorder'] = ($forum['simple'] & 32) ? 1 : 0;
			$forum['subforumsindex'] = bindec(substr($simplebin, 3, 2));
			$forum['subforumsindex'] = $forum['subforumsindex'] == 0 ? -1 : ($forum['subforumsindex'] == 2 ? 0 : 1);
			$forum['simple'] = $forum['simple'] & 1;
			$forum['modrecommend'] = $forum['modrecommend'] ? unserialize($forum['modrecommend']) : '';
			$forum['formulaperm'] = unserialize($forum['formulaperm']);$forum['formulaperm'] = $forum['formulaperm'][0];

			$sideselect = array();
			$infosidestatus[0] && $sideselect[0] = '<select name="foruminfosidestatus[0]"><option value=""></option>';
			$infosidestatus[1] && $sideselect[1] = '<select name="foruminfosidestatus[1]"><option value=""></option>';
			if($sideselect) {
				$query = $db->query("SELECT variable FROM {$tablepre}request WHERE type=-2");
				while($side = $db->fetch_array($query)) {
					$infosidestatus[0] && $sideselect[0] .= "<option value=\"$side[variable]\" ".($infosidestatus['f'.$fid][0] == $side['variable'] ? 'selected="selected"' : NULL).">$side[variable]</option>\n";
					$infosidestatus[1] && $sideselect[1] .= "<option value=\"$side[variable]\" ".($infosidestatus['f'.$fid][1] == $side['variable'] ? 'selected="selected"' : NULL).">$side[variable]</option>\n";
				}
				$infosidestatus[0] && $sideselect[0] .= '</select>';
				$infosidestatus[1] && $sideselect[1] .= '</select>';
			}

			showtagheader('div', 'basic', $anchor == 'basic');
			showtableheader('forums_edit_basic', 'nobottom');
			showsetting('forums_edit_name', 'namenew', $forum['name'], 'text');
			showsetting('forums_scheme', '', '', $projectselect);
			showsetting('forums_edit_display', 'statusnew', $forum['status'], 'radio');
			showsetting('forums_edit_perm_passwd', 'passwordnew', $forum['password'], 'text');
			showsetting('forums_edit_up', '', '', $fupselect);
			showsetting('forums_edit_redirect', 'redirectnew', $forum['redirect'], 'text');
			showsetting('forums_edit_icon', 'iconnew', $forum['icon'], 'text');
			showsetting('forums_edit_description', 'descriptionnew', html2bbcode($forum['description']), 'textarea');
			showsetting('forums_edit_rules', 'rulesnew', html2bbcode($forum['rules']), 'textarea');
			showsetting('forums_edit_keyword', 'keywordsnew', $forum['keywords'], 'text');
			showtablefooter();
			showtagfooter('div');

			showtagheader('div', 'extend', $anchor == 'extend');
			showtableheader('forums_edit_extend', 'nobottom');
			showsetting('forums_edit_style', '', '', $styleselect);
			showsetting('forums_sub_horizontal', 'forumcolumnsnew', $forum['forumcolumns'], 'text');
			showsetting('forums_edit_subforumsindex', array('subforumsindexnew', array(
				array(-1, $lang['default']),
				array(1, $lang['yes']),
				array(0, $lang['no'])
			), 1), $forum['subforumsindex'], 'mradio');
			showsetting('forums_edit_simple', 'simplenew', $forum['simple'], 'radio');
			showsetting('forums_edit_defaultorderfield', array('defaultorderfieldnew', array(
					array(0, $lang['forums_edit_order_lastpost']),
					array(1, $lang['forums_edit_order_starttime']),
					array(2, $lang['forums_edit_order_replies']),
					array(3, $lang['forums_edit_order_views'])
			)), $forum['defaultorderfield'], 'mradio');
			showsetting('forums_edit_defaultorder', array('defaultordernew', array(
					array(0, $lang['forums_edit_order_desc']),
					array(1, $lang['forums_edit_order_asc'])
			)), $forum['defaultorder'], 'mradio');
			showsetting('forums_threadcache', 'threadcachesnew', $forum['threadcaches'], 'text');
			showsetting('forums_edit_edit_rules', 'alloweditrulesnew', $forum['alloweditrules'], 'radio');
			if($sideselect) {
				showsetting('forums_edit_sideselect', '', '', '
					<ul>
						<li class="clear">'.$lang['settings_sideselect_0'].'</li>
						<li class="clear">'.$sideselect[0].'</li>
						<li class="clear">'.$lang['settings_sideselect_1'].'</li>
						<li class="clear">'.$sideselect[1].'</li>
						<li class="clear">'.$lang['settings_sideselect_replies_condition'].' <input name="foruminfosidestatus[posts]" value="'.$infosidestatus['f'.$fid]['posts'].'" style="width:50px;" /> '.$lang['settings_sideselect_replies_show'].'</li>
					</ul>
				');
			}
			showsetting('forums_edit_recommend', 'modrecommendnew[open]', $forum['modrecommend']['open'], 'radio', '', 1);
			showsetting('forums_edit_recommend_sort', array('modrecommendnew[sort]', array(
				array(1, $lang['forums_edit_recommend_sort_auto']),
				array(0, $lang['forums_edit_recommend_sort_manual']),
				array(2, $lang['forums_edit_recommend_sort_mix']))), $forum['modrecommend']['sort'], 'mradio');
			showsetting('forums_edit_recommend_orderby', array('modrecommendnew[orderby]', array(
				array(0, $lang['forums_edit_recommend_orderby_dateline']),
				array(1, $lang['forums_edit_recommend_orderby_lastpost']),
				array(2, $lang['forums_edit_recommend_orderby_views']),
				array(3, $lang['forums_edit_recommend_orderby_replies']),
				array(4, $lang['forums_edit_recommend_orderby_digest']))), $forum['modrecommend']['orderby'], 'mradio');
			showsetting('forums_edit_recommend_num', 'modrecommendnew[num]', $forum['modrecommend']['num'], 'text');
			showsetting('forums_edit_recommend_maxlength', 'modrecommendnew[maxlength]', $forum['modrecommend']['maxlength'], 'text');
			showsetting('forums_edit_recommend_cachelife', 'modrecommendnew[cachelife]', $forum['modrecommend']['cachelife'], 'text');
			showsetting('forums_edit_recommend_dateline', 'modrecommendnew[dateline]', $forum['modrecommend']['dateline'], 'text');
			showtablefooter();
			showtagfooter('div');

			showtagheader('div', 'posts', $anchor == 'posts');
			showtableheader('forums_edit_posts', 'nobottom');
			showsetting('forums_edit_modposts', array('modnewpostsnew', array(
				array(0, $lang['none']),
				array(1, $lang['forums_edit_modposts_threads']),
				array(2, $lang['forums_edit_modposts_posts'])
			)), $forum['modnewposts'], 'mradio');
			showsetting('forums_edit_alloweditpost', 'alloweditpostnew', $forum['alloweditpost'], 'radio');
			showsetting('forums_edit_recyclebin', 'recyclebinnew', $forum['recyclebin'], 'radio');
			showsetting('forums_edit_html', 'allowhtmlnew', $forum['allowhtml'], 'radio');
			showsetting('forums_edit_bbcode', 'allowbbcodenew', $forum['allowbbcode'], 'radio');
			showsetting('forums_edit_imgcode', 'allowimgcodenew', $forum['allowimgcode'], 'radio');
			showsetting('forums_edit_mediacode', 'allowmediacodenew', $forum['allowmediacode'], 'radio');
			showsetting('forums_edit_smilies', 'allowsmiliesnew', $forum['allowsmilies'], 'radio');
			showsetting('forums_edit_jammer', 'jammernew', $forum['jammer'], 'radio');
			showsetting('forums_edit_anonymous', 'allowanonymousnew', $forum['allowanonymous'], 'radio');
			showsetting('forums_edit_disablewatermark', 'disablewatermarknew', $forum['disablewatermark'], 'radio');
			if($tagstatus == 1) {
				showsetting('forums_edit_tagstatus', array('allowtagnew', array(
					array(0, $lang['settings_tagstatus_none']),
					array(1, $lang['settings_tagstatus_use']),
					array(2, $lang['settings_tagstatus_quired'])
				)), $forum['allowtag'], 'mradio');
			}
			showsetting('forums_edit_allowpostspecial', array('allowpostspecialnew', array(
				$lang['thread_poll'],
				$lang['thread_trade'],
				$lang['thread_reward'],
				$lang['thread_activity'],
				$lang['thread_debate'],
				$lang['thread_video']
			)), $forum['allowpostspecial'], 'binmcheckbox');
			showsetting('forums_edit_allowspecialonly', 'allowspecialonlynew', $forum['allowspecialonly'], 'radio');
			if(!empty($tradetypes) && is_array($tradetypes)) {
				$forum['tradetypes'] = $forum['tradetypes'] == '' ? -1 : unserialize($forum['tradetypes']);
				$tradetypeselect = '';
				foreach($tradetypes as $typeid => $typename) {
					$tradetypeselect .= '<input class="checkbox" type="checkbox" name="tradetypesnew[]" value="'.$typeid.'" '.($forum['tradetypes'] == -1 || @in_array($typeid, $forum['tradetypes']) ? 'checked' : '').'> '.$typename.'<br />';
				}
				showsetting('forums_edit_trade_type', '', '', $tradetypeselect);
			}
			showsetting('forums_edit_autoclose', array('autoclosenew', array(
				array(0, $lang['forums_edit_autoclose_none'], array('autoclose_time' => 'none')),
				array(1, $lang['forums_edit_autoclose_dateline'], array('autoclose_time' => '')),
				array(-1, $lang['forums_edit_autoclose_lastpost'], array('autoclose_time' => ''))
			)), $forum['autoclose'], 'mradio');
			showtagheader('tbody', 'autoclose_time', $forum['autoclose'], 'sub');
			showsetting('forums_edit_autoclose_time', 'autoclosetimenew', $forum['autoclosetime'], 'text');
			showtagfooter('tbody');
			showsetting('forums_edit_attach_ext', 'attachextensionsnew', $forum['attachextensions'], 'text');
			showtablefooter();
			showtagfooter('div');


			showtagheader('div', 'credits', $anchor == 'credits');
			showtableheader('forums_edit_credits', 'nobottom');
			echo '<tr ><td>'.$lang['credits_id'].'</td><td>'.$lang['credits_title'].'</td><td>'.$lang['forums_edit_postcredits_add'].'</td><td>'.$lang['forums_edit_replycredits_add'].'</td><td>'.$lang['settings_credits_policy_digest'].'</td><td>'.$lang['settings_credits_policy_postattach'].'</td><td>'.$lang['settings_credits_policy_getattach'].'</td></tr>';
			$customcreditspolicy = '';
			if(is_array($extcredits)) {
				foreach($extcredits as $i => $extcredit) {
					$customcreditspolicy .= showtablerow('', '', array(
        					"extcredits$i",
        					$extcredit['title'],
        					"<input type=\"text\" class=\"txt\" size=\"2\" name=\"postcreditsnew[$i]\" value=\"".$forum['postcredits'][$i]."\" />",
        					"<input type=\"text\" class=\"txt\" size=\"2\" name=\"replycreditsnew[$i]\" value=\"".$forum['replycredits'][$i]."\" />",
        					"<input type=\"text\" class=\"txt\" size=\"2\" name=\"digestcreditsnew[$i]\" value=\"".$forum['digestcredits'][$i]."\" />",
        					"<input type=\"text\" class=\"txt\" size=\"2\" name=\"postattachcreditsnew[$i]\" value=\"".$forum['postattachcredits'][$i]."\" />",
        					"<input type=\"text\" class=\"txt\" size=\"2\" name=\"getattachcreditsnew[$i]\" value=\"".$forum['getattachcredits'][$i]."\" />"
        				), TRUE);
				}
			}
			$customcreditspolicy .= '<tr><td colspan="7">'.$lang['forums_edit_credits_comment'].'</td></tr>';
			echo $customcreditspolicy;
			showtablefooter();
			showtagfooter('div');

			if($allowthreadtypes) {
				echo <<<EOT
<script type="text/JavaScript">
	var rowtypedata = [
		[
			[1,'<input type="checkbox" class="checkbox" name="newenable[]" checked="checked" />', 'td25'],
			[1,'<input type="text" class="txt" name="newname[]" size="15" />'],
			[1,'<input type="text" class="txt" name="newdescription[]" size="15" />'],
			[1,'<select name="newoptions[]"><option value="1" selected="selected">$lang[forums_threadtypes_use_cols]</option><option value="2">$lang[forums_threadtypes_use_choice]</option></select>'],
			[1,'']
		],
	];
</script>
EOT;
				showtagheader('div', 'threadtypes', $anchor == 'threadtypes');

				showtableheader('forums_edit_threadtypes', 'nobottom');
				showsetting('forums_edit_threadtypes_status', array('threadtypesnew[status]', array(
					array(1, $lang['yes'], array('threadtypes_config' => '', 'threadtypes_manage' => '')),
					array(0, $lang['no'], array('threadtypes_config' => 'none', 'threadtypes_manage' => 'none'))
				), TRUE), $forum['threadtypes']['status'], 'mradio');
				showtagheader('tbody', 'threadtypes_config', $forum['threadtypes']['status']);
				showsetting('forums_edit_threadtypes_required', 'threadtypesnew[required]', $forum['threadtypes']['required'], 'radio');
				showsetting('forums_edit_threadtypes_listable', 'threadtypesnew[listable]', $forum['threadtypes']['listable'], 'radio');
				showsetting('forums_edit_threadtypes_prefix', 'threadtypesnew[prefix]', $forum['threadtypes']['prefix'], 'radio');
				showsetting('forums_edit_threadtypes_typemodel', '', '', $typemodelselect);
				showtagfooter('tbody');
				showtablefooter();

				showtagheader('div', 'threadtypes_manage', $forum['threadtypes']['status']);
				showtableheader('forums_threadtypes', 'noborder fixpadding');
				showsubtitle(array('enable', 'forums_edit_cat_name', 'forums_sort_note', 'forums_threadtypes_showtype', 'forums_threadtypes_show'));
				echo $typeselect;
				echo '<tr><td colspan="6"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('threadtype_infotypes_add').'</a></div></td></tr>';
				echo '<tr><td class="lineheight" colspan="6">'.$lang['forums_edit_threadtypes_comment'].'</td></tr>';
				showtablefooter();
				showtagfooter('div');

				showtagfooter('div');
			}

			showtagheader('div', 'perm', $anchor == 'perm');
			showtableheader('forums_edit_forumperm', 'nobottom fixpadding');
			showsubtitle(array(
				'',
				'<input class="checkbox" type="checkbox" name="chkall1" onclick="checkAll(\'prefix\', this.form, \'viewperm\', \'chkall1\')" id="chkall1" /><label for="chkall1"> '.$lang['forums_edit_perm_view'].'</label>',
				'<input class="checkbox" type="checkbox" name="chkall2" onclick="checkAll(\'prefix\', this.form, \'postperm\', \'chkall2\')" id="chkall2" /><label for="chkall2"> '.$lang['forums_edit_perm_post'].'</label>',
				'<input class="checkbox" type="checkbox" name="chkall3" onclick="checkAll(\'prefix\', this.form, \'replyperm\', \'chkall3\')" id="chkall3" /><label for="chkall3"> '.$lang['forums_edit_perm_reply'].'</label>',
				'<input class="checkbox" type="checkbox" name="chkall4" onclick="checkAll(\'prefix\', this.form, \'getattachperm\', \'chkall4\')" id="chkall4" /><label for="chkall4"> '.$lang['forums_edit_perm_getattach'].'</label>',
				'<input class="checkbox" type="checkbox" name="chkall5" onclick="checkAll(\'prefix\', this.form, \'postattachperm\', \'chkall5\')" id="chkall5" /><label for="chkall5"> '.$lang['forums_edit_perm_postattach'].'</label>'

			));

			foreach($groups as $group) {
				$colums = array('<input class="checkbox" title="'.$lang['select_all'].'" type="checkbox" name="chkallv'.$group['groupid'].'" onclick="checkAll(\'value\', this.form, '.$group['groupid'].', \'chkallv'.$group['groupid'].'\')" id="chkallv_'.$group['groupid'].'" /><label for="chkallv_'.$group['groupid'].'"> '.$group[grouptitle].'</label>');
				foreach($perms as $perm) {
					$checked = strstr($forum[$perm], "\t$group[groupid]\t") ? 'checked="checked"' : NULL;
					$colums[] = '<input class="checkbox" type="checkbox" name="'.$perm.'[]" value="'.$group['groupid'].'" '.$checked.'>';
				}
				showtablerow('', '', $colums);
			}
			showtablerow('', 'class="lineheight" colspan="6"', $lang['forums_edit_forumperm_comment']);
			showtablefooter();

			showtableheader('forums_edit_access_mask', 'noborder fixpadding');
			showtablerow('', 'colspan="5"', array(lang('forums_edit_perm_view'), substr($viewaccess, 2)));
			showtablerow('', 'colspan="5"', array(lang('forums_edit_perm_post'), substr($postaccess, 2)));
			showtablerow('', 'colspan="5"', array(lang('forums_edit_perm_reply'), substr($replyaccess, 2)));
			showtablerow('', 'colspan="5"', array(lang('forums_edit_perm_getattach'), substr($getattachaccess, 2)));
			showtablerow('', 'colspan="5"', array(lang('forums_edit_perm_postattach'), substr($postattachaccess, 2)));
			showtablefooter();

			showtableheader('settings_formulaperm', 'noborder fixpadding');
			$formulareplace .= '\'<u>'.$lang['settings_creditsformula_digestposts'].'</u>\',\'<u>'.$lang['settings_creditsformula_posts'].'</u>\',\'<u>'.$lang['settings_creditsformula_oltime'].'</u>\',\'<u>'.$lang['settings_creditsformula_pageviews'].'</u>\'';

?>
<script type="text/JavaScript">

	function isUndefined(variable) {
		return typeof variable == 'undefined' ? true : false;
	}

	function insertunit(text, textend) {
		$('formulapermnew').focus();
		textend = isUndefined(textend) ? '' : textend;
		if(!isUndefined($('formulapermnew').selectionStart)) {
			var opn = $('formulapermnew').selectionStart + 0;
			if(textend != '') {
				text = text + $('formulapermnew').value.substring($('formulapermnew').selectionStart, $('formulapermnew').selectionEnd) + textend;
			}
			$('formulapermnew').value = $('formulapermnew').value.substr(0, $('formulapermnew').selectionStart) + text + $('formulapermnew').value.substr($('formulapermnew').selectionEnd);
		} else if(document.selection && document.selection.createRange) {
			var sel = document.selection.createRange();
			if(textend != '') {
				text = text + sel.text + textend;
			}
			sel.text = text.replace(/\r?\n/g, '\r\n');
			sel.moveStart('character', -strlen(text));
		} else {
			$('formulapermnew').value += text;
		}
		formulaexp();
	}

	var formulafind = new Array('digestposts', 'posts', 'oltime', 'pageviews');
	var formulareplace = new Array(<?php echo $formulareplace?>);
	function formulaexp() {
		var result = $('formulapermnew').value;
<?php

	$extcreditsbtn = '';
	for($i = 1; $i <= 8; $i++) {
		$extcredittitle = $extcredits[$i]['title'] ? $extcredits[$i]['title'] : $lang['settings_creditsformula_extcredits'].$i;
		echo 'result = result.replace(/extcredits'.$i.'/g, \'<u>'.$extcredittitle.'</u>\');';
		$extcreditsbtn .= '<a href="###" onclick="insertunit(\'extcredits'.$i.'\')">'.$extcredittitle.'</a> &nbsp;';
	}

	echo 'result = result.replace(/digestposts/g, \'<u>'.$lang['settings_creditsformula_digestposts'].'</u>\');';
	echo 'result = result.replace(/posts/g, \'<u>'.$lang['settings_creditsformula_posts'].'</u>\');';
	echo 'result = result.replace(/oltime/g, \'<u>'.$lang['settings_creditsformula_oltime'].'</u>\');';
	echo 'result = result.replace(/pageviews/g, \'<u>'.$lang['settings_creditsformula_pageviews'].'</u>\');';
	echo 'result = result.replace(/and/g, \'&nbsp;&nbsp;'.$lang['settings_formulaperm_and'].'&nbsp;&nbsp;\');';
	echo 'result = result.replace(/or/g, \'&nbsp;&nbsp;'.$lang['settings_formulaperm_or'].'&nbsp;&nbsp;\');';
	echo 'result = result.replace(/>=/g, \'&ge;\');';
	echo 'result = result.replace(/<=/g, \'&le;\');';

?>
		$('formulapermexp').innerHTML = result;
	}
</script>
<tr><td colspan="2"><div class="extcredits">
<?php echo $extcreditsbtn?><br />
<a href="###" onclick="insertunit(' digestposts ')"><?php echo lang('settings_creditsformula_digestposts')?></a>&nbsp;
<a href="###" onclick="insertunit(' posts ')"><?php echo lang('settings_creditsformula_posts')?></a>&nbsp;
<a href="###" onclick="insertunit(' oltime ')"><?php echo lang('settings_creditsformula_oltime')?></a>&nbsp;
<a href="###" onclick="insertunit(' pageviews ')"><?php echo lang('settings_creditsformula_pageviews')?></a>&nbsp;
<a href="###" onclick="insertunit(' + ')">&nbsp;+&nbsp;</a>&nbsp;
<a href="###" onclick="insertunit(' - ')">&nbsp;-&nbsp;</a>&nbsp;
<a href="###" onclick="insertunit(' * ')">&nbsp;*&nbsp;</a>&nbsp;
<a href="###" onclick="insertunit(' / ')">&nbsp;/&nbsp;</a>&nbsp;
<a href="###" onclick="insertunit(' > ')">&nbsp;>&nbsp;</a>&nbsp;
<a href="###" onclick="insertunit(' >= ')">&nbsp;>=&nbsp;</a>&nbsp;
<a href="###" onclick="insertunit(' < ')">&nbsp;<&nbsp;</a>&nbsp;
<a href="###" onclick="insertunit(' <= ')">&nbsp;<=&nbsp;</a>&nbsp;
<a href="###" onclick="insertunit(' = ')">&nbsp;=&nbsp;</a>&nbsp;
<a href="###" onclick="insertunit(' (', ') ')">&nbsp;(&nbsp;)&nbsp;</a>&nbsp;
<a href="###" onclick="insertunit(' and ')">&nbsp;<?php echo lang('settings_formulaperm_and')?>&nbsp;</a>&nbsp;
<a href="###" onclick="insertunit(' or ')">&nbsp;<?php echo lang('settings_formulaperm_or')?>&nbsp;</a>&nbsp;<br />
<div id="formulapermexp" class="margintop marginbot diffcolor2"><?php echo $formulapermexp?></div>
</div>
<textarea name="formulapermnew" id="formulapermnew" class="marginbot" style="width:80%" rows="3" onkeyup="formulaexp()"><?php echo dhtmlspecialchars($forum['formulaperm'])?></textarea>
<script type="text/JavaScript">formulaexp()</script>
<br /><span class="smalltxt"><?=$lang['settings_formulaperm_comment']?></span>
<br /><?php echo lang('creditwizard_current_formula_notice')?>
</td></tr>
<?php

			showtablefooter();
			showtagfooter('div');

			showtableheader('', 'notop');
			showsubmit('detailsubmit', 'submit', '', $forum['type'] != 'group' ? '<input type="submit" class="btn" name="saveconfigsubmit" value="'.$lang['saveconf'].'">' : '');
			showtablefooter();

		}

	showformfooter();

	} else {

		if(strlen($namenew) > 50) {
			cpmsg('forums_name_toolong', '', 'error');
		}

		if($formulapermnew && !preg_match("/^(\+|\-|\*|\/|\.|>|<|=|\d|\s|extcredits[1-8]|digestposts|posts|pageviews|oltime|and|or)+$/", $formulapermnew) || !is_null(@eval(preg_replace("/(digestposts|posts|pageviews|oltime|extcredits[1-8])/", "\$\\1", $formulapermnew).';'))) {
			cpmsg('forums_formulaperm_error', '', 'error');
		}

		$formulapermary[0] = $formulapermnew;
		$formulapermary[1] = preg_replace("/(digestposts|posts|pageviews|oltime|extcredits[1-8])/", "\$_DSESSION['\\1']", $formulapermnew);
		$formulapermnew = addslashes(serialize($formulapermary));

		if($type == 'group') {

			if($namenew) {
				$db->query("UPDATE {$tablepre}forums SET name='$namenew',forumcolumns='".intval($forumcolumnsnew)."' WHERE fid='$fid'");
				updatecache('forums');

				cpmsg('forums_edit_succeed', 'admincp.php?action=forums', 'succeed');
			} else {
				cpmsg('forums_edit_name_invalid', '', 'error');
			}

		} else {

			require_once DISCUZ_ROOT.'./include/discuzcode.func.php';

			$extensionarray = array();
			foreach(explode(',', $attachextensionsnew) as $extension) {
				if($extension = trim($extension)) {
					$extensionarray[] = $extension;
				}
			}
			$attachextensionsnew = implode(', ', $extensionarray);

			foreach($perms as $perm) {
				${$perm.'new'} = is_array($$perm) && !empty($$perm) ? "\t".implode("\t", $$perm)."\t" : '';
			}

			$fupadd = '';
			if($fupnew != $forum['fup']) {
				$query = $db->query("SELECT fid FROM {$tablepre}forums WHERE fup='$fid'");
				if($db->num_rows($query)) {
					cpmsg('forums_edit_sub_notnull', '', 'error');
				}

				$fup = $db->fetch_first("SELECT fid, type, inheritedmod FROM {$tablepre}forums WHERE fid='$fupnew'");

				$fupadd = ", type='".($fup['type'] == 'forum' ? 'sub' : 'forum')."', fup='$fup[fid]'";
				$db->query("DELETE FROM {$tablepre}moderators WHERE fid='$fid' AND inherited='1'");
				$query = $db->query("SELECT * FROM {$tablepre}moderators WHERE fid='$fupnew' ".($fup['inheritedmod'] ? '' : "AND inherited='1'"));
				while($mod = $db->fetch_array($query)) {
					$db->query("REPLACE INTO {$tablepre}moderators (uid, fid, displayorder, inherited)
						VALUES ('$mod[uid]', '$fid', '0', '1')");
				}

				$moderators = $tab = '';
				$query = $db->query("SELECT m.username FROM {$tablepre}members m, {$tablepre}moderators mo WHERE mo.fid='$fid' AND mo.inherited='0' AND m.uid=mo.uid ORDER BY mo.displayorder");
				while($mod = $db->fetch_array($query)) {
					$moderators .= $tab.addslashes($mod['username']);
					$tab = "\t";
				}
				$db->query("UPDATE {$tablepre}forumfields SET moderators='$moderators' WHERE fid='$fid'");
			}

			$allowpostspecialtrade = intval($allowpostspecialnew[2]);
			$allowpostspecialnew = bindec(intval($allowpostspecialnew[6]).intval($allowpostspecialnew[5]).intval($allowpostspecialnew[4]).intval($allowpostspecialnew[3]).intval($allowpostspecialnew[2]).intval($allowpostspecialnew[1]));
			$allowspecialonlynew = $allowpostspecialnew ? $allowspecialonlynew : 0;
			$forumcolumnsnew = intval($forumcolumnsnew);
			$threadcachesnew = max(0, min(100, intval($threadcachesnew)));
			$subforumsindexnew = $subforumsindexnew == -1 ? 0 : ($subforumsindexnew == 0 ? 2 : 1);
			$simplenew = bindec(sprintf('%02d', decbin($defaultorderfieldnew)).$defaultordernew.sprintf('%02d', decbin($subforumsindexnew)).'00'.$simplenew);

			$db->query("UPDATE {$tablepre}forums SET status='$statusnew', name='$namenew', styleid='$styleidnew', alloweditpost='$alloweditpostnew',
				allowpostspecial='$allowpostspecialnew', allowspecialonly='$allowspecialonlynew', allowhtml='$allowhtmlnew', allowbbcode='$allowbbcodenew', allowimgcode='$allowimgcodenew', allowmediacode='$allowmediacodenew',
				allowsmilies='$allowsmiliesnew', alloweditrules='$alloweditrulesnew', modnewposts='$modnewpostsnew',
				recyclebin='$recyclebinnew', jammer='$jammernew', allowanonymous='$allowanonymousnew', forumcolumns='$forumcolumnsnew', threadcaches='$threadcachesnew',
				simple='$simplenew', disablewatermark='$disablewatermarknew', allowtag='$allowtagnew', autoclose='".intval($autoclosenew * $autoclosetimenew)."' $fupadd
				WHERE fid='$fid'");

			$query = $db->query("SELECT fid FROM {$tablepre}forumfields WHERE fid='$fid'");
			if(!($db->num_rows($query))) {
				$db->query("INSERT INTO {$tablepre}forumfields (fid)
					VALUES ('$fid')");
			}

			foreach(array('post', 'reply', 'digest', 'postattach', 'getattach') as $item) {
				if(${$item.'creditsnew'}) {
					foreach(${$item.'creditsnew'} as $i => $v) {
						if($v == '') {
							unset(${$item.'creditsnew'}[$i]);
						} else {
							$v = intval($v);
							${$item.'creditsnew'}[$i]  = $v < -99 ? -99 : $v;
							${$item.'creditsnew'}[$i]  = $v > 99 ? 99 : $v;
						}
					}
				}
				${$item.'creditsnew'} = ${$item.'creditsnew'} ? addslashes(serialize(${$item.'creditsnew'})) : '';
			}

			$threadtypesnew['types'] = $threadtypesnew['flat'] = $threadtypes['selectbox'] = $threadtypes['special'] = $threadtypes['show'] = array();

			if($allowthreadtypes) {
				if(is_array($newname) && $newname) {
					$newname = array_unique($newname);
					if($newname) {
						foreach($newname as $key => $val) {
							$val = trim($val);
							if($newenable[$key] && $val) {
								$newtypeid = $db->result_first("SELECT typeid FROM {$tablepre}threadtypes WHERE name='$val'");
								if(!$newtypeid) {
									$db->query("INSERT INTO	{$tablepre}threadtypes (name, description) VALUES
										('$val', '".dhtmlspecialchars(trim($newdescription[$key]))."')");
									$newtypeid = $db->insert_id();
								}
								if($newoptions[$key] == 1) {
									$threadtypesnew['types'][$newtypeid] = $threadtypesnew['flat'][$newtypeid] = $val;
								} elseif($newoptions[$key] == 2) {
									$threadtypesnew['types'][$newtypeid] = $threadtypesnew['selectbox'][$newtypeid] = $val;
								}
							}
						}
					}
					$threadtypesnew['status'] = 1;
				} else {
					$newname = array();
				}
				if($threadtypesnew['status']) {
					if(is_array($threadtypesnew['options']) && $threadtypesnew['options']) {

						$typeids = '0';
						foreach($threadtypesnew['options'] as $key => $val) {
							$typeids .= $val ? ', '.intval($key) : '';
						}

						$query = $db->query("SELECT * FROM {$tablepre}threadtypes WHERE typeid IN ($typeids) ORDER BY displayorder");
						while($type = $db->fetch_array($query)) {
							if($threadtypesnew['options']['enable'][$type['typeid']]) {
								if($threadtypesnew['options'][$type['typeid']] == 1) {
									$threadtypesnew['types'][$type['typeid']] = $threadtypesnew['flat'][$type['typeid']] = $type['name'];
								} elseif($threadtypesnew['options'][$type['typeid']] == 2) {
									$threadtypesnew['types'][$type['typeid']] = $threadtypesnew['selectbox'][$type['typeid']] = $type['name'];
								}
							}
							$threadtypesnew['special'][$type['typeid']] = $type['special'];
							$threadtypesnew['expiration'][$type['typeid']] = $type['expiration'];
							$threadtypesnew['show'][$type['typeid']] = $threadtypesnew['options']['show'][$type['typeid']] ? 1 : 0;
							$threadtypesnew['typemodelid'][$type['typeid']] = $type['modelid'];
						}
					}
					$threadtypesnew = $threadtypesnew['types'] ? addslashes(serialize(array
						(
						'required' => (bool)$threadtypesnew['required'],
						'listable' => (bool)$threadtypesnew['listable'],
						'prefix' => (bool)$threadtypesnew['prefix'],
						'types' => $threadtypesnew['types'],
						'selectbox' => $threadtypesnew['selectbox'],
						'flat' => $threadtypesnew['flat'],
						'special' => $threadtypesnew['special'],
						'show' => $threadtypesnew['show'],
						'expiration' => $threadtypesnew['expiration'],
						'modelid' => $threadtypesnew['typemodelid'],
						))) : '';
				} else {
					$threadtypesnew = '';
				}
				$threadtypesadd = "threadtypes='$threadtypesnew',";

				if($typemodel) {
					$query = $db->query("SELECT id, name FROM {$tablepre}typemodels WHERE id IN (".implodeids($typemodel).") ORDER BY displayorder");
					while($model = $db->fetch_array($query)) {
						$threadtypemodel[$model['id']]['name'] = $model['name'];
					}
					$threadtypemodeladd = addslashes(serialize($threadtypemodel));
				}

			} else {
				$threadtypesadd = $threadtypemodeladd = '';
			}

			if(!empty($tradetypes) && is_array($tradetypes) && $allowpostspecialtrade) {
				if(count($tradetypes) == count($tradetypesnew)) {
					$tradetypesnew = '';
				} else {
					$tradetypesnew = addslashes(serialize($tradetypesnew));
				}
			} else {
				$tradetypesnew = '';
			}

			$modrecommendnew['num'] = $modrecommendnew['num'] ? intval($modrecommendnew['num']) : 10;
			$modrecommendnew['cachelife'] = $modrecommendnew['cachelife'] ? intval($modrecommendnew['cachelife']) : 900;
			$modrecommendnew['maxlength'] = $modrecommendnew['maxlength'] ? intval($modrecommendnew['maxlength']) : 0;
			$modrecommendnew['dateline'] = $modrecommendnew['dateline'] ? intval($modrecommendnew['dateline']) : 0;
			$modrecommendnew = $modrecommendnew && is_array($modrecommendnew) ? addslashes(serialize($modrecommendnew)) : '';
			$descriptionnew = addslashes(discuzcode(stripslashes($descriptionnew), 1, 0, 0, 0, 1, 1, 0, 0, 1));
			$rulesnew = addslashes(discuzcode(stripslashes($rulesnew), 1, 0, 0, 0, 1, 1, 0, 0, 1));
			$db->query("UPDATE {$tablepre}forumfields SET description='$descriptionnew', icon='$iconnew', password='$passwordnew', redirect='$redirectnew', rules='$rulesnew',
				attachextensions='$attachextensionsnew', $threadtypesadd postcredits='$postcreditsnew', replycredits='$replycreditsnew', digestcredits='$digestcreditsnew',
				postattachcredits='$postattachcreditsnew', getattachcredits='$getattachcreditsnew', viewperm='$viewpermnew', postperm='$postpermnew', replyperm='$replypermnew', tradetypes='$tradetypesnew', typemodels='$threadtypemodeladd',
				getattachperm='$getattachpermnew', postattachperm='$postattachpermnew', formulaperm='$formulapermnew', modrecommend='$modrecommendnew', keywords='$keywordsnew' WHERE fid='$fid'");

			if($modrecommendnew && !$modrecommendnew['sort']) {
				require_once DISCUZ_ROOT.'./include/forum.func.php';
				recommendupdate($fid, $modrecommendnew, '1');
			}

			if($statusnew == 0) {
				$db->query("UPDATE {$tablepre}forums SET status='$statusnew' WHERE fup='$fid'", 'UNBUFFERED');
			}

			updatecache('forums');

			if($foruminfosidestatus) {
				$infosidestatusnew = $infosidestatus;
				unset($infosidestatusnew['f'.$fid]);
				$foruminfosidestatus[0] != $infosidestatus[0] && $foruminfosidestatus[0] != '' && $infosidestatusnew['f'.$fid][0] = $foruminfosidestatus[0];
				$foruminfosidestatus[1] != $infosidestatus[1] && $foruminfosidestatus[1] != '' && $infosidestatusnew['f'.$fid][1] = $foruminfosidestatus[1];
				$foruminfosidestatus['posts'] != $infosidestatus['posts'] && $foruminfosidestatus['posts'] != '' && $infosidestatusnew['f'.$fid]['posts'] = $foruminfosidestatus['posts'];
				if($infosidestatus != $infosidestatusnew) {
					$db->query("REPLACE INTO {$tablepre}settings (variable, value) VALUES ('infosidestatus', '".(addslashes(serialize($infosidestatusnew)))."')");
					updatecache('settings');
				}
			}

			if(submitcheck('saveconfigsubmit') && $type != 'group') {
				$projectid = intval($projectid);
				dheader("Location: {$boardurl}admincp.php?action=project&operation=add&id=$fid&type=forum&projectid=$projectid");
			} else {
				cpmsg('forums_edit_succeed', "admincp.php?action=forums&operation=edit&fid=$fid".($anchor ? "&anchor=$anchor" : ''), 'succeed');
			}
		}

	}

} elseif($operation == 'delete') {

	if($ajax) {
		ob_end_clean();
		require_once DISCUZ_ROOT.'./include/post.func.php';
		$tids = 0;

		$total = intval($total);
		$pp = intval($pp);
		$currow = intval($currow);

		$query = $db->query("SELECT tid FROM {$tablepre}threads WHERE fid='$fid' LIMIT $pp");
		while($thread = $db->fetch_array($query)) {
			$tids .= ','.$thread['tid'];
		}

		if($tids) {
			$query = $db->query("SELECT attachment, thumb, remote FROM {$tablepre}attachments WHERE tid IN ($tids)");
			while($attach = $db->fetch_array($query)) {
				dunlink($attach['attachment'], $attach['thumb'], $attach['remote']);
			}

			foreach(array('threads', 'threadsmod', 'relatedthreads', 'posts', 'polls', 'polloptions', 'trades', 'activities', 'activityapplies', 'debates', 'debateposts', 'videos', 'attachments', 'favorites', 'mythreads', 'myposts', 'subscriptions', 'typeoptionvars', 'forumrecommend') as $value) {
				$db->query("DELETE FROM {$tablepre}$value WHERE tid IN ($tids)", 'UNBUFFERED');
			}
		}

		if($currow + $pp > $total) {
			$db->query("DELETE FROM {$tablepre}forums WHERE fid='$fid'");
			$db->query("DELETE FROM {$tablepre}forumfields WHERE fid='$fid'");
			$db->query("DELETE FROM {$tablepre}moderators WHERE fid='$fid'");
			$db->query("DELETE FROM {$tablepre}access WHERE fid='$fid'");
			echo 'TRUE';
			exit;
		}

		echo 'GO';
		exit;

	} else {

		if($finished) {
			updatecache('forums');
			cpmsg('forums_delete_succeed', 'admincp.php?action=forums', 'succeed');

		}

		if($db->result_first("SELECT COUNT(*) FROM {$tablepre}forums WHERE fup='$fid'")) {
			cpmsg('forums_delete_sub_notnull', '', 'error');
		}

		if(!$confirmed) {

			cpmsg('forums_delete_confirm', "admincp.php?action=forums&operation=delete&fid=$fid", 'form');

		} else {

			$threads = $db->result_first("SELECT COUNT(*) FROM {$tablepre}threads WHERE fid='$fid'");

			cpmsg('forums_delete_alarm', "admincp.php?action=forums&operation=delete&fid=$fid&confirmed=1", 'loadingform', '<div id="percent">0%</div>', FALSE);

			echo "
			<div id=\"statusid\" style=\"display:none\"></div>
			<script type=\"text/JavaScript\">
				var xml_http_building_link = '".$lang['xml_http_building_link']."';
				var xml_http_sending = '".$lang['xml_http_sending']."';
				var xml_http_loading = '".$lang['xml_http_loading']."';
				var xml_http_load_failed = '".$lang['xml_http_load_failed']."';
				var xml_http_data_in_processed = '".$lang['xml_http_data_in_processed']."';
				function forumsdelete(url, total, pp, currow) {

					var x = new Ajax('HTML', 'statusid');
					x.get(url+'&ajax=1&pp='+pp+'&total='+total+'&currow='+currow, function(s) {
						if(s != 'GO') {
							location.href = 'admincp.php?action=forums&operation=delete&finished=1';
						}

						currow += pp;
						var percent = ((currow / total) * 100).toFixed(0);
						percent = percent > 100 ? 100 : percent;
						document.getElementById('percent').innerHTML = percent+'%';
						document.getElementById('percent').style.backgroundPosition = '-'+percent+'%';

						if(currow < total) {
							forumsdelete(url, total, pp, currow);
						}
					});
				}
				forumsdelete('admincp.php?action=forums&operation=delete&fid=$fid&confirmed=1', $threads, 2000, 0);
			</script>
			";
		}
	}

} elseif($operation == 'copy') {

	require_once DISCUZ_ROOT.'./forumdata/cache/cache_forums.php';

	$source = intval($source);
	$sourceforum = $_DCACHE['forums'][$source];

	if(empty($sourceforum) || $sourceforum['type'] == 'group') {
		cpmsg('forums_copy_source_invalid', '', 'error');
	}

	$optgroups = array
		(
		'normal'	=> array('modnewposts', 'recyclebin', 'allowshare', 'allowhtml', 'allowbbcode', 'allowimgcode', 'allowmediacode', 'allowsmilies', 'jammer', 'allowanonymous', 'disablewatermark', 'allowpostspecial'),
		'credits'	=> array('postcredits', 'replycredits'),
		'access'	=> array('password', 'viewperm', 'postperm', 'replyperm', 'getattachperm' ,'postattachperm', 'formulaperm'),
		'misc'		=> array('threadtypes', 'attachextensions', 'modrecommend', 'tradetypes')
		);

	if(!submitcheck('copysubmit')) {

		require_once DISCUZ_ROOT.'./include/forum.func.php';

		$forumselect = '<select name="target[]" size="10" multiple="multiple">'.forumselect().'</select>';
		$optselect = '<select name="options[]" size="10" multiple="multiple">';

		foreach($optgroups as $optgroup => $options) {
			$optselect .= '<optgroup label="'.$lang['forums_copy_optgroups_'.$optgroup]."\">\n";
			foreach($options as $option) {
				$optselect .= "<option value=\"$option\">".$lang['forums_copy_options_'.$option]."</option>\n";
			}
		}
		$optselect .= '</select>';
		shownav('forum', 'forums_copy');
		showsubmenu('forums_copy');
		showtips('forums_copy_tips');
		showformheader('forums&operation=copy');
		showhiddenfields(array('source' => $source));
		showtableheader();
		showtitle($lang['forums_copy']);
		showsetting(lang('forums_copy_source').':','','', $sourceforum['name']);
		showsetting('forums_copy_target', '', '', $forumselect);
		showsetting('forums_copy_options', '', '', $optselect);
		showsubmit('copysubmit');
		showtablefooter();
		showformfooter();

	} else {

		$fids = $comma = '';
		if(is_array($target) && count($target)) {
			foreach($target as $fid) {
				if(($fid = intval($fid)) && $fid != $source ) {
					$fids .= $comma.$fid;
					$comma = ',';
				}
			}
		}
		if(empty($fids)) {
			cpmsg('forums_copy_target_invalid', '', 'error');
		}

		$forumoptions = array();
		if(is_array($options) && !empty($options)) {
			foreach($options as $option) {
				if($option = trim($option)) {
					if(in_array($option, $optgroups['normal'])) {
						$forumoptions['forums'][] = $option;
					} elseif(in_array($option, $optgroups['misc']) || in_array($option, $optgroups['credits']) || in_array($option, $optgroups['access'])) {
						$forumoptions['forumfields'][] = $option;
					}
				}
			}
		}

		if(empty($forumoptions)) {
			cpmsg('forums_copy_options_invalid', '', 'error');
		}

		foreach(array('forums', 'forumfields') as $table) {
			if(is_array($forumoptions[$table]) && !empty($forumoptions[$table])) {
				$sourceforum = $db->fetch_first("SELECT ".implode($forumoptions[$table],',')." FROM {$tablepre}$table WHERE fid='$source'");
				if(!$sourceforum) {
					cpmsg('forums_copy_source_invalid', '', 'error');
				}

				$updatequery = 'fid=fid';
				foreach($sourceforum as $key => $val) {
					$updatequery .= ", $key='".addslashes($val)."'";
				}
				$db->query("UPDATE {$tablepre}$table SET $updatequery WHERE fid IN ($fids)");
			}
		}

		updatecache('forums');
		cpmsg('forums_copy_succeed', 'admincp.php?action=forums', 'succeed');

	}

}

function showforum($key, $type = '', $last = '') {
	global $forums, $showedforums, $lang, $indexname;

	$forum = $forums[$key];
	$showedforums[] = $key;

	if($last == '') {
		$return = '<tr><td class="td25"><input type="text" class="txt" name="order['.$forum['fid'].']" value="'.$forum['displayorder'].'" /></td><td>';
		if($type == 'group') {
			$return .= '<div class="parentboard">';
		} elseif($type == '') {
			$return .= '<div class="board">';
		} elseif($type == 'sub') {
			$return .= '<div id="cb_'.$forum['fid'].'" class="childboard">';
		}
		$return .= '<input type="text" name="name['.$forum['fid'].']" value="'.htmlspecialchars($forum['name']).'" class="txt" />'.
			($type == '' ? '<a href="###" onclick="addrowdirect = 1;addrow(this, 2, '.$forum['fid'].')" class="addchildboard">'.$lang['forums_add_sub'].'</a>' : '').
			'</div><div class="boardattr">'.($forum['status'] ? '' : ' '.$lang['forums_hidden']).
			(!$forum['password'] ? '' : ' '.$lang['forums_password']).
			(!$forum['redirect'] ? '' : ' '.$lang['forums_url']).
			'</div><td>'.showforum_moderators($forum).'</td>
			<td><a href="admincp.php?action=forums&operation=edit&fid='.$forum['fid'].'" title="'.$lang['forums_edit_comment'].'" class="act">'.$lang['edit'].'</a>'.
			($type != 'group' ? '<a href="admincp.php?action=forums&operation=copy&source='.$forum['fid'].'" title="'.$lang['forums_copy_comment'].'" class="act">'.$lang['forums_copy'].'</a>' : '').
			'<a href="admincp.php?action=forums&operation=delete&fid='.$forum['fid'].'" title="'.$lang['forums_delete_comment'].'" class="act">'.$lang['delete'].'</a></td></tr>';
	} else {
		if($last == 'lastboard') {
			$return = '<tr><td></td><td colspan="3"><div class="lastboard"><a href="###" onclick="addrow(this, 1, '.$forum['fid'].')" class="addtr">'.$lang['forums_add_forum'].'</a></div></td></tr>';
		} elseif($last == 'lastchildboard' && $type) {
			$return = '<script type="text/JavaScript">$(\'cb_'.$type.'\').className = \'lastchildboard\';</script>';
		} elseif($last == 'last') {
			$return = '<tr><td></td><td colspan="3"><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.$lang['forums_add_category'].'</a></div></td></tr>';
		}
	}

	return $return;
}

function showforum_moderators($forum) {
	if($forum['moderators']) {
		$moderators = explode("\t", $forum['moderators']);
		$count = count($moderators);
		$max = $count > 2 ? 2 : $count;
		$mods = array();
		for($i = 0;$i < $max;$i++) {
			$mods[] = $forum['inheritedmod'] ? '<b>'.$moderators[$i].'</b>' : $moderators[$i];
		}
		$r = implode(', ', $mods);
		if($count > 2) {
			$r = '<span onmouseover="showMenu(this.id)" id="mods_'.$forum['fid'].'">'.$r.'</span>';
			$mods = array();
			foreach($moderators as $moderator) {
				$mods[] = $forum['inheritedmod'] ? '<b>'.$moderator.'</b>' : $moderator;
			}
			$r = '<a href="admincp.php?action=forums&operation=moderators&fid='.$forum['fid'].'" title="'.lang('forums_moderators_comment').'">'.$r.'</a> ...';
			$r .= '<div class="dropmenu1" id="mods_'.$forum['fid'].'_menu" style="display: none">'.implode('<br />', $mods).'</div>';
		} else {
			$r = '<a href="admincp.php?action=forums&operation=moderators&fid='.$forum['fid'].'" title="'.lang('forums_moderators_comment').'">'.$r.'</a>';
		}


	} else {
		$r = '<a href="admincp.php?action=forums&operation=moderators&fid='.$forum['fid'].'" title="'.lang('forums_moderators_comment').'">'.lang('forums_no_moderator').'</a>';
	}
	return $r;
}

?>