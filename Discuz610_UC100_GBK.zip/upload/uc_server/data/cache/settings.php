<?php
$_CACHE['settings'] = array (
  'accessemail' => '',
  'censoremail' => '',
  'censorusername' => '',
  'dateformat' => 'y-n-j',
  'doublee' => '1',
  'nextnotetime' => '0',
  'timeoffset' => '28800',
);
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'DISCUZ',
    'name' => 'Discuz! Board',
    'url' => 'http://localhost/release',
    'authkey' => 'W6VeZdren9dcLeO9o505Ff7b2aD3c6n4Ren0ccO6W0Ob71A9fbS8ZdY0UbAej6P8',
    'ip' => '127.0.0.1',
    'charset' => 'gbk',
    'dbcharset' => 'gbk',
    'synlogin' => '1',
    'recvnote' => '1',
    'extra' => '',
    'tagtemplates' => '',
  ),
);

?>