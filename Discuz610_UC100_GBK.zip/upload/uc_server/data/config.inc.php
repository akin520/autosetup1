<?php 
define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'root');
define('UC_DBPW', 'root');
define('UC_DBNAME', 'pack');
define('UC_DBCHARSET', 'gbk');
define('UC_DBTABLEPRE', 'uc_');
define('UC_COOKIEPATH', '/');
define('UC_COOKIEDOMAIN', '');
define('UC_DBCONNECT', 0);
define('UC_CHARSET', 'gbk');
define('UC_FOUNDERPW', '291f745fd78ad604fccaf2e84f823b96');
define('UC_FOUNDERSALT', 'i6Rerd');
define('UC_KEY', '66kewdCed9Fcce39r5x5Sfobaas3z6T4jeu0qco6r0ebg1t9jbm8xde02buea6P8');
define('UC_SITEID', '669eSdteY9LcFeN9g5M5TfYb2as3D6y4yeR0pcV6J08bG1v9abk8Kd90obmei6f8');
define('UC_MYKEY', 'j6AeydjeU9Lc5ej9u5a5SfrbZaK3U6y4se404cA620ebv1W9Xbb8Hd40vbZeu6H8');
define('UC_DEBUG', false);
define('UC_PPP', 20);
