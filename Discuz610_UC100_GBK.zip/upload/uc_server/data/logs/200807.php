<?PHP exit;?>	admin	127.0.0.1	1215395186	login	succeed
