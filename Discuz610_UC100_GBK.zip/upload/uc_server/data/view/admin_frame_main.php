<? if(!defined('UC_ROOT')) exit('Access Denied');?>
<? include $this->gettpl('header');?>
<div class="container">
	<h3>UCenter ͳ����Ϣ</h3>
	<ul class="memlist fixwidth">
		<li><em>��Ա����:</em><?=$members?></li>
		<li><em>Ӧ������:</em><?=$apps?></li>
		<li><em>δ���͵�֪ͨ��:</em><?=$notes?></li>
		<li><em>����Ϣ��:</em><?=$pms?></li>
		<li><em>������:</em><?=$friends?></li>
	</ul>
	<h3>����������</h3>
	<ul class="memlist fixwidth">
		<li><em>����ϵͳ�� PHP:</em><?=$serverinfo?></li>
		<li><em>MySQL �汾:</em><?=$dbversion?></li>
		<li><em>�ϴ�����:</em><?=$fileupload?></li>
		<li><em>��ǰ���ݿ�ߴ�:</em><?=$dbsize?></li>
		<li><em>Magic_quote_gpc:</em><?=$magic_quote_gpc?></li>
	</ul>
	<h3>�����Ŷ�</h3>
	<ul class="memlist fixwidth">
		<li>
			<em>��Ȩ����:</em>
			<em class="memcont"><a href="http://www.comsenz.com" target="_blank">&#x5eb7;&#x76db;&#x521b;&#x60f3;(&#x5317;&#x4eac;)&#x79d1;&#x6280;&#x6709;&#x9650;&#x516c;&#x53f8; (Comsenz Inc.)</a></em>
		</li>
		<li>
			<em>�ܲ߻�����Ŀ����:</em>
			<em class="memcont"><a href="http://www.discuz.net/space.php?uid=1" target="_blank">&#x6234;&#x5FD7;&#x5EB7; (Kevin 'Crossday' Day)</a></em>
		</li>
		<li>
			<em>�����Ŷ�:</em>
			<em class="memcont">
				<a href="http://www.discuz.net/space.php?uid=859" target="_blank">Haibo 'cnteacher' Wang</a>,
				<a href="http://www.discuz.net/space.php?uid=16678" target="_blank">Yang 'Tiger' Song</a>,
				<a href="http://www.discuz.net/space.php?uid=10407" target="_blank">Qiang Liu</a>,
				<a href="http://www.discuz.net/space.php?uid=80629" target="_blank">Ning 'Monkey' Hou</a>,
				<a href="http://www.discuz.net/space.php?uid=122246" target="_blank">Min 'Heyond' Huang</a>
			</em>
		</li>
		<li>
			<em>��ȫ�Ŷ�:</em>
			<em class="memcont">
				<a href="http://www.discuz.net/space.php?uid=859" target="_blank">Haibo 'cnteacher' Wang</a>,
				<a href="http://www.discuz.net/space.php?uid=210272" target="_blank">XiaoDun 'Kenshine' Fang</a>,
				<a href="http://www.discuz.net/space.php?uid=492114" target="_blank">Liang 'Metthew' Xu</a>,
				<a href="http://www.discuz.net/space.php?uid=285706" target="_blank">Wei (Sniffer) Yu</a>
			</em>
		</li>
		<li>
			<em>֧���Ŷ�:</em>
			<em class="memcont">
				<a href="http://www.discuz.net/space.php?uid=2691" target="_blank">Liang 'Readme' Chen</a>,
				<a href="http://www.discuz.net/space.php?uid=1519" target="_blank">Yang 'Summer' Xia</a>,
				<a href="http://www.discuz.net/space.php?uid=1904" target="_blank">Tao (FengXue) Cheng</a>,
				<a href="http://www.discuz.net/space.php?uid=294092" target="_blank">Fangming (Dennis) Li</a>
			</em>
		</li>
		<li>
			<em>��˾��վ:</em>
			<em class="memcont"><a href="http://www.comsenz.com" target="_blank">http://www.Comsenz.com</a></em>
		</li>
		<li>
			<em>��Ʒ�ٷ���վ:</em>
			<em class="memcont"><a href="http://www.discuz.com" target="_blank">http://www.Discuz.com</a></em>
		</li>
		<li>
			<em>��Ʒ�ٷ���̳:</em>
			<em class="memcont"><a href="http://www.discuz.net" target="_blank">http://www.Discuz.net</a></em>
		</li>
	</ul>
</div>

<?=$ucinfo?>

<? include $this->gettpl('footer');?>