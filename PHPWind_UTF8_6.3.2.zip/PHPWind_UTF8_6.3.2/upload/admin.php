<?php
/**
*
*  Copyright (c) 2003-08  PHPWind.net. All rights reserved.
*  Support : http://www.phpwind.net
*  This software is the proprietary information of PHPWind.com.
*
*/
error_reporting(E_ERROR | E_PARSE);
set_magic_quotes_runtime(0);

define('R_P',getdirname(__FILE__));
define('D_P',R_P);

!$_SERVER['PHP_SELF'] && $_SERVER['PHP_SELF'] = $_SERVER['SCRIPT_NAME'];
$admin_file = $_SERVER['PHP_SELF'];
require_once(R_P.'admin/admincp.php');

if(!$adminjob){
	require_once(R_P."admin/index.php");
} elseif($adminjob == 'notice'){
	require_once(R_P."admin/notice.php");
} elseif($adminjob == 'admin'){
	$tdtime	= (floor($timestamp/3600)-gmdate('G',$timestamp+$db_timedf*3600))*3600;
	if (filemtime(D_P.'data/bbscache/admin_cache.php') < $tdtime) {
		require_once(R_P.'admin/table.php');
		list($tabledb) = N_getTabledb();
		$pw_size = $o_size = 0;
		$query = $db->query('SHOW TABLE STATUS');
		while ($rt = $db->fetch_array($query)) {
			if (in_array($rt['Name'],$tabledb)) {
				$pw_size += $rt['Data_length'] + $rt['Index_length'] + 0;
			} else {
				$o_size  += $rt['Data_length'] + $rt['Index_length'] + 0;
			}
		}
		$o_size		 = number_format($o_size/(1024*1024),2);
		$pw_size	 = number_format($pw_size/(1024*1024),2);
		$dbversion	 = $db->server_info();
		$max_upload  = ini_get('file_uploads') ? ini_get('upload_max_filesize') : 'Disabled';
		$max_ex_time = ini_get('max_execution_time').' seconds';
		$sys_mail    = ini_get('sendmail_path') ? 'Unix Sendmail ( Path: '.ini_get('sendmail_path').')' :( ini_get('SMTP') ? 'SMTP ( Server: '.ini_get('SMTP').')': 'Disabled' );
		@extract($db->get_one("SELECT totalmember,yposts FROM pw_bbsinfo WHERE id=1"));
		@extract($db->get_one("SELECT SUM(topic) AS threads,SUM(article) AS posts FROM pw_forumdata"));
		@extract($db->get_one("SELECT SUM(hits) AS hits FROM pw_threads"));
		writeover(D_P.'data/bbscache/admin_cache.php',"<?php die;?>$pw_size|$o_size|$dbversion|$max_upload|$max_ex_time|$sys_mail|$totalmember|$threads|$posts|$hits|$yposts");
	} else {
		list($pw_size,$o_size,$dbversion,$max_upload,$max_ex_time,$sys_mail,$totalmember,$threads,$posts,$hits,$yposts) = explode('|',substr(readover(D_P.'data/bbscache/admin_cache.php'),12));
	}
	$systemtime	= gmdate("Y-m-d H:i",time()+$db_timedf*3600);
	$altertime	= gmdate("Y-m-d H:i",$timestamp+$db_timedf*3600);
	$sysversion = PHP_VERSION;
	$sysos      = trim(preg_replace("/php\/$sysversion/i",'',$_SERVER['SERVER_SOFTWARE']));
	$ifcookie   = isset($_COOKIE) ? "SUCCESS" : "FAIL";
	$warnning = 'none';
	if (($admin_gid == '3' || CkInArray($admin_name,$manager)) && is_writeable(D_P.'data/sql_config.php') || file_exists('data') || ini_get('register_globals') || file_exists('admin.php') || !$db_ifsafecv || strpos($db_safegroup,'3')===false || strpos($db_safegroup,'4')===false || strpos($db_safegroup,'5')===false || $pw_size > 300) {
		$warnning = '';
	}
	$mid = 0;
	$content = $sltlv = '';
	@extract($db->get_one("SELECT mid,content FROM pw_memo WHERE isuser='0' AND username='$admin_name'"));
	$content && $content = str_replace('<br />',"\n",$content);
	if($rightset['level']){
		foreach($ltitle as $key => $value){
			$sltlv .= "<option value=\"$key\">$value</option>";
		}
	}
	include_once(D_P.'data/bbscache/forumcache.php');
	if(If_manager){
		list(,$hideforum) = GetHiddenForum();
		$forumcache .= $hideforum;
	} elseif($rightset['setforum']){
		if($admin_gid == '5'){
			list(,$forumcache) = GetAllowForum($admin_name);
		}
	} else{
		$forumcache = '';
	}
	require_once PrintEot('admin');exit;
} elseif(in_array($adminjob,array('rightset','manager','code','diyoption','optimize','ystats')) && If_manager){
	require_once(R_P."admin/$adminjob.php");
} elseif($adminjob == 'hackcenter' && $rightset['hackcenter']){
	require_once(R_P."admin/hackcenter.php");
} elseif($adminjob == 'hack' && $rightset['hackcenter']){
	if(!$db_hackdb[$hackset] || !is_dir(R_P."hack/$hackset") || !file_exists(R_P."hack/$hackset/admin.php")){
		adminmsg("hack_error");
	}
	define('H_P',R_P."hack/$hackset/");
	$basename="$admin_file?adminjob=hack&hackset=$hackset";
	require_once Pcv(H_P.'admin.php');
} elseif($adminjob == 'content' && ($rightset['tpccheck'] && $type == 'tpc' || $rightset['postcheck'] && $type == 'post' || $rightset['message'] && $type == 'message')){
	require_once(R_P."admin/content.php");
} elseif($rightset[$adminjob] || ($a_type && $rightset[$a_type])){
	require_once Pcv(R_P."admin/$adminjob.php");
} elseif($adminjob == 'left' || $adminjob == 'left2'){
	require_once(R_P."admin/$adminjob.php");
} elseif($adminjob == 'updatememo') {
	list($mmid,$mcontent) = $db->get_one("SELECT mid,content FROM pw_memo WHERE isuser='0' AND username='$admin_name'",MYSQL_NUM);
	$mmid = (int)$mmid;
	$content = Char_cv($_POST['content']);
	if (!$mmid) {
		$db->update("INSERT INTO pw_memo(username,postdate,content,isuser) VALUES('$admin_name','$timestamp','$content','0')");
	} elseif ($mmid==(int)$_POST['mid'] && $mcontent!=$content) {
		$db->update("UPDATE pw_memo SET postdate='$timestamp',content='$content' WHERE mid='$mmid'");
	}
	ObHeader("$admin_file?adminjob=admin");
} else{
	adminmsg('undefine_action');
}
function SafeFunc(){
	//Safe The Admin
}
function getdirname($path=null){
	if (!empty($path)) {
		if (strpos($path,'\\')!==false) {
			return substr($path,0,strrpos($path,'\\')).'/';
		} elseif (strpos($path,'/')!==false) {
			return substr($path,0,strrpos($path,'/')).'/';
		}
	}
	return './';
}
?>