<?php
/**
*
*  Copyright (c) 2003-08  PHPWind.net. All rights reserved.
*  Support : http://www.phpwind.net
*  This software is the proprietary information of PHPWind.com.
*
*/
!defined('R_P') && exit('Forbidden');
function_exists('date_default_timezone_set') && date_default_timezone_set('Etc/GMT+0');

$defined_vars = get_defined_vars();
foreach ($defined_vars as $_key => $_value) {
	if(!in_array($_key,array('GLOBALS','_POST','_GET','_COOKIE','_SERVER','_FILES','admin_file'))){
		${$_key} = '';
		unset(${$_key});
	}
}
unset($_key,$_value,$defined_vars);

if(!get_magic_quotes_gpc()){
	Add_S($_POST);
	Add_S($_GET);
	Add_S($_COOKIE);
}
Add_S($_FILES);

$c_agentip = 1;
if ($_SERVER['HTTP_X_FORWARDED_FOR']) {
	$onlineip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} elseif ($_SERVER['HTTP_CLIENT_IP']) {
	$onlineip = $_SERVER['HTTP_CLIENT_IP'];
} else {
	$onlineip = $_SERVER['REMOTE_ADDR'];
	$c_agentip = 0;
}
$onlineip  = preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/',$onlineip) ? $onlineip : 'Unknown';

$timestamp = time();
require_once(R_P.'admin/defend.php');
if ($adminjob=='quit') {
	Cookie('AdminUser','',0);
	ObHeader($admin_file);
}
$db_cvtime != 0 && $timestamp += $db_cvtime*60;

$ckdtime = 31536000;
$REQUEST_URI = $_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];
//unset($db_ckpath,$db_ckdomain);
$wind_version = '6.3.2';
$wind_repair  = '20080804';
$db_olsize    = 96;

list($db_moneyname,$db_moneyunit,$db_rvrcname,$db_rvrcunit,$db_creditname,$db_creditunit)=explode("\t",$db_credits);

$imgpath	= $db_http		!= 'N' ? $db_http		: "$db_bbsurl/$db_picpath";
$attachpath = $db_attachurl != 'N' ? $db_attachurl	: "$db_bbsurl/$db_attachname";
$imgdir 	= R_P.$db_picpath;
$attachdir	= R_P.$db_attachname;
$pw_posts	= 'pw_posts';
$pw_tmsgs	= 'pw_tmsgs';

if (D_P != R_P && $db_http != 'N') {
	$R_url = substr($db_http,-1)=='/' ? substr($db_http,0,-1) : $db_http;
	$R_url = substr($R_url,0,strrpos($R_url,'/'));
} else {
	$R_url = $db_bbsurl;
}

if ($_POST['skinco']) {
	$skinco = $_POST['skinco'];
} elseif ($_GET['skinco']) {
	$skinco = $_GET['skinco'];
} else {
	$skinco = GetCookie('skinco');
}
if ($skinco && file_exists(D_P."data/style/$skinco.php") && strpos($skinco,'..')===false) {
	$skin = $skinco;
	Cookie('skinco',$skinco);
} else {
	$skin = $db_defaultstyle;
}
@include_once Pcv(D_P."data/style/$skin.php");
include_once(D_P.'data/sql_config.php');
include_once(D_P.'data/bbscache/forum_cache.php');
require_once(R_P.'admin/cache.php');
!is_array($manager) && $manager = array();
!is_array($manager_pwd) && $manager_pwd = array();
$newmanager = $newmngpwd = array();
foreach ($manager as $key => $value) {
	if (!empty($value) && !is_array($value)) {
		$newmanager[$key] = $value;
		$newmngpwd[$key] = $manager_pwd[$key];
	}
}
$manager = $newmanager;
$manager_pwd = $newmngpwd;
$H_url = $db_wwwurl;
$B_url = $db_bbsurl;

if ($database=='mysqli' && Pwloaddl('mysqli')===false) {
	$database = 'mysql';
}
if (!(!$adminjob || ($adminjob=='settings' && $type=='coreset') || $adminjob=='creathtm') && $db_obstart && function_exists('ob_gzhandler')) {//����� ob_gzhandler ����̨������������
	ob_start('ob_gzhandler');
} else {
	ob_start();
}

$bbsrecordfile = D_P.'data/bbscache/admin_record.php';
!file_exists($bbsrecordfile) && writeover($bbsrecordfile,"<?php die;?>\n");
$F_count = F_L_count($bbsrecordfile,2000);
$L_T = 1200-($timestamp-filemtime($bbsrecordfile));
$L_left = 15-$F_count;

if ($F_count>15 && $L_T>0) {
	require_once GetLang('cpmsg');
	$msg = $lang['login_fail'];
	Cookie('AdminUser','',0);
	include PrintEot('adminlogin');exit;
}
file_exists('install.php') && adminmsg('installfile_exists');
if (empty($manager)) {
	include_once PrintEot('unloginleft');
	adminmsg('sql_config');
}

$admin_name = '';
$CK = $rightset = array();
if ($_POST['admin_pwd'] && $_POST['admin_name']) {
	$admin_name = stripcslashes($_POST['admin_name']);
	$safecv = $db_ifsafecv ? questcode($_POST['question'],$_POST['customquest'],$_POST['answer']) : '';
	$CK = array($timestamp,$_POST['admin_name'],md5(PwdCode(md5($_POST['admin_pwd'])).$timestamp),$safecv);
	Cookie('AdminUser',StrCode(implode("\t",$CK)));
} else {
	$AdminUser = GetCookie('AdminUser');
	if ($AdminUser) {
		$CK = explode("\t",StrCode($AdminUser,'DECODE'));
		$admin_name = stripcslashes($CK[1]);
	}
}
if (!empty($CK)) {
	require_once Pcv(R_P."require/db_$database.php");
	$db = new DB($dbhost,$dbuser,$dbpw,$dbname,$pconnect);
	$rightset = checkpass($CK);
} else {
	$db = null;
}

if (empty($rightset)) {
	if ($_POST['admin_name'] && $_POST['admin_pwd']) {
		writeover($bbsrecordfile,'|'.str_replace('|','&#124;',Char_cv($_POST['admin_name'])).'|'.str_replace('|','&#124;',Char_cv($_POST['admin_pwd']))."|Logging Failed|$onlineip|$timestamp|\n",'ab');
		adminmsg('login_error');
	}
	Cookie('AdminUser','',0);
	include PrintEot('adminlogin');exit;
} elseif ($_POST['admin_name']) {
	ObHeader($REQUEST_URI);
}

$admin_gid = $rightset['gid'];
if ($db_ifsafecv && strpos($db_safegroup,",$admin_gid,")!==false && !$CK[3]) {
	Cookie('AdminUser','',0);
	adminmsg('safecv_prompt');
}

include_once(D_P.'data/bbscache/level.php');
!defined('If_manager') && define('If_manager',0);
if (!If_manager) {
	Iplimit();
	$temp_a = array_merge($_POST,$_GET);
	foreach ($temp_a as $value) {
		CheckVar($value);
	}
	unset($temp_a);
	$admin_level = $ltitle[$admin_gid];
} else {
	$admin_level = 'manager';
}

$_postdata  = $_POST ? PostLog($_POST) : '';
$new_record = '|'.str_replace('|','&#124;',Char_cv($admin_name)).'||'.str_replace('|','&#124;',Char_cv($REQUEST_URI))."|$onlineip|$timestamp|$_postdata|\n";
writeover($bbsrecordfile,$new_record,"ab");

if ($_SERVER['REQUEST_METHOD']=='POST' && !($adminjob=='hack' && $hackset=='advert' && $job=='add' && !$_POST['step'])) {
	$referer_a = @parse_url($_SERVER['HTTP_REFERER']);
	if ($referer_a['host']) {
		list($http_host) = explode(':',$_SERVER['HTTP_HOST']);
		if ($referer_a['host']!=$http_host) {
			adminmsg('undefined_action');
		}
	}
	unset($referer_a);
	PostCheck($verify);
}
unset($_postdata,$new_record,$bbsrecordfile,$dbhost,$dbuser,$dbpw,$dbname,$pconnect,$newmanager,$newmngpwd);

function Cookie($ck_Var,$ck_Value,$ck_Time = 'F',$ck_Httponly = true){
	global $ckdtime,$timestamp;
	
	if (!$_SERVER['REQUEST_URI'] || ($https = @parse_url($_SERVER['REQUEST_URI']))===false) {
		$https = array();
	}
	if ((empty($https['scheme']) && ($_SERVER['HTTP_SCHEME']=='https' || $_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS'])!='off')) || $https['scheme']=='https') {
		$ck_Secure = true;
	} else {
		$ck_Secure = false;
	}
	if ($ck_Time=='F') {
		$ck_Time = $timestamp+$ckdtime;
	} elseif ($ck_Value=='' && $ck_Time==0) {
		return setcookie(CookiePre()."_$ck_Var",'',$timestamp-$ckdtime,'/','',$ck_Secure);
	}
	if (PHP_VERSION >= '5.2.0') {
		return setcookie(CookiePre()."_$ck_Var",$ck_Value,$ck_Time,'/','',$ck_Secure,$ck_Httponly);
	} else {
		return setcookie(CookiePre()."_$ck_Var",$ck_Value,$ck_Time,'/'.($ck_Httponly ? '; HttpOnly' : ''),'',$ck_Secure);
	}
}
function GetCookie($Var){
    return $_COOKIE[CookiePre()."_$Var"];
}
function CookiePre(){
	static $pre = null;
	!isset($pre) && $pre = substr(md5($GLOBALS['db_sitehash']),0,5);
	return $pre;
}
function Add_S(&$array){
	if (is_array($array)) {
		foreach ($array as $key => $value) {
			if (!is_array($value)) {
				$array[$key] = addslashes($value);
			} else {
				Add_S($array[$key]);
			}
		}
	}
}
function HtmlConvert(&$array){
	if (is_array($array)) {
		foreach ($array as $key => $value) {
			if (!is_array($value)) {
				$array[$key] = htmlspecialchars($value);
			} else {
				HtmlConvert($array[$key]);
			}
		}
	} else {
		$array = htmlspecialchars($array);
	}
}
function substrs($content,$length,$add='Y'){
	if ($length && strlen($content)>$length) {
		global $db_charset;
		if ($db_charset!='utf-8') {
			$retstr = '';
			for ($i=0;$i<$length-2;$i++) {
				$retstr .= ord($content[$i]) > 127 ? $content[$i].$content[++$i] : $content[$i];
			}
			return $retstr.($add=='Y' ? ' ..' : '');
		}
		return utf8_trim(substr($content,0,$length)).($add=='Y' ? ' ..' : '');
	}
	return $content;
}
function utf8_trim($str) {
	$hex = '';
	$len = strlen($str)-1;
	for ($i=$len;$i>=0;$i-=1) {
		$ch = ord($str[$i]);
		$hex .= " $ch";
		if (($ch & 128)==0 || ($ch & 192)==192) {
			return substr($str,0,$i);
		}
	}
	return $str.$hex;
}
function checkpass($CK){
	Add_S($CK);
	global $db,$manager,$db_ifsafecv,$db_gdcheck;
	if ($_POST['Login_f']==1 && ($db_gdcheck & 32)) {
		GdConfirm($_POST['lg_num']);
	}
	if (CkInArray($CK[1],$manager)) {
		global $manager_pwd;
		$v_key = array_search($CK[1],$manager);
		if (!SafeCheck($CK,PwdCode($manager_pwd[$v_key]))) {
			$rt = $db->get_one("SELECT uid,username,groupid,groups,password,safecv FROM pw_members WHERE username='$CK[1]'");
			if (!SafeCheck($CK,PwdCode($rt['password'])) || $db_ifsafecv && $rt['safecv']!=$CK['3']) {
				return false;
			}
			if (!admincheck($rt['uid'],$rt['username'],$rt['groupid'],$rt['groups'],'check')) {
				return false;
			}
		} elseif ($db_ifsafecv) {
			$query = $db->query("SELECT safecv FROM pw_members WHERE username='$CK[1]'",null,false);
			if ($db->num_rows($query) > 0) {
				$rt = $db->fetch_array($query,MYSQL_NUM);
				if ($rt[0] != $CK['3']) return false;
			}
		}
		define('If_manager',1);
		$rightset = array('gid' => 3);
		require GetLang('left');
		foreach ($lang as $left) {
			foreach ($left as $key => $value) {
				$rightset[$key] = '1';
			}
		}
		return $rightset;
	}
	$rt = $db->get_one("SELECT m.uid,m.username,m.groupid,m.groups,m.password,m.safecv,m.groupid,u.gptype,u.allowadmincp FROM pw_members m LEFT JOIN pw_usergroups u ON u.gid=m.groupid WHERE username='$CK[1]'");
	if (!$rt['allowadmincp'] || ($rt['gptype']!='system' && $rt['gptype']!='special') || $db_ifsafecv && $rt['safecv']!=$CK['3']) {
		return false;
	}
	if (!SafeCheck($CK,PwdCode($rt['password'])) || !admincheck($rt['uid'],$rt['username'],$rt['groupid'],$rt['groups'],'check')) {
		return false;
	}
	$rightset = $db->get_value("SELECT value FROM pw_adminset WHERE gid='$rt[groupid]'");
	if (!$rightset) {
		$rightset = array('gid'=>$rt['groupid']);
	} else {
		$rightset = P_unserialize($rightset);
		$rightset['gid'] = $rt['groupid'];
	}
	return $rightset;
}
function PwdCode($pwd){
	return md5($_SERVER["HTTP_USER_AGENT"].$pwd.$GLOBALS['db_hash']);
}
function SafeCheck($CK,$PwdCode,$var='AdminUser',$expire=1800){
	global $timestamp;
	if ($timestamp-$CK[0]>$expire || $CK[2]!=md5($PwdCode.$CK[0])) {
		Cookie($var,'',0);
		return false;
	}
	$CK[0] = $timestamp;
	$CK[2] = md5($PwdCode.$timestamp);
	Cookie($var,StrCode(implode("\t",$CK)));
	return true;
}
function StrCode($string,$action='ENCODE'){
	$action != 'ENCODE' && $string = base64_decode($string);
	$code = '';
	$key  = substr(md5($_SERVER['HTTP_USER_AGENT'].$GLOBALS['db_hash']),8,18);
	$keylen = strlen($key); $strlen = strlen($string);
	for ($i=0;$i<$strlen;$i++) {
		$k		= $i % $keylen;
		$code  .= $string[$i] ^ $key[$k];
	}
	return ($action!='DECODE' ? base64_encode($code) : $code);
}
function gets($filename,$value='4096'){
	$getcontent = '';
	if ($handle = @fopen($filename,'rb')) {
		flock($handle,LOCK_SH);
		$getcontent = fread($handle,$value);//fgets����
		fclose($handle);
	}
	return $getcontent;
}
function P_unlink($filename){
	strpos($filename,'..')!==false && exit('Forbidden');
	return @unlink($filename);
}
function openfile($filename,$style='Y'){
	if ($style=='Y') {
		$filedb = explode('<:wind:>',str_replace("\n","\n<:wind:>",readover($filename)));
		$count = count($filedb)-1;
		if ($count > -1 && (!$filedb[$count] || $filedb[$count]=="\r")) {
			unset($filedb[$count]);
		}
		empty($filedb) && $filedb[0] = '';
		return $filedb;
	} else {
		return file($filename);
	}
}
function readover($filename,$method='rb'){
	strpos($filename,'..')!==false && exit('Forbidden');
	$filedata = '';
	if ($handle = @fopen($filename,$method)) {
		flock($handle,LOCK_SH);
		$filedata = @fread($handle,filesize($filename));
		fclose($handle);
	}
	return $filedata;
}
function writeover($filename,$data,$method='rb+',$iflock=1,$check=1,$chmod=1){
	//Copyright (c) 2003-08 PHPWind
	$check && strpos($filename,'..')!==false && exit('Forbidden');
	touch($filename);
	$handle = fopen($filename,$method);
	$iflock && flock($handle,LOCK_EX);
	fwrite($handle,$data);
	$method=='rb+' && ftruncate($handle,strlen($data));
	fclose($handle);
	$chmod && @chmod($filename,0777);
}
function Showmsg($msg,$jumpurl='',$t=2,$langtype='index'){
	adminmsg($msg,$jumpurl,$t,$langtype);
}
function adminmsg($msg,$jumpurl='',$t=2,$langtype='admin'){
	@extract($GLOBALS,EXTR_SKIP);
	if ($jumpurl!='') {
		$basename = $jumpurl;
		$ifjump	  = "<meta http-equiv='Refresh' content='$t; url=$jumpurl'>";
	} elseif (!$basename) {
		$basename = $REQUEST_URI;
	}
	if ($langtype=='admin') {
		require_once GetLang('cpmsg');
	} else {
		require_once GetLang('msg',$langtype);
	}
	$lang[$msg] && $msg = $lang[$msg];
	include PrintEot('message');exit;
}
function Char_cv($msg,$isurl=null){
	$msg = preg_replace('/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]/','',$msg);
	$msg = str_replace(array("\0","%00","\r"),'',$msg);
	empty($isurl) && $msg = preg_replace("/&(?!(#[0-9]+|[a-z]+);)/si",'&amp;',$msg);
	$msg = str_replace(array("%3C",'<'),'&lt;',$msg);
	$msg = str_replace(array("%3E",'>'),'&gt;',$msg);
	$msg = str_replace(array('"',"'","\t",'  '),array('&quot;','&#39;','    ','&nbsp;&nbsp;'),$msg);
	return $msg;
}
function ieconvert($msg){
	return str_replace(array("\t","\r",'  '),array('','','&nbsp; '),$msg);
}
function Quot_cv($msg){
	return str_replace('"','&quot;',$msg);
}
function deldir($path){
	if (file_exists($path)) {
		if (is_file($path)) {
			P_unlink($path);
		} else {
			$handle = opendir($path);
			while ($file = readdir($handle)) {
				if ($file!='' && !in_array($file,array('.','..'))) {
					if (is_dir("$path/$file")) {
						deldir("$path/$file");
					} else {
						P_unlink("$path/$file");
					}
				}
			}
			closedir($handle);
			rmdir($path);
		}
	}
}
//phpwind
function getusergroup($username,$getpostnum=N){
	global $db;
	include(D_P."data/bbscache/level.php");
	@extract($db->get_one("SELECT m.groupid,md.postnum FROM pw_members m LEFT JOIN pw_memberdata md ON md.uid=m.uid WHERE m.username='$username'"));
	if(ereg("^[0-9]{1,}",$groupid) || $getpostnum==Y){
		$count=count($lpost);
		for($i=0;$i<$count;$i++){
			if($postnum>=$lpost[$i] && $postnum<$lpost[$i+1]){
				$groupid=$i;$isalet=1;
				break;
			}
		}
		if(!$isalet) $groupid=0;
	}
	settype($groupid, "string");
	return $groupid;
}
function ifadmin($username){
	global $db;
	$query=$db->query("SELECT forumadmin FROM pw_forums WHERE forumadmin!=''");
	while($forum=$db->fetch_array($query)){
		if($forum['forumadmin'] && strpos($forum['forumadmin'],",$username,")!==false){
			return true;
		}
	}
	return false;
}
function ifcheck($var,$out){
	global ${$out.'_Y'},${$out.'_N'};
	if($var) ${$out.'_Y'}="CHECKED"; else ${$out.'_N'}="CHECKED";
}
function F_L_count($filename,$offset){
	global $onlineip;
	$count=0;
	if($fp=@fopen($filename,"rb")){
		flock($fp,LOCK_SH);
		fseek($fp,-$offset,SEEK_END);
		$readb=fread($fp,$offset);
		fclose($fp);
		$readb=trim($readb);
		$readb=explode("\n",$readb);
		$count=count($readb);$count_F=0;
		for($i=$count-1;$i>0;$i--){
			if(strpos($readb[$i],"|Logging Failed|$onlineip|")===false){
				break;
			}
			$count_F++;
		}
	}
	return $count_F;
}
function get_date($timestamp,$timeformat=''){
	global $db_datefm,$db_timedf,$_datefm,$_timedf;
	$date_show=$timeformat ? $timeformat : ($_datefm ? $_datefm : $db_datefm);
	if($_timedf){
		$offset = $_timedf=='111' ? 0 : $_timedf;
	} else{
		$offset = $db_timedf=='111' ? 0 : $db_timedf;
	}
	return gmdate($date_show,$timestamp+$offset*3600);
}
function GetLang($lang,$type='admin',$EXT='php'){
	global $tplpath;
	in_array($lang,array('email','log','bbscode','other','writemsg')) && $type = 'index';
	if ($type!='admin') {
		if (file_exists(R_P."template/$tplpath/lang_$lang.$EXT")) {
			return R_P."template/$tplpath/lang_$lang.$EXT";
		} elseif (file_exists(R_P."template/wind/lang_$lang.$EXT")) {
			return R_P."template/wind/lang_$lang.$EXT";
		} else {
			exit("Can not find lang_$lang.$EXT file");
		}
	}
	if (file_exists(R_P."template/admin_$tplpath/cp_lang_$lang.$EXT")) {
		return R_P."template/admin_$tplpath/cp_lang_$lang.$EXT";
	} elseif (file_exists(R_P."template/admin/cp_lang_$lang.$EXT")) {
		return R_P."template/admin/cp_lang_$lang.$EXT";
	} else {
		exit("Can not find cp_lang_$lang.$EXT file");
	}
}
function PrintEot($template,$EXT="htm"){
	global $tplpath;
	!$template && $template = 'N';
	//cms
	if ($template=='bbscode' || in_array($template,array('c_header','c_footer'))) {
		if (file_exists(R_P."template/$tplpath/$template.$EXT")) {
			return R_P."template/$tplpath/$template.$EXT";
		} elseif (file_exists(R_P."template/wind/$template.$EXT")) {
			return R_P."template/wind/$template.$EXT";
		} else {
			exit("Can not find $template.$EXT file");
		}
	}
	if (file_exists(R_P."template/admin_$tplpath/$template.$EXT")) {
		return R_P."template/admin_$tplpath/$template.$EXT";
	} elseif (file_exists(R_P."template/admin/$template.$EXT")) {
		return R_P."template/admin/$template.$EXT";
	} else {
		exit("Can not find $template.$EXT file");
	}
}
function readlog($filename,$offset=1024000){
	$readb=array();
	if($fp=@fopen($filename,"rb")){
		flock($fp,LOCK_SH);
		$size=filesize($filename);
		$size>$offset ? fseek($fp,-$offset,SEEK_END): $offset=$size;
		$readb=fread($fp,$offset);
		fclose($fp);
		$readb=str_replace("\n","\n<:wind:>",$readb);
		$readb=explode("<:wind:>",$readb);
		$count=count($readb);
		if($readb[$count-1]==''||$readb[$count-1]=="\r"){unset($readb[$count-1]);}
		if(empty($readb)){$readb[0]="";}
	}
	return $readb;
}

function checkselid($selid){
	if(is_array($selid)){
		$ret='';
		foreach($selid as $key => $value){
			if(!is_numeric($value)){
				return false;
			}
			$ret .= $ret ? ','.$value : $value;
		}
		return $ret;
	} else{
		return '';
	}
}
function ObHeader($URL){
	echo '<meta http-equiv="expires" content="0">';
	echo '<meta http-equiv="Pragma" content="no-cache">';
	echo '<meta http-equiv="Cache-Control" content="no-cache">';
	echo "<meta http-equiv='refresh' content='0;url=$URL'>";exit;
}
function updateadmin(){
	global $db;
	$f_admin = array();
	$query = $db->query("SELECT forumadmin FROM pw_forums");
	while ($forum = $db->fetch_array($query)) {
		$adminarray = explode(",",addslashes($forum['forumadmin']));
		foreach ($adminarray as $key=>$value) {
			$value = trim($value);
			if ($value) {
				$f_admin[] = $value;
			}
		}
	}
	$f_admin = array_unique($f_admin);

	$query = $db->query("SELECT uid,username,groupid,groups FROM pw_administrators WHERE groupid=5 OR groups LIKE '%,5,%'");
	while ($rt = $db->fetch_array($query)) {
		if (!in_array($rt['username'],$f_admin)) {
			if ($rt['groupid']=='5') {
				$db->update("UPDATE pw_members SET groupid='-1' WHERE uid='$rt[uid]'");
				$rt['groupid'] = -1;
			} else {
				$rt['groups'] = str_replace(',5,',',',$rt['groups']);
				$rt['groups']==',' && $rt['groups'] = '';
				$db->update("UPDATE pw_members SET groups='$rt[groups]' WHERE uid='$rt[uid]'");
			}
			if ($rt['groupid'] == '-1' && $rt['groups']=='') {
				admincheck($rt['uid'],$rt['username'],$rt['groupid'],$rt['groups'],'delete');
			} else {
				admincheck($rt['uid'],$rt['username'],$rt['groupid'],$rt['groups'],'update');
			}
		}
	}
	if ($f_admin) {
		$usernames = "'".implode("','",$f_admin)."'";
		$query = $db->query("SELECT uid,username,groupid,groups FROM pw_members WHERE username IN($usernames)");
		while ($rt = $db->fetch_array($query)) {
			if ($rt['groupid']=='-1') {
				$rt['groups'] = str_replace(',5,',',',$rt['groups']);
				$rt['groups'] == ',' && $rt['groups'] = '';
				$db->update("UPDATE pw_members SET groupid='5',groups='$rt[groups]' WHERE uid='$rt[uid]'");
				$rt['groupid'] = 5;
			} elseif ($rt['groupid']!='5' && strpos($rt['groups'],',5,')===false) {
				$rt['groups'] = $rt['groups'] ? $rt['groups'].'5,' : ",5,";
				$db->update("UPDATE pw_members SET groups='$rt[groups]' WHERE uid='$rt[uid]'");
			}
			admincheck($rt['uid'],$rt['username'],$rt['groupid'],$rt['groups'],'update');
		}
	}
}

function GetAllowForum($username){
	global $db;
	$allowfid    = '-99';
	$forumoption = '';
	$query = $db->query("SELECT fid,name,forumadmin FROM pw_forums WHERE type!='category' AND (forumadmin LIKE '%,$username,%' OR fupadmin LIKE '%,$username,%')");
	while($rt = $db->fetch_array($query)){
		$allowfid    .= ','.$rt['fid'];
		$forumoption .= "<option value=\"$rt[fid]\"> >> $rt[name]</option>";
	}
	return array($allowfid,$forumoption);
}
function GetHiddenForum(){
	global $db;
	$forumoption = '<option></option>';
	$allowfid    = '-99';
	$query = $db->query("SELECT fid,name FROM pw_forums WHERE f_type='hidden'");
	while($rt = $db->fetch_array($query)){
		$allowfid    .= ','.$rt['fid'];
		$forumoption .= "<option value=\"$rt[fid]\"> &nbsp;|- $rt[name]</option>";
	}
	return array($allowfid,$forumoption);
}
function Iplimit(){
	global $db_iplimit;
	if ($db_iplimit) {
		global $onlineip;
		$allowip = false;
		$ip_a = explode(',',$db_iplimit);
		foreach ($ip_a as $value) {
			$value = trim($value);
			if ($value && strpos(",$onlineip.",",$value.")!==false) {
				$allowip = true;
				break;
			}
		}
		!$allowip && adminmsg('ip_ban');
	}
}
function CheckVar($var){
	if (is_array($var)) {
		foreach ($var as $key => $value) {
			if (!in_array($key,array('module','advert'))) {
				CheckVar($value);
			}
		}
	} else{
		$tar = array('<iframe','<meta','<script');
		foreach ($tar as $value) {
			if (strpos(strtolower($var),$value)!==false) {
				global $basename;
				$basename = 'javascript:history.go(-1);';
				adminmsg('word_error');
			}
		}
	}
}
function PostLog($log){
	foreach($log as $key=>$val){
		if(is_array($val)){
			$data .= "$key=array(".PostLog($val).")";
		} else{
			$val = str_replace(array("\n","\r","|"),array('','','&#124;'),$val);
			if($key=='password' || $key=='check_pwd'){
				$data .= "$key=***, ";
			} else{
				$data .= "$key=$val, ";
			}
		}
	}
	return $data;
}
function GdConfirm($code,$t=1){
	Cookie('cknum','',0);
	if(!$code || !SafeCheck(explode("\t",StrCode(GetCookie('cknum'),'DECODE')),strtoupper($code),'cknum',300)){
		global $basename,$admin_file;
		$t && Cookie('AdminUser','',0);
		$basename = $admin_file;
		adminmsg('check_error');
	}
}
function randstr($lenth){
	mt_srand((double)microtime() * 1000000);
	for($i=0;$i<$lenth;$i++){
		$randval.= mt_rand(0,9);
	}
	$randval=substr(md5($randval),mt_rand(0,32-$lenth),$lenth);
	return $randval;
}
function num_rand($lenth){
	mt_srand((double)microtime() * 1000000);
	for($i=0;$i<$lenth;$i++){
		$randval.= mt_rand(1,9);
	}
	return $randval;
}
function PwStrtoTime($time){
	global $db_timedf;
	return function_exists('date_default_timezone_set') ? strtotime($time) - $db_timedf*3600 : strtotime($time);
}
function EncodeUrl($url){
	global $db_hash,$admin_name,$admin_gid;
	$url_a=substr($url,strrpos($url,'?')+1);
	substr($url,-1)=='&' && $url=substr($url,0,-1);
	parse_str($url_a,$url_a);
	$source='';
	foreach($url_a as $key=>$val){
		$source .= $key.$val;
	}
	$posthash=substr(md5($source.$admin_name.$admin_gid.$db_hash),0,8);
	$url .= "&verify=$posthash";
	return $url;
}
function FormCheck($pre,$url,$add){
	$pre=stripslashes($pre);
	$add=stripslashes($add);
	return "<form{$pre} action=\"".EncodeUrl($url)."&\"{$add}>";
}
function PostCheck($verify){
	global $db_hash,$admin_name,$admin_gid;
	$source='';
	foreach($_GET as $key=>$val){
		if(!in_array($key,array('verify','nowtime'))){
			$source .= $key.$val;
		}
	}
	if($verify!=substr(md5($source.$admin_name.$admin_gid.$db_hash),0,8)){
		adminmsg('illegal_request');
	}
	return true;
}

function Pcv($filename,$ifcheck=1){
	strpos($filename,'http://')!==false && exit('Forbidden');
	$ifcheck && strpos($filename,'..')!==false && exit('Forbidden');
	return $filename;
}
function PrintHack($template,$EXT="htm"){
	return H_P."template/".$template.".$EXT";
}
function geturl($attachurl,$type=''){
	global $attachdir,$attachpath,$db_ftpweb,$attach_url;

	if(file_exists($attachdir.'/'.$attachurl)){
		return array($attachpath.'/'.$attachurl,'Local');
	}
	if($db_ftpweb && !$attach_url){
		return array($db_ftpweb.'/'.$attachurl,'Ftp');
	}
	if(!$db_ftpweb && !is_array($attach_url)){
		return array($attach_url.'/'.$attachurl,'att');
	}
	if(!$db_ftpweb && count($attach_url)==1){
		return array($attach_url[0].'/'.$attachurl,'att');
	}
	if($type=='show'){
		return 'imgurl';
	}
	if($db_ftpweb && @$fp=fopen($db_ftpweb.'/'.$attachurl,'rb')){
		@fclose($fp);
		return array($db_ftpweb.'/'.$attachurl,'Ftp');
	}
	if($attach_url){
		foreach($attach_url as $key=>$val){
			if($val==$db_ftpweb)continue;
			if(@$fp=fopen($val.'/'.$attachurl,'rb')){
				@fclose($fp);
				return array($val.'/'.$attachurl,'att');
			}
		}
	}
	return false;
}
function GetTtable($tid){
	global $db_tlist;
	if(!$db_tlist) return 'pw_tmsgs';
	$tlistdb = unserialize($db_tlist);
	foreach($tlistdb as $key=>$value){
		if($key>0 && $tid>$value){
			return 'pw_tmsgs'.(int)$key;
		}
	}
	return 'pw_tmsgs';
}
function GetPtable($tbid,$tid=''){
	if($GLOBALS['db_plist'] && $tbid=='N' && $tid){
		@extract($GLOBALS['db']->get_one("SELECT ptable AS tbid FROM pw_threads WHERE tid='$tid'"));
	}
	if($GLOBALS['db_plist'] && $tbid && is_numeric($tbid) && strpos(",{$GLOBALS[db_plist]},",",$tbid,")!==false){
		return 'pw_posts'.(int)$tbid;
	} else{
		return 'pw_posts';
	}
}
function maxmin($id){
	global $tlistdb;
	$tidmax = $tidmin = 0;
	foreach($tlistdb as $key=>$val){
		if($key==$id){
			$tidmin = $val;
			break;
		}
		$tidmax = $val;
	}
	return array($tidmin,$tidmax);
}
function admincheck($uid,$username,$groupid,$groups,$action) {
	global $db;
	if ($action == 'check') {
		$rt = $db->get_one("SELECT username,groupid,groups FROM pw_administrators WHERE uid='$uid'");
		if ($rt && $rt['username']==$username && ($rt['groupid']==$groupid || strpos($rt['groups'],",$groupid,")!==false)) {
			return true;
		} else {
			return false;
		}
	} elseif ($action == 'update') {
		$rt = $db->get_one("SELECT username,groupid,groups FROM pw_administrators WHERE uid='$uid'");
		if (!$rt) {
			$db->update("INSERT INTO pw_administrators(uid,username,groupid,groups) VALUES('$uid','$username','$groupid','$groups')");
		} elseif ($rt['username']!=$username || $rt['groupid']!=$groupid || $rt['groups']!=$groups) {
			$db->update("UPDATE pw_administrators SET username='$username',groupid='$groupid',groups='$groups' WHERE uid='$uid'");
		}
	} elseif ($action=='delete') {
		$db->update("DELETE FROM pw_administrators WHERE uid='$uid'");
	} else {
		return false;
	}
}
function InitGP($keys,$method='GP',$htmcv=0){
	!is_array($keys) && $keys = array($keys);
	foreach($keys as $val){
		$GLOBALS[$val] = NULL;
		if($method!='P' && isset($_GET[$val])){
			$GLOBALS[$val] = $_GET[$val];
		} elseif($method!='G' && isset($_POST[$val])){
			$GLOBALS[$val] = $_POST[$val];
		}
		$htmcv && $GLOBALS[$val] = Char_cv($GLOBALS[$val]);
	}
}
function GetGP($key,$method='GP'){
	if($method=='G' || $method!='P' && isset($_GET[$key])){
		return $_GET[$key];
	}
	return $_POST[$key];
}
function questcode($question,$customquest,$answer){
	$question = $question=='-1' ? $customquest : $question;
	return $question ? substr(md5(md5($question).md5($answer)),8,10) : '';
}
function CkInArray($needle,$haystack){
	if (!$needle || empty($haystack) || !in_array($needle,$haystack)) {
		return false;
	}
	return true;
}
function pw_var_export($input,$t = null) {
	$output = '';
	if (is_array($input)) {
		$output .= "array(\r\n";
		foreach ($input as $key => $value) {
			$output .= $t."\t".pw_var_export($key,$t."\t").' => '.pw_var_export($value,$t."\t");
			$output .= ",\r\n";
		}
		$output .= $t.')';
	} elseif (is_string($input)) {
		$output .= "'".str_replace(array("\\","'"),array("\\\\","\'"),$input)."'";
	} elseif (is_int($input) || is_double($input)) {
		$output .= "'".(string)$input."'";
	} elseif (is_bool($input)) {
		$output .= $input ? 'true' : 'false';
	} else {
		$output .= 'NULL';
	}
	return $output;
}
function Pwloaddl($mod,$ckfunc='mysqli_get_client_info'){
	static $isallowed = null;
	if (extension_loaded($mod)) {
		if ($ckfunc && !function_exists($ckfunc)) return false;
		return true;
	}
	return false;

	if ($isallowed===null) {
		if (!@ini_get('safe_mode') && @ini_get('enable_dl') && @function_exists('dl') && @function_exists('phpinfo')) {
			ob_start();
			@phpinfo(INFO_GENERAL);
			$infomsg = strip_tags(ob_get_contents());
			ob_end_clean();
			if (preg_match('/thread safety\s*enabled/i',$infomsg) && !preg_match('/server api\s*\(cgi\|cli\)/i',$infomsg)) {
				$isallowed = false;
			} else {
				$isallowed = true;
			}
		} else {
			$isallowed = false;
		}
	}
	if (!$isallowed) return false;
	if (strtoupper(substr(PHP_OS,0,3))==='WIN') {
		$module = "php_$mod.dll";
	} elseif (PHP_OS=='HP-UX') {
		$module = "$mod.sl";
	} else {
		$module ="$mod.so";
	}
	@dl(Pcv($module));
	if ($ckfunc && !function_exists($ckfunc)) {
		return false;
	}
}
?>