<?php
!function_exists('adminmsg') && exit('Forbidden');

require_once GetLang('all');
$basename = "$admin_file?adminjob=announcement";

if ($action=='order') {
	!is_array($vieworder = $_POST['vieworder']) && $vieworder = array();
	$updatedb = array();
	foreach ($vieworder as $key => $value) {
		if (is_numeric($key)) {
			$value = (int)$value;
			$updatedb[$value] .= ",'$key'";
		}
	}
	foreach ($updatedb as $key => $value) {
		$value && $db->update("UPDATE pw_announce SET vieworder='$key' WHERE aid IN (".substr($value,1).')');
	}
	updatecache_i();
	adminmsg('operate_success');
} elseif ($action=='add') {
	list($fids,$forumcache,$cmscache) = GetForumdb();
	if ($_POST['step']!=2) {
		$fid = (int)$_GET['fid']==0 ? -1 : $_GET['fid'];
		$ifopen_Y = 'CHECKED'; $vieworder = (int)$vieworder;
		$ifopen_N = $subject = $atc_content = $enddate = '';
		$startdate = get_date($timestamp,'Y-m-d H:i');
		
		Showoption($fid);
		$ckdisplay = Displayfid();
		include PrintEot('notice');exit;
	} else {
		$successurl = $basename;
		$basename .= '&action=add';
		$fid = (int)$_POST['fid'];
		!$fid && adminmsg('annouce_fid');
		!Checkright($fids,$fid) && adminmsg('annouce_right');
		$basename .= "&fid=$fid";
		
		$atc_title = trim(ieconvert($_POST['atc_title']));
		!$atc_title && adminmsg('annouce_title');
		
		$atc_content = trim(ieconvert($_POST['atc_content']));
		$url = trim(Char_cv(str_replace(array('"',"'",'\\'),'',$_POST['url']),true));
		!$atc_content && !$url && adminmsg('annouce_content');
		
		$startdate = $_POST['startdate'] ? PwStrtoTime($_POST['startdate']) : $timestamp;
		$enddate = $_POST['enddate'] ? PwStrtoTime($_POST['enddate']) : '';
		$enddate && $enddate<=$startdate && adminmsg('annouce_time');
//		!Datecheck($fid,$startdate,$enddate) && adminmsg('annouce_date');
		InitGP(array('ifopen','vieworder'),'P');
		$db->update("INSERT INTO pw_announce(fid,ifopen,vieworder,author,startdate,enddate,url,subject,content) VALUES ('$fid','".(int)$ifopen."','".(int)$vieworder."','$admin_name','$startdate','$enddate','$url','$atc_title','$atc_content')");
		updatecache_i();
		adminmsg('operate_success',$successurl);
	}
} elseif ($action=='edit') {
	$aid = (int)GetGP('aid');
	$sql_select = $_POST['step']!=2 ? ',ifopen,vieworder,startdate,enddate,url,subject,content' : '';
	$rt = $db->get_one("SELECT aid,fid $sql_select FROM pw_announce WHERE aid='$aid'");
	!$rt['aid'] && adminmsg('operate_fail');
	
	list($fids,$forumcache,$cmscache) = GetForumdb();
	!Checkright($fids,$rt['fid']) && adminmsg('annouce_right');
	
	if ($_POST['step']!=2) {
		extract($rt,EXTR_SKIP);
		ifcheck($ifopen,'ifopen');
		$subject = Char_cv($subject); $atc_content = Char_cv($content);
		
		Showoption($fid);
		$ckdisplay = Displayfid();
		$startdate && $startdate = get_date($startdate,'Y-m-d H:i'); $enddate && $enddate = get_date($enddate,'Y-m-d H:i');
		$vieworder = (int)$vieworder;
		include PrintEot('notice');exit;
	} else {
		$successurl = $basename;
		$basename .= "&action=edit&aid=$aid";
		$fid = (int)$_POST['fid'];
		!$fid && adminmsg('annouce_fid');
		!Checkright($fids,$fid) && adminmsg('annouce_right');
		$basename .= "&fid=$fid";
		
		$atc_title = trim(ieconvert($_POST['atc_title']));
		!$atc_title && adminmsg('annouce_title');
		
		$atc_content = trim(ieconvert($_POST['atc_content']));
		$url = trim(Char_cv(str_replace(array('"',"'",'\\'),'',$_POST['url']),true));
		!$atc_content && !$url && adminmsg('annouce_content');
		
		$startdate = $_POST['startdate'] ? PwStrtoTime($_POST['startdate']) : $timestamp;
		$enddate = $_POST['enddate'] ? PwStrtoTime($_POST['enddate']) : '';
		$enddate && $enddate<=$startdate && adminmsg('annouce_time');
//		!Datecheck($fid,$startdate,$enddate,$aid) && adminmsg('annouce_date');
		InitGP(array('ifopen','vieworder'),'P');
		$db->update("UPDATE pw_announce SET fid='$fid',ifopen='".(int)$ifopen."',vieworder='".(int)$vieworder."',startdate='$startdate',enddate='$enddate',url='$url',subject='$atc_title',content='$atc_content' WHERE aid='$aid'");
		updatecache_i();
		adminmsg('operate_success',$successurl);
	}
} elseif ($action=='del') {
	$aid = (int)$_GET['aid'];
	$rt = $db->get_one("SELECT aid,fid FROM pw_announce WHERE aid='$aid'");
	!$rt['aid'] && adminmsg('operate_fail');
	list($fids) = GetForumdb();
	!Checkright($fids,$rt['fid']) && adminmsg('annouce_right');
	$db->update("DELETE FROM pw_announce WHERE aid='$aid'");
	updatecache_i();
	adminmsg('operate_success');
} else {
	include_once(D_P.'data/bbscache/forum_cache.php');
	$titledb = $namedb = array();
	list($fids,$forumcache,$cmscache) = GetForumdb();
	$pages = '';
	$sqlwhere = 'WHERE 1';

	InitGP(array('fid','page','ifopen'));
	$fid = (int)$fid; (int)$page<1 && $page = 1;
	if ($fid && Checkright($fids,$fid)) {
		$sqlwhere .= " AND fid='$fid'";
		switch ($fid) {
			case -1:
				$titledb[-1] = " (<a href=\"$basename\"><b>$lang[all_notice]</b></a> &raquo; $lang[whole_notice] &raquo; <a href=\"$basename&action=add&fid=$fid\"><b style=\"color:#0033FF\">$lang[add_notice]</b></a>)"; break;
			case -2:
				$titledb[-2] = " (<a href=\"$basename\"><b>$lang[all_notice]</b></a> &raquo; $lang[cms_notice] &raquo; <a href=\"$basename&action=add&fid=$fid\"><b style=\"color:#0033FF\">$lang[add_notice]</b></a>)"; break;
			default:
				$titledb[$fid] = " (<a href=\"$basename\"><b>$lang[all_notice]</b></a> &raquo; {$forum[$fid][name]} &raquo; <a href=\"$basename&action=add&fid=$fid\"><b style=\"color:#0033FF\">$lang[add_notice]</b></a>)";
		}
	} else {
		$namedb = $forum;
		$namedb[-1]['name'] = $lang['whole_notice'];
		$namedb[-2]['name'] = $lang['cms_notice'];
		if ($fids) {
			switch ($admin_gid) {
				case 5:
					$sqlwhere .= " AND fid IN ($fids)"; break;
				default:
					$sqlwhere .= " AND fid NOT IN ($fids)";
			}
		}
	}
	unset($forum);
	
	if (isset($_POST['ifopen'])) {
		$sqlwhere .= ' AND ifopen=';
		${'ifopen_'.$ifopen} = 'SELECTED';
		switch ($ifopen) {
			case 3:
				$sqlwhere .= "1 AND startdate>$timestamp"; break;//δ����
			case 2:
				$sqlwhere .= "1 AND enddate>0 AND enddate<$timestamp"; break;//�ѹ���
			case 1:
				$sqlwhere .= "1 AND startdate<=$timestamp AND (enddate=0 OR enddate>=$timestamp)"; break;//�ѷ���
			default:
				$sqlwhere .= '0';//�ѹر�
		}
	}

	Showoption($fid);
	$annoucedb = array();
	$query = $db->query("SELECT aid,fid,ifopen,vieworder,author,subject,startdate,enddate FROM pw_announce $sqlwhere ORDER BY fid,vieworder,startdate DESC LIMIT ".($page-1)*$db_perpage.",$db_perpage");
	while ($rt = $db->fetch_array($query)) {
		$rt['subject'] = htmlspecialchars(substrs($rt['subject'],30));
		$rt['starttime'] = $rt['startdate'] ? get_date($rt['startdate'],'Y-m-d H:i') : '--';
		$rt['endtime'] = $rt['enddate'] ? get_date($rt['enddate'],'Y-m-d H:i') : '--';
		$annoucedb[$rt['fid']][] = $rt;
	}
	$db->free_result($query);
	$count = $db->get_value("SELECT COUNT(*) FROM pw_announce $sqlwhere");
	if ($count > $db_perpage) {
		require_once(R_P.'require/forum.php');
		$addpage = $fid ? "fid=$fid&" : '';
		$pages = numofpage($count,$page,ceil($count/$db_perpage),"$basename&$addpage");
	}
	include PrintEot('notice');exit;
}
function GetForumdb(){
	global $admin_gid,$admin_name;
	if ($admin_gid==5) {
		list($fids,$forumcache) = GetAllowForum($admin_name);
		$cmscache = '';
	} else {
		include D_P.'data/bbscache/forumcache.php';
		list($fids,$hideforum) = GetHiddenForum();
		if ($admin_gid==3) {
			$fids = '';
			$forumcache .= $hideforum;
		}
		unset($hideforum);
		$cmscache = trim($cmscache);
	}
	return array($fids,$forumcache,$cmscache);
}
function Checkright($fids,$fid){
	global $admin_gid;
	if ($fids) {
		$strpos = strpos(",$fids,","$fid");
		if ($admin_gid==5 && $strpos===false) {
			return false;
		} elseif ($admin_gid!=5 && $strpos!==false) {
			return false;
		}
	}
	return true;
}
function Displayfid(){
	include(D_P.'data/bbscache/forum_cache.php');
	$ckdisplay = ',-1,';
	foreach ($forum as $value) {
		if ($value['type']=='category') {
			$ckdisplay .= "$value[fid],";
		}
	}
	return $ckdisplay;
}
function Showoption($fid){
	global $admin_gid,$forumcache,$cmscache,$lang;
	$admin_gid!=5 && $forumcache = "<option value=\"-1\">$lang[whole_notice]</option>$forumcache";
	if ($admin_gid==3 && $cmscache) {
		$forumcache .= "<option></option><option value=\"-2\">$lang[cms_notice]</option>$cmscache";
	}
	$fid && $forumcache = str_replace("\"$fid\"","\"$fid\" SELECTED",$forumcache);
}
function Datecheck($fid,$startdate,$enddate=null,$aid=null){
	global $db;
	!empty($enddate) && $startdate = $enddate;
	$sql_where = empty($aid) ? '' : "AND aid!='$aid'";
	$rt = $db->get_one("SELECT startdate,enddate FROM pw_announce WHERE fid='$fid' $sql_where ORDER BY vieworder,startdate DESC LIMIT 1");
	if ($rt['startdate']) {
		$rt['enddate'] && $rt['startdate'] = $rt['enddate'];
		if ($startdate<=$rt['startdate']) {
			return false;
		}
	}
	return true;
}
?>