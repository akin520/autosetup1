<?php
!function_exists('writeover') && exit('Forbidden');
require_once(R_P.'require/pw_func.php');

function updatecache($array=''){
	if(empty($array) || !is_array($array)){
		updatecache_i(1);
		if(R_P==D_P || !file_exists(D_P.'data/bbscache/config.php')||!file_exists(D_P.'data/bbscache/dbreg.php')){
			updatecache_c();
		}
		updatecache_p(1);
		updatecache_w();
		updatecache_sy();
		updatecache_g();
		updatecache_bk();
		updatecache_df();
		updatecache_cy();
		updatecache_ol();
		updatecache_mddb(1);
		//updatemedal_list();
		updatecache_ml();

		updatecache_f(1);
		updatecache_md(1);
		updatecache_l(1);
		updatecache_gr(1);

		updatecache_inv();
		updatecache_plan();
		updatecache_ftp();
		updatecache_field(1);
		updatecache_form();
		updatecache_help();
		cache_read();
	} else{
		foreach($array as $value){
			$value();
		}
	}
}
function updatecache_f($return=0) {
	global $db,$tplpath;
	updatecache_fd();
	$db->update("UPDATE pw_forums SET ifsub='0' WHERE type<>'sub'");
	$db->update("UPDATE pw_forums SET ifsub='1' WHERE type='sub'");
	$query	= $db->query("SELECT f.fid,f.fup,f.ifsub,f.type,f.name,f.style,f.f_type,f.cms,f.ifhide,fd.aid,fd.aids,fd.aidcache FROM pw_forums f LEFT JOIN pw_forumdata fd ON f.fid=fd.fid ORDER BY f.vieworder,f.fid");
	$catedb = $forumdb = $subdb1 = $subdb2 = $forum_cache = $fname= array();
	while ($forum = $db->fetch_array($query)) {
		$fname[$forum['fid']] = str_replace(array("\\","'",'<','>'),array("\\\\","\'",'&lt;','&gt;'), strip_tags($forum['name']));
		if ($forum['type'] == 'category') {
			$catedb[] = $forum;
		} elseif ($forum['type']=='forum') {
			$forumdb[$forum['fup']] || $forumdb[$forum['fup']] = array();
			$forumdb[$forum['fup']][] = $forum;
		} else {
			$sub = $db->get_one("SELECT type FROM pw_forums WHERE fid='$forum[fup]'");
			if ($sub['type'] == 'forum') {
				$subdb1[$forum['fup']] || $subdb1[$forum['fup']] = array();
				$subdb1[$forum['fup']][] = $forum;
			} else {
				$subdb2[$forum['fup']] || $subdb2[$forum['fup']] = array();
				$subdb2[$forum['fup']][] = $forum;
			}
		}
	}
	$forumcache = '';
	foreach ($catedb as $cate) {
		if (!$cate) continue;
		$forum_cache[$cate['fid']] = $cate;

		if ($cate['cms']) {
			$cmscache .= "<option value=\"$cate[fid]\">>> {$fname[$cate[fid]]}</option>\r\n";
		} elseif ($cate['f_type']!='hidden') {
			$forumcache .= "<option value=\"$cate[fid]\">>> {$fname[$cate[fid]]}</option>\r\n";
		}
		if (!$forumdb[$cate['fid']]) continue;

		foreach ($forumdb[$cate['fid']] as $forum) {
			$forum_cache[$forum['fid']] = $forum;
			
			if ($forum['cms']) {
				$cmscache .= "<option value=\"$forum[fid]\"> &nbsp;|- {$fname[$forum[fid]]}</option>\r\n";
			} elseif ($forum['f_type']!='hidden') {
				$forumcache .= "<option value=\"$forum[fid]\"> &nbsp;|- {$fname[$forum[fid]]}</option>\r\n";
			}
			if (!$subdb1[$forum['fid']]) continue;

			foreach ($subdb1[$forum['fid']] as $sub1) {
				$forum_cache[$sub1['fid']] = $sub1;

				if ($sub1['cms']) {
					$cmscache .= "<option value=\"$sub1[fid]\"> &nbsp; &nbsp;|-  {$fname[$sub1[fid]]}</option>\r\n";
				} elseif ($sub1['f_type']!='hidden') {
					$forumcache .= "<option value=\"$sub1[fid]\"> &nbsp; &nbsp;|-  {$fname[$sub1[fid]]}</option>\r\n";
				}
				if (!$subdb2[$sub1['fid']]) continue;

				foreach ($subdb2[$sub1['fid']] as $sub2) {
					$forum_cache[$sub2['fid']] = $sub2;

					if ($sub2['cms']) {
						$cmscache .= "<option value=\"$sub2[fid]\">&nbsp;&nbsp; &nbsp; &nbsp;|-  {$fname[$sub2[fid]]}</option>\r\n";
					} elseif ($sub2['f_type']!='hidden') {
						$forumcache .= "<option value=\"$sub2[fid]\">&nbsp;&nbsp; &nbsp; &nbsp;|-  {$fname[$sub2[fid]]}</option>\r\n";
					}
				}
			}
		}
	}
	$forum_cache = "\$forum=".pw_var_export($forum_cache).";";
	$forumcache  = "\$forumcache='\r\n$forumcache';\r\n\$cmscache='\r\n$cmscache';";
	writeover(D_P."data/bbscache/forumcache.php","<?php\r\n".$forumcache."\r\n?>");
	writeover(D_P.'data/bbscache/forum_cache.php',"<?php\r\n".$forum_cache."\r\n?>");
	$cache = addslashes($forum_cache."\r\n".$forumcache);
	$db->pw_update(
		"SELECT * FROM pw_cache WHERE name='forum_cache'",
		"UPDATE pw_cache SET cache='$cache' WHERE name='forum_cache'",
		"INSERT INTO pw_cache(name,cache) VALUES('forum_cache','$cache')"
	);
	if (empty($return)) {
		cache_read();
	}
}
function updatecache_fd() {
	global $db;
	$db->update("UPDATE pw_forums SET childid='0',fupadmin=''");
	$query = $db->query("SELECT fid,forumadmin FROM pw_forums WHERE type='category' ORDER BY vieworder");
	while ($cate = $db->fetch_array($query)) {
		Add_S($cate);
		$query2 = $db->query("SELECT fid,forumadmin FROM pw_forums WHERE type='forum' AND fup='$cate[fid]'");
		if ($db->num_rows($query2)) {
			$havechild[] = $cate['fid'];
			while ($forum = $db->fetch_array($query2)) {
				Add_S($forum);
				$fupadmin = trim($cate['forumadmin']);
				if ($fupadmin) {
					$db->update("UPDATE pw_forums SET fupadmin='$fupadmin' WHERE fid='$forum[fid]'");
				}
				if (trim($forum['forumadmin'])) {
					$fupadmin .= $fupadmin ? substr($forum['forumadmin'],1) : $forum['forumadmin']; //is
				}
				$query3 = $db->query("SELECT fid,forumadmin FROM pw_forums WHERE type='sub' AND fup='$forum[fid]'");
				if ($db->num_rows($query3)) {
					$havechild[] = $forum['fid'];
					while ($sub1 = $db->fetch_array($query3)) {
						Add_S($sub1);
						$fupadmin1 = $fupadmin;
						if ($fupadmin1) {
							$db->update("UPDATE pw_forums SET fupadmin='$fupadmin1' WHERE fid='$sub1[fid]'");
						}
						if (trim($sub1['forumadmin'])) {
							$fupadmin1 .= $fupadmin1 ? substr($sub1['forumadmin'],1) : $sub1['forumadmin'];
						}
						$query4 = $db->query("SELECT fid,forumadmin FROM pw_forums WHERE type='sub' AND fup='$sub1[fid]'");
						if ($db->num_rows($query4)) {
							$havechild[] = $sub1['fid'];
							while ($sub2 = $db->fetch_array($query4)) {
								Add_S($sub2);
								$fupadmin2 = $fupadmin1;
								if ($fupadmin2) {
									$db->update("UPDATE pw_forums SET fupadmin='$fupadmin2' WHERE fid='$sub2[fid]'");
								}
							}
						}
					}
				}
			}
		}
	}
	if ($havechild) {
		$havechilds = implode(',',$havechild);
		$db->update("UPDATE pw_forums SET childid='1' WHERE fid IN($havechilds)");
	}
}

/**
* ���¹��滺��,�����������ӻ���
*/
function updatecache_i($return=0){
	global $db,$db_windpost,$timestamp;
	//���沿��
	require_once(R_P.'require/bbscode.php');
	@include(D_P.'data/bbscache/forum_cache.php');
	$db->update("UPDATE pw_forumdata SET aid='0',aids='',aidcache='0'");
	$db->update("UPDATE pw_announce SET ifconvert='0' WHERE ifconvert!='0'");
	$num = 0;
	$sharelink = $notice_A = $notice_C = $C_cfid = $F_ffid = $F_fid = $cachedb = $cachetype = $newforum = array();
	$query = $db->query("SELECT aid,fid,author,startdate,enddate,url,subject,content FROM pw_announce WHERE ifopen='1' AND (enddate=0 OR enddate>=$timestamp) ORDER BY vieworder,startdate DESC");
	while ($rt = $db->fetch_array($query)) {
		if ($rt['fid']==-1) {
			if ($rt['startdate']<=$timestamp) {
				$num++;
			}else{
				continue;
			}
			$rt['subject'] = substrs($rt['subject'],65);
			$notice_A[$rt['aid']] = array(
				'aid' => $rt['aid'],
				'author' => $rt['author'],
				'startdate' => $rt['startdate'],
				'enddate' => $rt['enddate'],
				'subject' => $rt['subject'],
				'url' => $rt['url']
			);
		} elseif (!$forum[$rt['fid']]['cms'] && $forum[$rt['fid']]['type']=='category') {
			if ($rt['startdate']<=$timestamp) {
				if ($C_cfid[$rt['fid']]) {
					continue;
				} elseif (!$rt['enddate']) {
					$C_cfid[$rt['fid']] = true;
				}
			}
			$rt['subject'] = substrs($rt['subject'],65);
			$notice_C[$rt['fid']][$rt['aid']] = array(
				'aid' => $rt['aid'],
				'fid' => $rt['fid'],
				'author' => $rt['author'],
				'startdate' => $rt['startdate'],
				'enddate' => $rt['enddate'],
				'subject' => $rt['subject'],
				'url' => $rt['url']
			);
		} elseif ($rt['fid']!=-2) {
			if ($rt['startdate']<=$timestamp) {
				if ($F_ffid[$rt['fid']]) {
					continue;
				} elseif (!$rt['enddate']) {
					$F_ffid[$rt['fid']] = true;
				}
			}
			if (!$F_fid[$rt['fid']]['aid'] && $rt['startdate']<=$timestamp && (!$rt['enddate'] || $rt['enddate']>=$timestamp)) {
				$F_fid[$rt['fid']]['aid'] = $rt['aid'];
				if ($rt['content']!=convert($rt['content'],$db_windpost,2)) {
					$db->update("UPDATE pw_announce SET ifconvert='1' WHERE aid='$rt[aid]'");
				}
			} else {
				$F_fid[$rt['fid']]['aids'] .= ",$rt[aid]";
			}
		}
	}
	foreach ($forum as $key => $value) {
		$value['aids'] = '';
		$value['aid'] = $value['aidcache'] = 0;
		$update = false;
		if ((int)$F_fid[$key]['aid']>0) {
			$update = true;
			$value['aid'] = $F_fid[$key]['aid'];
		}
		if ($F_fid[$key]['aids']) {
			$update = true;
			$value['aids'] = substr($F_fid[$key]['aids'],1);
			$value['aidcache'] = $timestamp;
		}
		$update && $db->update("UPDATE pw_forumdata SET aid='{$value[aid]}',aids='{$value[aids]}',aidcache='{$value[aidcache]}' WHERE fid='$key'");
		$newforum[$key] = $value;
	}
	//�������Ӳ���
	$sharelogo = $sharetext = '';
	$query = $db->query("SELECT threadorder,name,url,descrip,logo FROM pw_sharelinks WHERE ifcheck=1 ORDER BY threadorder");
	while ($rt = $db->fetch_array($query)) {
		if ($rt['threadorder']<0) {
			$sharelink[0][] = ($rt['logo'] ? "<div class=\"fl\"><a href=\"$rt[url]\"><img src=\"$rt[logo]\" width=\"88\" height=\"31\" /></a></div>" : '')."<div><a href=\"$rt[url]\" target=\"_blank\">$rt[name]</a><br />$rt[descrip]</div>";
		} elseif ($rt['logo']) {
			$sharelogo .= "<a href=\"$rt[url]\" target=\"_blank\"><img src=\"$rt[logo]\" alt=\"$rt[descrip]\" width=\"88\" height=\"31\"></a> ";
		} else {
			$sharetext .= "<a href=\"$rt[url]\" target=\"_blank\" title=\"$rt[descrip]\">[$rt[name]]</a> ";
		}
	}
	if ($sharelogo || $sharetext) {
		$brtags = $sharelogo && $sharetext ? '<br />' : '';
		$sharelink[1] = rtrim($sharelogo).$brtags.rtrim($sharetext);
	} else {
		$sharelink[1] = '';
	}
	//����ϵͳ����+��������
	$cachetype['index_cache'] = "\$notice_A=".pw_var_export($notice_A).";\r\n\$sharelink=".pw_var_export($sharelink).";";
	writeover(D_P.'data/bbscache/index_cache.php',"<?php\r\n{$cachetype[index_cache]}\r\n?>");
	//���·��๫��
	$cachetype['thread_announce'] = "\$notice_A=".pw_var_export($notice_A).";\r\n\$notice_C=".pw_var_export($notice_C).";";
	writeover(D_P.'data/bbscache/thread_announce.php',"<?php\r\n{$cachetype[thread_announce]}\r\n?>");
	//���°��
	if ($newforum!=$forum) {
		$cachetype['forum_cache'] = "\$forum=".pw_var_export($newforum).";";
		writeover(D_P.'data/bbscache/forum_cache.php',"<?php\r\n{$cachetype[forum_cache]}\r\n?>");
		@include(D_P.'data/bbscache/forumcache.php');
		$cachetype['forum_cache'] .= "\r\n\$forumcache='".str_replace(array("\\","'"),array("\\\\","\'"),$forumcache)."';\r\n\$cmscache='".str_replace(array("\\","'"),array("\\\\","\'"),$cmscache)."';";
		$sql_in = ",'forum_cache'";
	} else {
		$sql_in = '';
	}
	//���»������ݿ�
	$query = $db->query("SELECT name FROM pw_cache WHERE name IN('index_cache','thread_announce'$sql_in)");
	while ($rt = $db->fetch_array($query,MYSQL_NUM)) {
		$cachedb[] = $rt[0];
	}
	$db->free_result($query);
	foreach ($cachetype as $key => $value) {
		if (in_array($key,$cachedb)) {
			$db->update("UPDATE pw_cache SET cache='".addslashes($value)."' WHERE name='$key'");
		} else {
			$db->update("INSERT INTO pw_cache(name,cache) VALUES ('$key','".addslashes($value)."')");
		}
	}
	if (empty($return)) {
		cache_read();
	}
}
/**
* �����û��黺��
*/
function updatecache_g($gid='A'){
	global $db;
	if ($gid == 'A') {
		$query = $db->query("SELECT * FROM pw_usergroups WHERE ifdefault='0' OR gid='1'");
		while ($group = $db->fetch_array($query)) {
			updatecache_gp($group);
		}
	} else {
		$group = $db->get_one("SELECT * FROM pw_usergroups WHERE gid='$gid'");
		updatecache_gp($group);
	}
}

function updatecache_gp($group){

	$groupcache = "<?php\r\n";
	$sysstart = 0;
	$sysdb = array();
	foreach ($group as $key => $value) {
		if ($sysstart == 0) {
			if ($key == 'mright') {
				$mright = P_unserialize($value);
				!is_array($mright) && $mright = array();
				$groupcache .= "\$_G=".pw_var_export($mright).";\r\n";
			} else {
				$groupcache .= "\$gp_$key=".pw_var_export($value).";\r\n";
			}
		} else {
			if ($group['gptype']=='member' || $group['gptype']=='default') break;

			if ($key == 'sright') {
				$sright = P_unserialize($value);
				!is_array($sright) && $sright = array();
				$sysdb = array_merge($sysdb,$sright);
			} else {
				$sysdb[$key] = $value;
			}
		}
		if ($key == 'ifdefault') $sysstart = 1;
	}
	$groupcache = $groupcache."\r\n\r\n\$SYSTEM=".pw_var_export($sysdb).";\r\n?>";
	writeover(D_P."data/groupdb/group_$group[gid].php",$groupcache);
}
function updatecache_gr($return=0) {
	global $db;
	$gpright = array();
	$query = $db->query("SELECT gid,mright FROM pw_usergroups ORDER BY gid");
	while ($rt = $db->fetch_array($query)) {
		$mright = P_unserialize($rt['mright']);
		if (is_array($mright)) {
			$gpright[$rt['gid']] = array(
				'imgwidth' => $mright['imgwidth'],
				'imgheight' => $mright['imgheight'],
				'fontsize' => $mright['fontsize']
			);
		}
	}
	$gpright = "\$gp_right=".pw_var_export($gpright).";";
	writeover(D_P."data/bbscache/gp_right.php","<?php\r\n{$gpright}\r\n?>");
	$cache = addslashes($gpright);
	$db->pw_update(
		"SELECT * FROM pw_cache WHERE name='gp_right'",
		"UPDATE pw_cache SET cache='$cache' WHERE name='gp_right'",
		"INSERT INTO pw_cache(name,cache) VALUES('gp_right','$cache')"
	);
	if (empty($return)) {
		cache_read();
	}
}
/**
* �����û��ȼ�����
*/
function updatecache_l($return=0){
	global $db;
	$query = $db->query("SELECT gid,gptype,grouptitle,groupimg,grouppost FROM pw_usergroups ORDER BY grouppost,gid");
	$defaultdb = "\$ltitle=\$lpic=\$lneed=array();\r\n/**\r\n* default\r\n*/\r\n";
	$sysdb = "\r\n/**\r\n* system\r\n*/\r\n";
	$vipdb = "\r\n/**\r\n* special\r\n*/\r\n";
	$memdb = "\r\n/**\r\n* member\r\n*/\r\n";
	while (@extract($db->fetch_array($query))) {
		$gid = (int)$gid;
		if ($gptype=='member') {
			$memdb.="\$ltitle[$gid]=".pw_var_export($grouptitle).";\t\t\$lpic[$gid]=".pw_var_export($groupimg). ";\t\t\$lneed[$gid]=".pw_var_export($grouppost).";\r\n";
		} elseif ($gptype=='special') {
			$vipdb.="\$ltitle[$gid]=".pw_var_export($grouptitle).";\t\t\$lpic[$gid]=".pw_var_export($groupimg). ";\r\n";
		} elseif ($gptype=='system') {
			$sysdb .= "\$ltitle[$gid]=".pw_var_export($grouptitle).";\t\t\$lpic[$gid]=".pw_var_export($groupimg). ";\r\n";
		} elseif ($gptype=='default') {
			$defaultdb .= "\$ltitle[$gid]=".pw_var_export($grouptitle).";\t\t\$lpic[$gid]=". pw_var_export($groupimg).";\r\n";
		}
	}
	writeover(D_P.'data/bbscache/level.php',"<?php\r\n".$defaultdb.$sysdb.$vipdb.$memdb."\r\n?>");
	$cache = addslashes($defaultdb.$sysdb.$vipdb.$memdb);
	$db->pw_update(
		"SELECT * FROM pw_cache WHERE name='level'",
		"UPDATE pw_cache SET cache='$cache' WHERE name='level'",
		"INSERT INTO pw_cache(name,cache) VALUES('level','$cache')"
	);
	if (empty($return)) {
		cache_read();
	}
}
/**
* ���º��������黺��
*/
function updatecache_c(){
	global $db;
	$query = $db->query("SELECT db_name,db_value FROM pw_config");
	$configdb = $regdb = "<?php\r\n";
	while (@extract($db->fetch_array($query))) {
		$db_name = key_cv($db_name);
		if (in_array($db_name,array('db_hackdb','db_question','db_answer','db_questions','rg_regcredit','db_windpost','db_windreply','db_windpic'))) {
			if (!is_array($db_value = unserialize($db_value))) {
				$db_value = array();
			}
		}
		if (strpos($db_name,'db_')!==false) {
			$configdb .= "\$$db_name=".pw_var_export($db_value).";\r\n";
		} elseif (strpos($db_name,'rg_')!==false) {
			$regdb .= "\$$db_name=".pw_var_export($db_value).";\r\n";
		}
	}
	$creditdb = $advertdb = array();
	$query	  = $db->query("SELECT * FROM pw_modules WHERE type=6 AND state=1 ORDER BY vieworder");
	while($rt = $db->fetch_array($query)){
		$ad   = array();
		$code = $style = '';
		$conf = unserialize($rt['config']);
		if ($conf['style'] == 'code') {
			$code = $conf['htmlcode'];
		} elseif ($conf['style'] == 'txt') {
			if($conf['color']){
				$style .= "color:$conf[color];";
			}
			if($conf['size']){
				$style .= "font-size:$conf[size];";
			}
			if($style){
				$style = " style=\"$style\"";
			}
			$code = "<a href=\"$conf[link]\" target=\"_blank\"{$style}>$conf[title]</a>";
		} elseif ($conf['style'] == 'img') {
			if($conf['width']){
				$style .= " width=\"$conf[width]\"";
			}
			if($conf['height']){
				$style .= " height=\"$conf[height]\"";
			}
			if($conf['descrip']){
				$style .= " alt=\"$conf[descrip]\"";
			}
			$code = "<a href=\"$conf[link]\" target=\"_blank\"><img src=\"$conf[url]\"{$style}></a>";
		} elseif ($conf['style'] == 'flash') {
			if($conf['width']){
				$style .= " width=\"$conf[width]\"";
			}
			if($conf['height']){
				$style .= " height=\"$conf[height]\"";
			}
			$code = "<embed{$style} src=\"$conf[link]\" type=\"application/x-shockwave-flash\"></embed>";
		}
		if ($rt['varname'] == 'popup') {
			$conf['height']= (int) $conf['height'];
			$conf['width'] = (int) $conf['width'];
			$conf['close'] = (int) $conf['close'];
			$code = array($conf['title'],$code,$conf['height'],$conf['width'],$conf['close']);
		} elseif ($rt['varname'] == 'article') {
			$ad['lou']		= $conf['lou'];
			$ad['position'] = $conf['position'];
		}
		$ad['starttime'] = PwStrtoTime($conf['starttime']);
		$ad['endtime']	 = PwStrtoTime($conf['endtime']);
		$ad['fid']		 = $conf['fid'];
		$ad['descrip']	 = $conf['descrip'];
		$ad['link']	     = $conf['link'];
		$ad['code']		 = $code;
		$advertdb[$rt['varname']][] = $ad;
	}
	$configdb .= "\$db_advertdb=".pw_var_export($advertdb).";\r\n";

	$query = $db->query("SELECT * FROM pw_credits");
	while ($rt = $db->fetch_array($query)) {
		$creditdb[$rt['cid']] = array($rt['name'],$rt['unit'],$rt['description']);
	}
	$configdb .= "\$_CREDITDB=".pw_var_export($creditdb).";\r\n?>";
	$regdb .= "?>";
	writeover(D_P.'data/bbscache/config.php',$configdb);
	writeover(D_P.'data/bbscache/dbreg.php',$regdb);
}

/**
* ���·�񻺳�
*/
function updatecache_sy($name=''){
	global $db,$db_picpath;
	$imgpath = '../../'.$db_picpath;

	$name != '' && $sqlwhere="WHERE name='$name'";
	$query = $db->query("SELECT * FROM pw_styles $sqlwhere");
	while (@extract($db->fetch_array($query))) {
		$stylecontent = "<?php
\$stylepath = ".pw_var_export($stylepath).";
\$tplpath = ".pw_var_export($tplpath).";
\$yeyestyle = ".pw_var_export($yeyestyle).";
\$bgcolor = ".pw_var_export($bgcolor).";
\$linkcolor = ".pw_var_export($linkcolor).";
\$tablecolor = ".pw_var_export($tablecolor).";
\$tdcolor = ".pw_var_export($tdcolor).";
\$tablewidth = ".pw_var_export($tablewidth).";
\$mtablewidth = ".pw_var_export($mtablewidth).";
\$headcolor	= ".pw_var_export($headcolor).";
\$headborder = ".pw_var_export($headborder).";
\$headfontone = ".pw_var_export($headfontone).";
\$headfonttwo = ".pw_var_export($headfonttwo).";
\$cbgcolor = ".pw_var_export($cbgcolor).";
\$cbgborder = ".pw_var_export($cbgborder).";
\$cbgfont = ".pw_var_export($cbgfont).";
\$forumcolorone	= ".pw_var_export($forumcolorone).";
\$forumcolortwo	= ".pw_var_export($forumcolortwo).";
\$extcss = ".pw_var_export($extcss).";
\?>";
		$style_css = explode('<!--css-->',readover(D_P."data/style/{$tplpath}_css.htm"));
		$style_css = addslashes(str_replace(array('<style type="text/css">','</style>'),'',$style_css[1]));
		eval("\$style_css = \"$style_css\";");
		writeover(D_P."data/bbscache/$tplpath.css",$style_css);
		writeover(D_P."data/style/$name.php",str_replace("\?>","?>",$stylecontent));
	}
}
/**
* ���¶������黺��
*/
function updatecache_p($return=0){
	global $db;
	$faces="\$faces=array(\r\n"; //������
	$face="\$face=array(\r\n"; //����
	$jsface="var face=new Array();\n";
	$jsfaces="var faces=new Array();\n";
	$jsfacedb="var facedb=new Array();\n";

	$count=0;
	@extract($db->get_one("SELECT db_value AS fc_shownum FROM pw_config WHERE db_name='fc_shownum'"));
	$rs = $db->query("SELECT * FROM pw_smiles WHERE type=0 ORDER BY vieworder");
	while (@extract(db_cv($db->fetch_array($rs)))) {
		if ($count==0) {
			$jsdefault="var defaultface='$path';\nvar fc_shownum='$fc_shownum';\n\n";
			$count=1;
		}
		$faces.="\t'$path'=>array(\r\n";
		$faces.="\t\t'name'=>'$name',\r\n";
		$faces.="\t\t'child'=>array(";
		$jsfaces.="faces['$path'] = [";
		$jsfacedb.="facedb['$path'] = '$name';\n";
		$query = $db->query("SELECT * FROM pw_smiles WHERE type='$id' ORDER BY vieworder");
		while ($smile = db_cv($db->fetch_array($query))) {
			$face.="\t'$smile[id]'=>array('$path/$smile[path]','$smile[name]','$smile[descipt]'),\r\n";
			$faces.="'$smile[id]',";
			$jsface.="face[$smile[id]]=['$path/$smile[path]','$smile[name]'];\n";
			$jsfaces.="$smile[id],";
		}
		$faces.="),\r\n";
		$faces.="\t),\r\n";
		$jsfaces.="];\n";
	}
	$faces.=");\r\n";
	$face.=");";
	writeover(D_P."data/bbscache/face.js",$jsdefault.$jsfacedb."\n".$jsface."\n".$jsfaces);
	writeover(D_P."data/bbscache/postcache.php","<?php\r\n".$faces.$face."\r\n?>");

	$cache = addslashes($faces.$face);
	$db->pw_update(
		"SELECT * FROM pw_cache WHERE name='postcache'",
		"UPDATE pw_cache SET cache='$cache' WHERE name='postcache'",
		"INSERT INTO pw_cache(name,cache) VALUES('postcache','$cache')"
	);
	if(empty($return)){
		cache_read();
	}
}
/**
* ���½��ô��ﻺ��
*/
function updatecache_w(){
	global $db;
	$writeinfo = "<?php";
	$replace = $wordsfb = $alarm = $pwcode  = array();
	$query = $db->query("SELECT * FROM pw_wordfb");
	while (@extract($db->fetch_array($query))) {
		if ($word) {
			$word = preg_quote($word,'/');
			if ($type == 0) {
				$replace[$word] = $wordreplace;
			} elseif ($type==1) {
				$wordsfb[$word] = $wordreplace;
			} else {
				$alarm[$word] = $wordreplace;
			}
		}
	}
	$regxp = array('([^\(&]+?)','(\w+)','(\d+)');
	$query = $db->query("SELECT name,pattern,replacement,param FROM pw_windcode");
	while (@extract($db->fetch_array($query))) {
		list($o,$t,$s) = explode("\t",$pattern);
		$name = preg_quote($name,'/');
		if ($param==2) {
			$pwcode['searcharray'][] = "/\[$name=$regxp[$o]\]$regxp[$t]\[\/$name\]/is";
		} elseif ($param==3) {
			$pwcode['searcharray'][] = "/\[$name=$regxp[$o],$regxp[$t]\]$regxp[$s]\[\/$name\]/is";
		} else {
			$pwcode['searcharray'][] = "/\[$name\]$regxp[$o]\[\/$name\]/is";
		}
		$pwcode['replacearray'][] = preg_replace('/\{(\d+)\}/i','\\\\\\1',$replacement);
	}
	$writeinfo .= "\r\n\$replace=".pw_var_export($replace).";";
	$writeinfo .= "\r\n\$wordsfb=".pw_var_export($wordsfb).";";
	$writeinfo .= "\r\n\$alarm=".pw_var_export($alarm).";";
	$writeinfo .= "\r\n\$pwcode=".pw_var_export($pwcode).";";
	writeover(D_P."data/bbscache/wordsfb.php",$writeinfo."\r\n?>");
}
function updatecache_bk(){
	global $db;
	$query=$db->query("SELECT * FROM pw_hack WHERE hk_name LIKE 'bk_%'");
	$configdb="<?php\r\n";
	while (@extract($db->fetch_array($query))) {
		$hk_name = key_cv($hk_name);
		$configdb.="\$$hk_name=".pw_var_export($hk_value).";\r\n";
	}
	$configdb.="?>";
	writeover(D_P.'data/bbscache/bk_config.php',$configdb);
}
function updatecache_df(){
	global $db;
	$query = $db->query("SELECT * FROM pw_config WHERE db_name LIKE 'df_%'");
	$configdb = "<?php\r\n";
	$_cachedb = $_newdb = $_cmsdb = $_fiddb = $_forumlogodb = array();

	while (@extract($db->fetch_array($query))) {
		$db_name = key_cv($db_name);
		if ($db_name == 'df_cache') {
			$db_value = P_unserialize($db_value);
			if (is_array($db_value)) {
				foreach ($db_value as $key=>$value) {
					$_cachedb[$key] = array(trim($value[0]),trim($value[1]));
				}
			}
		} elseif ($db_name == 'df_NEW') {
			$db_value = P_unserialize($db_value);
			if (is_array($db_value)) {
				foreach ($db_value as $value) {
					$_newdb[] = $value;
				}
			}
		} elseif ($db_name=='df_CMS') {
			$db_value = P_unserialize($db_value);
			if (is_array($db_value)) {
				foreach ($db_value as $value) {
					$_cmsdb[] = $value;
				}
			}
		} elseif ($db_name=='df_FID') {
			$db_value = P_unserialize($db_value);
			if (is_array($db_value)) {
				foreach ($db_value as $value) {
					$_fiddb[] = $value;
				}
			}
		} elseif ($db_name=='df_forumlogo') {
			$db_value = P_unserialize($db_value);
			if (is_array($db_value)) {
				foreach($db_value as $key => $value){
					if ($value[0]) {
						$_forumlogodb[$key] = array($value[0],$value[1],$value[2],$value[3]);
					}
				}
			}
		} else {
			$configdb .= "\$$db_name=".pw_var_export($db_value).";\r\n";
		}
	}
	$configdb .= "\r\n\$df_cache=".pw_var_export($_cachedb).";\r\n";
	$configdb .= "\r\n\$df_NEW=".pw_var_export($_newdb).";\r\n";
	$configdb .= "\r\n\$df_CMS=".pw_var_export($_cmsdb).";\r\n";
	$configdb .= "\r\n\$df_FID=".pw_var_export($_fiddb).";\r\n";
	$configdb .= "\r\n\$df_forumlogo=".pw_var_export($_forumlogodb).";\r\n";
	$configdb .= "?>";
	writeover(D_P.'data/bbscache/c_config.php',$configdb);
}
function updatecache_cy(){
	global $db;
	$query = $db->query("SELECT * FROM pw_hack WHERE hk_name LIKE 'cn\_%'");
	$colonydb = "<?php\r\n";
	while (@extract($db->fetch_array($query))) {
		$hk_name = key_cv($hk_name);
		$colonydb .= "\$$hk_name=".pw_var_export($hk_value).";\r\n";
	}
	$colonydb .= "\n?>";
	writeover(D_P.'data/bbscache/cn_config.php', $colonydb);
}

function updatecache_inv(){
	global $db;
	$query = $db->query("SELECT * FROM pw_hack WHERE hk_name LIKE 'inv_%'");
	$invdb = "<?php\r\n";
	while (@extract($db->fetch_array($query))) {
		$hk_name = key_cv($hk_name);
		$invdb .="\$$hk_name=".pw_var_export($hk_value).";\r\n";
	}
	$invdb .="\n?>";
	writeover(D_P.'data/bbscache/inv_config.php', $invdb);
}
function updatecache_ol(){
	global $db;
	$onlinedb = "<?php\r\n";
	$query = $db->query("SELECT * FROM pw_config WHERE db_name LIKE 'ol_%'");
	while (@extract($db->fetch_array($query))) {
		$db_name   = key_cv($db_name);
		$onlinedb .= "\$$db_name=".pw_var_export($db_value).";\r\n";
	}
	$onlinedb .= "?>";
	writeover(D_P.'data/bbscache/ol_config.php',$onlinedb);
}
function updatecache_md($return=0){
	global $db;
	$medaldb='';
	$query = $db->query("SELECT * FROM pw_hack WHERE hk_name LIKE 'md\_%'");
	while (@extract($db->fetch_array($query))) {
		$hk_name = key_cv($hk_name);
		$medaldb.="\$$hk_name=".pw_var_export($hk_value).";\r\n";
	}
	writeover(D_P.'data/bbscache/md_config.php',"<?php\r\n".$medaldb."\r\n?>");
	$cache = addslashes($medaldb);
	$db->pw_update(
		"SELECT * FROM pw_cache WHERE name='md_config'",
		"UPDATE pw_cache SET cache='$cache' WHERE name='md_config'",
		"INSERT INTO pw_cache(name,cache) VALUES('md_config','$cache')"
	);
	if (empty($return)) {
		cache_read();
	}
}
function updatecache_mddb($return=0){
	global $db;
	$medaldb = array();
	$query = $db->query("SELECT * FROM pw_medalinfo ORDER BY id");
	while ($rt = $db->fetch_array($query)) {
		$medaldb[$rt['id']] = $rt;
	}
	$medaldb = "\$_MEDALDB=".pw_var_export($medaldb).";";
	writeover(D_P.'data/bbscache/medaldb.php',"<?php\r\n".$medaldb."\r\n?>");
	$cache = addslashes($medaldb);
	$db->pw_update(
		"SELECT * FROM pw_cache WHERE name='medaldb'",
		"UPDATE pw_cache SET cache='$cache' WHERE name='medaldb'",
		"INSERT INTO pw_cache(name,cache) VALUES('medaldb','$cache')"
	);
	if (empty($return)) {
		cache_read();
	}
}
function updatecache_plan(){
	global $db;
	$plandb = $plantime = array();
	$query = $db->query("SELECT id,month,week,day,hour,nexttime,filename FROM pw_plan WHERE ifopen='1' ORDER BY id");
	while ($rt = $db->fetch_array($query)) {
		$plantime[] = $rt['nexttime'];
		$plandb[$rt['id']] = $rt;
	}
	writeover(D_P.'data/bbscache/plandb.php',"<?php\r\n\$plandb=".pw_var_export($plandb).";\r\n?>");
	rsort($plantime);
	$plantime = array_pop($plantime);
	$db->update("UPDATE pw_bbsinfo SET plantime='$plantime' WHERE id='1'");
}
function updatemedal_list(){
	global $db;
	$query   = $db->query("SELECT uid,medals FROM pw_members WHERE medals!=''");
	$medaldb = '<?php die;?>0';
	while ($rt = $db->fetch_array($query)) {
		if (str_replace(',','',$rt['medals'])) {
			$medaldb .= ','.$rt['uid'];
		}
	}
	writeover(D_P.'data/bbscache/medals_list.php',$medaldb);
}
function updatecache_ml(){
	global $db;
	$maildb	= '';
	$query	= $db->query("SELECT * FROM pw_config WHERE db_name LIKE 'ml\_%'");
	while (@extract($db->fetch_array($query))) {
		$db_name = key_cv($db_name);
		$maildb	.= "\$$db_name=".pw_var_export($db_value).";\r\n";
	}
	writeover(D_P.'data/bbscache/mail_config.php',"<?php\r\n".$maildb."?>");
}
function updatecache_ftp(){
	global $db;
	$ftpdb	= '';
	$query	= $db->query("SELECT * FROM pw_config WHERE db_name LIKE 'ftp\_%'");
	while (@extract($db->fetch_array($query))) {
		$db_name = key_cv($db_name);
		$ftpdb	.= "\$$db_name=".pw_var_export($db_value).";\r\n";
	}
	writeover(D_P.'data/bbscache/ftp_config.php',"<?php\r\n".$ftpdb."?>");
}
function updatecache_field($return=0){
	global $db;
	$customfield=array();
	$query = $db->query("SELECT * FROM pw_customfield WHERE state='1' ORDER BY vieworder");
	while ($rt = $db->fetch_array($query)) {
		$customfield[] = $rt;
	}
	$cachedb = "\$customfield=".pw_var_export($customfield).";";
	writeover(D_P.'data/bbscache/customfield.php',"<?php\r\n".$cachedb."\r\n?>");
	$cache = addslashes($cachedb);
	$db->pw_update(
		"SELECT * FROM pw_cache WHERE name='customfield'",
		"UPDATE pw_cache SET cache='$cache' WHERE name='customfield'",
		"INSERT INTO pw_cache(name,cache) VALUES('customfield','$cache')"
	);
	if (empty($return)) {
		cache_read();
	}
}
function updatecache_form(){
	global $db;
	$rs = $db->query("SELECT id,name,value FROM pw_setform WHERE ifopen='1'");
	$setform = "<?php\n\$setformdb=array(\n";
	while ($rt = $db->fetch_array($rs)) {
		$rt['value'] = unserialize($rt['value']);
		$setformdb[$rt['id']] = $rt;
	}
	$setformdb = "\$setformdb=".pw_var_export($setformdb).";\r\n";
	writeover(D_P.'data/bbscache/setform.php',"<?php\r\n".$setformdb."?>");
}
function updatecache_help(){
	global $db;
	$db->update("UPDATE pw_help SET lv='0',fathers='' WHERE hup='0'");
	$ifchilds = '';
	$_HELP = $gorydb = $subdb = array();
	$query = $db->query('SELECT hid,hup,lv,fathers,ifchild,title,url,content,vieworder FROM pw_help ORDER BY vieworder,hid');
	while ($rt = $db->fetch_array($query)) {
		$rt['ifcontent'] = $rt['content'] ? 1 : 0;
		if (!$rt['hup']) {
			$gorydb[] = array('hid' => $rt['hid'],'hup' => $rt['hup'],'lv' => $rt['lv'],'fathers' => $rt['fathers'],'ifchild' => $rt['ifchild'],'title' => $rt['title'],'vieworder' => $rt['vieworder'],'ifcontent' => $rt['ifcontent'],'url' => $rt['url']);
		} else {
			$subdb[$rt['hup']][] = array('hid' => $rt['hid'],'hup' => $rt['hup'],'lv' => $rt['lv'],'fathers' => $rt['fathers'],'ifchild' => $rt['ifchild'],'title' => $rt['title'],'vieworder' => $rt['vieworder'],'ifcontent' => $rt['ifcontent'],'url' => $rt['url']);
		}
	}
	foreach ($gorydb as $value) {
		if (!empty($value)) {
			$_HELP[$value['hid']] = $value;
			if (!empty($subdb[$value['hid']])) {
				$value['ifchild']!='1' && $ifchilds .= ",'$value[hid]'";
				$_HELP += get_subhelp($subdb,$value['hid']);
			}
		}
	}
	if ($ifchilds) {
		$db->update("UPDATE pw_help SET ifchild='1' WHERE hid IN (".substr($ifchilds,1).')');
	}
	$writecache = '$_HELP = '.pw_var_export($_HELP).";\r\n";
	writeover(D_P.'data/bbscache/help_cache.php',"<?php\r\n$writecache?>");
}
function get_subhelp($subdb,$hid,$lv = 0,$fathers = null){
	global $db;
	$rtarray = array();
	$lv++;
	$fathers .= (empty($fathers) ? '' : ',').$hid;
	foreach ($subdb[$hid] as $value) {
		$sql = $extra = '';
		if ($value['lv'] != $lv) {
			$value['lv'] = $lv;
			$sql .= "lv='$lv'";
			$extra = ',';
		}
		if ($value['fathers']!=$fathers) {
			$value['fathers'] = $fathers;
			$sql .= "{$extra}fathers='$fathers'";
			$extra = ',';
		}
		$get = 1;
		if (empty($subdb[$value['hid']])) {
			$get = 0;
			if ($value['ifchild']!='0') {
				$sql .= "{$extra}ifchild='0'";
				$value['ifchild'] = '0';
			}
		} elseif ($value['ifchild']!='1') {
			$sql .= "{$extra}ifchild='1'";
			$value['ifchild'] = '1';
		}
		$rtarray[$value['hid']] = $value;
		$sql && $db->update("UPDATE pw_help SET $sql WHERE hid='$value[hid]'");
		$get && $rtarray += get_subhelp($subdb,$value['hid'],$lv,$fathers);
	}
	return $rtarray;
}
function cache_read(){
	global $db;
	$query = $db->query("SELECT * FROM pw_cache WHERE name IN('forum_cache','md_config','level','gp_right','customfield','medaldb','postcache','index_cache','thread_announce')");
	$c = array();
	while ($rt = $db->fetch_array($query)) {
		$c[$rt['name']] = $rt['cache']."\r\n\r\n";
	}
	writeover(D_P.'data/bbscache/cache_index.php',"<?php\r\n{$c[level]}{$c[index_cache]}?>");
	writeover(D_P.'data/bbscache/cache_thread.php',"<?php\r\n{$c[forum_cache]}{$c[thread_announce]}?>");
	writeover(D_P.'data/bbscache/cache_read.php',"<?php\r\n{$c[forum_cache]}{$c[md_config]}{$c[level]}{$c[gp_right]}{$c[customfield]}{$c[medaldb]}?>");
	writeover(D_P.'data/bbscache/cache_post.php',"<?php\r\n{$c[forum_cache]}{$c[level]}{$c[postcache]}?>");
}
function db_cv($array){
	if (is_array($array)) {
		foreach ($array as $key => $value) {
			$array[$key] = db_cv($value);
		}
	} else {
		$array = str_replace(array("\\","'"),array("\\\\","\'"),$array);
	}
	return $array;
}
function key_cv($key) {
	return preg_replace('/[^\d\w\_]/is','',$key);
}
?>