<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename="$admin_file?adminjob=code";
if($_GET['sessionid']){
	Cookie('sessionid',$sessionid);
}else{
	$sessionid=GetCookie('sessionid');
}
$adskin=GetCookie('adskin');


if(!$action || $action=='info' || $action=='prompt'){
	if(!$_POST['step']){
		include PrintEot('code');exit;
	} else{
		InitGP(array('lguser','lgpwd','gdcode'));
		GdConfirm($gdcode,0);
		$lgpwd=md5($lgpwd);
		$verify=md5("actionloginlguser{$lguser}lgpwd{$lgpwd}{$_SERVER[HTTP_USER_AGENT]}");
		ObHeader("http://union.phpwind.com/index.php?action=login&lguser=$lguser&lgpwd=$lgpwd&verify=$verify");
	}
} elseif($action=='key'){
	if(!$db_siteid){
		$rt = $db->get_one("SELECT db_value FROM pw_config WHERE db_name='db_siteid'");
		if(!$rt['db_value']){
			$db_siteid = generatestr(16);
			$db->update("REPLACE INTO pw_config(db_name,db_value) VALUES('db_siteid','$db_siteid')");

			$db_siteownerid = generatestr(18);
			$db->update("REPLACE INTO pw_config(db_name,db_value) VALUES('db_siteownerid','$db_siteownerid')");

			$db_sitehash = '10'.SitStrCode(md5($db_siteid.$db_siteownerid),md5($db_siteownerid.$db_siteid));
			$db->update("REPLACE INTO pw_config(db_name,db_value) VALUES('db_sitehash','$db_sitehash')");
		}
		updatecache_c();
	}
	include PrintEot('code');exit;
} elseif($action=='modify'){
	if(!$_POST['step']){
		include PrintEot('code');exit;
	} else{
		
		InitGP(array('siteid','siteownerid','sitehash'));
		if(empty($siteid) || empty($siteownerid) || empty($sitehash)){
			adminmsg('adcode_error');
		}
		if($sitehash != '10'.SitStrCode(md5($siteid.$siteownerid),md5($siteownerid.$siteid))){
			adminmsg('adcode_error');
		}
		$db->update("REPLACE INTO pw_config(db_name,db_value) VALUES('db_siteid','$siteid')");
		$db->update("REPLACE INTO pw_config(db_name,db_value) VALUES('db_siteownerid','$siteownerid')");
		$db->update("REPLACE INTO pw_config(db_name,db_value) VALUES('db_sitehash','$sitehash')");
		updatecache_c();
		adminmsg('operate_success');
	}
}

function generatestr($len) {
	mt_srand((double)microtime() * 1000000);
    $keychars = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWYXZ";
	$maxlen = strlen($keychars)-1;
	$str = '';
	for ($i=0;$i<$len;$i++){
		$str .= $keychars[mt_rand(0,$maxlen)];
	}
	return substr(md5($str.time().$_SERVER["HTTP_USER_AGENT"].$GLOBALS['db_hash']),0,$len);
}
function SitStrCode($string,$key,$action='ENCODE'){
	$string	= $action == 'ENCODE' ? $string : base64_decode($string);
	$len	= strlen($key);
	$code	= '';
	for($i=0; $i<strlen($string); $i++){
		$k		= $i % $len;
		$code  .= $string[$i] ^ $key[$k];
	}
	$code = $action == 'DECODE' ? $code : str_replace('=','',base64_encode($code));
	return $code;
}
?>