<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename="$admin_file?adminjob=creditchange";
require_once(R_P.'require/credit.php');
$credittype = GetCreditType();

$rt = $db->get_one("SELECT db_value FROM pw_config WHERE db_name='jf_A'");
$jf_A = $rt['db_value'] ? unserialize($rt['db_value']) : array();

if(!$action){
	$creditlist = '';
	foreach($credittype as $key=>$value){
		$creditlist .= "<option value=\"$key\">$value</option>";
	}
	$jf = array();
	foreach($jf_A as $key=>$value){
		list($j_1,$j_2) = explode('_',$key);
		$jf[$key] = array($credittype[$j_1],$credittype[$j_2],$value[0],$value[1],$value[2]);
	}
	include PrintEot('creditchange');exit;
} elseif($_POST['action']=='add'){
	InitGP(array('credit'));
	if($credit[0]==$credit[1]){
		adminmsg('bankset_save');
	}
	if(empty($credit[2]) || $credit[2]<=0 || empty($credit[3]) || $credit[3]<=0){
		adminmsg('bankset_rate_error');
	}
	if(isset($jf_A[$credit[0].'_'.$credit[1]])){
		adminmsg('bankset_exists');
	}
	$jf_A[$credit[0].'_'.$credit[1]] = array($credit[2],$credit[3],1);
	$value = addslashes(serialize($jf_A));
	if($rt){
		$db->update("UPDATE pw_config SET db_value='$value' WHERE db_name='jf_A'");
	} else{
		$db->update("INSERT INTO pw_config (db_name,db_value) VALUES('jf_A','$value')");
	}
	adminmsg('operate_success');
} elseif($_POST['action']=='submit'){
	InitGP(array('selid','ifopen'),'P');
	if($selid){
		foreach($selid as $key=>$value){
			unset($jf_A[$value]);
		}
	}
	foreach($jf_A as $key=>$vlaue){
		$jf_A[$key][2] = in_array($key,$ifopen) ? 1 : 0;
	}
	$value = addslashes(serialize($jf_A));
	if($rt){
		$db->update("UPDATE pw_config SET db_value='$value' WHERE db_name='jf_A'");
	} else{
		$db->update("INSERT INTO pw_config (db_name,db_value) VALUES('jf_A','$value')");
	}
	adminmsg('operate_success');
}
?>