<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename="$admin_file?adminjob=currencyset";

if(!$action){
	$query = $db->query("SELECT db_name,db_value FROM pw_config WHERE db_name LIKE 'cy\_%'");
	while($rt = $db->fetch_array($query)){
		$$rt['db_name'] = $rt['db_value'];
	}
	ifcheck($cy_virement,'virement');
	include PrintEot('currencyset');exit;
} elseif($_POST['action'] == 'virement'){
	InitGP(array('config'),'P');
	foreach($config as $key=>$value){
		$db->pw_update(
			"SELECT db_name FROM pw_config WHERE db_name='$key'",
			"UPDATE pw_config SET db_value='$value' WHERE db_name='$key'",
			"INSERT INTO pw_config SET db_name='$key',db_value='$value'"
		);
	}
	adminmsg('operate_success');
} elseif($_POST['action']=="setname"){
	InitGP(array('config'),'P');
	foreach($config as $key=>$value){
		if($key=='db_rmbrate' || $key=='db_rmblest'){
			$value=(int)$value;
			$value<1 && $value=10;
		}
		$db->pw_update(
			"SELECT db_value FROM pw_config WHERE db_name='$key'",
			"UPDATE pw_config SET db_value='$value' WHERE db_name='$key'",
			"INSERT INTO pw_config SET db_value='$value',db_name='$key'"
		);
	}
	updatecache_c();
	adminmsg('operate_success');
}
?>