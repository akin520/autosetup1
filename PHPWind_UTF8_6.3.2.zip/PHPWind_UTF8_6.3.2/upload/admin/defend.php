<?php
//Copyright (c) 2003-06 PHPWind
!function_exists('adminmsg') && exit('Forbidden');
$ceversion = 0;
InitGP(array('adminjob','type','hackset','a_type','action','verify','adskin','job'));

include_once(D_P.'data/bbscache/config.php');

if ($db_forcecharset && !defined('W_P')) {
	@header("Content-Type: text/html; charset=$db_charset");
}

if ($db_cc && ((!$_COOKIE && !$_SERVER['HTTP_USER_AGENT']) || ($db_cc==2 && $c_agentip))) {
	exit('Forbidden');
}

strpos($adminjob,'..')!==false && exit('Forbidden');
?>