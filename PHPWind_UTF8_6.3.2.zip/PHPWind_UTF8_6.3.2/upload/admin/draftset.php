<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename="$admin_file?adminjob=draftset";

if(!$action){
	InitGP(array('page','uid','username','keyword'));
	$sqladd = 'WHERE 1';
	if(is_numeric($uid)){
		$sqladd .= " AND uid='$uid'";
	} elseif($username){
		@extract($db->get_one("SELECT uid FROM pw_members WHERE username='$username'"));
		$sqladd .= " AND uid='$uid'";
	}
	if($keyword){
		$sqladd .= " AND content LIKE '%$keyword%'";
	}
	require_once(R_P.'require/forum.php');
	$db_perpage = 15;
	(!is_numeric($page) || $page < 1) && $page = 1;
	$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
	$rt    = $db->get_one("SELECT COUNT(*) AS n FROM pw_draft $sqladd");
	$pages = numofpage($rt['n'],$page,ceil($rt['n']/$db_perpage),"$basename&uid=$uid&keyword=".rawurlencode($keyword)."&");

	$draft = array();
	$query = $db->query("SELECT d.*,m.username FROM pw_draft d LEFT JOIN pw_members m USING(uid) $sqladd $limit");
	while($rt = $db->fetch_array($query)){
		$draft[] = $rt;
	}
	include PrintEot('draftset');exit;
} elseif($action=='del'){
	if(!$_POST['step']){
		include PrintEot('draftset');exit;
	} else{
		InitGP(array('username','keyword','num','clear'));
		if($clear){
			$db->query("TRUNCATE TABLE pw_draft");
		} else{
			$num<1 && $num = 200;
			$sql = '';
			if($username){
				$rt = $db->get_one("SELECT uid FROM pw_members WHERE username='$username'");
				if(!$rt){
					$errorname = Char_cv($username);
					adminmsg('user_not_exists');
				}
				$sql .= " AND uid='$rt[uid]'";
			}
			if($keyword){
				$sql .= " AND content LIKE '%$keyword%'";
			}
			$db->update("DELETE FROM pw_draft WHERE 1 $sql LIMIT $num");
		}
		adminmsg('operate_success');
	}
} elseif($_POST['action']=='draft'){
	InitGP(array('selid'));
	if(!$selid = checkselid($selid)){
		adminmsg('operate_error');
	}
	$db->update("DELETE FROM pw_draft WHERE did IN($selid)");
	adminmsg("operate_success");
}
?>