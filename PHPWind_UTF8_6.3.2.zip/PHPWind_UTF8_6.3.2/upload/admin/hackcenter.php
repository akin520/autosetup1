<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename="$admin_file?adminjob=hackcenter";

if (!$action) {
	$installdb = $uninstalldb = array();
	foreach ($db_hackdb as $key => $value) {
		$value[0] = htmlspecialchars($value[0]);
		${$value[1].'_'.$value[2]} = 'SELECTED';
		$value[4] = EncodeUrl("$basename&action=delete&id=$value[1]");
		$installdb[$key] = $value;
	}
	if ($fp = opendir(R_P.'hack')) {
		$infodb = array();
		while (($hackdir = readdir($fp))) {
			if (strpos($hackdir,'.')===false && empty($db_hackdb[$hackdir])) {
				$hackname = $hackdir;
				$hackopen = 0;
				if (function_exists('file_get_contents')) {
					$filedata = @file_get_contents(R_P."hack/$hackdir/info.xml");
				} else {
					$filedata = readover(R_P."hack/$hackdir/info.xml");
				}
				if (preg_match('/\<hackname\>(.+?)\<\/hackname\>\s+\<ifopen\>(.+?)\<\/ifopen\>/is',$filedata,$infodb)) {
					$infodb[1] && $hackname = Char_cv(str_replace(array("\n"),'',$infodb[1]));
					$hackopen = (int)$infodb[2];
				}
				$hackurl = EncodeUrl("$basename&action=add&hackdir=$hackdir&hackname=".rawurlencode($hackname)."&hackopen=$hackopen");
				$uninstalldb[] = array($hackname,$hackdir,$hackopen,$hackurl);
			}
		}
		closedir($fp);
	}
	unset($db_hackdb);
	include PrintEot('hackcenter');exit;
} elseif ($action=='edit') {
	InitGP(array('hackname','hackopen'));
	foreach ((array)$hackname as $key => $value) {
		$value = str_replace(array("\t","\n","\r",'  '),array('&nbsp; &nbsp; ','<br />','','&nbsp; '),$value);
		if ($value && $db_hackdb[$key][1]==$key && ($db_hackdb[$key][0] != $value || $db_hackdb[$key][2] != (int)$hackopen[$key])) {
			$db_hackdb[$key] = array(stripslashes($value),$key,(int)$hackopen[$key]);
		}
	}
	$db_hackdb = addslashes(serialize($db_hackdb));
	$rt = $db->get_one("SELECT db_name FROM pw_config WHERE db_name='db_hackdb'");
	if (!empty($rt)) {
		$db->update("UPDATE pw_config SET db_value='$db_hackdb' WHERE db_name='db_hackdb'");
	} else {
		$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('db_hackdb','$db_hackdb')");
	}
	updatecache_c();
	adminmsg('operate_success');
} elseif($action=='delete'){
	InitGP(array('id'));
	empty($db_hackdb[$id]) && adminmsg('hackcenter_del');
	unset($db_hackdb[$id]);
	$sqlarray = file_exists(R_P."hack/$id/sql.txt") ? FileArray($id) : array();
	!empty($sqlarray) && SQLDrop($sqlarray);
	$db_hackdb = addslashes(serialize($db_hackdb));
	$rt = $db->get_one("SELECT db_name FROM pw_config WHERE db_name='db_hackdb'");
	if (!empty($rt)) {
		$db->update("UPDATE pw_config SET db_value='$db_hackdb' WHERE db_name='db_hackdb'");
	} else {
		$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('db_hackdb','$db_hackdb')");
	}
	updatecache_c();
	adminmsg('operate_success');
} elseif ($action=='add') {
	InitGP(array('hackdir','hackname','hackopen'),'G',1);
	!empty($db_hackdb[$hackdir]) && adminmsg('hackcenter_sign_exists');
	$sqlarray = file_exists(R_P."hack/$hackdir/sql.txt") ? FileArray($hackdir) : array();
	!empty($sqlarray) && SQLCreate($sqlarray);
	$db_hackdb[$hackdir] = array($hackname,$hackdir,$hackopen);
	$db_hackdb = addslashes(serialize($db_hackdb));
	$rt = $db->get_one("SELECT db_name FROM pw_config WHERE db_name='db_hackdb'");
	if (!empty($rt)) {
		$db->update("UPDATE pw_config SET db_value='$db_hackdb' WHERE db_name='db_hackdb'");
	} else {
		$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('db_hackdb','$db_hackdb')");
	}
	updatecache_c();
	adminmsg('operate_success');
}
function SQLCreate($sqlarray) {
	global $db,$charset;
	$query = '';
	foreach ($sqlarray as $value) {
		if ($value[0]!='#') {
			$query .= $value;
			if (substr($value,-1)==';' && !in_array(strtolower(substr($query,0,5)),array('drop ','delet','updat'))) {
				$lowquery = strtolower(substr($query,0,5));
				if (in_array($lowquery,array('creat','alter','inser','repla'))) {
					$next = CheckDrop($query);
					if ($lowquery == 'creat') {
						if (!$next) continue;
						strpos($query,'IF NOT EXISTS')===false && $query = str_replace('TABLE','TABLE IF NOT EXISTS',$query);
						$extra1 = trim(substr(strrchr($value,')'),1));
						$tabtype = substr(strchr($extra1,'='),1);
						$tabtype = substr($tabtype,0,strpos($tabtype,strpos($tabtype,' ') ? ' ' : ';'));
						if ($db->server_info() >= '4.1') {
							$extra2 = "ENGINE=$tabtype".($charset ? " DEFAULT CHARSET=$charset" : '');
						} else {
							$extra2 = "TYPE=$tabtype";
						}
						$query = str_replace($extra1,$extra2.';',$query);
					} elseif (in_array($lowquery,array('inser','repla'))) {
						if (!$next) continue;
						$lowquery == 'inser' && $query = 'REPLACE '.substr($query,6);
					} elseif ($lowquery == 'alter' && !$next && strpos(strtolower($query),'drop')!==false) {
						continue;
					}
					$db->query($query);
					$query = '';
				}
			}
		}
	}
}
function SQLDrop($sqlarray) {
	global $db;
	foreach ($sqlarray as $query) {
		$lowquery = strtolower(substr($query,0,6));
		$next = CheckDrop($query);
		if ($next && $lowquery == 'create') {
			$t_name = trim(substr($query,0,strpos($query,'(')));
			$t_name = substr($t_name,strrpos($t_name,' ')+1);
			$db->query("DROP TABLE IF EXISTS $t_name");
		}
	}
}
function FileArray($hackdir){
	if (function_exists('file_get_contents')) {
		$filedata = @file_get_contents(Pcv(R_P."hack/$hackdir/sql.txt"));
	} else {
		$filedata = readover(R_P."hack/$hackdir/sql.txt");
	}
	$filedata = trim(str_replace(array("\t","\r","\n\n",';'),array('','','',";\n"),$filedata));
	$sqlarray = $filedata ? explode("\n",$filedata) : array();
	return $sqlarray;
}
function CheckDrop($query){
	global $db;
	require_once(R_P.'admin/table.php');
	list($pwdb) = N_getTabledb();
	$next = true;
	foreach ($pwdb as $value) {
		if (strpos(strtolower($query),strtolower($value))!==false) {
			$next = false;
			break;
		}
	}
	return $next;
}
?>