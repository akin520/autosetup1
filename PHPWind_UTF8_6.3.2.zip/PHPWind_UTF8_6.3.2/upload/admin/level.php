<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename="$admin_file?adminjob=level";
if(empty($action)){
	$memberdb=$vipdb=$sysdb=$defaultdb=array();
	$query=$db->query("SELECT gid,gptype,grouptitle,groupimg,grouppost FROM pw_usergroups ORDER BY grouppost,gid");
	while($level=$db->fetch_array($query)){
		if($level['gptype']=='member'){
			$memberdb[]=$level;
		} elseif($level['gptype']=='special'){
			$vipdb[]=$level;
		} elseif($level['gptype']=='system'){
			$sysdb[]=$level;
		} elseif($level['gptype']=='default'){
			$defaultdb[]=$level;
		}
	}
	include PrintEot('level');exit;
} elseif($_POST['action']=="menedit"){
	InitGP(array('memtitle','mempic','mempost'),'P');
	@asort($mempost);
	foreach($mempost as $key=>$value){
		if(!is_numeric($value)){
			$value=20*pow(2,$key);
			$mempost[$key]=$value;
		}
		$db->update("UPDATE pw_usergroups SET grouptitle='$memtitle[$key]',groupimg='$mempic[$key]',grouppost='".(int)$mempost[$key]."' WHERE gptype='member' AND gid='$key'");
	}
	updatecache_l();
	adminmsg('operate_success');
} elseif($_POST['action']=="defedit"){
	InitGP(array('deftitle','defpic'),'P');
	foreach($deftitle as $key=>$value){
		$db->update("UPDATE pw_usergroups SET grouptitle='$value',groupimg='$defpic[$key]' WHERE gptype='default' AND gid='$key'");
	}
	updatecache_l();
	adminmsg('operate_success');
} elseif($_POST['action']=="sysedit"){
	InitGP(array('systitle','syspic'),'P');
	foreach($systitle as $key=>$value){
		$db->update("UPDATE pw_usergroups SET grouptitle='$value',groupimg='$syspic[$key]' WHERE gptype='system' AND gid='$key'");
	}
	updatecache_l();
	adminmsg('operate_success');
} elseif($_POST['action']=="vipedit"){
	InitGP(array('viptitle','vippic'),'P');
	foreach($viptitle as $key=>$value){
		$db->update("UPDATE pw_usergroups SET grouptitle='$value',groupimg='$vippic[$key]' WHERE gptype='special' AND gid='$key'");
	}
	updatecache_l();
	adminmsg('operate_success');
} elseif($_POST['action']=="addmengroup"){
	InitGP(array('newtitle','newpic','newpost'),'P');
	$db->update("INSERT INTO pw_usergroups(gptype,grouptitle,groupimg,grouppost) VALUES ('member', '$newtitle', '$newpic','".(int)$newpost."')");
	updatecache_l();
	$gid=$db->insert_id();
	$basename="$admin_file?adminjob=level&action=editgroup&gid=$gid";
	adminmsg('operate_success');
} elseif($_POST['action']=="addadmingroup"){
	InitGP(array('newtitle','newpic'),'P');
	$db->update("INSERT INTO pw_usergroups(gptype,grouptitle,groupimg,ifdefault) VALUES ('system', '$newtitle', '$newpic','0')");
	$gid=$db->insert_id();
	updatecache_g($gid);
	updatecache_l();
	$basename="$admin_file?adminjob=level&action=editgroup&gid=$gid";
	adminmsg('operate_success');
} elseif($_POST['action']=="addvipgroup"){
	InitGP(array('newtitle','newpic'),'P');
	$db->update("INSERT INTO pw_usergroups(gptype,grouptitle,groupimg,ifdefault) VALUES ('special','$newtitle','$newpic','0')");
	$gid=$db->insert_id();
	updatecache_g($gid);
	updatecache_l();
	$basename="$admin_file?adminjob=level&action=editgroup&gid=$gid";
	adminmsg('operate_success');
} elseif($action=="delgroup"){
	PostCheck($verify);
	InitGP(array('delid'));
	if($delid<7){
		adminmsg('level_del');
	}
	$db->update("DELETE FROM pw_usergroups WHERE gid='$delid'");
	updatecache_l();
	adminmsg('operate_success');
} elseif($action=="editgroup"){
	InitGP(array('gid','step'));
	$basename="$admin_file?adminjob=level&action=editgroup&gid=$gid";
	if(!$step){
		if(file_exists(D_P."data/groupdb/group_$gid.php") && $gid!=1){
			include_once Pcv(D_P."data/groupdb/group_$gid.php");
			$default=0;
		} else{
			include_once(D_P."data/groupdb/group_1.php");
			$default=1;
		}
		@extract($SYSTEM);
		@extract($_G);
		$uploadtype = unserialize($uploadtype);
		$selected_g[$gid]='selected';

		foreach($ltitle as $key=>$value){
			$groupselect.="<option value=$key $selected_g[$key]>$value</option>";
		}
		list($maxcredit,$minper,$maxper,$credittype,$markdt)=explode("|",$markdb);
		$credits=explode(',',$credittype);
		foreach($credits as $value){
			$check_c[$value]='checked';
		}
		$pergroupdb = explode(',',$pergroup);
		foreach ($pergroupdb as $value) {
			${'per_'.$value} = 'CHECKED';
		}
		require_once GetLang('all');
		$credittypes=array('rvrc'=>$db_rvrcname,'money'=>$db_moneyname,'credit'=>$db_creditname);
		foreach($_CREDITDB as $key=>$value){
			$credittypes[$key]=$value[0];
		}
		$credit_type='';
		foreach($credittypes as $key=>$value){
			$credit_type.="<input type=checkbox name=c_type[] value='$key' $check_c[$key]>".$value;
		}
		$sell_type[$selltype] = 'selected';
		$special_type = "<option value='currency' $sell_type[currency]>$db_currencyname</option>";
		foreach($credittypes as $key=>$value){
			$special_type .= "<option value='$key' $sell_type[$key]>$value</option>";
		}
		!$banmax && $banmax!=0 && $banmax = 1;

		$media = explode(',',$_G['media']);
		foreach($media as $key=>$value){
			${'m_'.$value} = 'checked';
		}
		/*
		* ����Ȩ��
		*/
		ifcheck($markdt,'markdt');
		ifcheck($gp_allowread,'read');
		if($gp_allowsearch==0) $search_N="CHECKED"; elseif($gp_allowsearch==1) $search_1="CHECKED";else $search_2="CHECKED";
		ifcheck($gp_allowmember,'member');
		ifcheck($gp_allowprofile,'profile');
		ifcheck($gp_allowreport,'report');
		ifcheck($gp_allowmessege,'messege');
		ifcheck($gp_allowsort,'sort');
		ifcheck($gp_alloworder,'order');
		ifcheck($gp_allowpost,'post');
		ifcheck($gp_allowrp,'reply');
		ifcheck($gp_allownewvote,'postvote');
		ifcheck($gp_allowvote,'vote');
		ifcheck($gp_allowactive,'active');
		ifcheck($gp_htmlcode,'html');
		//ifcheck($gp_wysiwyg,'wysiwyg');
		ifcheck($gp_allowhidden,'hidden');
		ifcheck($gp_allowsell,'sell');
		ifcheck($gp_allowloadrvrc,'uploadrvrc');
		ifcheck($gp_allowhide,'hide');
		ifcheck($gp_upload,'uploadimg');
		ifcheck($gp_allowportait,'portait');
		ifcheck($gp_allowhonor,'honor');
		ifcheck($gp_allowdelatc,'delatc');
		${'upload_'.(int)$gp_allowupload}='checked';
		${'download_'.(int)$gp_allowdownload}='checked';

		ifcheck($msggroup,'msggroup');
		ifcheck($ifmemo,'ifmemo');
		ifcheck($previewvote,'previewvote');
		ifcheck($allowreward,'reward');
		ifcheck($viewvote,'viewvote');
		ifcheck($pmodifyvote,'pmodifyvote');
		ifcheck($modifyvote,'modifyvote');
		ifcheck($viewipfrom,'viewipfrom');
		ifcheck($atclog,'atclog');
		ifcheck($show,'show');
		ifcheck($atccheck,'atccheck');
		ifcheck($dig,'dig');
		ifcheck($leaveword,'leaveword');
		ifcheck($allowencode,'encode');
		/*
		* ����Ȩ��
		*/
		ifcheck($allowbuy,'allowbuy');
		ifcheck($allowadmincp,'allowadmincp');
		ifcheck($visithide,'visithide');
		ifcheck($rzforum,'rzforum');
		ifcheck($tpctype,'tpctype');
		ifcheck($tpccheck,'tpccheck');
		ifcheck($delatc,'adelatc');
		ifcheck($moveatc,'moveatc');
		ifcheck($copyatc,'copyatc');
		ifcheck($typeadmin,'typeadmin');
		ifcheck($viewcheck,'viewcheck');
		ifcheck($viewclose,'viewclose');
		ifcheck($attachper,'attachper');
		ifcheck($delattach,'delattach');
		ifcheck($shield,'shield');
		ifcheck($unite,'unite');
		ifcheck($remind,'remind');
		ifcheck($inspect,'inspect');

		ifcheck($selgroup,'selgroup');
		${'viewip_'.(int)$viewip}='checked';
		${'topped_'.(int)$topped}='checked';
		${'markable_'.(int)$markable}='checked';
		ifcheck($banuser,'banuser');
		ifcheck($bantype,'bantype');
		ifcheck($viewhide,'viewhide');
		ifcheck($postpers,'postpers');
		ifcheck($anonymous,'anonymous');
		ifcheck($replylock,'replylock');
		ifcheck($modown,'modown');
		ifcheck($modother,'modother');
		ifcheck($deltpcs,'deltpcs');
		$fids = explode(',',$rightwhere);
		if($fids){
			foreach($fids as $key=>$val){
				${'selids_'.$val}='checked';
			}
		}
		$_G['schtime'] != 'all' && !is_numeric($_G['schtime']) && $_G['schtime'] = 7776000;
		${'schtime_'.$_G['schtime']} = 'SELECTED';
		$sellinfo && $sellinfo = str_replace('<br />',"\n",$sellinfo);

		include PrintEot('level');exit;
	} elseif($_POST['step']==2){
		InitGP(array('gptype','othergroup','group','mright','sright','markdb','c_type','othergid','selids','sysgroup','filetype','maxsize','media','pergroup'),'P');
		!isset($group['maxmsg'])		&& $group['maxmsg']=10;
		!isset($group['allownum'])	    && $group['allownum']=5;
		!isset($group['edittime'])		&& $group['edittime']=0;
		!isset($group['postpertime'])	&& $group['postpertime']=0;
		!isset($group['searchtime'])	&& $group['searchtime']=0;
		!isset($group['signnum'])		&& $group['signnum']=0;
		!isset($markdb['maxcredit'])	&& $markdb['maxcredit']=10;
		if($markdb['maxcredit']<max(abs($markdb['minper']),$markdb['maxper']) || $markdb['minper']>$markdb['maxper']){
			adminmsg('level_credit_error');
		}
		$uploadtype = array();
		foreach($filetype as $key=>$value){
			if($value){
				$uploadtype[$value] = (int)$maxsize[$key];
			}
		}
		$mright['uploadtype'] = $uploadtype ? serialize($uploadtype) : '';

		$c_type = is_array($c_type) ? ','.implode(',',$c_type).',':'';
		$mright['media']  = implode(',',$media);
		$mright['pergroup'] = implode(',',$pergroup);
		$mright['markdb'] = $markdb['maxcredit']."|".$markdb['minper']."|".$markdb['maxper']."|".$c_type."|".$markdb['markdt'];
		$mright['schtime'] != 'all' && !is_numeric($mright['schtime']) && $mright['schtime'] = 7776000;
		$group['mright'] = P_serialize($mright);
		$group['ifdefault'] = $gid !=1 ? 0 : 1;

		if($gptype=='system' || $gptype=='special'){
			$fids = '';
			if(is_array($selids)){
				foreach($selids as $key=>$val){
					is_numeric($val) && $fids .= $fids ? ','.$val : $val;
				}
			}
			isset($sright['sellinfo']) && $sright['sellinfo'] = str_replace("\n",'<br />',$sright['sellinfo']);
			$sright['rightwhere'] = $fids;
			$sright && $sysgroup['sright'] = P_serialize($sright);
			foreach($sysgroup as $key => $value){
				$group[$key] = $value;
			}
		}
		$sql = "gid='$gid'";
		foreach($group as $key => $value){
			$sql .=",$key='$value'";
		}
		$db->update("UPDATE pw_usergroups SET $sql WHERE gid='$gid'");

		$othersql = $othergids = $extra = $update_m = $update_s = '';
		if(is_array($othergid)){
			$othergids = "'".implode("','",$othergid)."'";
		}
		if(is_array($othergroup)){
			foreach($othergroup as $key => $value){
				if($key === 'mright'){
					$update_m = 1;
					continue;
				} elseif($key === 'sright'){
					$update_s = 1;
					continue;
				}
				$othersql .= "$extra$value='".$group[$value]."'";
				$extra = ',';
			}
		}
		if($othersql && $othergids){
			$db->update("UPDATE pw_usergroups SET $othersql WHERE gid IN($othergids)");
		}
		if($othergids && ($update_m || $update_s)){
			$query = $db->query("SELECT gid,mright,sright FROM pw_usergroups WHERE gid IN($othergids)");
			while($rt = $db->fetch_array($query)){
				$sql = "gid='$rt[gid]'";
				if($update_m){
					$newmright = P_unserialize($rt['mright']);
					foreach($othergroup['mright'] as $key => $value){
						$newmright[$value] = $mright[$value];
					}
					$newmright = P_serialize($newmright);
					$sql .= ",mright='$newmright'";
				}
				if($update_s){
					$newsright = P_unserialize($rt['sright']);
					foreach($othergroup['sright'] as $key => $value){
						$newsright[$value] = $sright[$value];
					}
					$newsright = P_serialize($newsright);
					$sql .= ",sright='$newsright'";
				}
				$db->update("UPDATE pw_usergroups SET $sql WHERE gid='$rt[gid]'");
			}
		}
		if($othergids && ($othersql || $update_m || $update_s)){
			updatecache_g();
		} else{
			updatecache_g($gid);
		}
		updatecache_gr();
		adminmsg('operate_success');
	} elseif($step==3){
		$db->update("UPDATE pw_usergroups SET ifdefault='1' WHERE gid='$gid'");
		P_unlink(D_P."data/groupdb/group_$gid.php");
		adminmsg('operate_success');
	}
} elseif($action == 'batch'){
	if(!$_POST['step']){
		$group = array();
		$query = $db->query("SELECT gid,gptype,grouptitle FROM pw_usergroups WHERE gptype<>'default' ORDER BY gptype,gid");
		while($rt=$db->fetch_array($query)){
			$group[] = $rt;
		}
		include PrintEot('level');exit;
	} elseif($_POST['step']==3){
		$upload = $_FILES['upload'];

		if(is_array($upload)){
			$upload_name = $upload['name'];
			$upload_size = $upload['size'];
			$upload = $upload['tmp_name'];
		}
		$gids	= '';
		$titles = array();
		if($upload && $upload!='none'){
			require_once(R_P.'require/postfunc.php');
			$attach_ext = strtolower(substr(strrchr($upload_name,'.'),1));
			if(!if_uploaded_file($upload)){
				adminmsg('upload_error');
			} elseif($attach_ext!='txt'){
				adminmsg('upload_type_error');
			}
			$source = D_P."data/tmp/group.txt";
			if(postupload($upload,$source)){
				include_once(D_P."data/bbscache/wordsfb.php");
				$content = explode("\n",readover($source));
				foreach($content as $key=>$value){
					list($gid,$title) = explode("=>",$value);
					if(is_numeric($gid)){
						$gids .= ($gids ? ',' : '').$gid;
						$titles[$gid] = Char_cv(trim($title));
					}
				}
			} else{
				adminmsg('upload_error');
			}
			P_unlink($source);
		} else{
			adminmsg('upload_error');
		}
		if($gids){
			$query = $db->query("SELECT gid,grouptitle FROM pw_usergroups WHERE gid IN($gids)");
			while(@extract($db->fetch_array($query))){
				if($grouptitle != $titles[$gid]){
					$db->update("UPDATE pw_usergroups SET grouptitle='".addslashes($titles[$gid])."' WHERE gid='$gid'");
				}
			}
			updatecache_l();
		}
		adminmsg('operate_success');
	} else{
		InitGP(array('filename','selid'),'P');
		!$filename && $filename = 'group';
		if (!eregi("^[-a-zA-Z0-9_]+$",$filename)) {
			adminmsg('undefined_action');
		}
		if (!$selid = checkselid($selid)) {
			adminmsg('operate_error');
		}
		$writeinfo = '';
		$query = $db->query("SELECT gid,grouptitle FROM pw_usergroups WHERE gid IN($selid)");
		while ($rt = $db->fetch_array($query)) {
			$writeinfo .= $rt['gid']."=>".$rt['grouptitle']."\r\n";
		}
		header('Last-Modified: '.gmdate('D, d M Y H:i:s',$timestamp+86400).' GMT');
		header('Cache-control: no-cache');
		header('Content-Encoding: none');
		header('Content-Disposition: attachment; filename='.$filename.".txt");
		header('Content-type: txt');
		header('Content-Length: '.strlen($writeinfo));
		echo $writeinfo;exit;
	}
}
?>