<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename = "$admin_file?adminjob=manager";

if (!is_writeable(D_P.'data/sql_config.php')) {
	adminmsg('manager_error');
}
if (!$admin_name || !CkInArray($admin_name,$manager)) {
	adminmsg('undefined_action');
}

if (empty($action)) {

	include PrintEot('manager');exit;

} elseif ($action=='add') {
	
	if (empty($_POST['step'])) {

		include PrintEot('manager');exit;

	} else {
		
		InitGP(array('username','password','check_pwd'));
		
		if (empty($username) || CkInArray($username,$manager)) {
			adminmsg('manager_empty');
		}
		$rs = $db->get_one("SELECT uid,groups FROM pw_members WHERE username='$username'");
	
		if (empty($password) || $check_pwd != $password) {
			adminmsg('password_confirm');
		}
		$S_key = array("\\",'&',' ',"'",'"','/','*',',','<','>',"\r","\t","\n",'#');
		foreach ($S_key as $value) {
			if (strpos($password,$value)!==false) {
				adminmsg('illegal_password');
			}
		}
		$password = md5($password);
		
		include D_P.'data/sql_config.php';
		!is_array($manager) && $manager = array();
		!is_array($manager_pwd) && $manager_pwd = array();
		$newmanager = $newmngpwd = array();
		foreach ($manager as $key => $value) {
			if (!empty($value) && !is_array($value)) {
				$newmanager[$key] = $value;
				$newmngpwd[$key] = $manager_pwd[$key];
			}
		}
		$manager = array_merge($newmanager,array($username));
		$manager_pwd = array_merge($newmngpwd,array($password));
		$newconfig = array(
			'dbhost' => $dbhost,
			'dbuser' => $dbuser,
			'dbpw' => $dbpw,
			'dbname' => $dbname,
			'database' => $database,
			'PW' => $PW,
			'pconnect' => $pconnect,
			'charset' => $charset,
			'manager' => $manager,
			'manager_pwd' => $manager_pwd,
			'db_hostweb' => $db_hostweb,
			'attach_url' => $attach_url
		);
		require_once(R_P.'require/updateset.php');
		write_config($newconfig);

		if (!$rs) {
			$db->update("INSERT INTO pw_members SET username='$username',password='$password',groupid='3',regdate='$timestamp'");
			$uid = $db->insert_id();
			$db->update("INSERT INTO pw_memberdata (uid,postnum,lastvisit,thisvisit,onlineip) VALUES ('$uid','0','$timestamp','$timestamp','$onlineip')");
		} else {
			$uid = $rs['uid'];
			$db->update("UPDATE pw_members SET password='$password',groupid='3' WHERE username='$username'");
		}
		admincheck($uid,$username,'3',$rs['groups'],'update');

		adminmsg('operate_success');
	}

} elseif ($action == 'edit') {
	
	InitGP(array('username'));

	if (!CkInArray($username,$manager)) {
		adminmsg('undefined_action');
	}

	if (empty($_POST['step'])) {

		include PrintEot('manager');exit;

	} else {

		InitGP(array('newname','password','check_pwd'));
		
		include D_P.'data/sql_config.php';
		$v_key = array_search($username,$manager);

		if ($password) {
			$check_pwd != $password && adminmsg('password_confirm');
			$S_key = array("\\",'&',' ',"'",'"','/','*',',','<','>',"\r","\t","\n",'#');
			foreach ($S_key as $value) {
				if (strpos($password,$value)!==false) {
					adminmsg('illegal_password');
				}
			}
			$password = md5($password);
		} else {
			$password = $manager_pwd[$v_key];
		}
		$rs = $db->get_one("SELECT uid,groups FROM pw_members WHERE username='$newname'");
		
		
		require_once(R_P.'require/updateset.php');

		$manager[$v_key]		= $newname;
		$manager_pwd[$v_key]	= $password;

		$newconfig = array(
			'dbhost' => $dbhost,
			'dbuser' => $dbuser,
			'dbpw' => $dbpw,
			'dbname' => $dbname,
			'database' => $database,
			'PW' => $PW,
			'pconnect' => $pconnect,
			'charset' => $charset,
			'manager' => $manager,
			'manager_pwd' => $manager_pwd,
			'db_hostweb' => $db_hostweb,
			'attach_url' => $attach_url
		);
		write_config($newconfig);

		if (!$rs) {
			$db->update("INSERT INTO pw_members SET username='$newname',password='$password',groupid='3',regdate='$timestamp'");
			$uid = $db->insert_id();
			$db->update("INSERT INTO pw_memberdata (uid,postnum,lastvisit,thisvisit,onlineip) VALUES ('$uid','0','$timestamp','$timestamp','$onlineip')");
		} else {
			$uid = $rs['uid'];
			$db->update("UPDATE pw_members SET password='$password',groupid='3' WHERE username='$newname'");
		}
		admincheck($uid,$newname,'3',$rs['groups'],'update');

		adminmsg('operate_success');
	}
} elseif ($_POST['action'] == 'delete') {
	
	InitGP(array('selid'));
	
	include D_P.'data/sql_config.php';
	foreach ($selid as $key => $value) {
		$v_key = array_search($value,$manager);
		unset($manager[$v_key]);
		unset($manager_pwd[$v_key]);
	}
	if (count($manager) < 1) {
		adminmsg('manager_only');
	}

	require_once(R_P.'require/updateset.php');
	$newconfig = array(
		'dbhost' => $dbhost,
		'dbuser' => $dbuser,
		'dbpw' => $dbpw,
		'dbname' => $dbname,
		'database' => $database,
		'PW' => $PW,
		'pconnect' => $pconnect,
		'charset' => $charset,
		'manager' => $manager,
		'manager_pwd' => $manager_pwd,
		'db_hostweb' => $db_hostweb,
		'attach_url' => $attach_url
	);
	write_config($newconfig);

	adminmsg('operate_success');
}
?>