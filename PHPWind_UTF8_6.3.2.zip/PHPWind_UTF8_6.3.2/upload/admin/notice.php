<?php
!function_exists('SafeFunc') && exit('Forbidden');

$cachetime = $timestamp-3600*24;
if (@filemtime(D_P.'data/bbscache/file_lock.txt')<$cachetime) {
	require_once(R_P.'require/posthost.php');
	$wget = PostHost('http://nt.phpwind.com/src/pw6/union2.php',"url=$_SERVER[HTTP_HOST]$_SERVER[PHP_SELF]&repair=$wind_repair&charset=$db_charset&ce=$ceversion");
	$wget = str_replace(array('<pwret>','</pwret>'),'',$wget);
	$wget = explode("\t<windtag>\t",$wget);
	$wget_a = explode("\t",$wget[0]);
	$wget_b = explode("\t",$wget[1]);
	$higholnum = $db->get_value('SELECT higholnum FROM pw_bbsinfo WHERE id=1');
	foreach ($wget_a as $key => $value) {
		$higholnum<(int)$wget_b[$key] && $wget_a[$key] = '';
	}
	$wget = implode("\t",$wget_a);
	if ($db_union!=$wget) {
		$db_name = $db->get_value("SELECT db_name FROM pw_config WHERE db_name='db_union'");
		if($db_name){
			$db->update("UPDATE pw_config SET db_value='$wget' WHERE db_name='db_union'");
		} else {
			$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('db_union','$wget')");
		}
		updatecache_c();
	}
	writeover(D_P.'data/bbscache/file_lock.txt','');
} elseif (@filemtime(D_P.'data/bbscache/info.txt')<$cachetime) {
	require_once(R_P.'require/posthost.php');
	$wget = PostHost('http://nt.phpwind.com/src/pw6/info1.php',"charset=$db_charset&ce=$ceversion");
	$wget = str_replace(array('<pwret>','</pwret>'),'',$wget);
	writeover(D_P.'data/bbscache/info.txt',$wget);
} elseif (@filemtime(D_P."data/bbscache/myshow_default.php")<$cachetime) {
	require_once(R_P.'require/posthost.php');
	$url = "http://dm.phpwind.net/misc/custom/recommend_2.xml?$timestamp";
	$data = PostHost($url);
	if ($data && strpos($data,'<?xml')!==false) {
		$name   = array();
		$id     = array();
		$T      = '';
		$maxnum = 8;
		$xml_parser = xml_parser_create();
		xml_parse_into_struct($xml_parser,$data,$arr_vals);
		xml_parser_free($xml_parser);
		foreach ($arr_vals as $v) {
			if ($v['tag'] == 'ITEM' && $v['attributes']) {
				$name[] = $v['attributes']['NAME'];
			} elseif ($v['tag'] == 'CODE') {
				$id[] = $v['value'];
			}
		}
		if ($db_charset!='utf-8') {
			require_once(R_P.'wap/chinese.php');
			$chs = new Chinese('UTF-8',$db_charset);
			foreach ($name as $k=>$v) {
				$name[$k] = $chs->Convert($v);
			}
		}
		foreach ($id as $k=>$v) {
			$T .= $T ? ",$v : '$name[$k]'" : "$v : '$name[$k]'";
			if(!$maxnum--)break;
		}
		writeover(D_P."data/bbscache/myshow_default.php","<?php\r\n\t\$mDef = \"$T\";\r\n?>");
	}
}
exit;
?>