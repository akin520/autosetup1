<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename="$admin_file?adminjob=optimize";

if(!$action){
	include PrintEot('optimize');exit;
} elseif($action=='size_detail'){
	if(!$_POST['step']){
		include(R_P.'admin/optimize_conf.php');
		@extract($optimize_conf['size'][$type]);
		$db_hithour && $hithour_sel[$db_hithour]='selected';
		${'ads_'.$db_ads}='checked';
		$safegroup = "<table cellspacing='0' cellpadding='0' border='0' width='100%' align='center'><tr>";
		foreach($ltitle as $key => $value){
			if($key==1||$key==2)continue;
			$num++;
			$htm_tr = $num % 3 == 0 ? '</tr><tr>' : '';
			if(strpos($db_safegroup,",$key,")!==false){
				$s_checked = 'checked';
			} else {
				$s_checked = '';
			}
			$safegroup .= "<td><input type='checkbox' name='safegroup[]' value='$key' $s_checked>$value</td>$htm_tr";
		}
		$safegroup .= "</tr></table>";
		list($db_opensch,$db_schstart,$db_schend)=explode("\t",$db_opensch);
		ifcheck($db_opensch,'opensch');
		ifcheck($db_lp,'lp');
		ifcheck($db_obstart_tmp,'obstart');
		ifcheck($db_ifonlinetime,'ifonlinetime');
		ifcheck($db_ifselfshare,'ifselfshare');
		ifcheck($db_indexshowbirth,'indexshowbirth');
		ifcheck($db_indexonline,'indexonline');
		ifcheck($db_showguest,'showguest');
		ifcheck($db_today,'today');;
		ifcheck($db_threadonline,'threadonline');
		ifcheck($db_showcolony,'showcolony');
		ifcheck($db_watermark,'watermark');
		ifcheck($db_iffthumb,'iffthumb');
		ifcheck($db_wapifopen,'wapifopen');
		ifcheck($db_jsifopen,'jsifopen');
		ifcheck($db_ifsafecv,'ifsafecv');
		ifcheck($db_htmifopen,'htmifopen');
		ifcheck($db_ipstates,'ipstates');
		ifcheck($db_ads,'ads');
		include PrintEot('optimize');exit;
	}else{
		InitGP(array('config','safegroup','schcontrol'),'P');

		$config['opensch']=$schcontrol['opensch']."\t".$schcontrol['schstart']."\t".$schcontrol['schend'];
		if($safegroup){
			$config['safegroup']=",".implode(",",$safegroup).",";
		} else{
			$config['safegroup']='';
		}
		$config['onlinetime'] *= 60;

		$configdb=array();
		$query = $db->query("SELECT * FROM pw_config WHERE db_name LIKE 'db\_%'");
		while ($rt = $db->fetch_array($query)){
			$configdb[$rt['db_name']]=$rt['db_value'];
		}
		foreach($config as $key=>$value){
			$c_key=${'db_'.$key};
			if($c_key!=$value || $configdb["db_$key"]!=$value){
				$rt=$db->get_one("SELECT db_name FROM pw_config WHERE db_name='db_$key'");
				if($rt['db_name']){
					$db->update("UPDATE pw_config SET db_value='$value' WHERE db_name='db_$key'");
				}else{
					$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('db_$key','$value')");
				}
			}
		}
		updatecache_c();
		adminmsg('operate_success');
	}
} elseif($action=='func_detail'){
	if(!$_POST['step']){
		include(R_P.'admin/optimize_conf.php');
		@extract($optimize_conf['func'][$type]);
		${'columns_'.$db_columns}='checked';
		$menu_p = ($db_menu%2==1) ? 'checked' : '';
		$menu_f = ($db_menu%4>1)  ? 'checked' : '';
		$menu_m = $db_menu>3      ? 'checked' : '';
		list($db_upload,$db_imglen,$db_imgwidth,$db_imgsize)=explode("\t",$db_upload);
		$db_imgsize=ceil($db_imgsize/1024);

		ifcheck($db_upload,'upload');
		ifcheck($db_msgsound,'msgsound');
		ifcheck($db_shield,'shield');
		ifcheck($db_tcheck,'tcheck');
		ifcheck($db_adminset,'adminset');
		ifcheck($db_allowupload,'allowupload');
		ifcheck($db_replysendmail,'replysendmail');
		ifcheck($db_replysitemail,'replysitemail');
		ifcheck($db_pwcode,'pwcode');
		ifcheck($db_setform,'setform');
		ifcheck($db_autoimg,'autoimg');
		ifcheck($db_menu,'menu');
		ifcheck($db_topped,'topped');
		ifcheck($db_watermark,'watermark');
		ifcheck($db_iffthumb,'iffthumb');
		ifcheck($db_ifathumb,'ifathumb');
		ifcheck($db_ifselfshare,'ifselfshare');
		include PrintEot('optimize');exit;
	}else{
		InitGP(array('config','menu'),'P');
		$config['imgsize']=!is_numeric($config['imgsize']) ? 20480 : $config['imgsize']*1024;
		!is_numeric($config['imglen'])   && $config['imglen']=200;
		!is_numeric($config['imgwidth']) && $config['imgwidth']=180;
		$config['upload']="$upload[upload]\t$upload[imglen]\t$upload[imgwidth]\t$upload[imgsize]";
		$config['menu'] = 0;
		foreach($menu as $value){
			$config['menu'] += $value;
		}

		$configdb=array();
		$query = $db->query("SELECT * FROM pw_config WHERE db_name LIKE 'db\_%'");
		while ($rt = $db->fetch_array($query)){
			$configdb[$rt['db_name']]=$rt['db_value'];
		}
		foreach($config as $key=>$value){
			$c_key=${'db_'.$key};
			if($c_key!=$value || $configdb["db_$key"]!=$value){
				$rt=$db->get_one("SELECT db_name FROM pw_config WHERE db_name='db_$key'");
				if($rt['db_name']){
					$db->update("UPDATE pw_config SET db_value='$value' WHERE db_name='db_$key'");
				}else{
					$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('db_$key','$value')");
				}
			}
		}
		updatecache_c();
		adminmsg('operate_success');
	}
} elseif($_POST['action']=='size'){
	include(R_P.'admin/optimize_conf.php');
	$configdb=array();
	$query = $db->query("SELECT * FROM pw_config WHERE db_name LIKE 'db\_%'");
	while ($rt = $db->fetch_array($query)){
		$configdb[$rt['db_name']]=$rt['db_value'];
	}
	foreach($optimize_conf['size'][$type] as $key=>$value){
		$c_key=$$key;
		if($c_key!=$value || $configdb[$key]!=$value){
			$rt=$db->get_one("SELECT db_name FROM pw_config WHERE db_name='$key'");
			if($rt['db_name']){
				$db->update("UPDATE pw_config SET db_value='$value' WHERE db_name='$key'");
			}else{
				$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('$key','$value')");
			}
		}
	}
	updatecache_c();
	adminmsg('operate_success');
} elseif($_POST['action']=='func'){
	include(R_P.'admin/optimize_conf.php');
	$configdb=array();
	$query = $db->query("SELECT * FROM pw_config WHERE db_name LIKE 'db\_%'");
	while ($rt = $db->fetch_array($query)){
		$configdb[$rt['db_name']]=$rt['db_value'];
	}
	foreach($optimize_conf['func'][$type] as $key=>$value){
		$c_key=$$key;
		if($c_key!=$value || $configdb[$key]!=$value){
			$rt=$db->get_one("SELECT db_name FROM pw_config WHERE db_name='$key'");
			if($rt['db_name']){
				$db->update("UPDATE pw_config SET db_value='$value' WHERE db_name='$key'");
			}else{
				$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('$key','$value')");
			}
		}
	}
	updatecache_c();
	adminmsg('operate_success');
}
?>