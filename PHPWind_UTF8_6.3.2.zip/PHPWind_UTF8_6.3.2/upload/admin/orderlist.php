<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename="$admin_file?adminjob=orderlist";

if(!$action){
	InitGP(array('state','page'));
	if($state == 1){
		$sqladd = "WHERE state=0 OR state=1";
	} elseif($state == 2){
		$sqladd = "WHERE state=2";
	} else {
		$sqladd = '';
	}

	include_once(R_P.'require/forum.php');
	(!is_numeric($page) || $page < 1) && $page = 1;
	$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
	$rt    = $db->get_one("SELECT COUNT(*) AS sum FROM pw_clientorder $sqladd");
	$pages = numofpage($rt['sum'],$page,ceil($rt['sum']/$db_perpage),"$basename&state=$state&");

	$orderdb = array();
	$query = $db->query("SELECT c.*,m.username FROM pw_clientorder c LEFT JOIN pw_members m USING(uid) $sqladd ORDER BY date DESC $limit");
	while($rt=$db->fetch_array($query)){
		$rt['date'] = get_date($rt['date']);
		$orderdb[]  = $rt;
	}
	include PrintEot('orderlist');exit;
} elseif($action == 'pay'){
	InitGP(array('id','step','payemail'));
	$rt=$db->get_one("SELECT c.*,m.username FROM pw_clientorder c LEFT JOIN pw_members m USING(uid) WHERE id='$id' AND state=0");
	!$rt && adminmsg('undefined_action');
	if(!$step){
		$rt['date'] = get_date($rt['date']);
		include PrintEot('orderlist');exit;
	}else{
		if(!$payemail){
			$basename="javascript:history.go(-1);";
			adminmsg('no_payemail');
		}
		!$db_rmbrate && $db_rmbrate=10;
		$currency = $rt['number'] * $db_rmbrate;
		$number   = $rt['number'];
		$db->update("UPDATE pw_memberdata SET currency=currency+'$currency' WHERE uid='$rt[uid]'");
		$db->update("UPDATE pw_clientorder SET payemail='$payemail',state=2 WHERE id='$id'");
		
		$log=array(
			'nums'		=>	0,
			'money'		=>	0,
			'uid'		=>	$rt['uid'],
			'username'	=>	Char_cv($rt['username']),
			'ip'		=>	$onlineip,
			'time'		=>	$timestamp,
			'number'	=>	$number,
			'currency'	=>	$currency,
		);
		include_once('template/wind/lang_toollog.php');
		$log['type']    = $lang['olpay'];
		$log['descrip'] = Char_cv($lang['olpay_descrip']);

		$db->update("INSERT INTO pw_toollog(type,filename,nums,money,descrip,uid,touid,username,ip,time) VALUES('$log[type]','$log[filename]','".(int)$log['nums']."','".(int)$log['money']."','$log[descrip]','$log[uid]','$log[touid]','$log[username]','$log[ip]','$log[time]')");

		require_once(R_P.'require/msg.php');
		$message=array(
			$rt['username'],
			'',
			'olpay_title',
			$timestamp,
			'olpay_content_2',
			'',
			'SYSTEM'
		);
		writenewmsg($message,1);
		adminmsg('operate_success');
	}
} elseif($_POST['action'] == 'del'){
	InitGP(array('selid'),'P');
	if(!$selid = checkselid($selid)){
		$basename="javascript:history.go(-1);";
		adminmsg('operate_error');
	}
	$db->update("DELETE FROM pw_clientorder WHERE id IN($selid)");
	adminmsg('operate_success');
}
?>