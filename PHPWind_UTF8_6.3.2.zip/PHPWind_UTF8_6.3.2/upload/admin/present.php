<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename="$admin_file?adminjob=present";

require_once(R_P."require/credit.php");
$credittype = GetCreditType();

if (empty($action)) {

	include PrintEot('present');exit;

} elseif ($action == "send") {

	$_SERVER['REQUEST_METHOD']!='POST' && PostCheck($verify);
	InitGP(array('step','by','sendto','subject','atc_content','present','percount','count'));
	$cache_file = D_P."data/bbscache/".substr($admin_pwd,10,10).".txt";
	if (!$step) {
		writeover($cache_file,$atc_content);
	} else {
		$atc_content = readover($cache_file);
	}
	if (empty($subject) || empty($atc_content)) {
		adminmsg('sendmsg_empty');
	}
	$subject     = Char_cv($subject);
	$sendmessage = Char_cv($atc_content);
	!$percount && $percount = 100;
	empty($step) && $step = 1;
	$start = ($step-1)*$percount;
	$limit = "LIMIT $start,$percount";

	$sqladd = $creditlist = '';
	require_once GetLang('other');
	$sendmessage .= '<br /><br /><b>'.$lang['affect'].'</b>';

	foreach ($present as $key => $val) {
		if (empty($val)) continue;
		if (is_numeric($val)) {
			$creditlist .= "&present[$key]=$val";
			$sendmessage .= $credittype[$key]."<font color=#FA891B>(+$val)</font> ";
			if (in_array($key,array('rvrc','money','credit','currency'))) {
				$key == 'rvrc' && $val *= 10;
				$sqladd .= ($sqladd ? ',' : '')."$key=$key+'$val'";
			}
		} else {
			adminmsg('credit_isnum');
		}
	}

	if ($by == 0) {
		!$sendto && adminmsg('operate_error');
		is_array($sendto) && $sendto = implode(",",$sendto);
		$sqlwhere = "groupid IN('".str_replace(",","','",$sendto)."')";
		if ($step == 1) {
			$rs = $db->get_one("SELECT count(*) AS count FROM pw_members WHERE $sqlwhere");
			$count = $rs['count'];
			$db->update("INSERT INTO pw_msg (togroups,fromuid,username,type,ifnew,mdate) VALUES (',$sendto,','0','SYSTEM','public','0','$timestamp')");
			$mid = $db->insert_id();
			$db->update("REPLACE INTO pw_msgc(mid,title,content) VALUES ('$mid','$subject','$sendmessage')");
		}
	} elseif ($by == 1) {
		require_once(R_P.'require/GetOnlineUser.php');
		$onlineuser = GetOnlineUser();
		$uids = '';
		foreach ($onlineuser as $key => $value) {
			is_numeric($key) && $uids .=  $uids ? ",$key" : $key;
		}
		$sqlwhere = "uid IN($uids)";
		$count = count($onlineuser);
	} else {
		adminmsg('operate_error');
	}

	$msg_a = array();
	$uids  = $pruids = '';
	$query = $db->query("SELECT uid,username,email,newpm FROM pw_members WHERE $sqlwhere $limit");
	while ($rt = $db->fetch_array($query)) {
		$uids .= $uids ? ','.$rt['uid'] : $rt['uid'];

		if ($by == 1) {
			$msg_a[] = array($rt['uid'],'0','System','rebox','1',$timestamp,$subject,$sendmessage);
		} else {
			!$rt['newpm'] && $pruids .= ($pruids ? ',' : '').$rt['uid'];
		}
		foreach ($present as $key => $val) {
			if ($val && is_numeric($val) && is_numeric($key)) {
				$db->pw_update(
					"SELECT value FROM pw_membercredit WHERE uid='$rt[uid]' AND cid='$key'",
					"UPDATE pw_membercredit SET value=value+'$val' WHERE uid='$rt[uid]' AND cid='$key'",
					"INSERT INTO pw_membercredit(uid,cid,value) VALUES('$rt[uid]','$key','$val')"
				);
			}
		}
	}
	if ($msg_a) {
		require_once(R_P.'require/msg.php');
		send_msgc($msg_a);
	}
	$pruids && $db->update("UPDATE pw_members SET newpm=1 WHERE uid IN($pruids)");
	if ($sqladd && $uids) {
		$db->update("UPDATE pw_memberdata SET $sqladd WHERE uid IN($uids)");
	}
	$havesend = $step*$percount;
	if ($count > $step*$percount) {
		$step++;
		$j_url = "$basename&action=$action&step=$step&count=$count&sendto=$sendto&subject=". rawurlencode($subject)."&by=$by&percount=$percount$creditlist";
		adminmsg("sendmsg_step",EncodeUrl($j_url),1);
	} else {
		P_unlink($cache_file);
		adminmsg('sendmsg_success');
	}
}
?>