<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename="$amind_file?adminjob=rebang";
if(!$action){
	if ($_POST['step']) {
		InitGP(array('config'),'P');
		$ifsort = 0;
		foreach ($config['ifsort'] as $val) {
			$ifsort ^= (int)$val;
		}
		$db->pw_update(
			"SELECT * FROM pw_config WHERE db_name='db_ifsort'",
			"UPDATE pw_config SET db_value='$ifsort' WHERE db_name='db_ifsort'",
			"INSERT INTO pw_config(db_name,db_value) VALUES ('db_ifsort','$ifsort')"
		);
		$sortnum = $config['sortnum'] ? (int)$config['sortnum'] : 20;
		$db->pw_update(
			"SELECT * FROM pw_config WHERE db_name='db_sortnum'",
			"UPDATE pw_config SET db_value='$sortnum' WHERE db_name='db_sortnum'",
			"INSERT INTO pw_config(db_name,db_value) VALUES ('db_sortnum','$sortnum')"
		);
		$sorttime = $config['sorttime'] ? (int)$config['sorttime'] : 300;
		$db->pw_update(
			"SELECT * FROM pw_config WHERE db_name='db_sorttime'",
			"UPDATE pw_config SET db_value='$sorttime' WHERE db_name='db_sorttime'",
			"INSERT INTO pw_config(db_name,db_value) VALUES ('db_sorttime','$sorttime')"
		);
		updatecache_c();
		adminmsg('operate_success',$basename);
	} else {
		$ifsort_1 = $db_ifsort&1 ? 'checked' : '';
		$ifsort_2 = $db_ifsort&2 ? 'checked' : '';
		$ifsort_4 = $db_ifsort&4 ? 'checked' : '';
		$ifsort_8 = $db_ifsort&8 ? 'checked' : '';
		$ifsort_16 = $db_ifsort&16 ? 'checked' : '';
		!$db_sortnum && $db_sortnum = 20;
		!$db_sorttime && $db_sorttime = 300;
		include PrintEot('rebang');exit;
	}
} elseif ($action == 'rebang') {
	@include_once(D_P.'data/bbscache/newinfo_config.php');
	require_once(R_P.'require/credit.php');
	$creditdb = GetCreditValue();
	if ($_POST['job'] == 'cate') {
		InitGP(array('cate'));
		$sort = $catedb = array();
		foreach ($cate as $key=>$val) {
			$flag = Char_cv($val['flag']);
			$id = Char_cv($val['id']);
			$val['type'] = Char_cv($val['type']);
			if (!$flag) {
				$flag = $id ? $id : randstr(5);
			} elseif($id && $id!=$flag) {
				$nf_order[$id] = $nf_order[$flag];
				$nf_newinfodb[$id] = $nf_newinfodb[$flag];
				unset($nf_order[$flag]);
				unset($nf_newinfodb[$flag]);
				$flag = $id;
			}
			$tmp = $nf_order[$flag]['type']==$val['type'] ? $nf_order[$flag] : array();
			$tmp['name']  = Char_cv($val['name']);
			$tmp['type']  = $val['type'];
			$tmp['order'] = (int)$val['order'];
			$catedb[$flag] = $tmp;
			$sort[$flag] = $tmp['order'];
		}
		$nf_newinfo = $nf_order = array();
		arsort($sort);
		foreach ($sort as $key=>$val) {
			$nf_order[$key] = $catedb[$key];
			$nf_newinfodb[$key] && $nf_newinfo[$key] = $nf_newinfodb[$key];
		}
		$nf_order = addslashes(serialize($nf_order));
		$nf_newinfodb = addslashes(serialize($nf_newinfo));
		$db->pw_update(
			"SELECT * FROM pw_config WHERE db_name='nf_order'",
			"UPDATE pw_config SET db_value='$nf_order' WHERE db_name='nf_order'",
			"INSERT INTO pw_config(db_name,db_value) VALUES ('nf_order','$nf_order')"
		);
		$db->pw_update(
			"SELECT * FROM pw_config WHERE db_name='nf_newinfodb'",
			"UPDATE pw_config SET db_value='$nf_newinfodb' WHERE db_name='nf_newinfodb'",
			"INSERT INTO pw_config(db_name,db_value) VALUES ('nf_newinfodb','$nf_newinfodb')"
		);
		updatecache_newinfo();
		adminmsg('operate_success',"$basename&action=rebang");
	} elseif($_POST['job']=='config') {
		InitGP(array('newinfoifopen','position','titlelen','shownum','updatetime'),'P');
		$newinfoifopen = $newinfoifopen ? '1' : '0';
		$nf_config['position'] = (int)$position ? (int)$position : '1';
		$nf_config['titlelen'] = (int)$titlelen ? (int)$titlelen : '25';
		$nf_config['shownum'] = (int)$shownum ? (int)$shownum : '7';
		$nf_config['updatetime'] = (int)$updatetime ? (int)$updatetime : '600';
		$nf_config = addslashes(serialize($nf_config));
		$db->pw_update(
			"SELECT * FROM pw_config WHERE db_name='db_newinfoifopen'",
			"UPDATE pw_config SET db_value='$newinfoifopen' WHERE db_name='db_newinfoifopen'",
			"INSERT INTO pw_config(db_name,db_value) VALUES ('db_newinfoifopen','$newinfoifopen')"
		);
		$db->pw_update(
			"SELECT * FROM pw_config WHERE db_name='nf_config'",
			"UPDATE pw_config SET db_value='$nf_config' WHERE db_name='nf_config'",
			"INSERT INTO pw_config(db_name,db_value) VALUES ('nf_config','$nf_config')"
		);
		updatecache_c();
		updatecache_newinfo();
		adminmsg('operate_success',"$basename&action=rebang");
	} else {
		if ($nf_newinfodb) {
			$tmp = addslashes(serialize($nf_newinfodb));
			$db->pw_update(
				"SELECT * FROM pw_config WHERE db_name='nf_newinfodb'",
				"UPDATE pw_config SET db_value='$tmp' WHERE db_name='nf_newinfodb'",
				"INSERT INTO pw_config(db_name,db_value) VALUES ('nf_newinfodb','$tmp')"
			);
		}
		if ($nf_order) {
			$tmp = addslashes(serialize($nf_order));
			$db->pw_update(
				"SELECT * FROM pw_config WHERE db_name='nf_order'",
				"UPDATE pw_config SET db_value='$tmp' WHERE db_name='nf_order'",
				"INSERT INTO pw_config(db_name,db_value) VALUES ('nf_order','$tmp')"
			);
		}
		ifcheck($db_newinfoifopen,'newinfoifopen');
		$nf_config['position']  ?  ${'position_'.$nf_config['position']} = 'checked' : $position_1 = 'checked';
		!$nf_config['titlelen'] && $nf_config['titlelen'] = '25';
		!$nf_config['shownum'] && $nf_config['shownum'] = '7';
		!$nf_config['updatetime'] && $nf_config['updatetime'] = '600';
		include PrintEot('rebang');exit;
	}
} elseif ($action == 'update') {
	@include_once (D_P.'data/bbscache/newinfo_config.php');
	$orderid = GetGP('orderid');
	$orderid = Char_cv($orderid);
	!$nf_config['shownum'] && $nf_config['shownum'] = '7';
	!$nf_config['titlelen'] && $nf_config['titlelen'] = '24';
	!$nf_order[$orderid] && adminmsg('operate_fail',"$basename&action=rebang");
	if ($nf_order[$orderid]['type'] == 'custom' || ($nf_order[$orderid]['type'] == 'newpic' && $nf_order[$orderid]['mode'])) {
		adminmsg('updatecache_null',"$basename&action=rebang");
	}
	$t		= array('hours'=>gmdate('G',$timestamp+$db_timedf*3600));
	$tddays = get_date($timestamp,'j');
	$tdtime	= (floor($timestamp/3600)-$t['hours'])*3600;
	$montime = $tdtime-($tddays-1)*86400;
	require_once (R_P.'require/rebang.php');
	$rebang = new reBang();
	if ($nf_order[$orderid]['type'] == 'newpic' && !$nf_order[$orderid]['mode']) {
		$nf_newinfodb[$orderid] = $rebang->getReBang('newpic',5);
	} elseif ($nf_order[$orderid]['type'] == 'info' && $nf_order[$orderid]['mode']) {
		$info = $rebang->getReBang('info',$nf_config['shownum']);
		$bbsinfo = explode(',',$nf_order[$orderid]['mode']);
		unset($nf_newinfodb[$orderid]);
		foreach ($bbsinfo as $val) {
			$nf_newinfodb[$orderid][$val] = $info[$val];
		}
	} elseif ($nf_order[$orderid]['type']) {
		$nf_newinfodb[$orderid] = $rebang->getReBang($nf_order[$orderid]['type'],$nf_config['shownum']);
	}
	foreach ($nf_newinfodb[$orderid] as $k=>$v) {
		$nf_newinfodb[$orderid][$k]['name'] && $nf_newinfodb[$orderid][$k]['name'] = substrs($v['name'],$nf_config['titlelen'],'N');
	}
	$updatetime = $nf_order[$orderid]['updatetime'] ? $nf_order[$orderid]['updatetime'] : ($nf_config['updatetime'] ? $nf_config['updatetime'] : '600');
	$nf_order[$orderid]['cachetime'] = $timestamp + $updatetime;
	$nf_order = addslashes(serialize($nf_order));
	$nf_newinfodb = addslashes(serialize($nf_newinfodb));
	$db->pw_update(
		"SELECT * FROM pw_config WHERE db_name='nf_newinfodb'",
		"UPDATE pw_config SET db_value='$nf_newinfodb' WHERE db_name='nf_newinfodb'",
		"INSERT INTO pw_config(db_name,db_value) VALUES ('nf_newinfodb','$nf_newinfodb')"
	);
	$db->pw_update(
		"SELECT * FROM pw_config WHERE db_name='nf_order'",
		"UPDATE pw_config SET db_value='$nf_order' WHERE db_name='nf_order'",
		"INSERT INTO pw_config(db_name,db_value) VALUES ('nf_order','$nf_order')"
	);
	updatecache_newinfo();
	adminmsg('operate_success',"$basename&action=rebang");
} elseif ($action == 'setting') {
	@include_once (D_P.'data/bbscache/newinfo_config.php');
	InitGP(array('orderid','type'));
	$orderid = Char_cv($orderid);
	$type = Char_cv($type);
	if (!$nf_order[$orderid] || $nf_order[$orderid]['type'] != $type) {
		adminmsg('operate_fail',"$basename&action=rebang");
	}
	if ($type == 'newpic') {
		if ($_POST['step'] == '2') {
			InitGP(array('picmode','urls','links','title'),'P');
			$nf_order[$orderid]['mode'] = $picmode ? '1' : '0';
			if ($nf_order[$orderid]['mode'] && is_array($urls)){
				$pic = array();
				foreach ($urls as $key => $value) {
					if($value && $links[$key]){
						$pic[] = array(
							'id'		=> stripslashes($links[$key]),
							'name'		=> stripslashes($title[$key]),
							'value'		=> stripslashes($value)
						);
					}
				}
				$nf_newinfodb[$orderid] = $pic;
				$nf_newinfodb = addslashes(serialize($nf_newinfodb));
				$db->pw_update(
					"SELECT * FROM pw_config WHERE db_name='nf_newinfodb'",
					"UPDATE pw_config SET db_value='$nf_newinfodb' WHERE db_name='nf_newinfodb'",
					"INSERT INTO pw_config(db_name,db_value) VALUES ('nf_newinfodb','$nf_newinfodb')"
				);
			}
		} else {
			if(!$nf_order[$orderid]['mode']){
				$picmode_1 = 'checked';
			} else{
				$picmode_2 = 'checked';
			}
			include PrintEot('rebang');exit;
		}
	} elseif ($type == 'custom') {
		if (!$_POST['step']) {
			foreach ($nf_newinfodb[$orderid] as $key=>$value) {
				$nf_newinfodb[$orderid][$key]['name'] = Quot_cv($value['name']);
			}
			include PrintEot('rebang');exit;
		} else {
			InitGP(array('titles','links'),'P');
			if (is_array($titles)){
				$custom = array();
				foreach ($titles as $key => $value) {
					if($value){
						$custom[] = array(
							'name'=>stripslashes($value),
							'id'=>$links[$key],
						);
					}
				}
				$nf_newinfodb[$orderid] = $custom;
				$nf_newinfodb = addslashes(serialize($nf_newinfodb));
				$db->pw_update(
					"SELECT * FROM pw_config WHERE db_name='nf_newinfodb'",
					"UPDATE pw_config SET db_value='$nf_newinfodb' WHERE db_name='nf_newinfodb'",
					"INSERT INTO pw_config(db_name,db_value) VALUES ('nf_newinfodb','$nf_newinfodb')"
				);
			}
		}
	} elseif ($type == 'info') {
		if ($_POST['step'] == '2') {
			InitGP(array('info'),'P');
			$bbsinfo = '';
			foreach ($info as $val) {
				$val = Char_cv($val);
				$val && $bbsinfo .= ','.$val;
			}
			$bbsinfo && $bbsinfo = substr($bbsinfo,1);
			$nf_order[$orderid]['mode'] = $bbsinfo;
		} else {
			$bbsinfo = explode(',',$nf_order[$orderid]['mode']);
			foreach ($bbsinfo as $val) {
				$$val = 'checked';
			}
			include PrintEot('rebang');exit;
		}
	} elseif (!$_POST['step']) {
		include PrintEot('rebang');exit;
	}
	if ($_POST['step'] == '2') {
		$updatetime = GetGP('updatetime','P');
		$nf_order[$orderid]['updatetime'] = is_numeric($updatetime) ? intval($updatetime) : '0';
		$nf_order = addslashes(serialize($nf_order));
		$db->pw_update(
			"SELECT * FROM pw_config WHERE db_name='nf_order'",
			"UPDATE pw_config SET db_value='$nf_order' WHERE db_name='nf_order'",
			"INSERT INTO pw_config(db_name,db_value) VALUES ('nf_order','$nf_order')"
		);
		updatecache_newinfo();
		adminmsg('operate_success',"$basename&action=rebang");
	}
} elseif ($action == 'cache') {
	$type = GetGP('type','G');
	if (!$type) {
		include PrintEot('rebang');exit;
	}else{
		!$db_sortnum && $db_sortnum = 20;
		require_once(R_P.'require/rebang.php');
		$rebang = new reBang();
		if($type=='newpic'){
			$_NEWPIC = array();
			@include_once(D_P.'data/bbscache/sort_newpic.php');
			$_NEWPIC = $rebang->getNewPic($db_sortnum);;
			writeover(D_P.'data/bbscache/sort_newpic.php',"<?php\r\n\$_NEWPIC = ".pw_var_export($_NEWPIC).";\r\n?>");
		}elseif($type=='newpost'){
			$_NEWPOST = array();
			@include_once(D_P.'data/bbscache/sort_newpost.php');
			$_NEWPOST = $rebang->getNewPost($db_sortnum);
			writeover(D_P.'data/bbscache/sort_newpost.php',"<?php\r\n\$_NEWPOST = ".pw_var_export($_NEWPOST).";\r\n?>");
		}elseif($type=='newreply'){
			$_NEWREPLY = array();
			@include_once(D_P.'data/bbscache/sort_newreply.php');
			$_NEWREPLY = $rebang->getNewReply($db_sortnum);
			writeover(D_P.'data/bbscache/sort_newreply.php',"<?php\r\n\$_NEWREPLY = ".pw_var_export($_NEWREPLY).";\r\n?>");
		}elseif($type=='post'){
			$step = GetGP('step');
			$__THRESHOLD = $__ARTICLEDB = $_ARTICLE = array();
			$array = array('digest','hits','replies');
			$step = $step ? intval($step) : 0;
			if ($array[$step]) {
				@include_once(D_P.'data/bbscache/sort_article.php');
				@include_once(D_P.'data/bbscache/sort_articledata.php');
				$_ARTICLE[$array[$step]] = $rebang->getPost($db_sortnum,$array[$step]);
				unset($__ARTICLEDB[$array[$step]]);
				foreach ($_ARTICLE[$array[$step]] as $val) {
					$__ARTICLEDB[$array[$step]][$val['id']] = $val['value'];
				}
				$__THRESHOLD[$array[$step]] = end($__ARTICLEDB[$array[$step]]);
				writeover(D_P.'data/bbscache/sort_article.php',"<?php\r\n\$__THRESHOLD = ".pw_var_export($__THRESHOLD).";\r\n\$__ARTICLEDB = ".pw_var_export($__ARTICLEDB).";\r\n?>");
				writeover(D_P.'data/bbscache/sort_articledata.php',"<?php\r\n\$_ARTICLE = ".pw_var_export($_ARTICLE).";\r\n?>");
				$step++;
				adminmsg('updatecache_autostep',"$basename&action=cache&type=post&step=$step");
			} else {
				adminmsg('operate_success',"$basename&action=cache");
			}
		}elseif($type=='member'){
			$step = GetGP('step');
			$array = array('postnum','todaypost','monthpost','onlinetime','rvrc','money','credit','currency');
			foreach ($_CREDITDB as $key => $value) {
				array_push($array,$key);
			}
			$step = $step ? intval($step) : 0;
			if ($array[$step]) {
				$__THRESHOLD = $__MEMBERDB = $_MEMBER = array();
				$t		= array('hours'=>gmdate('G',$timestamp+$db_timedf*3600));
				$tddays = get_date($timestamp,'j');
				$tdtime	= (floor($timestamp/3600)-$t['hours'])*3600;
				$montime = $tdtime-($tddays-1)*86400;
				@include_once(D_P.'data/bbscache/sort_member.php');
				$_MEMBER[$array[$step]] = $rebang->getMember($db_sortnum,$array[$step]);
				unset($__MEMBERDB[$array[$step]]);
				foreach ($_MEMBER[$array[$step]] as $val) {
					$__MEMBERDB[$array[$step]][$val['id']] = $val['value'];
				}
				$__THRESHOLD[$array[$step]] = end($__MEMBERDB[$array[$step]]);
				writeover(D_P.'data/bbscache/sort_member.php',"<?php\r\n\$__THRESHOLD = ".pw_var_export($__THRESHOLD).";\r\n\$__MEMBERDB = ".pw_var_export($__MEMBERDB).";\r\n?>");
				writeover(D_P.'data/bbscache/sort_memberdata.php',"<?php\r\n\$_MEMBER = ".pw_var_export($_MEMBER).";\r\n?>");
				$step++;
				adminmsg('updatecache_autostep',"$basename&action=cache&type=member&step=$step");
			} else {
				adminmsg('operate_success',"$basename&action=cache");
			}
		}
		adminmsg('operate_success',"$basename&action=cache");
	}
}

function updatecache_newinfo() {
	global $db;
	$query = $db->query("SELECT * FROM pw_config WHERE db_name LIKE 'nf\_%'");
	$newinfodb = "<?php\r\n";
	while (@extract($db->fetch_array($query))) {
		$db_name = preg_replace('/[^\d\w\_]/is','',$db_name);
		$db_value = (array)unserialize($db_value);
		$newinfodb .= "\$$db_name=".pw_var_export($db_value).";\r\n";
	}
	$newinfodb .= "\n?>";
	writeover(D_P.'data/bbscache/newinfo_config.php',$newinfodb);
}
?>