<?php
!function_exists('adminmsg') && exit('Forbidden');
$type!='reply' && $type = 'topic';
!$db_perpage && $db_perpage = 25;
$basename="$admin_file?adminjob=recycle";
$fid = (int)GetGP('fid');
include_once(R_P.'require/forum.php');
require_once(R_P.'require/updateforum.php');

if($admin_gid == 5){
	list($allowfid,$forumcache) = GetAllowForum($admin_name);
	$sql = "AND r.fid IN($allowfid)";
} else{
	include(D_P.'data/bbscache/forumcache.php');
	list($hidefid,$hideforum) = GetHiddenForum();
	if($admin_gid == 3){
		$forumcache .= $hideforum;
		$sql = '';
	} else{
		$sql = "AND r.fid NOT IN($hidefid)";
	}
}
$forumcache = str_replace("<option value=\"$fid\">","<option value=\"$fid\" selected>",$forumcache);

if(!$action){
	InitGP(array('admin','username','uid','page'));
	$fid && $sql = " AND r.fid='$fid'";
	$admin && $sql .= " AND r.admin='$admin'";
	if($username){
		$rt  = $db->get_one("SELECT uid FROM pw_members WHERE username='$username'");
		$uid = $rt['uid'];
	}
	(!is_numeric($page) || $page<1) && $page = 1;
	$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
	if ($type == 'topic'){
		is_numeric($uid) && $sql .= " AND t.authorid='$uid'";
		$rt    = $db->get_one("SELECT COUNT(*) AS sum FROM pw_recycle r LEFT JOIN pw_threads t USING(tid) WHERE r.pid='0' $sql");
		$pages = numofpage($rt['sum'],$page,ceil($rt['sum']/$db_perpage),"$basename&fid=$fid&uid=$uid&admin=$admin&type=$type&");
		$query = $db->query("SELECT r.*,t.subject,t.author,t.authorid FROM pw_recycle r LEFT JOIN pw_threads t USING(tid) WHERE r.pid='0' $sql ORDER BY deltime DESC $limit");
		while($rt=$db->fetch_array($query)){
			$rt['deltime'] = get_date($rt['deltime']);
			$rt['subject'] = substrs($rt['subject'],50);
			$rt['fname']   = $forum[$rt['fid']]['name'];
			$recycledb[$rt['tid']] = $rt;
			$ttable_a[GetTtable($rt['tid'])] .= ','.$rt['tid'];
		}
		foreach ($ttable_a as $pw_tmsgs=>$value) {
			$value = substr($value,1);
			$query = $db->query("SELECT tid,content FROM $pw_tmsgs WHERE tid IN($value)");
			while ($rt = $db->fetch_array($query)) {
				$rt['content'] = str_replace("\n","<br>",$rt['content']);
				$recycledb[$rt['tid']]['content'] = $rt['content'];
			}
		}
	} else {
		if ($db_plist) {
			$ptable = GetGP('ptable');
			!is_numeric($ptable) && $ptable = $db_ptable;
			$p_table = "<option value=\"0\">post</option>";
			$p_list  = explode(',',$db_plist);
			foreach ($p_list as $key=>$val) {
				$p_table .= "<option value=\"$val\">post$val</option>";
			}
			$p_table  = str_replace("<option value=\"$ptable\">","<option value=\"$ptable\" selected>",$p_table);
			$url_a	 .= "ptable=$ptable&";
			$pw_posts = GetPtable($ptable);
		} else {
			$pw_posts = 'pw_posts';
		}
		is_numeric($uid) && $sql .= " AND p.authorid='$uid'";
		$rt    = $db->get_one("SELECT COUNT(*) AS sum FROM pw_recycle r LEFT JOIN $pw_posts p USING(pid) WHERE r.pid>'0' $sql AND p.fid='0'");
		$pages = numofpage($rt['sum'],$page,ceil($rt['sum']/$db_perpage),"$basename&fid=$fid&uid=$uid&admin=$admin&ptable=$ptable&type=$type&");
		$query = $db->query("SELECT r.*,p.author,p.authorid,p.content,t.subject FROM pw_recycle r LEFT JOIN $pw_posts p USING(pid) LEFT JOIN pw_threads t ON r.tid=t.tid WHERE r.pid>'0' $sql AND p.fid='0' ORDER BY deltime DESC $limit");
		while($rt=$db->fetch_array($query)){
			$rt['deltime'] = get_date($rt['deltime']);
			$rt['subject'] = substrs($rt['subject'],50);
			$rt['content'] = str_replace("\n","<br>",$rt['content']);
			$rt['fname']   = $forum[$rt['fid']]['name'];
			$recycledb[]   = $rt;
		}
	}
	include PrintEot('recycle');exit;
} elseif($_POST['action'] == 'revert'){
	InitGP(array('selid'),'P');
	$selids = '';
	$fids	= array();
	foreach($selid as $key => $value){
		if(is_numeric($key)){
			$fids[$value] = 1;
			$selids .= ','.$key;
		}
	}
	if($selids){
		$selids = substr($selids,1);
		if ($type == 'topic') {
			$ptable_a = array();
			$query = $db->query("SELECT fid,ptable FROM pw_threads WHERE tid IN ($selids)");
			while ($rt = $db->fetch_array($query)) {
				$ptable_a[$rt['ptable']]=1;
			}
			foreach ($ptable_a as $key=>$val) {
				$pw_posts = GetPtable($key);
				$db->update("UPDATE pw_recycle r LEFT JOIN $pw_posts p ON r.tid=p.tid SET p.fid=r.fid WHERE r.pid='0' AND r.tid IN($selids)");
			}
			$db->update("UPDATE pw_recycle r LEFT JOIN pw_threads t ON r.tid=t.tid SET t.fid=r.fid,t.ifshield='0' WHERE r.pid='0' AND r.tid IN ($selids)");
			$db->update("UPDATE pw_attachs a LEFT JOIN pw_recycle r ON a.tid=r.tid SET a.fid=r.fid WHERE a.tid IN($selids)");

			$db->update("DELETE FROM pw_recycle WHERE tid IN ($selids)");
		} else {
			$ptable = GetGP('ptable');
			!is_numeric($ptable) && $ptable = $db_ptable;
			$pw_posts = GetPtable($ptable);
			$db->update("UPDATE $pw_posts p LEFT JOIN pw_recycle r ON p.pid=r.pid SET p.tid=r.tid,p.fid=r.fid WHERE p.pid IN ($selids)");
			$db->update("UPDATE pw_attachs a LEFT JOIN pw_recycle r ON a.pid=r.pid SET a.fid=r.fid WHERE a.pid IN ($selids)");
			$repliesnum = array();
			$query = $db->query("SELECT * FROM pw_recycle WHERE pid IN ($selids)");
			while($rt = $db->fetch_array($query)){
				$repliesnum[$rt['tid']]++;
			}
			foreach ($repliesnum as $key=>$val) {
				$db->update("UPDATE pw_threads SET replies=replies+'$val' WHERE tid='$key'");
			}
			$db->update("DELETE FROM pw_recycle WHERE pid IN ($selids)");
		}

	}
	foreach($fids as $key => $value){
		updateforum($key);
	}
	adminmsg('operate_success');
} elseif($action == 'delete' || $action == 'del'){
	$_SERVER['REQUEST_METHOD']!='POST' && PostCheck($verify);
	if ($action == 'del') {
		InitGP(array('selid'),'P');
		$selids = '';
		foreach($selid as $key => $value){
			if(is_numeric($key)){
				$selids .= ','.$key;
			}
		}
		$selids = substr($selids,1);
		if (empty($selids)){
			adminmsg('operate_success');
		}
	}

	$ftp = null;
	if ($db_ifftp) {
		require_once(R_P.'require/ftp.php');
		$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
	}
	$goon = 0;
	if ($type == 'topic') {
		$taid_a = $ttable_a = $ptable_a = array();
		$delids = $shids = $pollids = $actids = $delaids = $rewids = $ids = '';
		if ($action == 'del') {
			$sql = "WHERE  r.pid='0' AND r.tid IN ($selids)";
		} else {
			$sql = "WHERE r.pid='0' AND (t.fid='0' OR t.ifshield='2')";
		}
		$query  = $db->query("SELECT r.*,special,ifshield,ifupload,ptable FROM pw_recycle r LEFT JOIN pw_threads t ON r.tid=t.tid $sql LIMIT 100");
		while(@extract($db->fetch_array($query))){
			$goon = 1;
			$ids .= ','.$tid;
			$ifshield != '2' && $delids .= $tid.',';
			$special == 1 && $pollids .= $tid.',';
			$special == 2 && $actids  .= $tid.',';
			$special == 3 && $rewids  .= $tid.',';
			if ($ifshield != '2') {
				$ptable_a[$ptable] = 1;
				$ttable_a[GetTtable($tid)] .= $tid.',';
			}
			if($ifupload){
				$taid_a[GetTtable($tid)] .= $tid.',';
				if ($ifshield != '2') {
					$pw_posts = GetPtable($ptable);
					$query2 = $db->query("SELECT aid FROM $pw_posts WHERE tid='$tid' AND aid!=''");
					while(@extract($db->fetch_array($query2))){
						if(!$aid) continue;
						$attachs = unserialize(stripslashes($aid));
						foreach($attachs as $key => $value){
							is_numeric($key) && $delaids .= $key.',';
							if($ftp && !file_exists($attachdir."/".$value['attachurl'])){
								$ftp->delete($value['attachurl']);
								$value['ifthumb'] && $ftp->delete("thumb/$value[attachurl]");
							} else{
								P_unlink("$attachdir/$value[attachurl]");
								$value['ifthumb'] && P_unlink("$attachdir/thumb/$value[attachurl]");
							}
						}
					}
				}
			}
		}
		foreach($taid_a as $pw_tmsgs=>$value){
			$value = substr($value,0,-1);
			$query = $db->query("SELECT aid FROM $pw_tmsgs WHERE tid IN($value) AND aid!=''");
			while(@extract($db->fetch_array($query))){
				if(!$aid) continue;
				$attachs = unserialize(stripslashes($aid));
				foreach($attachs as $key => $value){
					is_numeric($key) && $delaids .= $key.',';
					if($ftp && !file_exists($attachdir."/".$value['attachurl'])){
						$ftp->delete($value['attachurl']);
						$value['ifthumb'] && $ftp->delete("thumb/$value[attachurl]");
					} else{
						P_unlink("$attachdir/$value[attachurl]");
						$value['ifthumb'] && P_unlink("$attachdir/thumb/$value[attachurl]");
					}
				}
			}
		}
		if($pollids){
			$pollids = substr($pollids,0,-1);
			$db->update("DELETE FROM pw_polls WHERE tid IN($pollids)");
		}
		if($actids){
			$actids = substr($actids,0,-1);
			$db->update("DELETE FROM pw_activity WHERE tid IN($actids)");
			$db->update("DELETE FROM pw_actmember WHERE actid IN($actids)");
		}
		if ($rewids) {
			$rewids = substr($rewids,0,-1);
			$db->update("DELETE FROM pw_reward WHERE tid IN($rewids)");
		}
		if($delaids){
			$delaids  = substr($delaids,0,-1);
			$db->update("DELETE FROM pw_attachs WHERE aid IN($delaids)");
		}
		$delids  = substr($delids,0,-1);
		if($delids){
			$db->update("DELETE FROM pw_threads	WHERE tid IN($delids)");
		}
		foreach($ttable_a as $pw_tmsgs=>$val){
			$val = substr($val,0,-1);
			$db->update("DELETE FROM $pw_tmsgs WHERE tid IN($val)");
		}
		foreach($ptable_a as $key=>$val){
			$pw_posts = GetPtable($key);
			$db->update("DELETE FROM $pw_posts WHERE tid IN($delids)");
		}
		delete_tag($delids);
		if ($ids) {
			$ids = substr($ids,1);
			$db->update("DELETE FROM pw_recycle WHERE tid IN ($ids)");
		}
	} else {
		$ptable = GetGP('ptable');
		!is_numeric($ptable) && $ptable = $db_ptable;
		$pw_posts = GetPtable($ptable);
		if ($action == 'del') {
			$sql = "WHERE pid IN ($selids) AND tid='0'";
		} else {
			$sql = "WHERE tid='0'";
		}
		$query = $db->query("SELECT pid,tid,fid,aid FROM $pw_posts $sql LIMIT 100");
		while ($rt=$db->fetch_array($query)) {
			$goon = 1;
			$ids .= ','.$rt['pid'];
			$attachdb[] = $rt['aid'];
		}
		if ($ids) {
			$ids = substr($ids,1);
			$db->update("DELETE FROM $pw_posts WHERE pid IN ($ids)");
			$db->update("DELETE FROM pw_recycle WHERE pid IN ($ids)");
		}
		if ($attachdb) {
			delete_att($attachdb);
		}
	}
	if ($ftp) {
		$ftp->close(); unset($ftp);
	}
	if($goon && $action == 'delete'){
		$j_url = "$basename&action=$action&type=$type";
		adminmsg('delete_recycle',EncodeUrl($j_url),2);
	} else{
		adminmsg('operate_success');
	}
} elseif ($action == 'clear') {
	InitGP(array('selid'),'P');
	$selid = implode(',',$selid);
	$selid = Char_cv($selid);
	if ($selid) {
		if ($type == 'topic') {
			$db->update("DELETE FROM pw_recycle WHERE tid IN ($selid) AND pid='0'");
		} else {
			$db->update("DELETE FROM pw_recycle WHERE pid IN ($selid)");
		}
		adminmsg('operate_success');
	} else {
		adminmsg('operate_error');
	}
}
?>