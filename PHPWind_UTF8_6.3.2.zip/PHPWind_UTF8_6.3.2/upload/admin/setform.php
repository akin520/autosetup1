<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename="$admin_file?adminjob=setform";
if(!$action){
	$setformdb=array();
	$query=$db->query("SELECT * FROM pw_setform");
	while($rt=$db->fetch_array($query)){
		${'c_'.$rt['id']} = $rt['ifopen'] ? 'checked' : '';
		$setformdb[]=$rt;
	}
	include PrintEot('setform');exit;
} elseif($action=='add'){
	if(!$_POST['step']){
		$num = 0;
		include PrintEot('setform');exit;
	} else{
		InitGP(array('name','value','descipt'),'P');
		(!$name || !$value) && adminmsg('setform_empty');
		$setform = array();
		foreach($value as $k=>$v){
			$setform[] = array($v,$descipt[$k]);
		}
		$setform = addslashes(serialize($setform));
		$db->update("INSERT INTO pw_setform (name,ifopen,value) VALUES('$name','1','$setform')");
		updatecache_form();
		adminmsg("operate_success");
	}
} elseif($action=='edit'){
	if(!$_POST['step']){
		InitGP(array('id'));
		@extract($db->get_one("SELECT name,value FROM pw_setform WHERE id='$id'"));
		!$name && adminmsg('operate_error');
		$setform = unserialize($value);
		$num     = count($setform);
		include PrintEot('setform');exit;
	} else{
		InitGP(array('id','name','value','descipt'),'P');
		(!$name || !$value) && adminmsg('setform_empty');
		$setform = array();
		foreach($value as $k=>$v){
			$setform[] = array($v,$descipt[$k]);
		}
		$setform = addslashes(serialize($setform));
		$db->update("UPDATE pw_setform SET name='$name',value='$setform' WHERE id='$id'");
		updatecache_form();
		adminmsg("operate_success");
	}
} elseif($_POST['action']=='del'){
	InitGP(array('selid','ifopen'),'P');
	if($selid = checkselid($selid)){
		$db->update("DELETE FROM pw_setform WHERE id IN($selid)");
	}
	$db->update("UPDATE pw_setform SET ifopen='0'");
	if($ifopen = checkselid($ifopen)){
		$db->update("UPDATE pw_setform SET ifopen='1' WHERE id IN($ifopen)");
	}
	updatecache_form();
	adminmsg("operate_success");
}
?>