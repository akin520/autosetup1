<?php
!function_exists('adminmsg') && exit('Forbidden');
$basename="$admin_file?adminjob=settings&type=$type";

if ($action!='unsubmit') {

	require_once(R_P.'require/credit.php');
	$creditType = GetCreditType();

	if (!$type || $type=='bbsset' || $type=='all') {
		$db_whybbsclose = str_replace('<br />',"\n",$db_whybbsclose);
		list($db_openpost,$db_poststart,$db_postend) = explode("\t",$db_openpost);
		list($db_opensch,$db_schstart,$db_schend) = explode("\t",$db_opensch);
		$db_forumdir = (int)$db_forumdir;
		$db_bbsifopen = (int)$db_bbsifopen;
		${'forumdir_'.$db_forumdir}='checked';
		${'bbsifopen_'.$db_bbsifopen} = 'checked';

		ifcheck($db_setindex,'setindex');
		ifcheck($db_openpost,'openpost');
		ifcheck($db_opensch,'opensch');
		ifcheck($db_regpopup,'regpopup');
		ifcheck($db_debug,'debug');
	}
	if ($type=='setgd' || $type=='all') {
		for ($i = 0; $i < 6; $i++) {
			${'setgb_'.$i} = ($db_gdcheck & pow(2,$i)) ? 'checked' : '';
		}
		for ($i = 0; $i < 7; $i++) {
			${'gdstyle_'.$i} = ($db_gdstyle & pow(2,$i)) ? 'checked' : '';
		}
		${'gdtype_'.(int)$db_gdtype} = 'checked';
		$gdsize = explode("\t",$db_gdsize);

		list($regq,$loginq,$postq,$msgq) = explode("\t",$db_qcheck);
		ifcheck($regq,'regq');
		ifcheck($loginq,'loginq');
		ifcheck($msgq,'msgq');
	}
	if ($type=='basicset' || $type=='all') {
		ifcheck($db_recycle,'recycle');
		$db_hour && $hour_sel[$db_hour] = 'selected';
	}
	if($type=='pathset' || $type=='all'){
		$imgdisabled = $attdisabled = $htmdisabled = '';
		if (file_exists($imgdir) && !is_writeable($imgdir)) {
			$imgdisabled = 'disabled';
		}
		if (file_exists($attachdir) && !is_writeable($attachdir)) {
			$attdisabled = 'disabled';
		}
		if (file_exists(R_P.$db_htmdir) && !is_writeable(R_P.$db_htmdir)) {
			$htmdisabled = 'disabled';
		}
		ifcheck($db_autochange,'autochange');
	}
	if ($type=='coreset' || $type=='all') {
		require_once(R_P.'require/forum.php');
		$choseskin = getstyles($db_defaultstyle);
		$temptimedf = str_replace('.','_',abs($db_timedf));
		$db_timedf < 0 ? ${'zone_0'.$temptimedf}='SELECTED' : ${'zone_'.$temptimedf}='SELECTED';
		${'charset_'.str_replace('-','',$db_charset)} = 'SELECTED';
		$check_24 = ${'columns_'.$db_columns} = 'CHECKED';
		if ($db_datefm) {
			if (strpos($db_datefm,'h:i A')!==false) {
				$db_datefm = str_replace(' h:i A','',$db_datefm);
				$check_12 = 'CHECKED';
				$check_24 = '';
			} else {
				$db_datefm = str_replace(' H:i','',$db_datefm);
			}
			$db_datefm = str_replace(array('m','n','d','j','y','Y'),array('mm','m','dd','d','yy','yyyy'),$db_datefm);
		} else {
			$db_datefm = 'yyyy-mm-dd';
		}
		list($db_upload,$db_imglen,$db_imgwidth,$db_imgsize)=explode("\t",$db_upload);
		$db_onlinetime /= 60;
		$db_schwait = (int)$db_schwait;
		$db_obstart = (int)$db_obstart;

		ifcheck($db_online,'online');
		ifcheck($db_lp,'lp');
		ifcheck($db_upload,'upload');
		ifcheck($db_msgsound,'msgsound');
		ifcheck($db_ifonlinetime,'ifonlinetime');
		ifcheck($db_ifjump,'ifjump');
		ifcheck($db_footertime,'footertime');
		ifcheck($db_redundancy,'redundancy');
		ifcheck($db_shield,'shield');
		ifcheck($db_tcheck,'tcheck');
		ifcheck($db_forcecharset,'forcecharset');
		ifcheck($db_adminset,'adminset');
	}
	if ($type=='creditset' || $type=='all') {
		list($credits_1,$credits_2,$credits_3,$credits_4,$credits_5,$credits_6) = explode("\t",$db_credits);
	}
	if ($type=='regset' || $type=='all') {
		include(D_P.'data/bbscache/dbreg.php');
		$rg_whyregclose	= str_replace('<br />',"\n",$rg_whyregclose);
		$rg_welcomemsg	= str_replace('<br />',"\n",$rg_welcomemsg);
		$rg_rgpermit	= str_replace('<br />',"\n",$rg_rgpermit);
		$db_postallowtime && $regcheck[$db_postallowtime] = 'SELECTED';
		list($rg_regminname,$rg_regmaxname) = explode("\t",$rg_namelen);
		list($rg_regminpwd,$rg_regmaxpwd) = explode("\t",$rg_pwdlen);
		!$rg_regmaxpwd && $rg_regmaxpwd = '';
		ifcheck($rg_allowregister,'allowregister');
		ifcheck($rg_reg,'reg');
		ifcheck($rg_regdetail,'regdetail');
		ifcheck($rg_emailcheck,'emailcheck');
		ifcheck($rg_regsendmsg,'regsendmsg');
		ifcheck($rg_ifcheck,'ifcheck');
		ifcheck($rg_regsendemail,'regsendemail');
		ifcheck($rg_rglower,'rglower');
		ifcheck($rg_npdifferf,'npdifferf');
	}
	if ($type=='windcode' || $type=='all') {
		ifcheck($db_windpic['pic'],'windpic_pic');
		ifcheck($db_windpic['flash'],'windpic_flash');
		ifcheck($db_windpost['pic'],'windpost_pic');
		ifcheck($db_windpost['flash'],'windpost_flash');
		ifcheck($db_windpost['mpeg'],'windpost_mpeg');
		ifcheck($db_windpost['iframe'],'windpost_iframe');
		ifcheck($db_signwindcode,'signwindcode');
		ifcheck($db_windmagic,'windmagic');
		ifcheck($db_replysendmail,'replysendmail');
		ifcheck($db_replysitemail,'replysitemail');
		ifcheck($db_pwcode,'pwcode');
		ifcheck($db_setform,'setform');
		ifcheck($db_autoimg,'autoimg');

		$db_sellset = unserialize($db_sellset);
		$sellset = '';
		foreach ($creditType as $key => $value) {
			$checked  = in_array($key,$db_sellset['type']) ? 'checked' : '';
			$sellset .= "<input type=\"checkbox\" name=\"sellset[type][]\" value=\"$key\" $checked />$value ";
		}
	}
	if ($type=='attachset' || $type=='all') {
		!$db_attachnum && $db_attachnum = 4;
		!$db_attachdir && $db_attachdir = 0;
		$db_uploadfiletype = unserialize($db_uploadfiletype);
		$attachdir_ck[$db_attachdir] = 'checked';
		$maxuploadsize = ini_get('upload_max_filesize');
		ifcheck($db_allowupload,'allowupload');
		ifcheck($db_attfg,'attfg');
	}
	if ($type=='atcset' || $type=='all') {
		$credit = unserialize($db_creditset);
		foreach ($credit as $key => $value) {
			foreach ($value as $k => $v) {
				$v = (int)$v;
				if ($key=='rvrc' && $k!='Reply' && $k!='Deleterp') {
					$v /= 10;
				}
				$credit[$key][$k] = $v;
			}
		}
	}
	if ($type=='indexset' || $type=='all') {
		$gporder = explode(',',$db_showgroup);
		$usergroup = ''; $num = 0;
		foreach ($ltitle as $key => $value) {
			if ($key!=1 && $key!=2) {
				$num++;
				$htm_tr = $num % 2 == 0 ? '</tr><tr>' : '';
				if (in_array($key,$gporder)) {
					$g_ck    = 'checked';
					$g_order = array_search($key,$gporder);
				} else {
					$g_order = $g_ck = '';
				}
				$usergroup .= "<td><input type=\"checkbox\" name=\"gpshow[$key]\" value=\"$key\" $g_ck><input name=\"gporder[$key]\" value=\"$g_order\" size=\"1\"> $value</td>$htm_tr";
			}
		}
		$usergroup && $usergroup = "<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"100%\" align=\"center\"><tr>$usergroup</tr></table>";

		$db_indexfmlogo!=1 && $db_indexfmlogo!=2 && $db_indexfmlogo = 0;
		${'indexfmlogo_'.$db_indexfmlogo} = 'checked';

		ifcheck($db_ifselfshare,'ifselfshare');
		ifcheck($db_indexlink,'indexlink');
		ifcheck($db_indexmqshare,'indexmqshare');
		ifcheck($db_indexshowbirth,'indexshowbirth');
		ifcheck($db_bdayautohide,'bdayautohide');
		ifcheck($db_indexonline,'indexonline');
		ifcheck($db_adminshow,'adminshow');
		ifcheck($db_showguest,'showguest');
		ifcheck($db_today,'today');
		ifcheck($db_todaypost,'todaypost');
		ifcheck($db_ifbookinfo,'ifbookinfo');
	}
	if ($type=='viewset' || $type=='all') {
		$db_hithour && $hithour_sel[$db_hithour] = 'selected';
		ifcheck($db_topped,'topped');
		ifcheck($db_threadonline,'threadonline');
		ifcheck($db_showonline,'showonline');
		ifcheck($db_showcolony,'showcolony');
		ifcheck($db_threademotion,'threademotion');
		ifcheck($db_ipfrom,'ipfrom');
		ifcheck($db_threadshowpost,'threadshowpost');
		$menu_p = $db_menu & 1 ? 'checked' : '';
		$menu_f = $db_menu & 2 ? 'checked' : '';
		$menu_m = $db_menu & 4 ? 'checked' : '';
		$ajax_1 = $db_ajax & 1 ? 'checked' : '';
		$ajax_2 = $db_ajax & 2 ? 'checked' : '';
		$ajax_4 = $db_ajax & 4 ? 'checked' : '';
		$ajax_8 = $db_ajax & 8 ? 'checked' : '';
		$ajax_16 = $db_ajax & 16 ? 'checked' : '';
	}
	if ($type=='imageset' || $type=='all') {
		${'waterpos_ck_'.$db_waterpos} = ${'ifgif_'.$db_ifgif} = 'checked';
		list($db_fthumbwidth,$db_fthumbheight) = explode("\t",$db_fthumbsize);
		list($db_athumbwidth,$db_athumbheight) = explode("\t",$db_athumbsize);

		ifcheck($db_watermark,'watermark');
		ifcheck($db_iffthumb,'iffthumb');
		ifcheck($db_ifathumb,'ifathumb');
	}
	if ($type=='buysign' || $type=='all') {
		$signgroup = ''; $num = 0;
		foreach ($ltitle as $key => $value) {
			if ($key!=1 && $key!=2) {
				$num++;
				$htm_tr = $num % 3 == 0 ? '</tr><tr>' : '';
				$s_checked = strpos($db_signgroup,",$key,")!==false ? 'checked' : '';
				$signgroup .= "<td><input type=\"checkbox\" name=\"signgroup[]\" value=\"$key\" $s_checked>$value</td>$htm_tr";
			}
		}
		$signgroup && $signgroup = "<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"100%\" align=\"center\"><tr>$signgroup</tr></table>";
		list($moneyname,,$rvrcname,,$creditname) = explode("\t",$db_credits);

		$signcurtype = '';
		$sign_curtype[$db_signcurtype] = 'selected';
		foreach (array('money'=>$moneyname,'rvrc'=>$rvrcname,'credit'=>$creditname,'currency'=>$db_currencyname) as $key => $value) {
			$signcurtype .= "<option value='$key' {$sign_curtype[$key]}>$value</option>";
		}
	}
	if ($type=='wap' || $type=='all') {
		$forumcheck = ''; $num = 0;
		$query=$db->query("SELECT fid,name FROM pw_forums WHERE type<>'category' AND allowvisit='' AND f_type!='hidden' AND cms='0'");
		while ($rt = $db->fetch_array($query,MYSQL_NUM)) {
			$num++;
			$htm_tr = $num % 2 == 0 ? '</tr><tr>' : '';
			$checked = strpos(",$db_wapfids,",",$rt[0],")!==false ? 'checked' : '';
			$forumcheck.="<td><input type=\"checkbox\" name=\"wapfids[]\" value=\"$rt[0]\" $checked>$rt[1]</td>$htm_tr";
		}
		$forumcheck && $forumcheck = "<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"100%\" align=\"center\"><tr>$forumcheck</tr></table>";

		ifcheck($db_wapifopen,'wapifopen');
		ifcheck($db_wapcharset,'wapcharset');
	}
	if ($type=='js' || $type=='all') {
		ifcheck($db_jsifopen,'jsifopen');
	}
	if ($type=='mail' || $type=='all') {
		include_once(D_P.'data/bbscache/mail_config.php');
		${'mailmethod_'.$ml_mailmethod} = 'checked';
		$ml_smtppass = substr($ml_smtppass,0,1).'********'.substr($ml_smtppass,-1);

		ifcheck($ml_mailifopen,'mailifopen');
		ifcheck($ml_smtpauth,'smtpauth');
	}
	if ($type=='safe' || $type=='all') {
		${'cc_'.$db_cc} = 'checked';
		$safegroup = ''; $num = 0;
		foreach ($ltitle as $key => $value) {
			if ($key!=1 && $key!=2) {
				$num++;
				$htm_tr = $num % 3 == 0 ? '</tr><tr>' : '';
				$s_checked = strpos($db_safegroup,",$key,")!==false ? 'checked' : '';
				$safegroup .= "<td><input type=\"checkbox\" name=\"safegroup[]\" value=\"$key\" $s_checked>$value</td>$htm_tr";
			}
		}
		$safegroup && $safegroup = "<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" width=\"100%\" align=\"center\"><tr>$safegroup</tr></table>";

		ifcheck($db_ipcheck,'ipcheck');
		ifcheck($db_ifsafecv,'ifsafecv');
	}
	if ($type=='ftp' || $type=='all') {
		@include_once(D_P.'data/bbscache/ftp_config.php');
		$ftp_pass = substr($ftp_pass,0,1).'********'.substr($ftp_pass,-1);

		ifcheck($db_ifftp,'ifftp');
	}
	if ($type=='other' || $type=='all') {
		ifcheck($db_enterreason,'enterreason');
	}
	include PrintEot('setting');exit;
} else {
	if (!is_writeable(D_P.'data/bbscache/config.php') && !chmod(D_P.'data/bbscache/config.php',0777)) {
		adminmsg('config_777');
	}
	$config = GetGP('config','P');
	if ($type=='bbsset' || $type=='all') {
		$schcontrol = GetGP('schcontrol','P');
		$config['whybbsclose'] = ieconvert($config['whybbsclose']);
		!is_numeric($config['onlinelmt']) && $config['onlinelmt'] = 5000;
		$config['openpost'] = $config['openpost']."\t".$config['poststart']."\t".$config['postend'];
		$config['opensch'] = $schcontrol['opensch']."\t".$schcontrol['schstart']."\t".$schcontrol['schend'];
		unset($config['poststart'],$config['postend'],$schcontrol);
	}
	if ($type=='setgd' || $type=='all') {
		InitGP(array('gdcheck','gdstyle','qcheck','question','answer'),'P');
		$config['gdcheck'] = array_sum($gdcheck);
		$config['gdstyle'] = array_sum($gdstyle);
		$config['gdsize']  = implode("\t",$config['gdsize']);

		(int)$qcheck['post']<1 && $qcheck['post'] = 0;
		$config['qcheck'] = implode("\t",$qcheck);

		$q_array = $a_array = array();
		if (is_array($question) && is_array($answer)) {
			foreach ($question as $key => $value) {
				if ($value) {
					$q_array[] = stripslashes($value);
					$a_array[] = stripslashes($answer[$key]);
				}
			}
		}
		$config['question'] = !empty($q_array) ? addslashes(serialize($q_array)) : '';
		$config['answer'] = !empty($a_array) ? addslashes(serialize($a_array)) : '';
		unset($gdcheck,$qcheck,$question,$answer,$q_array,$a_array);
	}
	if ($type=='basicset' || $type=='all') {
		substr($config['bbsurl'],0,4)!='http' && adminmsg('bbsurl_http');
		$config['recycle'] = $config['recycle'] ? '1' : '0';
	}
	if ($type=='pathset' || $type=='all') {
		if ($config['http']!='N' && substr($config['http'],0,4)!='http') {
			adminmsg('setting_http');
		}
		if ($db_picpath && $db_picpath!=$config['picpath'] && (is_dir($config['picpath']) || !rename($db_picpath,$config['picpath']))) {
			adminmsg('setting_777_pic');
		}
		if ($db_attachname && $db_attachname!=$config['attachname'] && (is_dir($config['attachname']) || !rename($db_attachname,$config['attachname']))) {
			adminmsg('setting_777_att');
		}
		if ($db_htmdir && $db_htmdir!=$config['htmdir'] && (is_dir($config['htmdir']) || !rename($db_htmdir,$config['htmdir']))) {
			adminmsg('setting_777_htm');
		}
		if ($config['autochange'] && (!is_writeable($imgdir) || !is_writeable($attachdir))) {
			$config['autochange'] = 0;
		}
	}
	if ($type=='coreset' || $type=='all') {
		$upload = GetGP('upload','P');
		if ($config['datefm']) {
			if (strpos($config['datefm'],'mm')!==false) {
				$config['datefm'] = str_replace('mm','m',$config['datefm']);
			} else {
				$config['datefm'] = str_replace('m','n',$config['datefm']);
			}
			if (strpos($config['datefm'],'dd')!==false) {
				$config['datefm'] = str_replace('dd','d',$config['datefm']);
			} else {
				$config['datefm'] = str_replace('d','j',$config['datefm']);
			}
			$config['datefm'] = str_replace('yyyy','Y',$config['datefm']);
			$config['datefm'] = str_replace('yy','y',$config['datefm']);
			$timefm = GetGP('time_f','P')=='12' ? ' h:i A' :' H:i';
			$config['datefm'] .= $timefm;
		} else {
			$config['datefm'] = 'Y-n-j H:i';
		}
		if (!is_numeric($upload['imgsize'])) {
			$upload['imgsize'] = 20;
		}
		!is_numeric($upload['imglen']) && $upload['imglen'] = 160;
		!is_numeric($upload['imgwidth']) && $upload['imgwidth'] = 160;
		$config['upload'] = $upload['upload']."\t".$upload['imglen']."\t".$upload['imgwidth']."\t".$upload['imgsize'];
		$config['onlinetime'] *= 60;
		$config['schwait'] = (int)$config['schwait'];
		(int)$config['obstart']<1 && $config['obstart'] = 0;
	}
	if ($type=='creditset' || $type=='all') {
		$config['credits'] = implode("\t",GetGP('credits','P'));
	}
	if ($type=='regset' || $type=='all') {
		InitGP(array('reg','regcredit'));
		if ($reg['timeend']-$reg['timestart']>150 || $reg['timeend']-$reg['timestart']<0) {
			adminmsg('reg_timelimit');
		}
		if ((int)$_POST['namelen']['max']<1 || $_POST['namelen']['max']>15) {
			$_POST['namelen']['max'] = 15;
		}
		if ((int)$_POST['namelen']['min']<1 || $_POST['namelen']['min']>$_POST['namelen']['max']) {
			adminmsg('reg_username_limit');
		}
		$_POST['pwdlen']['max'] = (int)$_POST['pwdlen']['max'];
		if ((int)$_POST['pwdlen']['min']<1 || ($_POST['pwdlen']['max'] && $_POST['pwdlen']['min']>$_POST['pwdlen']['max'])) {
			adminmsg('reg_password_limit');
		}
		include_once(D_P.'data/bbscache/dbreg.php');
		$reg['welcomemsg'] = ieconvert($reg['welcomemsg']);
		$reg['rgpermit'] = ieconvert($reg['rgpermit']);
		$reg['timestart']	= (int)$reg['timestart'];
		$reg['timeend']		= (int)$reg['timeend'];
		$reg['namelen']		= $_POST['namelen']['min']."\t".$_POST['namelen']['max'];
		$reg['pwdlen']		= $_POST['pwdlen']['min']."\t".$_POST['pwdlen']['max'];
		$reg['regcredit']	= addslashes(serialize($regcredit));
		foreach ($reg as $key=>$value) {
			if (${'rg_'.$key}!=$value) {
				$db_name = $db->get_value("SELECT db_name FROM pw_config WHERE db_name='rg_$key'");
				if ($db_name=="rg_$key") {
					$db->update("UPDATE pw_config SET db_value='$value' WHERE db_name='rg_$key'");
				} else {
					$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('rg_$key','$value')");
				}
			}
		}
	}
	if ($type=='windcode' || $type=='all') {
		InitGP(array('sellset','windpost','windpic'),'P');
		$config['sellset'] = $sellset ? serialize($sellset) : '';
		!$config['postmax'] && $config['postmax'] = 50000;
		$config['windpost'] = addslashes(serialize($windpost));
		$config['windpic'] = addslashes(serialize($windpic));
	}
	if ($type=='attachset' || $type=='all') {
		InitGP(array('filetype','maxsize'),'P');
		$uploadfiletype = array();
		foreach ($filetype as $key => $value) {
			$value && $uploadfiletype[$value] = (int)$maxsize[$key];
		}
		$config['uploadfiletype'] = $uploadfiletype ? serialize($uploadfiletype) : '';
	}
	if ($type=='atcset' || $type=='all') {
		$creditdb = GetGP('creditdb','P');
		foreach ($creditdb as $key => $value) {
			foreach ($value as $k => $v) {
				$v = (int)$v;
				if ($key=='rvrc' && $k!='Reply' && $k!='Deleterp') {
					$v *= 10;
				}
				$creditdb[$key][$k] = $v;
			}
		}
		$config['creditset'] = $creditdb ? serialize($creditdb) : '';
	}
	if ($type=='indexset' || $type=='all') {
		$gpshow = GetGP('gpshow','P');
		if (is_array($gpshow)) {
			$gporder = GetGP('gporder','P');
			$showgroup = array();
			foreach ($gpshow as $key => $value) {
				$showgroup[$value] = $gporder[$key];
			}
			asort($showgroup);
			$showgroup = array_keys($showgroup);
			$config['showgroup'] = ','.implode(',',$showgroup).',';
		} else{
			$config['showgroup'] = '';
		}
	}
	if ($type=='viewset' || $type=='all') {
		InitGP(array('menu','ajax','showcustom'),'P');
		!$config['perpage'] && $config['perpage'] = 25;
		!$config['readperpage'] && $config['readperpage'] = 10;
		$config['showcustom'] = $showcustom ? ','.implode(',',$showcustom).',' : '';
		$config['menu'] = $config['ajax'] = 0;
		foreach ($menu as $value) {
			$config['menu'] += $value;
		}
		foreach ($ajax as $value) {
			$config['ajax'] += $value;
		}
	}
	if ($type=='imageset' || $type=='all') {
		if ($config['watermark'] && (!function_exists('imagecreatefromgif') || !function_exists('imagettfbbox') || !function_exists('imagealphablending'))) {
			adminmsg('setting_gd_error');
		}
		$config['waterpct'] = (int)$config['waterpct'];
		InitGP(array('fthumbsize','athumbsize'),'P');
		if (is_array($fthumbsize)) {
			foreach ($fthumbsize as $value) {
				$config['fthumbsize'] .= (isset($config['fthumbsize']) ? "\t" : '').(int)$value;
			}
		}
		if (is_array($athumbsize)) {
			foreach ($athumbsize as $value) {
				$config['athumbsize'] .= (isset($config['athumbsize']) ? "\t" : '').(int)$value;
			}
		}
	}
	if ($type=='buysign' || $type=='all') {
		$signgroup = GetGP('signgroup','P');
		$config['signgroup'] = $signgroup ? ','.implode(',',$signgroup).',' : '';
	}
	if ($type=='wap' || $type=='all') {
		$config['wapfids'] = implode(',',GetGP('wapfids','P'));
	}
	if ($type=='mail' || $type=='all') {
		$mailconfig = GetGP('mailconfig','P');
		@include_once(D_P.'data/bbscache/mail_config.php');
		$ml_smtppass = substr($ml_smtppass,0,1).'********'.substr($ml_smtppass,-1);
		foreach ($mailconfig as $key => $value) {
			if (${$key}!=$value) {
				$db_name = $db->get_value("SELECT db_name FROM pw_config WHERE db_name='$key'");
				if ($db_name==$key) {
					$db->update("UPDATE pw_config SET db_value='$value' WHERE db_name='$key'");
				} else {
					$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('$key','$value')");
				}
			}
		}
		updatecache_ml();
	}
	if ($type=='safe' || $type=='all') {
		$safegroup = GetGP('safegroup','P');
		$config['safegroup'] = $safegroup ? ','.implode(',',$safegroup).',' : '';
		if($config['registerfile'] && $db_registerfile!=$config['registerfile']){
			!preg_match('/^[a-zA-Z][a-zA-Z0-9\_]*\.php$/is',$config['registerfile']) && adminmsg('setting_rigfile_error');
			if(!rename($db_registerfile,$config['registerfile'])){
				$config['registerfile'] = $db_registerfile ? $db_registerfile:'register.php';
			}
		}else{
			$config['registerfile'] = $db_registerfile ? $db_registerfile:'register.php';
		}
		if($config['adminfile'] && $db_adminfile!=$config['adminfile']){
			!preg_match('/^[a-zA-Z][a-zA-Z0-9\_]*\.php$/is',$config['adminfile']) && adminmsg('setting_adminfile_error');
			if(!rename($db_adminfile,$config['adminfile'])){
				$config['adminfile'] = $db_adminfile ? $db_adminfile:'admin.php';
			}
		}else{
			$config['adminfile'] = $db_adminfile ? $db_adminfile:'admin.php';
		}
	}
	if ($type=='ftp' || $type=='all') {
		$ftp = GetGP('ftp','P');
		@include_once(D_P.'data/bbscache/ftp_config.php');
		$ftp_pass = substr($ftp_pass,0,1).'********'.substr($ftp_pass,-1);
		foreach ($ftp as $key => $value) {
			if (${$key}!=$value) {
				$db_name = $db->get_value("SELECT db_name FROM pw_config WHERE db_name='$key'");
				if ($db_name==$key) {
					$db->update("UPDATE pw_config SET db_value='$value' WHERE db_name='$key'");
				} else {
					$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('$key','$value')");
				}
			}
		}
		updatecache_ftp();
	}
	if (!in_array($type,array('mail'))) {
		//get pw_config value
		$query = $db->query("SELECT * FROM pw_config WHERE db_name LIKE 'db\_%' OR db_name LIKE 'rg\_%'");
		while ($rt = $db->fetch_array($query)){
			$rt['db_name'] = str_replace("'","\'",$rt['db_name']);
			$configdb[$rt['db_name']] = $rt['db_value'];
		}
		foreach ($config as $key => $value) {
			$c_key = ${'db_'.$key};
			if (strpos($key,'_')!==false) {
				$c_db = explode('_',$key);
				$c_db_array = ${'db_'.$c_db[0]};
				$c_key = $c_db_array[$c_db[1]];
				$key = str_replace('_',"[\'",$key)."\']";
			}
			if ($c_key!=$value || $configdb["db_$key"]!=$value) {
				$db_name = $db->get_value("SELECT db_name FROM pw_config WHERE db_name='db_$key'");
				if ($db_name) {
					$db->update("UPDATE pw_config SET db_value='$value' WHERE db_name='db_$key'");
				} else {
					$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('db_$key','$value')");
				}
			}
		}
	}
	updatecache_c();
	adminmsg('operate_success');
}
?>