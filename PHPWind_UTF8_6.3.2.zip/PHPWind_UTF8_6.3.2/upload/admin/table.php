<?php
!function_exists('adminmsg') && exit('Forbidden');

$tabledb = array(
	'pw_actions',
	'pw_activity',
	'pw_actmember',
	'pw_administrators',
	'pw_adminlog',
	'pw_adminset',
	'pw_advert',
	'pw_announce',
	'pw_argument',
	'pw_attachs',
	'pw_banuser',
	'pw_bbsinfo',
	'pw_cache',
	'pw_clientorder',
	'pw_cmembers',
	'pw_cnalbum',
	'pw_cnclass',
	'pw_cnphoto',
	'pw_colonys',
	'pw_config',
	'pw_credits',
	'pw_customfield',
	'pw_datastate',
	'pw_debateclass',
	'pw_debateinfo',
	'pw_debatereplys',
	'pw_debatethreads',
	'pw_draft',
	'pw_extragroups',
	'pw_favors',
	'pw_forumdata',
	'pw_forumlog',
	'pw_forums',
	'pw_forumsell',
	'pw_forumsextra',
	'pw_friends',
	'pw_hack',
	'pw_help',
	'pw_home',
	'pw_invitecode',
	'pw_ipstates',
	'pw_medalinfo',
	'pw_medalslogs',
	'pw_membercredit',
	'pw_memberdata',
	'pw_memberinfo',
	'pw_members',
	'pw_memo',
	'pw_modules',
	'pw_msg',
	'pw_msgc',
	'pw_msglog',
	'pw_nav',
	'pw_online',
	'pw_pidtmp',
	'pw_plan',
	'pw_polls',
	'pw_posts',
	'pw_recycle',
	'pw_report',
	'pw_reward',
	'pw_schcache',
	'pw_setform',
	'pw_sharelinks',
	'pw_singleright',
	'pw_smiles',
	'pw_sqlcv',
	'pw_styles',
	'pw_tagdata',
	'pw_tags',
	'pw_threads',
	'pw_tmsgs',
	'pw_toollog',
	'pw_tools',
	'pw_usergroups',
	'pw_usertool',
	'pw_windcode',
	'pw_wordfb'
);
if ($db_plist) {
	$p_list = explode(',',$db_plist);
	foreach ($p_list as $value) {
		$tabledb[] = 'pw_posts'.$value;
	}
}
if ($db_tlist) {
	!is_array($t_list = unserialize($db_tlist)) && $db_tlist = array();
	foreach ($t_list as $key => $value) {
		$tabledb[] = 'pw_tmsgs'.$key;
	}
}
function N_getTabledb($showother=null){//fix bug $PW
	global $tabledb,$PW,$adminjob;
	$table_a = $othortable = array();
	$cutonline = false;
	if ($adminjob=='repair') {
		$cutonline = true;
		foreach ($tabledb as $key => $value) {
			$value!='pw_online' && $table_a[0][$key] = str_replace('pw_',$PW,$value);
		}
	} elseif ($PW!='pw_') {
		foreach ($tabledb as $key => $value) {
			$table_a[0][$key] = str_replace('pw_',$PW,$value);
		}
	} else {
		$table_a[0] = $tabledb;
	}
	if (!empty($showother)) {
		global $db;
		$haystack = $cutonline ? array_merge($table_a[0],array($PW.'online')) : $table_a[0];
		$query = $db->query('SHOW TABLES');
		while ($rt = $db->fetch_array($query,MYSQL_NUM)) {
			$value = trim($rt[0]);
			!in_array($value,$haystack) && $othortable[] = $value;
		}
		$table_a[1] = $othortable;
	}
	return $table_a;
}
?>