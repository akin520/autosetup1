<?php
!function_exists('adminmsg') && exit('Forbidden');

require_once(R_P.'require/xml.php');
require_once(R_P.'require/posthost.php');
$xml = new XML();
$xml->setEncode('UTF-8');
$ystatsUrl = 'http://v3.tongji.cn.yahoo.com/export/phpwind';
$basename = "$admin_file?adminjob=ystats&type=other";
!$type && $type = 'draw';
!$action && $action = 'config';
if($type == 'other'){
	$step = GetGP('step');
	if($action == 'config'){
		if($step == 2){
			$config = GetGP('config');
			$config['ystats_ifopen'] = $config['ystats_ifopen'] ? 1 : 0;
			$config['ystats_style']  = intval($config['ystats_style']);
			if(empty($db_ystats_unit_id) && empty($db_ystats_key)){
				//�Ż�ͳ�Ƽ���
				$ystats = array();
				$response = PostHost("$ystatsUrl/reg.html?type=1");
				$response = chunkdecode($response);
				$xml->setXMLData($response);
				if(!$xml->isXMLFile()){
					adminmsg('ystat_xmldata_error');
				}
				$xml->parse();
				$result = XML::getChild($xml->getXMLRoot());
				foreach ($result as $tag){
					$tagname = XML::getTagName($tag);
					$ystats[$tagname] = XML::getData($tag);
				}
				if($ystats['status'] != '0'){
					adminmsg($ystats['info']);
				}else{
					$db_ystats_unit_id = $config['ystats_unit_id'] = $ystats['unit_id'];
					$db_ystats_key = $config['ystats_key'] = $ystats['key'];
				}
			}
			//�Ż�ͳ��ѡ��
			$ystats = array();
			$request = $ystatsUrl.'/reg.html?type=2&key='.$db_ystats_key.'&unit_id='.$db_ystats_unit_id.'&open='.$config['ystats_ifopen'].'&style='.$config['ystats_style'];
			$response = PostHost($request);
			$response = chunkdecode($response);
			$xml->setXMLData($response);
			if(!$xml->isXMLFile()){
				adminmsg('ystat_xmldata_error');
			}
			$xml->parse();
			$result = XML::getChild($xml->getXMLRoot());
			foreach ($result as $tag){
				$tagname = XML::getTagName($tag);
				$ystats[$tagname] = XML::getData($tag);
			}
			if($ystats['status'] != '0'){
				adminmsg($ystats['info']);
			}

			foreach ($config as $key=>$value){
				$db->pw_update(
					"SELECT db_name FROM pw_config WHERE db_name='db_{$key}'",
					"UPDATE pw_config SET db_value='$value' WHERE db_name='db_{$key}'",
					"INSERT INTO pw_config(db_name,db_value) VALUES ('db_{$key}','$value')"
				);
			}
			updatecache_c();
			adminmsg('operate_success');
		}else{
			empty($db_ystats_style) && $db_ystats_style = 1;
			$db_ystats_ifopen!='0' && $db_ystats_ifopen = 1;
			ifcheck($db_ystats_ifopen,'ystats_ifopen');
			${'ystats_style_'.$db_ystats_style} = 'CHECKED';
			include PrintEot('ystats');exit;
		}
	}elseif($action == 'report'){
		if(empty($db_ystats_unit_id) && empty($db_ystats_key)){
			adminmsg('ystat_active_account');
		}
		InitGP(array('view','year','month'));
		$pwDate['now']		= $timestamp+28800;//����ʱ��
		$pwDate['hours']	= gmdate('G',$pwDate['now']);//����Сʱ��
		$pwDate['mday']		= gmdate('j',$pwDate['now']);//��������
		$pwDate['wday']		= gmdate('w',$pwDate['now']);
		$pwDate['wday']		== 0 && $pwDate['wday'] = 7;//����:1-7
		$pwDate['ttime']	= (floor($pwDate['now']/3600)-$pwDate['hours'])*3600;//���쿪ʼʱ��,ʱ���
		$pwDate['mtime']	= $pwDate['ttime']-($pwDate['mday']-1)*86400;//���¿�ʼʱ��,ʱ���
		$pwDate['wtime']	= $pwDate['ttime']-($pwDate['wday']-1)*86400;//���ܿ�ʼʱ��(����һΪ��һ��),ʱ���
		$pwDate['lwtime']	= $pwDate['wtime']-604800;
		$pwDate['lasttime'] = $pwDate['now']-2505600;
		$pwDate['year']		= gmdate('Y',$pwDate['now']);
		$pwDate['month']	= gmdate('m',$pwDate['now']);
		$pwDate['md5time']	= mktime(date('H',$timestamp),0,0,date('m',$timestamp),date('d',$timestamp),date('Y',$timestamp));
		$edate = '';
		switch ($view){
			case 'colligate':
				$sdate = gmdate('Y-m-d',$pwDate['lasttime']);
				break;
			case 'thisweek':
				$sdate = gmdate('Y-m-d',$pwDate['wtime']);
				break;
			case 'lastweek':
				$sdate = gmdate('Y-m-d',$pwDate['lwtime']);
				$edate = gmdate('Y-m-d',$pwDate['wtime']-86400);
				break;
			case 'thismonth':
				$sdate = gmdate('Y-m-d',$pwDate['mtime']);
				break;
			case 'last30':
				$sdate = gmdate('Y-m-d',$pwDate['lasttime']);
				break;
			case 'other':
				if(!is_numeric($month) || !is_numeric($year)|| $year<2007 || $year>$pwDate['year'] || $month<1 || $month>12){
					adminmsg('ystat_date_error');
				}
				$sdate = gmdate('Y-m-d',strtotime($year.'-'.$month.'-1'));
				$edate = gmdate('Y-m-d',strtotime($year.'-'.$month.'-'.gmdate('t',strtotime($sdate))));
				if(strtotime($sdate)>$pwDate['now']){
					adminmsg('ystat_date_error');
				}
				strtotime($edate)>$pwDate['now'] && $edate = '';
				break;
			default:
				$view = 'colligate';
				$sdate = gmdate('Y-m-d',$pwDate['lasttime']);
		}
		!$year && $year = $pwDate['year'];
		!$month && $month = $pwDate['month'];
		${'year_'.$year} = 'SELECTED';
		${'month_'.$month} = 'SELECTED';
		${$view} = 'CHECKED';

		$ystats = array();
		$verify = md5($db_ystats_key.$db_ystats_unit_id.$pwDate['md5time']);
		$request = $ystatsUrl.'/report.html?key='.$db_ystats_key.'&unit_id='.$db_ystats_unit_id.'&s='.$verify.'&date1='.$sdate.'&date2='.$edate;
		$response = PostHost($request);
		$response = chunkdecode($response);
		$xml->setXMLData($response);
		if(!$xml->isXMLFile()){
			adminmsg('ystat_xmldata_error');
		}
		$xml->parse();
		$result = XML::getChild($xml->getXMLRoot());
		foreach ($result as $tag) {
			$tagname = XML::getTagName($tag);
			if ($tagname == 'status' || $tagname == 'info') {
				$ystats[$tagname] = XML::getData($tag);
			} elseif ($tagname == 'date_list'){
				$datelist = array();
				$datelist = XML::getChild($tag);
				foreach ($datelist as $list){
					$listkey = XML::getProperty($list,'value');
					$listkey = strtotime($listkey);
					$ystats['date_list'][$listkey] = XML::getAttribute($list);
				}
			} else {
				$ystats[$tagname] = XML::getAttribute($tag);
			}
		}
		if($ystats['status'] != '0'){
			adminmsg($ystats['info']);
		}
		empty($edate) && $edate = gmdate('Y-m-d',$pwDate['now']);
		$stime = strtotime($sdate);
		$etime = strtotime($edate);
		$flashvars['pv'] = array();
		$flashvars['uv'] = array();
		$flashvars['ip'] = array();
		$flashvars['date'] = array();
		$flashvars['maxvalue'] = 0;
		$sum_pv = 0;
		$sum_uv = 0;
		$sum_ip = 0;
		$total = intval(($etime-$stime)/86400);
		for ($i=0;$i<=$total;$i++){
			$flashvars['date'][$i] = $total>7 && $i%5 ? '' : gmdate('Y-m-d',$stime);
			if ($ystats['date_list'][$stime]) {
				$flashvars['maxvalue']<$ystats['date_list'][$stime]['pv'] && $flashvars['maxvalue'] = $ystats['date_list'][$stime]['pv'];
				$flashvars['maxvalue']<$ystats['date_list'][$stime]['uv'] && $flashvars['maxvalue'] = $ystats['date_list'][$stime]['uv'];
				$flashvars['pv'][$i] = $ystats['date_list'][$stime]['pv'];
				$flashvars['uv'][$i] = $ystats['date_list'][$stime]['uv'];
				$flashvars['ip'][$i] = $ystats['date_list'][$stime]['ip'];
				$sum_pv += $ystats['date_list'][$stime]['pv'];
				$sum_uv += $ystats['date_list'][$stime]['uv'];
				$sum_ip += $ystats['date_list'][$stime]['ip'];
			} else {
				$flashvars['pv'][$i] = '0';
				$flashvars['uv'][$i] = '0';
				$flashvars['ip'][$i] = '0';
			}
			$stime += 86400;
		}
		if($ystats['date_list']){
			$flashvars['maxvalue'] = ceil(($flashvars['maxvalue']+1)/10)*10;
			$flashvars['pv'] = implode(',',$flashvars['pv']);
			$flashvars['uv'] = implode(',',$flashvars['uv']);
			$flashvars['ip'] = implode(',',$flashvars['ip']);
			$flashvars['date'] = implode(',',$flashvars['date']);
			$flashvars = "&title=,5,&
&y_ticks=2,10,10&
&y_legend=Open Flash Chart,10,0xD2D2D2&
&y_min=0&
&bg_colour=#FFFFFF&
&x_labels=$flashvars[date]&
&values=$flashvars[pv]&
&values_2=$flashvars[uv]&
&values_3=$flashvars[ip]&
&line_dot=2,0xFF6600,PV,12,4&
&line_dot_2=2,0x04D215,UV,12,4&
&line_dot_3=2,0x0D8ECF,IP,12,4&
&y_max=$flashvars[maxvalue]&
";
		}else{
			$flashvars = '';
		}
		writeover(D_P.'data/bbscache/ystat.php',"<?php\n\$flashvars = \"$flashvars\";\n?>");
		krsort($ystats['date_list']);
		include PrintEot('ystats');exit;
	}elseif($action == 'bind'){
		if($db_ystats_ymail){
			adminmsg('ystat_ymail_error');
		}
		if($step==2){
			$ystats_ymail = GetGP('ystats_ymail','P');
			if(empty($ystats_ymail) || !ereg("^[a-zA-Z][a-zA-Z0-9_]{3,31}\@(yahoo\.com\.cn|yahoo\.cn)$",$ystats_ymail)){
				adminmsg('ystat_ymail_format');
			}
			$ystats = array();
			$request = $ystatsUrl.'/reg.html?type=3&key='.$db_ystats_key.'&unit_id='.$db_ystats_unit_id.'&ymail='.$ystats_ymail;
			$response = PostHost($request);
			$response = chunkdecode($response);
			$xml->setXMLData($response);
			if(!$xml->isXMLFile()){
				adminmsg('ystat_xmldata_error');
			}
			$xml->parse();
			$result = XML::getChild($xml->getXMLRoot());
			foreach ($result as $tag){
				$tagname = XML::getTagName($tag);
				$ystats[$tagname] = XML::getData($tag);
			}
			if($ystats['status'] != '0'){
				adminmsg($ystats['info']);
			}
			$db->pw_update(
				"SELECT db_name FROM pw_config WHERE db_name='db_ystats_ymail'",
				"UPDATE pw_config SET db_value='$ystats_ymail' WHERE db_name='db_ystats_ymail'",
				"INSERT INTO pw_config(db_name,db_value) VALUES ('db_ystats_ymail','$ystats_ymail')"
			);
			updatecache_c();
			adminmsg('operate_success');
		}else{
			include PrintEot('ystats');exit;
		}
	}elseif($action == 'reactivate'){
		$db->update("UPDATE pw_config SET db_value='' WHERE db_name IN('db_ystats_ymail','db_ystats_ifopen','db_ystats_style','db_ystats_unit_id','db_ystats_key')");
		updatecache_c();
		adminmsg('operate_success');
	}
}elseif($type == 'draw'){
	header("Cache-Control: no-cache, must-revalidate");
	@include_once(D_P.'data/bbscache/ystat.php');
	echo $flashvars;exit;
}

function chunkdecode($data){
	$tmp = '';
	$slen = strpos($data,"\r\n");
	$length = (int)hexdec(substr($data,0,$slen+1));
	while($length > 0) {
		$data = substr($data,$slen+2);
	    $tmp .= substr($data,0,$length);
	    $data = substr($data,$length);
		$slen = strpos($data,"\r\n");
		$length = (int)hexdec(substr($data,0,$slen+1));
	}
	return trim($tmp);
}
?>