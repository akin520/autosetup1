<?php
define('AJAX','1');
require_once('global.php');
require_once(R_P.'require/forum.php');

$groupid == 'guest' && Showmsg('not_login');

$foruminfo = $db->get_one("SELECT f.*,fe.forumset FROM pw_forums f LEFT JOIN pw_forumsextra fe ON fe.fid=f.fid WHERE f.fid='$fid' AND f.type<>'category'");
!$foruminfo && Showmsg('data_error');
wind_forumcheck($foruminfo);
$forumset = unserialize($foruminfo['forumset']);
empty($fid) && Showmsg('undefined_action');
/*
* ��ȡ����Ȩ��
*/
if($groupid==3 || $groupid==4 || admincheck($foruminfo['forumadmin'],$foruminfo['fupadmin'],$windid)){
	$admincheck=1;
} else{
	$admincheck=0;
}
if(!CkInArray($windid,$manager) && $groupid!=3 && !$foruminfo['allowvisit'] && !admincheck($foruminfo['forumadmin'],$foruminfo['fupadmin'],$windid)){
	forum_creditcheck();
}
if($forumset['allowtime'] && !$admincheck && !allowcheck($forumset['allowtime'],",$t[hours],",'')){
	Showmsg('forum_allowtime');
}
list($db_openpost,$db_poststart,$db_postend)=explode("\t",$db_openpost);
if($db_openpost==1 && $groupid != 3 && $groupid != 4){
	if($db_poststart < $db_postend && ($t['hours'] < $db_poststart || $t['hours'] >= $db_postend)){
		Showmsg('post_openpost');
	} elseif($db_poststart > $db_postend && ($t['hours'] < $db_poststart && $t['hours'] >= $db_postend)){
		Showmsg('post_openpost');
	}
}
if($groupid=='6'){
	$bandb=$db->get_one("SELECT * FROM pw_banuser WHERE uid='$winduid'");
	if(!$bandb){
		$db->update("UPDATE pw_members SET groupid='-1' WHERE uid='$winduid'");
	} elseif($bandb['type']==1 && $timestamp-$bandb['startdate']>$bandb['days']*86400){
		$db->update("DELETE FROM pw_banuser WHERE uid='$winduid'");
		$db->update("UPDATE pw_members SET groupid='-1' WHERE uid='$winduid'");
	} else{
		if($bandb['type']==1){
			$s_date=get_date($bandb['startdate']);
			$e_date=$bandb['startdate']+$bandb['days']*86400;
			$e_date=get_date($e_date);
			Showmsg('ban_info1');
		} else{
			if($bandb['type']==3){
				Cookie('force',$winduid);
				Showmsg('ban_info3');
			} else{
				Showmsg('ban_info2');
			}
		}
	}
}
if(GetCookie('force') && $winduid != GetCookie('force')){
	$force = GetCookie('force');
	$bandb = $db->get_one("SELECT type FROM pw_banuser WHERE uid='$force'");
	if($bandb['type']==3){
		Showmsg('ban_info3');
	} else{
		Cookie('force','',0);
	}
}
if($groupid=='7'){
	Showmsg('post_check');
}
if($db_postallowtime && $timestamp-$winddb['regdate']<$db_postallowtime*60){
	Showmsg('post_newrg_limit');
}
$userlastptime = $groupid != 'guest' ?  $winddb['lastpost'] : GetCookie('userlastptime');
$tdtime  >= $winddb['lastpost'] && $winddb['todaypost'] = 0;
$montime >= $winddb['lastpost'] && $winddb['monthpost'] = 0;

if($_G['postlimit'] && $winddb['todaypost'] >= $_G['postlimit']){
	Showmsg('post_gp_limit');
}
list(,,$postq)	= explode("\t",$db_qcheck);
InitGP(array('action'));

if($action=='modify'){
	InitGP(array('pid','article'));
	if(is_numeric($pid)){
		$pw_posts = GetPtable('N',$tid);
		$atcdb = $db->get_one("SELECT tid,aid,author,authorid,icon,postdate,subject,ifsign,leaveword,ifconvert,content,anonymous FROM $pw_posts WHERE pid='$pid' AND tid='$tid' AND fid='$fid'");
		!$atcdb['tid'] && Showmsg('illegal_tid');
		$ptable = substr($pw_posts,8);
	} else{
		$pw_tmsgs = GetTtable($tid);
		$atcdb = $db->get_one("SELECT t.tid,t.icon,t.author,t.authorid,t.subject,t.postdate,t.locked,t.anonymous,t.ptable,tm.aid,tm.ifsign,tm.content FROM pw_threads t LEFT JOIN $pw_tmsgs tm USING(tid) WHERE t.tid='$tid' AND fid='$fid'");
		!$atcdb['tid'] && Showmsg('illegal_tid');
		$ptable = $atcdb['ptable'];
	}
	if(!$admincheck && (!$SYSTEM['deltpcs'] || $groupid == 5)){
		if($groupid == 'guest' || $atcdb['authorid'] != $winduid){
			Showmsg('modify_noper');
		} elseif($atcdb['locked']%3 > 0){
			Showmsg('modify_locked');
		}
	}
	if($winduid != $atcdb['authorid'] && $groupid != 3 && $groupid != 4){
		$authordb = $db->get_one("SELECT groupid FROM pw_members WHERE uid='$atcdb[authorid]'");
		if(($authordb['groupid'] == 3 || $authordb['groupid'] == 4)){
			Showmsg('modify_admin');
		}
	}
	if($gp_edittime && ($timestamp - $atcdb['postdate']) > $gp_edittime * 60){
		Showmsg('modify_timelimit');
	}
	if(!$_POST['step']){
		$verify = substr(md5($winduid.$db_hash.$fid),0,8);
		$atcdb['anonymous'] && $atcdb['author'] = $db_anonymousname;
		$atc_content = str_replace(array('<','>','&nbsp;'),array('&lt;','&gt;',' '),$atcdb['content']);
		if(strpos($atc_content,$db_bbsurl) !== false){
			$atc_content = str_replace('p_w_picpath',$db_picpath,$atc_content);
			$atc_content = str_replace('p_w_upload',$db_attachname,$atc_content);
		}
		$atc_title = $atcdb['subject'];
		require_once PrintEot('ajax');ajax_footer();
	} else{
		(($db_gdcheck & 4) && $winddb['postnum'] < $db_postgd) && GdConfirm($_POST['gdcode']);
		$postcheck = $_POST['verify']==substr(md5($winduid.$db_hash.$fid),0,8) ? 1 : 0;
		if($db_charset!='utf-8'){
			$_POST['atc_title']   = ajax_convert($_POST['atc_title'],$db_charset);
			$_POST['atc_content'] = ajax_convert($_POST['atc_content'],$db_charset);
			$_POST['qanswer'] && $_POST['qanswer'] = ajax_convert($_POST['qanswer'],$db_charset);
		}
		$winddb['postnum'] < $postq && Qcheck($_POST['qanswer'],$_POST['qkey']);

		if(@include(D_P."data/bbscache/wordsfb.php")){
			foreach($wordsfb as $key => $value){
				$banword = (string) stripslashes($key);
				if(strpos($_POST['atc_title'],$banword)!==false){
					Showmsg('title_wordsfb');
				} elseif(strpos($_POST['atc_content'],$banword)!==false){
					Showmsg('content_wordsfb');
				}
			}
			foreach($replace as $key => $value){
				$banword = (string) stripslashes($key);
				if(strpos($_POST['atc_title'],$banword)!==false){
					Showmsg('post_wordsfb');
				}
			}
		}
		list(,,$downloadmoney,$downloadimg) = explode("\t",$forumset['uploadset']);
		require_once('require/postfunc.php');
		require_once(R_P.'require/bbscode.php');
		$atc_usesign = $atcdb['ifsign'];
		list($atc_title,$atc_content,$ifconvert,$ifwordsfb) = check_data('modify');

		if(file_exists(D_P."data/style/$skin.php") && strpos($skin,'..')===false){
			@include(D_P."data/style/$skin.php");
		} else{
			@include(D_P."data/style/wind.php");
		}
		if($groupid != 3 && $atcdb['postdate'] + 300 < $timestamp){
			$altername = $atcdb['anonymous'] && $windid==$atcdb['author'] ? $db_anonymousname : $windid;
			$timeofedit= get_date($timestamp);
			require_once GetLang('post');
			$alterinfo = $lang['edit_post'];
		} else{
			$alterinfo = '';
		}
		if($winduid != $authorid){
			/**
			* ����Ա�༭���ӵİ�ȫ�ռ�
			*/
			require_once(R_P.'require/writelog.php');
			$log = array(
				'type'      => 'edit',
				'username1' => $atcdb['author'],
				'username2' => $windid,
				'field1'    => $fid,
				'field2'    => '',
				'field3'    => '',
				'descrip'   => 'edit_descrip',
				'timestamp' => $timestamp,
				'ip'        => $onlineip,
				'tid'		=> $tid,
				'forum'		=> $foruminfo['name'],
				'subject'	=> substrs($subject,28),
				'reason'	=> 'edit article'
			);
			writelog($log);
		}
		$attachper = 1;
		$leaveword = $atcdb['leaveword'] ? leaveword($atcdb['leaveword']) : '';
		$content   = convert($atc_content.$leaveword,$db_windpost);
		$ifconvert = $content == $atc_content.$leaveword ? 1 : 2;
		if(is_numeric($pid)){
			$db->update("UPDATE $pw_posts SET subject='$atc_title',alterinfo='$alterinfo',content='$atc_content',ifconvert='$ifconvert',ifwordsfb='$ifwordsfb' WHERE pid='$pid'");
		} else{
			$db->update("UPDATE pw_threads SET subject='$atc_title' WHERE tid='$tid'");
			$db->update("UPDATE $pw_tmsgs SET alterinfo='$alterinfo',ifconvert='$ifconvert',ifwordsfb='$ifwordsfb',content='$atc_content' WHERE tid='$tid'");
		}
		if(strpos($content,'[p:')!==false || strpos($content,'[s:')!==false){
			$content = showface($content);
		}
		if($atcdb['ifsign'] < 2){
			$content = str_replace("\n",'<br />',$content);
		}
		if($ifwordsfb==0){
			$content = addslashes(wordsfb(stripslashes($content)));
		}
		if($attachper && $atcdb['aid']){
			$attachments = array();
			$attachs = unserialize(stripslashes($atcdb['aid']));
			if(is_array($attachs)){
				if($winduid==$read['authorid'] || $admincheck || ($groupid!=5 && $SYSTEM['delattach'])){
					$dfadmin=1;
				} else{
					$dfadmin=0;
				}
				foreach($attachs as $at){
					if($at['type']=='img' && $at['needrvrc']==0 && (!$downloadimg || !$downloadmoney || $gp_allowdownload==2)){
						$a_url = geturl($at['attachurl'],'show');
						if($a_url=='imgurl'){
							$attachments[$at['aid']]="<a href=\"job.php?action=showimg&tid={$tid}&pid={$read[pid]}&fid={$fid}&aid={$at[aid]}&verify=".md5("showimg{$tid}{$read[pid]}{$fid}{$at[aid]}{$GLOBALS[db_hash]}")."\" target=\"_blank\">$at[name]</a>";
						} else{
							$dfurl='<br>'.cvpic($a_url[0],1,$db_windpost['picwidth'],$db_windpost['picheight'],$at['ifthumb']);
							$read['pic'][$at['aid']]=array($at['aid'],$dfurl,$dfadmin,$at['desc']);
							$attachments[$at['aid']]="<b>$at[desc]</b>$dfurl";
						}
					}
				}
				$aids	 = array();
				$content = attachment($content);
			}
		}
		$alterinfo && $content.="<div id=\"alert_$pid\" style=\"color:gray;margin-top:30px\">[ $alterinfo ]</div>";
		$atcdb['icon'] = $atcdb['icon'] ? "<img src=\"$imgpath/post/emotion/$atcdb[icon].gif\" align=\"left\" border=\"0\" />" : '';
		echo "success\t".stripslashes($atcdb['icon']."&nbsp;".$atc_title)."\t".str_replace(array("\r","\t"), array("",""), stripslashes($content));
		ajax_footer();
	}
} elseif($action=='quote'){
	if($foruminfo['allowrp'] && !allowcheck($foruminfo['allowrp'],$groupid,$winddb['groups'],$fid,$winddb['reply']) && !$admincheck){
		Showmsg('reply_forum_right');
	}
	if(!$foruminfo['allowrp'] && !$admincheck && $gp_allowrp==0){
		Showmsg('reply_group_right');
	}
	InitGP(array('pid','article'));

	if($article=='0'){
		$pw_tmsgs = GetTtable($tid);
		$S_sql = ',tm.ifsign,tm.content,m.groupid';
		$J_sql = "LEFT JOIN $pw_tmsgs tm ON tm.tid=t.tid LEFT JOIN pw_members m ON t.authorid=m.uid";
	} else{
		$S_sql = $J_sql = '';
	}
	$tpcarray = $db->get_one("SELECT t.fid,t.locked,t.ifcheck,t.author,t.authorid,t.subject,t.postdate,t.ifshield,t.anonymous,t.ptable $S_sql FROM pw_threads t $J_sql WHERE t.tid='$tid'");
	$pw_posts = GetPtable($tpcarray['ptable']);

	if($tpcarray['fid']!=$fid){
		Showmsg('illegal_tid');
	}
	if($forumset['lock']&& !$admincheck && $timestamp - $tpcarray['postdate'] > $forumset['lock'] * 86400){
		Showmsg('forum_locked');
	}
	if(!$admincheck  && !$tpcarray['ifcheck']){
		Showmsg('reply_ifcheck');
	}
	if(!$admincheck && !$SYSTEM['replylock'] && $tpcarray['locked']%3<>0){
		Showmsg('reply_lockatc');
	}

	require_once(R_P.'require/bbscode.php');
	$verify = substr(md5($winduid.$db_hash.$fid),0,8);
	if($article=='0'){
		$atcarray = $tpcarray;
	} else{
		!is_numeric($pid) && Showmsg('illegal_tid');
		$atcarray = $db->get_one("SELECT p.author,p.subject,p.postdate,p.content,p.ifshield,p.anonymous,m.groupid FROM $pw_posts p LEFT JOIN pw_members m ON p.authorid=m.uid WHERE p.pid='$pid'");
	}
	if($atcarray['ifshield']=='1'){
		$atcarray['content'] = shield('shield_article');
	} elseif($atcarray['ifshield']=='2'){
		$atcarray['content'] = shield('shield_del_article');
	} elseif($atcarray['groupid'] == '6'){
		$atcarray['content'] = shield('ban_article');
	}
	$old_author = $atcarray['anonymous'] ? $db_anonymousname : $atcarray['author'];
	$replytitle = $atcarray['subject'];
	$wtof_oldfile=get_date($atcarray['postdate']);
	require_once GetLang('post');
	$old_content = stripslashes($atcarray['content']);
	$old_content = preg_replace("/\[hide=(.+?)\](.+?)\[\/hide\]/is",$lang['hide_post'],$old_content);
	$old_content = preg_replace("/\[post\](.+?)\[\/post\]/is",$lang['post_post'],$old_content);
	$old_content = preg_replace("/\[sell=(.+?)\](.+?)\[\/sell\]/is",$lang['sell_post'],$old_content);
	$old_content = preg_replace("/\[quote\](.*)\[\/quote\]/is","",$old_content);

	$bit_content = explode("\n",$old_content);
	if(count($bit_content) > 5){
		$old_content = "$bit_content[0]\n$bit_content[1]\n$bit_content[2]\n$bit_content[3]\n$bit_content[4]\n.......";
	}
	if(strpos($old_content,$db_bbsurl)!==false){
		$old_content = str_replace('p_w_picpath',$db_picpath,$old_content);
		$old_content = str_replace('p_w_upload',$db_attachname,$old_content);
	}
	$old_content = preg_replace("/\<(.+?)\>/is","",$old_content);
	$atc_content = "[quote]".($article==0 ? $lang['info_post_1'] : $lang['info_post_2'])."\n{$old_content}[/quote]\n";

	$replytitle =='' ? $atc_title = 'Re:'.$tpcarray['subject'] : $atc_title = 'Re:'.$replytitle;
	require_once PrintEot('ajax');ajax_footer();
} elseif($action=='subject'){
	!$admincheck && Showmsg('undefined_action');
	$atcdb = $db->get_one("SELECT authorid,subject FROM pw_threads WHERE tid='$tid' AND fid='$fid'");
	!$atcdb && Showmsg('illegal_tid');
	if($winduid != $atcdb['authorid'] && $groupid != 3 && $groupid != 4){
		$authordb = $db->get_one("SELECT groupid FROM pw_members WHERE uid='$atcdb[authorid]'");
		if(($authordb['groupid'] == 3 || $authordb['groupid'] == 4)){
			Showmsg('modify_admin');
		}
	}
	if(!$_POST['step']){
		$atcdb['subject'] = str_replace(array("&lt;","&gt;","\t"),array('<','>',''),$atcdb['subject']);
		echo "success\t".$atcdb['subject'];ajax_footer();
	} else{
		InitGP(array('atc_content'),'P',1);
		!$atc_content && Showmsg('content_empty');

		if($db_charset!='utf-8'){
			$atc_content = ajax_convert($atc_content,$db_charset);
		}
		$db->update("UPDATE pw_threads SET subject='$atc_content' WHERE tid='$tid'");
		$rt = $db->get_one("SELECT titlefont FROM pw_threads WHERE tid='$tid'");
		if($rt['titlefont']){
			$detail=explode("~",$rt['titlefont']);
			$detail[0] && $atc_content="<font color=$detail[0]>$atc_content</font>";
			$detail[1] && $atc_content="<b>$atc_content</b>";
			$detail[2] && $atc_content="<i>$atc_content</i>";
			$detail[3] && $atc_content="<u>$atc_content</u>";
		}
		echo "success\t".str_replace("\t","",$atc_content);ajax_footer();
	}
}
?>