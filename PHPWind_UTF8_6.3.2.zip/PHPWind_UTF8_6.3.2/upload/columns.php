<?php
define('COL',1);
require_once('global.php');

$url = ($_SERVER['HTTP_REFERER'] && strpos($_SERVER['HTTP_REFERER'],$db_adminfile)===false && strpos($_SERVER['HTTP_REFERER'],$db_bbsurl)!==false) ? $_SERVER['HTTP_REFERER'] : $db_bfn;

if($db_columns){
	if($_GET['action']=='columns'){
		if(file_exists(D_P."data/style/$skin.php") && strpos($skin,'..')===false){
			include_once Pcv(D_P."data/style/$skin.php");
		} else{
			include_once(D_P."data/style/wind.php");
		}
		Cookie('columns',2);
		require_once PrintEot('columns');exit;
	} else{
		Cookie('columns','1');
		echo "<script language=\"JavaScript\">top.location.href=\"".$url."\"</script>";
		exit;
	}
} else{
	ObHeader("index.php");
}
?>