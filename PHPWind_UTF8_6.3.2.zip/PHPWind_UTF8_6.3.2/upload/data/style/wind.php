<?php
$stylepath = 'wind';
$tplpath = 'wind';
$yeyestyle = '1';
$bgcolor = '#fff';
$linkcolor = '#2B76B0';
$tablecolor = '#76BAC2';
$tdcolor = '#D5E5E8';
$tablewidth = '98%';
$mtablewidth = '98%';
$headcolor	= '#CEECF0';
$headborder = '#AED6DB';
$headfontone = '#005368';
$headfonttwo = '#5495A0';
$cbgcolor = '#F7F7F7';
$cbgborder = '#daddbf';
$cbgfont = '#AFCE50';
$forumcolorone	= '#ffffff';
$forumcolortwo	= '#F4FBFF';
$extcss = '';
?>