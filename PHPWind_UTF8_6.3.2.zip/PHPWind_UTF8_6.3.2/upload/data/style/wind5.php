<?php
$stylepath = 'wind';
$tplpath = 'wind5';
$yeyestyle = '1';
$bgcolor = '#fff';
$linkcolor = '#2f5fa1';
$tablecolor = '#A6CBE7';
$tdcolor = '#D4EFF7';
$tablewidth = '98%';
$mtablewidth = '98%';
$headcolor	= '#E0F0F9';
$headborder = '#dbecF4';
$headfontone = '#004c7d';
$headfonttwo = '#5599bb';
$cbgcolor = '#f3f8ef';
$cbgborder = '#daebcd';
$cbgfont = '#659b28';
$forumcolorone	= '#ffffff';
$forumcolortwo	= '#F4FBFF';
?>