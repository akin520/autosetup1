<?php
require_once('global.php');
require_once(R_P.'require/forum.php');
include_once(D_P.'data/bbscache/forum_cache.php');
$groupid=='guest' && Showmsg('not_login');

$fiddb = array();
InitGP(array('action'));

if ($action) {
	!$fid && Showmsg('data_error');
	$forums = $db->get_one("SELECT f.name,f.forumadmin,f.fupadmin,fe.forumset FROM pw_forums f LEFT JOIN pw_forumsextra fe USING(fid) WHERE f.fid='$fid' AND f.type!='category'");
	!$forums && Showmsg('data_error');
	if (!in_array($groupid,array('3','4')) && !admincheck($forums['forumadmin'],$forums['fupadmin'],$windid)) {
		Showmsg('not_forumadmin');
	}
	$forumset = unserialize($forums['forumset']);
	$first_admin = $db_adminset && strpos($forums['forumadmin'],",".$windid.",")===0 ? 1 : 0;
} else {
	$query = $db->query("SELECT fid,forumadmin,fupadmin FROM pw_forums WHERE cms=0 AND type!='category'");
	while ($rt = $db->fetch_array($query)) {
		if (in_array($groupid,array('3','4')) || admincheck($rt['forumadmin'],$rt['fupadmin'],$windid)) {
			$fiddb[] = $rt['fid'];
		}
	}
	!$fiddb && Showmsg('not_forumadmin');
}
require_once(R_P.'require/header.php');

if (!$action) {
	$forum_name = '';
	$fids		= implode(',',$fiddb);
	$froumdb	= array();
	$query = $db->query("SELECT * FROM pw_forums f LEFT JOIN pw_forumdata fd USING(fid) WHERE f.fid IN($fids)");
	while ($rt = $db->fetch_array($query)) {
		$forumdb[] = $rt;
	}
	$i=count($forumdb);
	if ($i>4) {
		$j_sum = 4;
		$j_wid = '25%';
	} else {
		$j_sum = $i;
		$j_wid = (100/$i).'%';
	}
	require_once(PrintEot('forumcp'));footer();

} elseif ($action=='edit') {
	$forum_name = $forums['name'];
	InitGP(array('type'));
	!$type && $type='notice';
	if ($type=='notice') {
		$annoucedb = array();
		$pages = ''; $page = $_GET['page']; (int)$page<1 && $page = 1;
		$query = $db->query("SELECT aid,ifopen,vieworder,author,subject,startdate,enddate FROM pw_announce WHERE fid='$fid' ORDER BY fid,vieworder,startdate DESC LIMIT ".($page-1)*$db_perpage.",$db_perpage");
		while ($rt = $db->fetch_array($query)) {
			$rt['subject'] = substrs($rt['subject'],30);
			$rt['starttime'] = $rt['startdate'] ? get_date($rt['startdate'],'Y-m-d H:i') : '--';
			$rt['endtime'] = $rt['enddate'] ? get_date($rt['enddate'],'Y-m-d H:i') : '--';
			$annoucedb[] = $rt;
		}
		$db->free_result($query);
		$count = $db->get_value("SELECT COUNT(*) FROM pw_announce WHERE fid='$fid'");
		if ($count > $db_perpage) {
			require_once(R_P.'require/forum.php');
			$addpage = $fid ? "fid=$fid&" : '';
			$pages = numofpage($count,$page,ceil($count/$db_perpage),"$basename&$addpage");
		}
		require_once(PrintEot('forumcp'));footer();
	} elseif ($type=='n_del') {
		$aid = (int)$_GET['aid'];
		$rt = $db->get_one("SELECT aid,fid,ifopen FROM pw_announce WHERE aid='$aid'");
		(!$rt['aid'] || $rt['fid']!=$fid) && Showmsg('data_error');
		$db->update("DELETE FROM pw_announce WHERE aid='$aid'");
		if ($rt['ifopen']) {
			require_once(R_P.'require/updatenotice.php');
			updatecache_i($fid);
		}
		refreshto("forumcp.php?action=edit&fid=$fid",'operate_success');
	} elseif ($type=='n_order') {
		!is_array($vieworder = $_POST['vieworder']) && $vieworder = array();
		$updatedb = array();
		foreach ($vieworder as $key => $value) {
			if (is_numeric($key)) {
				$value = (int)$value;
				$updatedb[$value] .= ",'$key'";
			}
		}
		foreach ($updatedb as $key => $value) {
			$value && $db->update("UPDATE pw_announce SET vieworder='$key' WHERE aid IN (".substr($value,1).')');
		}
		require_once(R_P.'require/updatenotice.php');
		updatecache_i($fid);
		refreshto("forumcp.php?action=edit&fid=$fid",'operate_success');
	} elseif ($type=='add' || $type=='edit') {
		$aid = (int)GetGP('aid');
		if ($_POST['step']!=2) {
			$ifopen_Y = 'CHECKED'; $vieworder = (int)$vieworder;
			$ifopen_N = $subject = $atc_content = $enddate = '';
			$startdate = get_date($timestamp,'Y-m-d H:i');
			if ($type=='edit') {
				$db_redundancy = 0;
				$rt = $db->get_one("SELECT aid,fid,ifopen,vieworder,startdate,enddate,subject,content FROM pw_announce WHERE aid='$aid'");
				!$rt['aid'] && Showmsg('data_error');
				extract($rt,EXTR_OVERWRITE);
				if (!$ifopen) {
					$ifopen_Y = '';
					$ifopen_N = 'CHECKED';
				}
				$subject = Char_cv($subject); $atc_content = Char_cv($content);
				$startdate && $startdate = get_date($startdate,'Y-m-d H:i'); $enddate && $enddate = get_date($enddate,'Y-m-d H:i');
			}
			require_once(PrintEot('forumcp'));footer();
		} else {
			!$fid && Showmsg('annouce_fid');
			$startdate = $_POST['startdate'] ? PwStrtoTime($_POST['startdate']) : $timestamp;
			$enddate = $_POST['enddate'] ? PwStrtoTime($_POST['enddate']) : '';
			$enddate && $enddate<=$startdate && Showmsg('annouce_time');
			InitGP(array('ifopen','vieworder'),'P');

			if ($type=='add') {
				$atc_title = trim(Char_cv($_POST['atc_title']));
				!$atc_title && Showmsg('annouce_title');

				$atc_content = trim(Char_cv($_POST['atc_content']));
				!$atc_content && Showmsg('annouce_content');

				$ifopen = (int)$ifopen;
				$db->update("INSERT INTO pw_announce(fid,ifopen,vieworder,author,startdate,enddate,url,subject,content) VALUES ('$fid','$ifopen','".(int)$vieworder."','$windid','$startdate','$enddate','$url','$atc_title','$atc_content')");
				if ($ifopen && (!$enddate || $enddate>=$timestamp)) {
					require_once(R_P.'require/updatenotice.php');
					updatecache_i($fid);
				}
			} else {
				$rt = $db->get_one("SELECT aid,fid,subject,content FROM pw_announce WHERE aid='$aid'");

				if ($rt['subject']!=$atc_title) {
					$atc_title = trim(Char_cv($_POST['atc_title']));
				}
				!$atc_title && Showmsg('annouce_title');

				if ($rt['content']!=$atc_content) {
					$atc_content = trim(Char_cv($_POST['atc_content']));
				}
				!$atc_content && Showmsg('annouce_content');

				(!$rt['aid'] || $rt['fid']!=$fid) && Showmsg('data_error');
				$db->update("UPDATE pw_announce SET ifopen='".(int)$ifopen."',vieworder='".(int)$vieworder."',startdate='$startdate',enddate='$enddate',url='$url',subject='$atc_title',content='$atc_content' WHERE aid='$aid'");
				require_once(R_P.'require/updatenotice.php');
				updatecache_i($fid);
			}
			refreshto("forumcp.php?action=edit&fid=$fid",'operate_success');
		}
	} elseif ($type=='report') {
		InitGP(array('page'));
		(!is_numeric($page) || $page < 1) && $page=1;
		$limit="LIMIT ".($page-1)*$db_perpage.",$db_perpage";

		$rt=$db->get_one("SELECT COUNT(*) AS count FROM pw_report r LEFT JOIN pw_threads t ON t.tid=r.tid WHERE t.fid='$fid'");
		$sum=$rt['count'];
		$numofpage=ceil($sum/$db_perpage);
		$pages=numofpage($sum,$page,$numofpage,"forumcp.php?action=edit&type=report&fid=$fid&");

		$query=$db->query("SELECT r.*,m.username,t.fid FROM pw_report r LEFT JOIN pw_members m ON m.uid=r.uid LEFT JOIN pw_threads t ON t.tid=r.tid WHERE t.fid='$fid' ORDER BY id $limit");
		while ($rt=$db->fetch_array($query)) {
			$rt['fname']=$forum[$rt['fid']]['name'];
			$reportdb[]=$rt;
		}
		require_once(PrintEot('forumcp'));footer();
	} elseif ($type=='f_type') {
		$rt=$db->get_one("SELECT f.t_type,fe.fid,fe.forumset FROM pw_forums f LEFT JOIN pw_forumsextra fe USING(fid) WHERE f.fid='$fid'");
		$forumset=unserialize($rt['forumset']);
		if (!$_POST['step']) {
			$forumset['addtpctype'] ? $addtpctype_Y='checked' : $addtpctype_N='checked';
			$t_typedb=explode("\t",$rt['t_type']);/*�������*/
			$t_typedb[0] = (int)$t_typedb[0];
			${'t_type_'.$t_typedb[0]}='checked';
			require_once(PrintEot('forumcp'));footer();
		} elseif ($_POST['step']==3) {
			Add_S($forumset);
			InitGP(array('t_db','addtpctype'),'P');
			$t_type = implode("\t",$t_db)."\t";/*�������*/
			$t_type = str_replace('"','&quot;',$t_type);
			if ($t_type!=$rt['t_type']) {
				$db->update("UPDATE pw_forums SET t_type='$t_type' WHERE fid='$fid'");
			}
			if ($addtpctype!=$forumset['addtpctype']) {
				$forumset['addtpctype']=$addtpctype;
				$forumset=serialize($forumset);
				if ($rt['fid']) {
					$db->update("UPDATE pw_forumsextra SET forumset='$forumset' WHERE fid='$fid'");
				} else {
					$db->update("INSERT INTO pw_forumsextra (fid,forumset) VALUES ('$fid','$forumset')");
				}
			}
			refreshto("forumcp.php?action=edit&type=f_type&fid=$fid",'operate_success');
		}
	} elseif ($type=='reward') {
		list($db_moneyname,,$db_rvrcname,,$db_creditname)=explode("\t",$db_credits);
		InitGP(array('page','starttime','endtime','username'));
		(!is_numeric($page) || $page < 1) && $page=1;
		$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";

		$sql = $url_a = '';
		$_POST['starttime'] && $starttime= PwStrtoTime($starttime);
		$_POST['endtime']   && $endtime  = PwStrtoTime($endtime);
		if ($username) {
			$sql.=" AND t.author='$username'";
			$url_a.="username=".rawurlencode($username)."&";
		}
		if ($starttime) {
			$sql.=" AND t.postdate>'$starttime'";
			$url_a.="starttime=$starttime&";
		}
		if ($endtime) {
			$sql.=" AND t.postdate<'$endtime'";
			$url_a.="endtime=$endtime&";
		}

		$rt = $db->get_one("SELECT COUNT(*) AS count FROM pw_threads t LEFT JOIN pw_reward r USING(tid) WHERE t.fid='$fid' AND t.special='3' AND t.state='0' AND r.timelimit<'$timestamp' $sql");
		$sum = $rt['count'];
		$numofpage = ceil($sum/$db_perpage);
		$pages = numofpage($sum,$page,$numofpage,"forumcp.php?action=edit&type=reward&fid=$fid&$url_a");

		$threaddb = array();
		$query = $db->query("SELECT t.tid,t.fid,t.subject,t.author,t.authorid,t.postdate,r.cbtype,r.cbval,r.catype,r.caval FROM pw_threads t LEFT JOIN pw_reward r USING(tid) WHERE t.fid='$fid' AND t.special='3' AND t.state='0' AND r.timelimit<'$timestamp' $sql ORDER BY t.postdate $limit");

		while ($rt = $db->fetch_array($query)) {
			$rt['postdate'] = get_date($rt['postdate'],'Y-m-d');
			$rt['cbtype'] = is_numeric($rt['cbtype']) ? $_CREDITDB[$rt['cbtype']][0] : ${'db_'.$rt['cbtype'].'name'};
			$rt['catype'] = is_numeric($rt['catype']) ? $_CREDITDB[$rt['catype']][0] : ${'db_'.$rt['catype'].'name'};
			$rt['binfo'] = $rt['cbval']."&nbsp;".$rt['cbtype'];
			$rt['ainfo'] = $rt['caval']."&nbsp;".$rt['catype'];
			$threaddb[]  = $rt;
		}
		require_once(PrintEot('forumcp'));footer();
	} elseif ($type=='thread') {
		InitGP(array('page','starttime','endtime','username','t_type'));
		(!is_numeric($page) || $page < 1) && $page=1;
		$limit="LIMIT ".($page-1)*$db_perpage.",$db_perpage";
		$sql = $url_a = '';
		$_POST['starttime'] && $starttime= PwStrtoTime($starttime);
		$_POST['endtime']   && $endtime  = PwStrtoTime($endtime);
		if ($username) {
			$sql.=" AND author='$username'";
			$url_a.="username=".rawurlencode($username)."&";
		}
		if ($starttime) {
			$sql.=" AND postdate>'$starttime'";
			$url_a.="starttime=$starttime&";
		}
		if ($endtime) {
			$sql.=" AND postdate<'$endtime'";
			$url_a.="endtime=$endtime&";
		}
		if ($t_type) {
			switch($t_type) {
				case 'digest':
					$sql.=" AND digest>'0'";
					break;
				case 'active':
					$sql.=" AND special='2'";
					break;
				case 'reward':
					$sql.=" AND special='3'";
					break;
				case 'sale':
					$sql.=" AND special='4'";
					break;
				default :
					$sql.=" AND digest>'0'";
			}
			$url_a.="t_type=$t_type&";
		}
		if ($sql) {
			$rt = $db->get_one("SELECT COUNT(*) AS sum FROM pw_threads WHERE fid='$fid' AND ifcheck='1' $sql");
		} else {
			$rt = $db->get_one("SELECT topic AS sum FROM pw_forumdata WHERE fid='$fid'");
		}
		$pages=numofpage($rt['sum'],$page,ceil($rt['sum']/$db_perpage),"forumcp.php?action=edit&type=thread&fid=$fid&$url_a");
		$query=$db->query("SELECT tid,subject,author,authorid,postdate,titlefont,topped,digest FROM pw_threads WHERE fid='$fid' AND ifcheck='1' $sql ORDER BY topped DESC,lastpost DESC $limit");
		$threaddb = array();
		while ($rt = $db->fetch_array($query)) {
			$rt['subject']=substrs($rt['subject'],35);
			if ($rt['titlefont']) {
				$titledetail=explode("~",$rt['titlefont']);
				if ($titledetail[0])$rt['subject']="<font color=\"$titledetail[0]\">$rt[subject]</font>";
				if ($titledetail[1])$rt['subject']="<b>$rt[subject]</b>";
				if ($titledetail[2])$rt['subject']="<i>$rt[subject]</i>";
				if ($titledetail[3])$rt['subject']="<u>$rt[subject]</u>";
			}
			$rt['postdate']=get_date($rt['postdate']);
			$threaddb[]=$rt;
		}

		require_once PrintEot('forumcp');footer();
	} elseif ($type=='tcheck') {
		if (!$_POST['step']) {
			InitGP(array('page','starttime','endtime','username'));
			(!is_numeric($page) || $page < 1) && $page=1;
			$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
			$sql = $url_a = '';
			$_POST['starttime'] && $starttime= PwStrtoTime($starttime);
			$_POST['endtime']   && $endtime  = PwStrtoTime($endtime);
			if ($username) {
				$sql.=" AND author='$username'";
				$url_a.="username=".rawurlencode($username)."&";
			}
			if ($starttime) {
				$sql.=" AND postdate>'$starttime'";
				$url_a.="starttime=$starttime&";
			}
			if ($endtime) {
				$sql.=" AND postdate<'$endtime'";
				$url_a.="endtime=$endtime&";
			}
			$rt = $db->get_one("SELECT COUNT(*) AS sum FROM pw_threads WHERE fid='$fid' AND ifcheck='0' $sql");
			$pages=numofpage($rt['sum'],$page,ceil($rt['sum']/$db_perpage),"forumcp.php?action=edit&type=tcheck&fid=$fid&$url_a");
			$threaddb = $ttable_a = array();
			$query = $db->query("SELECT tid,subject,author,authorid,postdate FROM pw_threads WHERE fid='$fid' AND ifcheck='0' $sql ORDER BY topped DESC,lastpost DESC $limit");
			while ($rt = $db->fetch_array($query)) {
				$rt['subject']	= substrs($rt['subject'],35);
				$rt['postdate']	= get_date($rt['postdate']);
				$threaddb[$rt['tid']] = $rt;
				$ttable_a[GetTtable($rt['tid'])] .= $rt['tid'].',';
			}
			include_once(D_P.'data/bbscache/wordsfb.php');
			foreach ($ttable_a as $pw_tmsgs=>$value) {
				$value = substr($value,0,-1);
				$query = $db->query("SELECT tid,content FROM $pw_tmsgs WHERE tid IN($value)");
				while ($rt = $db->fetch_array($query)) {
					$rt['content'] = str_replace("\n","<br>",$rt['content']);
					foreach ($alarm as $key=>$value) {
						$rt['content'] = str_replace($key,'<span style="background-color:#ffff66">'.$key.'</span>',$rt['content']);
					}
					$threaddb[$rt['tid']]['content'] = $rt['content'];
				}
			}
			require_once PrintEot('forumcp');footer();
		} elseif ($_POST['step']==3) {
			InitGP(array('selid'));
			$tids = '';
			foreach ($selid as $key=>$value) {
				is_numeric($value) && $tids .= ($tids ? ',' : '').$value;
			}
			!$tids && Showmsg('id_error');
			$db->update("UPDATE pw_threads SET ifcheck='1' WHERE tid IN($tids) AND fid='$fid'");
			require_once(R_P.'require/updateforum.php');
			updateforum($fid);

			refreshto("forumcp.php?action=edit&type=$type&fid=$fid",'operate_success');
		} else {
			InitGP(array('selid'));
			$delids   = '';
			$ttable_a = $attachdb = array();
			foreach ($selid as $key => $value) {
				if (is_numeric($value)) {
					$delids .= $value.',';
					$ttable_a[GetTtable($value)] .= $value.',';
				}
			}
			!$delids && Showmsg('mawhole_nodata');
			$delids = substr($delids,0,-1);

			require_once(R_P.'require/updateforum.php');
			foreach ($ttable_a as $pw_tmsgs=>$value) {
				$value = substr($value,0,-1);
				$query = $db->query("SELECT t.tid,t.fid,tm.aid FROM pw_threads t LEFT JOIN $pw_tmsgs tm ON tm.tid=t.tid WHERE t.tid IN($value)");
				while ($read=$db->fetch_array($query)) {
					$read['fid'] != $fid && Showmsg('admin_forum_right');
					if ($read['aid']) $attachdb[] = $read['aid'];
				}
			}
			$db->update("DELETE FROM pw_threads WHERE tid IN($delids) AND fid='$fid' AND ifcheck='0'");
			foreach ($ttable_a as $pw_tmsgs=>$val) {
				$val = substr($val,0,-1);
				$db->update("DELETE FROM $pw_tmsgs WHERE tid IN($val)");
			}
			delete_tag($delids);

			if($attachdb){
				$ftp = null;
				if ($db_ifftp) {
					require_once(R_P.'require/ftp.php');
					$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
				}
				delete_att($attachdb);
				if ($ftp) {
					$ftp->close(); unset($ftp);
				}
			}
			refreshto("forumcp.php?action=edit&type=$type&fid=$fid",'operate_success');
		}
	} elseif ($type=='pcheck') {
		if (!$_POST['step']) {
			InitGP(array('page','starttime','endtime','username','ptable'));
			(!is_numeric($page) || $page < 1) && $page=1;
			$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
			$sql = $url_a = '';
			$_POST['starttime'] && $starttime= PwStrtoTime($starttime);
			$_POST['endtime']   && $endtime  = PwStrtoTime($endtime);
			if ($username) {
				$sql.=" AND author='$username'";
				$url_a.="username=".rawurlencode($username)."&";
			}
			if ($starttime) {
				$sql.=" AND postdate>'$starttime'";
				$url_a.="starttime=$starttime&";
			}
			if ($endtime) {
				$sql.=" AND postdate<'$endtime'";
				$url_a.="endtime=$endtime&";
			}
			if ($db_plist) {
				!is_numeric($ptable) && $ptable = $db_ptable;
				$p_table = "<option value=\"0\">post</option>";
				$p_list  = explode(',',$db_plist);
				foreach ($p_list as $key=>$val) {
					$p_table .= "<option value=\"$val\">post$val</option>";
				}
				$p_table  = str_replace("<option value=\"$ptable\">","<option value=\"$ptable\" selected>",$p_table);
				$url_a	 .= "ptable=$ptable&";
				$pw_posts = GetPtable($ptable);
			} else {
				$pw_posts = 'pw_posts';
			}
			$rt = $db->get_one("SELECT COUNT(*) AS sum FROM $pw_posts WHERE fid='$fid' AND ifcheck='0' $sql");
			$pages=numofpage($rt['sum'],$page,ceil($rt['sum']/$db_perpage),"forumcp.php?action=edit&type=$type&fid=$fid&$url_a");
			$postdb= array();
			include_once(D_P.'data/bbscache/wordsfb.php');
			$query = $db->query("SELECT pid,tid,subject,author,authorid,postdate,content FROM $pw_posts WHERE fid='$fid' AND ifcheck='0' $sql $limit");
			while ($rt = $db->fetch_array($query)) {
				if ($rt['subject']) {
					$rt['subject'] = substrs($rt['subject'],35);
				} else {
					$rt['subject'] = substrs($rt['content'],35);
				}
				$rt['postdate'] = get_date($rt['postdate']);
				$rt['content']  = str_replace("\n","<br>",$rt['content']);
				foreach ($alarm as $key=>$value) {
					$rt['content'] = str_replace($key,'<span style="background-color:#ffff66">'.$key.'</span>',$rt['content']);
				}
				$postdb[] = $rt;
			}
			require_once PrintEot('forumcp');footer();
		} elseif ($_POST['step']==3) {
			InitGP(array('selid','ptable'));
			$tids = '';
			foreach ($selid as $key=>$value) {
				is_numeric($value) && $tids .= ($tids ? ',' : '').$value;
			}
			!$tids && Showmsg('id_error');
			$pw_posts = GetPtable($ptable);
			$db->update("UPDATE $pw_posts SET ifcheck='1' WHERE pid IN($tids) AND fid='$fid'");
			require_once(R_P.'require/updateforum.php');
			updateforum($fid);

			refreshto("forumcp.php?action=edit&type=$type&fid=$fid",'operate_success');
		} else {
			InitGP(array('selid','ptable'));
			$tids = '';
			$attachdb = array();
			foreach ($selid as $key=>$value) {
				is_numeric($value) && $tids .= ($tids ? ',' : '').$value;
			}
			!$tids && Showmsg('id_error');
			$pw_posts = GetPtable($ptable);
			$query = $db->query("SELECT fid,aid FROM $pw_posts WHERE pid IN($tids)");
			while ($rt = $db->fetch_array($query)) {
				$rt['fid'] != $fid && Showmsg('admin_forum_right');
				if ($rt['aid']) $attachdb[] = $rt['aid'];
			}
			$db->update("DELETE FROM $pw_posts WHERE pid IN($tids)");
			if($attachdb){
				$ftp = null;
				if ($db_ifftp) {
					require_once(R_P.'require/ftp.php');
					$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
				}
				require_once(R_P.'require/updateforum.php');
				delete_att($attachdb);
				if ($ftp) {
					$ftp->close(); unset($ftp);
				}
			}
			refreshto("forumcp.php?action=edit&type=$type&fid=$fid",'operate_success');
		}
	} elseif ($type=='commend') {
		if (!$_POST['step']) {
			$commend = array();
			if ($forumset['commendlist']) {
				$query = $db->query("SELECT tid,authorid,author,postdate,subject FROM pw_threads WHERE tid IN($forumset[commendlist])");
				while ($rt=$db->fetch_array($query)) {
					$rt['postdate'] = get_date($rt['postdate']);
					$commend[] = $rt;
				}
			}
			require_once PrintEot('forumcp');footer();
		} else {
			InitGP(array('selid'));
			foreach ($selid as $key=>$value) {
				if (is_numeric($value)) {
					$forumset['commendlist'] = substr(str_replace(",$value,",",",",$forumset[commendlist],"),1,-1);
				}
			}
			updatecommend($fid,$forumset);
			refreshto("forumcp.php?action=edit&type=$type&fid=$fid",'operate_success');
		}
	} elseif ($type=='adminset') {
		!$first_admin && Showmsg('undefined_action');

		$admin_a = explode(',',trim($forums['forumadmin'],','));
		$firstadmin = $admin_a[0];
		$firstadmin != $windid && Showmsg('undefined_action');

		if (!$_POST['step']) {
			$s_admin = trim(str_replace(",$firstadmin,",',',$forums['forumadmin']),',');
			require_once(PrintEot('forumcp'));footer();
		} else {
			InitGP(array('forumadmin'),'P');
			$errorname = '';
			if ($forums['forumadmin'] != stripslashes(",".$windid.",$forumadmin,")) {
				$newadmin = array('0'=>$windid);
				$newadmin_a = array_unique(explode(",",$forumadmin));
				foreach ($newadmin_a as $aid=>$value) {
					$value = trim($value);
					if ($value && !in_array($value,$newadmin)) {
						$mb = $db->get_one("SELECT uid,groupid,groups FROM pw_members WHERE username='$value'");
						if ($mb) {
							$newadmin[] = $value;
							if ($mb['groupid'] == -1) {
								$db->update("UPDATE pw_members SET groupid='5' WHERE uid='$mb[uid]'");
								$db->update("REPLACE INTO pw_administrators (uid,username,groupid,groups) VALUES ('$mb[uid]','$value','5','$mb[groups]')");
							} elseif ($mb['groupid'] <> 5 && strpos($mb['groups'],',5,')===false) {
								$mb['groups'] = $mb['groups'] ? $mb['groups'].'5,' : ",5,";
								$db->update("UPDATE pw_members SET groups='$mb[groups]' WHERE uid='$mb[uid]'");
								$db->update("REPLACE INTO pw_administrators (uid,username,groupid,groups) VALUES ('$mb[uid]','$value','$mb[groupid]','$mb[groups]')");
							}
						} else {
							$errorname .= ','.$value;
						}
					}
				}
				$oldfadmin = explode(',',trim($forums['forumadmin'],','));
				if ($oldfadmin) {
					$f_admin = array();
					$query = $db->query("SELECT forumadmin FROM pw_forums WHERE fid<>'$fid' AND forumadmin<>''");
					while ($rt = $db->fetch_array($query)) {
						foreach (explode(",",$rt['forumadmin']) as $key=>$value) {
							if ($value = trim($value)) {
								$f_admin[] = $value;
							}
						}
					}
					$f_admin = array_unique($f_admin);
					Add_S($oldfadmin);

					$oldfadmin = "'".implode("','",$oldfadmin)."'";
					$query = $db->query("SELECT uid,username,groupid,groups FROM pw_members WHERE username IN($oldfadmin)");

					while ($rt = $db->fetch_array($query)) {
						if (!in_array($rt['username'],$newadmin) && !in_array($rt['username'],$f_admin)) {
							if ($rt['groupid']=='5') {
								$db->update("UPDATE pw_members SET groupid='-1' WHERE uid='$rt[uid]'");
								$rt['groupid'] = -1;
							} else {
								$rt['groups'] = str_replace(',5,',',',$rt['groups']);
								$rt['groups']==',' && $rt['groups'] = '';
								$db->update("UPDATE pw_members SET groups='$rt[groups]' WHERE uid='$rt[uid]'");
							}
							if (in_array($rt['groupid'],array('-1','6','7')) && $rt['groups']=='') {
								$db->update("DELETE FROM pw_administrators WHERE uid='$rt[uid]'");
							} else {
								$db->update("REPLACE INTO pw_administrators (uid,username,groupid,groups) VALUES ('$rt[uid]','".addslashes($rt['username'])."','$rt[groupid]','$rt[groups]')");
							}
						}
					}
				}
				$newadmin = addslashes(implode(',',$newadmin));
				$db->update("UPDATE pw_forums SET forumadmin=',$newadmin,' WHERE fid='$fid'");
				updatecache_fd();
			}
			if ($errorname) {
				$errorname = Char_cv(substr($errorname,1));
				Showmsg('user_not_exists');
			} else {
				refreshto("forumcp.php?action=edit&type=$type&fid=$fid",'operate_success');
			}
		}
	} elseif($db_recycle && $type=='trecycle') {
		require_once(R_P.'require/updateforum.php');
		require_once(R_P.'require/writelog.php');
		InitGP(array('page','step'));
		if (!$step) {
			InitGP(array('username','starttime','endtime','t_type'));
			(!is_numeric($page) || $page<1) && $page = 1;
			$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";

			$sql = $url_a = '';
			$starttime && $starttime= PwStrtoTime($starttime);
			$endtime   && $endtime  = PwStrtoTime($endtime);
			$username = Char_cv($username);
			if ($username) {
				$sql.=" AND t.author='$username'";
				$url_a.="username=".rawurlencode($username)."&";
			}
			if ($starttime) {
				$sql.=" AND t.postdate>'$starttime'";
				$url_a.="starttime=$starttime&";
			}
			if ($endtime) {
				$sql.=" AND t.postdate<'$endtime'";
				$url_a.="endtime=$endtime&";
			}
			if ($t_type) {
				switch($t_type) {
					case 'digest':
						$sql.=" AND t.digest>'0'";
						break;
					case 'active':
						$sql.=" AND t.special='2'";
						break;
					case 'reward':
						$sql.=" AND t.special='3'";
						break;
					case 'sale':
						$sql.=" AND t.special='4'";
						break;
					default :
				}
				${'t_type_'.$t_type} = 'selected';
				$url_a.="t_type=$t_type&";
			}
			$rt    = $db->get_one("SELECT COUNT(*) AS sum FROM pw_recycle r LEFT JOIN pw_threads t USING(tid) WHERE r.pid='0' AND r.fid='$fid' $sql");
			$pages = numofpage($rt['sum'],$page,ceil($rt['sum']/$db_perpage),"forumcp.php?action=edit&type=trecycle&fid=$fid&$url_a");
			$ttable_a = array();
			$query = $db->query("SELECT r.*,t.subject,t.author,t.authorid FROM pw_recycle r LEFT JOIN pw_threads t USING(tid) WHERE r.pid='0' AND r.fid='$fid' $sql ORDER BY deltime DESC $limit");
			while($rt=$db->fetch_array($query)){
				$rt['deltime'] = get_date($rt['deltime']);
				$rt['subject'] = substrs($rt['subject'],50);
				$rt['fname']   = $forum[$rt['fid']]['name'];
				$recycledb[$rt['tid']] = $rt;
				$ttable_a[GetTtable($rt['tid'])] .= $rt['tid'].',';
			}
			foreach ($ttable_a as $pw_tmsgs=>$value) {
				$value = substr($value,0,-1);
				$query = $db->query("SELECT tid,content FROM $pw_tmsgs WHERE tid IN($value)");
				while ($rt = $db->fetch_array($query)) {
					$rt['content'] = str_replace("\n","<br>",$rt['content']);
					$recycledb[$rt['tid']]['content'] = $rt['content'];
				}
			}
			require_once(PrintEot('forumcp'));footer();
		} elseif($forumset['recycle']&2 && $step=='1'){
			$ids = GetGP('ids','P');
			count($ids) > 500 && Showmsg('forumcp_recycle_maxcount');
			recycle($ids);
			$logdb = array(
				'type'      => 'recycle',
				'username1' => '',
				'username2' => $windid,
				'field1'    => $fid,
				'field2'    => '',
				'field3'    => '',
				'descrip'   => 'recycle_topic_delete',
				'timestamp' => $timestamp,
				'ip'        => $onlineip,
				'affect'    => '',
				'forum'		=> $forum[$fid]['name'],
				'reason'	=> ''
			);
			writelog($logdb);
			refreshto("forumcp.php?action=edit&type=trecycle&fid=$fid",'operate_success');
		} elseif($forumset['recycle']&4 && $step=='2'){
			$ids = GetGP('ids','P');
			count($ids) > 500 && Showmsg('forumcp_recycle_maxcount');
			$reids  = '';
			$logdb = $ptable_a = array();
			foreach ($ids as $key => $value) {
				if (is_numeric($value)) {
					$reids .= $value.',';
				}
			}
			$reids = substr($reids,0,-1);
			!$reids && Showmsg('forumcp_recycle_nodata');
			$query = $db->query("SELECT r.*,t.ptable FROM pw_recycle r LEFT JOIN pw_threads t ON r.tid=t.tid WHERE r.pid='0' AND r.tid IN ($reids)");
			$reids = '';
			$ptable_a = array();
			while ($read=$db->fetch_array($query)) {
				$read['fid'] != $fid && Showmsg('admin_forum_right');
				$ptable_a[$read['ptable']] = 1;
				$reids .= ','.$read['tid'];
			}
			if ($reids) {
				$reids = substr($reids,1);
				$db->update("UPDATE pw_threads SET fid='$fid',ifshield='0' WHERE tid IN($reids)");
				$db->update("UPDATE pw_attachs SET fid='$fid' WHERE tid IN($reids)");
				$db->update("DELETE FROM pw_recycle WHERE tid IN ($reids)");
				foreach ($ptable_a as $key=>$val) {
					$pw_posts = GetPtable($key);
					$db->update("UPDATE $pw_posts SET fid='$fid' WHERE tid IN($reids)");
				}
			}
			updateforum($fid);
			$logdb = array(
				'type'      => 'recycle',
				'username1' => '',
				'username2' => $windid,
				'field1'    => $fid,
				'field2'    => '',
				'field3'    => '',
				'descrip'   => 'recycle_topic_restore',
				'timestamp' => $timestamp,
				'ip'        => $onlineip,
				'affect'    => '',
				'forum'		=> $forum[$fid]['name'],
				'reason'	=> ''
			);
			writelog($logdb);
			refreshto("forumcp.php?action=edit&type=trecycle&fid=$fid",'operate_success');
		} elseif($forumset['recycle']&8 && $step=='3'){
			if ($_SERVER['REQUEST_METHOD']!='POST') {
				$verify = GetGP('verify');
				if ($verify != substr(md5($winduid.$db_sitehash.$winddb['postnum']),0,8)){
					Showmsg('undefined_action');
				}
			}
			$ids = array();
			$flag = false;
			$query = $db->query("SELECT * FROM pw_recycle WHERE fid='$fid' AND pid='0' LIMIT 100");
			while ($rt=$db->fetch_array($query)) {
				$flag || $flag = true;
				$ids[] = $rt['tid'];
			}
			if ($flag) {
				recycle($ids);
				$VerifyHash = substr(md5($winduid.$db_sitehash.$winddb['postnum']),0,8);
				refreshto("forumcp.php?action=edit&type=trecycle&fid=$fid&step=3&verify=$VerifyHash",'delete_recycle');
			} else {
				$logdb = array(
					'type'      => 'recycle',
					'username1' => '',
					'username2' => $windid,
					'field1'    => $fid,
					'field2'    => '',
					'field3'    => '',
					'descrip'   => 'recycle_topic_empty',
					'timestamp' => $timestamp,
					'ip'        => $onlineip,
					'affect'    => '',
					'forum'		=> $forum[$fid]['name'],
					'reason'	=> ''
				);
				writelog($logdb);
				refreshto("forumcp.php?action=edit&type=trecycle&fid=$fid",'operate_success');
			}
		}
	} elseif($db_recycle && $type=='precycle') {
		require_once(R_P.'require/updateforum.php');
		require_once(R_P.'require/writelog.php');
		InitGP(array('step','ptable','page'));
		$db_perpage = 5;
		if (!$step) {
			InitGP(array('username','starttime','endtime','t_type'));
			$sql = $url_a = '';
			if ($db_plist) {
				!is_numeric($ptable) && $ptable = $db_ptable;
				$p_table = "<option value=\"0\">post</option>";
				$p_list  = explode(',',$db_plist);
				foreach ($p_list as $key=>$val) {
					$p_table .= "<option value=\"$val\">post$val</option>";
				}
				$p_table  = str_replace("<option value=\"$ptable\">","<option value=\"$ptable\" selected>",$p_table);
				$url_a	 .= "ptable=$ptable&";
				$pw_posts = GetPtable($ptable);
			} else {
				$pw_posts = 'pw_posts';
			}
			$username = Char_cv($username);
			$starttime && $starttime= PwStrtoTime($starttime);
			$endtime   && $endtime  = PwStrtoTime($endtime);
			if ($username) {
				$sql.=" AND p.author='$username'";
				$url_a.="username=".rawurlencode($username)."&";
			}
			if ($starttime) {
				$sql.=" AND p.postdate>'$starttime'";
				$url_a.="starttime=$starttime&";
			}
			if ($endtime) {
				$sql.=" AND p.postdate<'$endtime'";
				$url_a.="endtime=$endtime&";
			}
			if ($t_type) {
				switch($t_type) {
					case 'digest':
						$sql.=" AND t.digest>'0'";
						break;
					case 'active':
						$sql.=" AND t.special='2'";
						break;
					case 'reward':
						$sql.=" AND t.special='3'";
						break;
					case 'sale':
						$sql.=" AND t.special='4'";
						break;
					default :
						$sql.="";
				}
				${'t_type_'.$t_type} = 'selected';
				$url_a.="t_type=$t_type&";
			}

			(!is_numeric($page) || $page<1) && $page = 1;
			$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
			$rt    = $db->get_one("SELECT COUNT(*) AS sum FROM pw_recycle r LEFT JOIN $pw_posts p USING(pid) LEFT JOIN pw_threads t ON r.tid=t.tid WHERE r.fid='$fid' AND r.pid>'0' AND p.fid='0' $sql");
			$pages = numofpage($rt['sum'],$page,ceil($rt['sum']/$db_perpage),"forumcp.php?action=edit&type=precycle&fid=$fid&$url_a");

			$query = $db->query("SELECT r.*,p.author,p.authorid,p.content,t.subject FROM pw_recycle r LEFT JOIN $pw_posts p ON r.pid=p.pid LEFT JOIN pw_threads t ON r.tid=t.tid WHERE r.fid='$fid' AND r.pid>'0' AND p.fid='0' $sql ORDER BY r.deltime DESC $limit");
			while($rt=$db->fetch_array($query)){
				$rt['deltime'] = get_date($rt['deltime']);
				$rt['subject'] = substrs($rt['subject'],50);
				$rt['content'] = str_replace("\n","<br>",$rt['content']);
				$rt['fname']   = $forum[$rt['fid']]['name'];
				$recycledb[]   = $rt;
			}
			require_once(PrintEot('forumcp'));footer();
		} elseif($forumset['recycle']&2 && $step=='1'){
			$ids = GetGP('ids','P');
			count($ids) > 500 && Showmsg('forumcp_recycle_maxcount');
			$delids = '';
			foreach ($ids as $key => $value) {
				if (is_numeric($value)) {
					$delids .= $value.',';
				}
			}
			$delids = substr($delids,0,-1);
			!$delids && Showmsg('forumcp_recycle_nodata');
			!is_numeric($ptable) && $ptable = $db_ptable;
			$pw_posts = GetPtable($ptable);

			$attachdb = array();
			$ids = '';
			$query = $db->query("SELECT r.*,p.aid FROM pw_recycle r LEFT JOIN $pw_posts p ON r.pid=p.pid WHERE r.pid IN($delids)");
			while ($read=$db->fetch_array($query)) {
				$read['fid'] != $fid && Showmsg('admin_forum_right');
				$read['aid'] && $attachdb[] = $read['aid'];
				$ids .= ','.$read['pid'];
			}
			if ($ids) {
				$ids = substr($ids,1);
				$db->update("DELETE FROM $pw_posts WHERE pid IN ($ids)");
			}
			if ($attachdb) {
				$ftp = null;
				if ($db_ifftp) {
					require_once(R_P.'require/ftp.php');
					$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
				}
				delete_att($attachdb);
				if ($ftp) {
					$ftp->close(); unset($ftp);
				}
			}
			$logdb = array(
				'type'      => 'recycle',
				'username1' => '',
				'username2' => $windid,
				'field1'    => $fid,
				'field2'    => '',
				'field3'    => '',
				'descrip'   => 'recycle_reply_delete',
				'timestamp' => $timestamp,
				'ip'        => $onlineip,
				'affect'    => '',
				'forum'		=> $forum[$fid]['name'],
				'reason'	=> ''
			);
			writelog($logdb);
			refreshto("forumcp.php?action=edit&type=precycle&fid=$fid&ptable=$ptable",'operate_success');
		} elseif($forumset['recycle']&4 && $step=='2'){
			$ids = GetGP('ids','P');
			count($ids) > 500 && Showmsg('forumcp_recycle_maxcount');
			$reids = '';
			foreach ($ids as $key => $value) {
				if (is_numeric($value)) {
					$reids .= ','.$value;
				}
			}
			$reids = substr($reids,1);
			!$reids && Showmsg('forumcp_recycle_nodata');
			!is_numeric($ptable) && $ptable = $db_ptable;
			$pw_posts = GetPtable($ptable);
			$ids = $delids = $rids = '';
			$articlenum = 0;
			$repliesnum = array();
			$query = $db->query("SELECT r.*,t.fid as tfid FROM pw_recycle r LEFT JOIN pw_threads t ON r.tid=t.tid WHERE r.pid IN($reids)");
			while ($read=$db->fetch_array($query)) {
				$read['fid'] != $fid && Showmsg('admin_forum_right');
				if ($read['tfid']) {
					$ids .= ','.$read['pid'];
					$articlenum++;
				} else {
					$delids .= ','.$read['pid'];
				}
				$rids .= ','.$read['pid'];
				$repliesnum[$read['tid']]++;
			}
			if ($ids) {
				$ids = substr($ids,1);
				$db->update("UPDATE $pw_posts p LEFT JOIN pw_recycle r ON p.pid=r.pid SET p.tid=r.tid,p.fid=r.fid WHERE p.pid IN ($ids)");
				$db->update("UPDATE pw_attachs SET fid='$fid' WHERE pid IN($reids)");
			}
			if ($delids) {
				$delids = substr($delids,1);
				$db->update("UPDATE $pw_posts p LEFT JOIN pw_recycle r ON p.pid=r.pid SET p.tid=r.tid,p.fid='0' WHERE p.pid IN ($delids)");
			}
			if ($rids) {
				$rids = substr($rids,1);
				$db->update("DELETE FROM pw_recycle WHERE pid IN ($ids)");
			}

			foreach ($repliesnum as $key=>$val) {
				$db->update("UPDATE pw_threads SET replies=replies+'$val' WHERE tid='$key'");
			}
			$articlenum && $db->update("UPDATE pw_forumdata SET article=article + '$articlenum' WHERE fid='$fid'");
			$logdb = array(
				'type'      => 'recycle',
				'username1' => '',
				'username2' => $windid,
				'field1'    => $fid,
				'field2'    => '',
				'field3'    => '',
				'descrip'   => 'recycle_reply_restore',
				'timestamp' => $timestamp,
				'ip'        => $onlineip,
				'affect'    => '',
				'forum'		=> $forum[$fid]['name'],
				'reason'	=> ''
			);
			writelog($logdb);
			refreshto("forumcp.php?action=edit&type=precycle&fid=$fid&ptable=$ptable",'operate_success');
		} elseif($forumset['recycle']&8 && $step=='3'){
			if ($_SERVER['REQUEST_METHOD']!='POST') {
				$verify = GetGP('verify');
				if ($verify != substr(md5($winduid.$db_sitehash.$winddb['postnum']),0,8)){
					Showmsg('undefined_action');
				}
			}
			$ids = '';
			$attachdb = array();
			$flag = false;
			!is_numeric($ptable) && $ptable = $db_ptable;
			$pw_posts = GetPtable($ptable);
			$query = $db->query("SELECT r.*,p.aid FROM pw_recycle r LEFT JOIN $pw_posts p ON r.pid=p.pid WHERE r.fid='$fid' AND r.pid>'0' LIMIT 100");
			while ($rt=$db->fetch_array($query)) {
				$flag || $flag = true;
				$ids .= ','.$rt['pid'];
				$attachdb[] = $rt['aid'];
			}
			if ($flag) {
				if ($ids) {
					$ids = substr($ids,1);
					$db->update("DELETE FROM $pw_posts WHERE pid IN ($ids)");
					$db->update("DELETE FROM pw_recycle WHERE pid IN ($ids)");
				}
				if ($attachdb) {
					$ftp = null;
					if ($db_ifftp) {
						require_once(R_P.'require/ftp.php');
						$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
					}
					delete_att($attachdb);
					if ($ftp) {
						$ftp->close(); unset($ftp);
					}
				}
				$VerifyHash = substr(md5($winduid.$db_sitehash.$winddb['postnum']),0,8);
				refreshto("forumcp.php?action=edit&type=precycle&fid=$fid&step=3&ptable=$ptable&verify=$VerifyHash",'delete_recycle');
			} else {
				$logdb = array(
					'type'      => 'recycle',
					'username1' => '',
					'username2' => $windid,
					'field1'    => $fid,
					'field2'    => '',
					'field3'    => '',
					'descrip'   => 'recycle_reply_empty',
					'timestamp' => $timestamp,
					'ip'        => $onlineip,
					'affect'    => '',
					'forum'		=> $forum[$fid]['name'],
					'reason'	=> ''
				);
				writelog($logdb);
				refreshto("forumcp.php?action=edit&type=precycle&fid=$fid",'operate_success');
			}
		}
	}
} elseif ($action=='del') {
	InitGP(array('selid','type'));
	$selids='';
	foreach ($selid as $key=>$value) {
		is_numeric($value) && $selids .= $selids ? ','.$value : $value;
	}
	!$selids && Showmsg('id_error');

	if ($type=='report') {
		$db->update("DELETE FROM pw_report WHERE id IN ($selids)");
		refreshto("forumcp.php?action=edit&type=report&fid=$fid",'operate_success');
	}
}

function updatecache_fd() {
	global $db;
	$db->update("UPDATE pw_forums SET childid='0',fupadmin=''");
	$query = $db->query("SELECT fid,forumadmin FROM pw_forums WHERE type='category' ORDER BY vieworder");
	while ($cate = $db->fetch_array($query)) {
		Add_S($cate);
		$query2 = $db->query("SELECT fid,forumadmin FROM pw_forums WHERE type='forum' AND fup='$cate[fid]'");
		if ($db->num_rows($query2)) {
			$havechild[] = $cate['fid'];
			while ($forum = $db->fetch_array($query2)) {
				Add_S($forum);
				$fupadmin = trim($cate['forumadmin']);
				if ($fupadmin) {
					$db->update("UPDATE pw_forums SET fupadmin='$fupadmin' WHERE fid='$forum[fid]'");
				}
				if (trim($forum['forumadmin'])) {
					$fupadmin .= $fupadmin ? substr($forum['forumadmin'],1) : $forum['forumadmin']; //is
				}
				$query3 = $db->query("SELECT fid,forumadmin FROM pw_forums WHERE type='sub' AND fup='$forum[fid]'");
				if ($db->num_rows($query3)) {
					$havechild[] = $forum['fid'];
					while ($sub1 = $db->fetch_array($query3)) {
						Add_S($sub1);
						$fupadmin1 = $fupadmin;
						if ($fupadmin1) {
							$db->update("UPDATE pw_forums SET fupadmin='$fupadmin1' WHERE fid='$sub1[fid]'");
						}
						if (trim($sub1['forumadmin'])) {
							$fupadmin1 .= $fupadmin1 ? substr($sub1['forumadmin'],1) : $sub1['forumadmin'];
						}
						$query4 = $db->query("SELECT fid,forumadmin FROM pw_forums WHERE type='sub' AND fup='$sub1[fid]'");
						if ($db->num_rows($query4)) {
							$havechild[] = $sub1['fid'];
							while ($sub2 = $db->fetch_array($query4)) {
								Add_S($sub2);
								$fupadmin2 = $fupadmin1;
								if ($fupadmin2) {
									$db->update("UPDATE pw_forums SET fupadmin='$fupadmin2' WHERE fid='$sub2[fid]'");
								}
							}
						}
					}
				}
			}
		}
	}
	if ($havechild) {
		$havechilds = implode(',',$havechild);
		$db->update("UPDATE pw_forums SET childid='1' WHERE fid IN($havechilds)");
	}
}

function recycle($ids){
	global $db,$fid,$attachdir,$ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir;
	$delids = '';
	foreach ($ids as $key => $value) {
		if (is_numeric($value)) {
			$delids .= $value.',';
		}
	}
	$delids = substr($delids,0,-1);
	!$delids && Showmsg('forumcp_recycle_nodata');
	$ftp = null;
	if ($db_ifftp) {
		require_once(R_P.'require/ftp.php');
		$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
	}
	$query  = $db->query("SELECT r.*,t.special,t.ifshield,t.ifupload,t.ptable FROM pw_recycle r LEFT JOIN pw_threads t ON r.tid=t.tid WHERE r.tid IN ($delids) AND r.pid='0' AND r.fid='$fid'");
	$taid_a = $ttable_a = $ptable_a = array();
	$delids = $pollids = $actids = $delaids = $rewids = $ids = '';
	while(@extract($db->fetch_array($query))){
		$ids .= ','.$tid;
		$ifshield != '2' && $delids .= $tid.',';
		$special == 1 && $pollids .= $tid.',';
		$special == 2 && $actids  .= $tid.',';
		$special == 3 && $rewids  .= $tid.',';
		if ($ifshield != '2') {
			$ptable_a[$ptable] = 1;
			$ttable_a[GetTtable($tid)] .= $tid.',';
		}
		if($ifupload){
			$taid_a[GetTtable($tid)] .= $tid.',';
			if ($ifshield != '2') {
				$pw_posts = GetPtable($ptable);
				$query2 = $db->query("SELECT aid FROM $pw_posts WHERE tid='$tid' AND aid!=''");
				while(@extract($db->fetch_array($query2))){
					if(!$aid) continue;
					$attachs = unserialize(stripslashes($aid));
					foreach($attachs as $key => $value){
						is_numeric($key) && $delaids .= $key.',';
						if($ftp && !file_exists($attachdir."/".$value['attachurl'])){
							$ftp->delete($value['attachurl']);
							$value['ifthumb'] && $ftp->delete("thumb/$value[attachurl]");
						} else{
							P_unlink("$attachdir/$value[attachurl]");
							$value['ifthumb'] && P_unlink("$attachdir/thumb/$value[attachurl]");
						}
					}
				}
			}
		}
	}
	foreach($taid_a as $pw_tmsgs=>$value){
		$value = substr($value,0,-1);
		$query = $db->query("SELECT aid FROM $pw_tmsgs WHERE tid IN($value) AND aid!=''");
		while(@extract($db->fetch_array($query))){
			if(!$aid) continue;
			$attachs = unserialize(stripslashes($aid));
			foreach($attachs as $key => $value){
				is_numeric($key) && $delaids .= $key.',';
				if($ftp && !file_exists($attachdir."/".$value['attachurl'])){
					$ftp->delete($value['attachurl']);
					$value['ifthumb'] && $ftp->delete("thumb/$value[attachurl]");
				} else{
					P_unlink("$attachdir/$value[attachurl]");
					$value['ifthumb'] && P_unlink("$attachdir/thumb/$value[attachurl]");
				}
			}
		}
	}
	if($pollids){
		$pollids = substr($pollids,0,-1);
		$db->update("DELETE FROM pw_polls WHERE tid IN($pollids)");
	}
	if($actids){
		$actids = substr($actids,0,-1);
		$db->update("DELETE FROM pw_activity WHERE tid IN($actids)");
		$db->update("DELETE FROM pw_actmember WHERE actid IN($actids)");
	}
	if ($rewids) {
		$rewids = substr($rewids,0,-1);
		$db->update("DELETE FROM pw_reward WHERE tid IN($rewids)");
	}
	if($delaids){
		$delaids  = substr($delaids,0,-1);
		$db->update("DELETE FROM pw_attachs WHERE aid IN($delaids)");
	}
	$delids  = substr($delids,0,-1);
	if($delids){
		$db->update("DELETE FROM pw_threads	WHERE tid IN($delids)");
	}
	foreach($ttable_a as $pw_tmsgs=>$val){
		$val = substr($val,0,-1);
		$db->update("DELETE FROM $pw_tmsgs WHERE tid IN($val)");
	}
	foreach($ptable_a as $key=>$val){
		$pw_posts = GetPtable($key);
		$db->update("DELETE FROM $pw_posts WHERE tid IN($delids)");
	}
	delete_tag($delids);
	if ($ids) {
		$ids = substr($ids,1);
		$db->update("DELETE FROM pw_recycle WHERE tid IN ($ids)");
	}
	if ($ftp) {
		$ftp->close(); unset($ftp);
	}
}
?>