<?php
/**
*
*  Copyright (c) 2003-08  PHPWind.net. All rights reserved.
*  Support : http://www.phpwind.net
*  This software is the proprietary information of PHPWind.com.
*
*/
file_exists('install.php') && ObHeader('install.php');
error_reporting(E_ERROR | E_PARSE);
set_magic_quotes_runtime(0);
function_exists('date_default_timezone_set') && date_default_timezone_set('Etc/GMT+0');

$defined_vars = get_defined_vars();
foreach ($defined_vars as $_key => $_value) {
	if (!in_array($_key,array('GLOBALS','_POST','_GET','_COOKIE','_SERVER','_FILES','wind_in'))) {
		${$_key} = '';
		unset(${$_key});
	}
}

$t_array = explode(' ',microtime());
$P_S_T	 = $t_array[0] + $t_array[1];

define('R_P',getdirname(__FILE__));
define('D_P',R_P);
!defined('SCR') && define('SCR','other');

if (!get_magic_quotes_gpc()) {
	Add_S($_POST);
	Add_S($_GET);
	Add_S($_COOKIE);
}
Add_S($_FILES);

$c_agentip = 1;
if ($_SERVER['HTTP_X_FORWARDED_FOR']) {
	$onlineip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} elseif ($_SERVER['HTTP_CLIENT_IP']) {
	$onlineip = $_SERVER['HTTP_CLIENT_IP'];
} else {
	$onlineip = $_SERVER['REMOTE_ADDR'];
	$c_agentip = 0;
}
$onlineip  = preg_match('/^([0-9]{1,3}\.){3}[0-9]{1,3}$/',$onlineip) ? $onlineip : 'Unknown';
$timestamp = time();

!$_SERVER['PHP_SELF'] && $_SERVER['PHP_SELF'] = $_SERVER['SCRIPT_NAME'];
require_once(R_P.'require/defend.php');

$dirstrpos = strpos($_SERVER['PHP_SELF'],$db_dir);
if ($dirstrpos!==false) {
	$tmp = substr($_SERVER['PHP_SELF'],0,$dirstrpos);
	$_SERVER['PHP_SELF'] = "$tmp.php";
} else {
	$tmp = $_SERVER['PHP_SELF'];
}
$REQUEST_URI = $_SERVER['PHP_SELF'].'?'.$_SERVER['QUERY_STRING'];

if (GetCookie('lastvisit')) {
	list($c_oltime,$lastvisit,$lastpath) = explode("\t",GetCookie('lastvisit'));
	($onbbstime=$timestamp-$lastvisit)<$db_onlinetime && $c_oltime+=$onbbstime;
} else {
	$lastvisit = $lastpath = '';
	$c_oltime = $onbbstime = 0;
	Cookie('lastvisit',$c_oltime."\t".$timestamp."\t".$REQUEST_URI);
}
if (defined('AJAX')) {
	require_once(R_P.'require/ajaxfunc.php');
}
$db_cvtime != 0 && $timestamp += $db_cvtime*60;

$db_debug && error_reporting(E_ALL ^ E_NOTICE);
$wind_version = '6.3.2';
$db_olsize	  = 96;

$R_url = $db_bbsurl = Char_cv("http://$_SERVER[HTTP_HOST]".substr($tmp,0,strrpos($tmp,'/')));
defined('SIMPLE') && SIMPLE && $db_bbsurl = substr($db_bbsurl,0,-7);

$fid = (int)GetGP('fid');
$tid = (int)GetGP('tid');
$db	 = null;

require_once(D_P.'data/sql_config.php');
!is_array($manager) && $manager = array();
$newmanager = array();
foreach ($manager as $key => $value) {
	if (!empty($value) && !is_array($value)) {
		$newmanager[$key] = $value;
	}
}
$manager = $newmanager;
if ($database=='mysqli' && Pwloaddl('mysqli')===false) {
	$database = 'mysql';
}
ObStart();//noizy

if ($db_http != 'N') {
	$imgpath = $db_http;
	if (D_P != R_P) {
		$R_url = substr($db_http,-1)=='/' ?  substr($db_http,0,-1) : $db_http;
		$R_url = substr($R_url,0,strrpos($R_url,'/'));
	}
} else {
	$imgpath = $db_picpath;
}
$attachpath = $db_attachurl != 'N' ? $db_attachurl : $db_attachname;
$imgdir		= R_P.$db_picpath;
$attachdir	= R_P.$db_attachname;
$pw_posts   = 'pw_posts';
$pw_tmsgs   = 'pw_tmsgs';
$runfc		= 'N';

list($winduid,$windpwd,$safecv) = explode("\t",addslashes(StrCode(GetCookie('winduser'),'DECODE')));
if ($db_pptifopen && $db_ppttype == 'client') {
	if (strpos($db_pptloginurl,'?')===false) {
		$db_pptloginurl .= '?';
	} elseif (substr($db_pptloginurl,-1)!='&') {
		$db_pptloginurl .= '&';
	}
	if (strpos($db_pptregurl,'?')===false) {
		$db_pptregurl .= '?';
	} elseif (substr($db_pptregurl,-1)!='&') {
		$db_pptregurl .= '&';
	}
	$urlencode = rawurlencode($db_bbsurl);
	$loginurl	 = "$db_pptserverurl/{$db_pptloginurl}forward=$urlencode";
	$loginouturl = PwEncodeUrl("$db_pptserverurl/$db_pptloginouturl&forward=$urlencode");
	$regurl = "$db_pptserverurl/{$db_pptregurl}forward=$urlencode";
} else {
	$loginurl = 'login.php';
	$loginouturl = PwEncodeUrl("login.php?action=quit");
	$regurl = $db_registerfile;
}

$ol_offset = GetCookie('ol_offset');
$skinco	   = GetCookie('skinco');
if ($db_refreshtime && $REQUEST_URI==$lastpath && $onbbstime<$db_refreshtime) {
	!GetCookie('winduser') && $groupid = 'guest';
	$skin = $skinco ? $skinco : $db_defaultstyle;
	Showmsg('refresh_limit');
}
if (!$db_bbsifopen && !defined('CK')) {
	require_once(R_P.'require/bbsclose.php');
}

$H_url =& $db_wwwurl;
$B_url =& $db_bbsurl;
$t		= array('hours'=>gmdate('G',$timestamp+$db_timedf*3600));
$tddays = get_date($timestamp,'j');
$tdtime	= (floor($timestamp/3600)-$t['hours'])*3600;
$montime = $tdtime-($tddays-1)*86400;
if ($_COOKIE || $timestamp%3==0) {
	if (SCR=='thread') {
		$lastpos = "F$fid";
	} elseif (SCR=='read') {
		$lastpos = "T$tid";
	} elseif (SCR=='index') {
		$lastpos = 'index';
	} else {
		$lastpos = 'other';
	}
	if ($timestamp-$lastvisit>$db_onlinetime || $lastpos != GetCookie('lastpos')) {
		$runfc = 'Y';
		Cookie('lastpos',$lastpos);
	}
}

if (is_numeric($winduid) && strlen($windpwd)>=16) {
	$winddb	  = User_info();
	$winduid  = $winddb['uid'];
	$groupid  = $winddb['groupid'];
	$userrvrc = (int)($winddb['rvrc']/10);
	$windid	  = $winddb['username'];
	$_datefm  = $winddb['datefm'];
	$_timedf  = $winddb['timedf'];
	$skin	  = $winddb['style'] ? $winddb['style'] : $db_defaultstyle;
	list($winddb['onlineip']) = explode('|',$winddb['onlineip']);
	$groupid=='-1' && $groupid=$winddb['memberid'];
	$curvalue = $db_signcurtype=='rvrc' ? $userrvrc : $winddb[$db_signcurtype];
	if ($winddb['showsign'] && (!$winddb['starttime'] && $db_signmoney && strpos($db_signgroup,",$groupid,") !== false && $curvalue > $db_signmoney || $winddb['starttime'] && $winddb['starttime'] != $tdtime)) {
		require_once(R_P.'require/Signfunc.php');
		Signfunc($winddb['showsign'],$winddb['starttime'],$curvalue);
	}
	unset($curvalue);
} else {
	$skin	 = $db_defaultstyle;
	$groupid = 'guest';
	$winddb  = $windid = $winduid = $_datefm = $_timedf = '';
}

if ($db_bbsifopen==2 && !defined('CK')) {
	require_once(R_P.'require/bbsclose.php');
}
if ($db_ifsafecv && strpos($db_safegroup,",$groupid,")!==false && !$safecv && !defined('PRO')) {
	Showmsg('safecv_prompt');
}
if ($db_ads && !$windid && (is_numeric($_GET['u']) || ($_GET['a'] && strlen($_GET['a'])<16)) && strpos($_SERVER['HTTP_REFERER'],$_SERVER['HTTP_HOST'])===false) {
	InitGP(array('u','a'));
	Cookie('userads',"$u\t$a\t".md5($_SERVER['HTTP_REFERER']));
} elseif (GetCookie('userads') && $db_ads=='1') {
	list($u,$a) = explode("\t",GetCookie('userads'));
	if ((int)$u>0 || ($a && strlen($a)<16)) {
		require_once(R_P.'require/userads.php');
	}
}

if ($_POST['skinco']) {
	$skinco = $_POST['skinco'];
} elseif ($_GET['skinco']) {
	$skinco = $_GET['skinco'];
}
if ($skinco && file_exists(D_P."data/style/$skinco.php") && strpos($skinco,'..')===false) {
	$skin = $skinco;
	Cookie('skinco',$skin);
}
if ($db_columns && !defined('W_P') && !defined('SIMPLE') && !defined('COL')) {
	$j_columns = GetCookie('columns');
	if (!$j_columns) {
		$db_columns==2 && $j_columns = 2;
		Cookie('columns',$j_columns);
	}
	if ($j_columns==2 && (strpos($_SERVER['HTTP_REFERER'],$db_bbsurl)===false || strpos($_SERVER['HTTP_REFERER'],$db_adminfile)!==false)) {
		strpos($REQUEST_URI,'index.php')===false ? Cookie('columns','1') : ObHeader('columns.php?action=columns');
	}
}
Ipban();
Cookie('lastvisit',$c_oltime."\t".$timestamp."\t".$REQUEST_URI);

if ($groupid=='guest' && $db_guestdir && GetGcache()) {
	require_once(R_P.'require/guestfunc.php');
	getguestcache();
}
PwNewDB();

unset($_key,$_value,$defined_vars,$t_array,$db_whybbsclose,$db_whycmsclose,$db_ipban,$db_diy,$dbhost,$dbuser,$dbpw,$dbname,$pconnect,$manager_pwd,$newmanager);

if ($groupid=='guest') {
	require_once(D_P.'data/groupdb/group_2.php');
} elseif (file_exists(D_P."data/groupdb/group_$groupid.php")) {
	require_once Pcv(D_P."data/groupdb/group_$groupid.php");
} else {
	require_once(D_P.'data/groupdb/group_1.php');
}

$SCR = SCR;
$header_ad = $footer_ad = '';
if (SCR != 'read') {
	$advertdb = AdvertInit(SCR,$fid);
	if (is_array($advertdb['header'])) {
		$header_ad = $advertdb['header'][array_rand($advertdb['header'])]['code'];
	}
	if (is_array($advertdb['footer'])) {
		$footer_ad = $advertdb['footer'][array_rand($advertdb['footer'])]['code'] .'<br />';
	}
	unset($advertdb['header'],$advertdb['footer']);
}
if ($_SERVER['REQUEST_METHOD']=='POST' && strpos($REQUEST_URI,'login.php')===false && strpos($REQUEST_URI,$db_registerfile)===false) {
	$referer_a = @parse_url($_SERVER['HTTP_REFERER']);
	if ($referer_a['host']) {
		list($http_host) = explode(':',$_SERVER['HTTP_HOST']);
		if ($referer_a['host']!=$http_host) {
			Showmsg('undefined_action');
		}
	}
	unset($referer_a);
}

function refreshto($URL,$content,$statime=1){
	if (defined('AJAX')) Showmsg($content);
	global $db_ifjump;
	$URL = str_replace('&#61;','=',$URL);
	if ($db_ifjump && $statime>0) {
		ob_end_clean();
		global $tplpath,$fid,$imgpath,$db_obstart,$db_bbsname,$skin,$B_url;
		$index_name =& $db_bbsname;
		$index_url =& $B_url;
		ObStart();//noizy
		if (file_exists(D_P."data/style/$skin.php") && strpos($skin,'..')===false) {
			include_once Pcv(D_P."data/style/$skin.php");
		} else {
			include_once(D_P.'data/style/wind.php');
		}
		@extract($GLOBALS, EXTR_SKIP);
		require_once GetLang('refreshto');
		$lang[$content] && $content = $lang[$content];
		@require PrintEot('refreshto');exit;
	} else {
		ObHeader($URL);
	}
}
function ObHeader($URL){
	global $db_obstart,$db_bbsurl,$db_htmifopen;
	if ($db_htmifopen && strtolower(substr($URL,0,4))!='http') {
		$URL = "$db_bbsurl/$URL";
	}
	ob_end_clean();
	if (!$db_obstart) {
		ob_start();
		echo "<meta http-equiv='refresh' content='0;url=$URL'>";exit;
	}
	header("Location: $URL");exit;
}
function Showmsg($msg_info,$dejump=0){
	@extract($GLOBALS, EXTR_SKIP);
	global $stylepath,$tablewidth,$mtablewidth,$tplpath;
	require_once GetLang('msg');
	$lang[$msg_info] && $msg_info = $lang[$msg_info];
	if (defined('AJAX')) {
		echo $msg_info; ajax_footer();
	}
	$showlogin = false;
	if ($dejump!='1' && $groupid=='guest' && $REQUEST_URI==str_replace(array('register','login'),'',$REQUEST_URI) && (!$db_pptifopen || $db_ppttype != 'client')) {
		if (strpos($REQUEST_URI,'post.php')!==false && $_POST['tid']) {
			$REQUEST_URI = substr($REQUEST_URI,0,strrpos($REQUEST_URI,'/'))."/read.php?tid=$_POST[tid]&toread=1";
		}
		if ($db_htmifopen) {
			$REQUEST_URI = str_replace(array('.php?','&','='),array($db_dir,'-','-'),$REQUEST_URI);
			strpos($REQUEST_URI,$db_ext)===false && $REQUEST_URI .= $db_ext;
		}
		$jumpurl = "http://$_SERVER[HTTP_HOST]".$REQUEST_URI;
		list(,$qcheck)=explode("\t",$db_qcheck);
		$qkey = $qcheck && $db_question ? array_rand($db_question) : '';
		$showlogin = true;
	}
	define('MSG',1);
	$subject = strip_tags($msg_info).' - ';
	require_once(R_P.'require/header.php');
	require_once PrintEot('showmsg');exit;
}
function GetLang($lang,$EXT='php'){
	global $tplpath;

	if (file_exists(R_P."template/$tplpath/lang_$lang.$EXT")) {
		return R_P."template/$tplpath/lang_$lang.$EXT";
	} elseif (file_exists(R_P."template/wind/lang_$lang.$EXT")) {
		return R_P."template/wind/lang_$lang.$EXT";
	} else {
		exit("Can not find lang_$lang.$EXT file");
	}
}
function PrintEot($template,$EXT='htm'){
	//Copyright (c) 2003-08 PHPWind
	global $tplpath;
	!$template && $template = 'N';

	if (file_exists(R_P."template/$tplpath/$template.$EXT")) {
		return R_P."template/$tplpath/$template.$EXT";
	} elseif (file_exists(R_P."template/wind/$template.$EXT")) {
		return R_P."template/wind/$template.$EXT";
	} else {
		exit("Can not find $template.$EXT file");
	}
}
function Cookie($ck_Var,$ck_Value,$ck_Time='F',$p=true,$ck_Httponly=true){
	global $db_ckpath,$db_ckdomain,$timestamp;

	if (!$_SERVER['REQUEST_URI'] || ($https = @parse_url($_SERVER['REQUEST_URI']))===false) {
		$https = array();
	}
	if ((empty($https['scheme']) && ($_SERVER['HTTP_SCHEME']=='https' || $_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS'])!='off')) || $https['scheme']=='https') {
		$ck_Secure = true;
	} else {
		$ck_Secure = false;
	}

	!$db_ckpath && $db_ckpath = '/';
	$p && $ck_Var = CookiePre()."_$ck_Var";
	if ($ck_Time=='F') {
		$ck_Time = $timestamp+31536000;
	} elseif ($ck_Value=='' && $ck_Time==0) {
		return setcookie($ck_Var,'',$timestamp-31536000,$db_ckpath,$db_ckdomain,$ck_Secure);
	}
	if (PHP_VERSION>='5.2.0') {
		return setcookie($ck_Var,$ck_Value,$ck_Time,$db_ckpath,$db_ckdomain,$ck_Secure,$ck_Httponly);
	} else {
		return setcookie($ck_Var,$ck_Value,$ck_Time,$db_ckpath.($ck_Httponly ? '; HttpOnly' : ''),$db_ckdomain,$ck_Secure);
	}
}
function GetCookie($Var){
	return $_COOKIE[CookiePre()."_$Var"];
}
function CookiePre(){
	static $pre = null;
	!isset($pre) && $pre = substr(md5($GLOBALS['db_sitehash']),0,5);
	return $pre;
}
function Ipban(){
	global $db_ipban,$onlineip,$imgpath,$stylepath;
	if ($db_ipban) {
		$baniparray = explode(',',$db_ipban);
		foreach ($baniparray as $banip) {
			if ($banip && strpos(",$onlineip.",','.trim($banip).'.')!==false) {
				Showmsg('ip_ban');
			}
		}
	}
}
function P_unlink($filename){
	strpos($filename,'..')!==false && exit('Forbidden');
	return @unlink($filename);
}
function openfile($filename){
	$filedb = explode('<:wind:>',str_replace("\n","\n<:wind:>",readover($filename)));
	$count = count($filedb)-1;
	if ($count > -1 && (!$filedb[$count] || $filedb[$count]=="\r")) {
		unset($filedb[$count]);
	}
	empty($filedb) && $filedb[0] = '';
	return $filedb;
}
function readover($filename,$method='rb'){
	strpos($filename,'..')!==false && exit('Forbidden');
	$filedata = '';
	if ($handle = @fopen($filename,$method)) {
		flock($handle,LOCK_SH);
		$filedata = @fread($handle,filesize($filename));
		fclose($handle);
	}
	return $filedata;
}
function writeover($filename,$data,$method='rb+',$iflock=1,$check=1,$chmod=1){
	//Copyright (c) 2003-08 PHPWind
	$check && strpos($filename,'..')!==false && exit('Forbidden');
	touch($filename);
	$handle = fopen($filename,$method);
	$iflock && flock($handle,LOCK_EX);
	fwrite($handle,$data);
	$method=='rb+' && ftruncate($handle,strlen($data));
	fclose($handle);
	$chmod && @chmod($filename,0777);
}
function Update_ol(){
	global $runfc,$db_online;
	if ($runfc == 'Y') {
		if ($db_online) {
			Sql_ol();
		} else {
			Txt_ol();
		}
		$runfc = 'N';
	}
}
function Txt_ol(){
	global $ol_offset,$winduid,$db_ipstates,$isModify;
	require_once(R_P.'require/userglobal.php');
	if ($winduid>0) {
		list($alt_offset,$isModify) = addonlinefile($ol_offset,$winduid);
	} else {
		list($alt_offset,$isModify) = addguestfile($ol_offset);
	}
	$alt_offset!=$ol_offset && Cookie('ol_offset',$alt_offset);
	if ($db_ipstates && ((!GetCookie('ipstate') && $isModify===1) || (GetCookie('ipstate') && GetCookie('ipstate')<$GLOBALS['tdtime']))) {
		require_once(R_P.'require/ipstates.php');
	}
}
function Sql_ol(){
	global $db,$fid,$tid,$timestamp,$windid,$winduid,$onlineip,$groupid,$wind_in,$db_onlinetime,$db_ipstates;
	$olid	= (int)GetCookie('olid');
	$ifhide = GetCookie('hideid') ? 1 : 0;
	$isModify = 0;
	PwNewDB();

	if ($olid) {
		$sqladd = $winduid ? "(uid='$winduid' OR olid='$olid' AND uid=0 AND ip='$onlineip')" : "olid='$olid' AND ip='$onlineip'";
		$db->update("UPDATE pw_online SET username='$windid',lastvisit='$timestamp',fid='$fid',tid='$tid',groupid='$groupid',action='$wind_in',ifhide='$ifhide',uid='$winduid',ip='$onlineip' WHERE $sqladd");
		if ($winduid && $db->affected_rows() > 1) {
			$db->update("DELETE FROM pw_online WHERE uid='$winduid' AND olid!='$olid'");
		}
	} elseif (!$_COOKIE) {
		$db->update("UPDATE pw_online SET username='$windid',lastvisit='$timestamp',fid='$fid',tid='$tid',groupid='$groupid',action='$wind_in',ifhide='$ifhide',uid='$winduid' WHERE ip='$onlineip'");
	}
	if (!$olid && $_COOKIE || $db->affected_rows()==0) {
		$db->update("DELETE FROM pw_online WHERE uid!=0 AND uid='$winduid' OR lastvisit<($timestamp-$db_onlinetime)");
		$rt = $db->get_one("SELECT MAX(olid) FROM pw_online",MYSQL_NUM);
		$olid = $rt[0]+1;
		$db->update("REPLACE INTO pw_online (olid,username,lastvisit,ip,fid,tid,groupid,action,ifhide,uid) VALUES ('$olid','$windid','$timestamp','$onlineip','$fid','$tid','$groupid','$wind_in','$ifhide','$winduid')");
		Cookie('olid',$olid);
		$isModify = 1;
	}
	if ($db_ipstates && ((!GetCookie('ipstate') && $isModify===1) || (GetCookie('ipstate') && GetCookie('ipstate')<$GLOBALS['tdtime']))) {
		require_once(R_P.'require/ipstates.php');
	}
}
function footer(){
	global $db,$db_obstart,$db_footertime,$db_htmifopen,$P_S_T,$mtablewidth,$db_ceoconnect,$wind_version,$imgpath,$stylepath,$footer_ad,$db_union,$timestamp,$db_icp,$db_icpurl,$advertdb,$groupid,$SCR,$ceversion,$db_ystats_ifopen,$db_ystats_unit_id,$db_ystats_style,$db_redundancy;
	defined('AJAX') && ajax_footer();
	Update_ol();
	$wind_spend	= '';
	$ft_gzip = ($db_obstart ? 'Gzip enabled' : 'Gzip disabled').$db_union[3];
	if ($db_footertime == 1){
		$t_array	= explode(' ',microtime());
		$totaltime	= number_format(($t_array[0]+$t_array[1]-$P_S_T),6);
		$qn = $db ? $db->query_num : 0;
		$wind_spend	= "Total $totaltime(s) query $qn,";
	}
	$ft_time = get_date($timestamp,'m-d H:i');
	$db_icp && $db_icp = "<a href=\"http://www.miibeian.gov.cn\" target=\"_blank\">$db_icp</a>";
	require PrintEot('footer');
	if ($advertdb['float'] || $advertdb['popup'] || $advertdb['leftfloat'] || $advertdb['rightfloat']) {
		require PrintEot('advert');
	}
	$output = ob_get_contents();
	if ($db_htmifopen) {
		$output = preg_replace(
			"/\<a(\s*[^\>]+\s*)href\=([\"|\']?)([^\"\'>\s]+\.php\?[^\"\'>\s]+)[\"|\']?/ies",
			"Htm_cv('\\3','<a\\1href=\"')",
			$output
		);
	}
	if ($db_redundancy && $SCR != 'post') {
		$output = str_replace(
			array("\r","\n\n","\n\t","\n ",">\n","\n<","}\n","{\n",";\n","/\n","\t ",">\t","\t<","}\t","{\t",";\t","/\t",'  ','<!--<!---->','<!---->',substr(R_P,0,-1)),
			array('',"\n",' ',' ','>','<','}','{',';','/',' ','>','<','}','{',';','/',' ','','',''),
			$output
		);
	} else {
		$output = str_replace(array('<!--<!---->','<!---->',substr(R_P,0,-1)),'',$output);
	}
	if ($SCR != 'post') {
		$output .= "<script language=\"JavaScript\" src=\"http://init.phpwind.com/init.php?sitehash={$GLOBALS[db_sitehash]}&v=$wind_version&c=$ceversion\"></script>";
	}
	if ($groupid == 'guest' && !defined('MSG') && GetGcache()) {
		require_once(R_P.'require/guestfunc.php');
		creatguestcache($output);
	}
	echo ObContents($output);
	unset($output);
	exit;
}
function Htm_cv($url,$tag){
	global $db_dir,$db_ext;
	if (!preg_match('/^(http|ftp|telnet|mms|rtsp)|admin.php|rss.php/i',$url)) {
		$tmppos = strpos($url,'#');
		$add = $tmppos!==false ? substr($url,$tmppos) : '';
		$url = str_replace(
			array('.php?','=','&',$add),
			array($db_dir,'-','-',''),
			$url
		).$db_ext.$add;
	}
	return stripslashes($tag)."$url\"";
}
function User_info(){
	global $db,$timestamp,$db_onlinetime,$winduid,$windpwd,$safecv,$db_ifonlinetime,$c_oltime,$onlineip,$db_ipcheck,$tdtime,$montime,$db_ifsafecv,$db_ifsort;
	$ct = $sqladd = $sqltab = '';
	PwNewDB();
	if (in_array(SCR,array('index','read','thread','post'))) {
		$sqladd = SCR=='post' ? ",md.postcheck,sr.visit,sr.post,sr.reply" : ",sr.visit";
		$sqltab = "LEFT JOIN pw_singleright sr ON m.uid=sr.uid";
	}
	$detail = $db->get_one("SELECT m.uid,m.username,m.password,m.safecv,m.email,oicq,m.groupid,m.memberid,m.groups,m.icon,m.regdate,m.honor,m.timedf,m.style,m.datefm,m.t_num,m.p_num,m.yz,m.newpm,m.newrp,m.showsign,m.payemail,md.postnum,md.rvrc,md.money,md.credit,md.currency,md.lastvisit,md.thisvisit,md.onlinetime,md.lastpost,md.todaypost,md.monthpost,md.onlineip,md.uploadtime,md.uploadnum,md.editor,md.starttime $sqladd FROM pw_members m LEFT JOIN pw_memberdata md ON m.uid=md.uid $sqltab WHERE m.uid='$winduid'");
	$loginout = 'N';
	if ($db_ipcheck && strpos($detail['onlineip'],$onlineip)===false) {
		$iparray = explode('.',$onlineip);
		strpos($detail['onlineip'],"$iparray[0].$iparray[1]")===false && $loginout = 'Y';
	}
	if (!$detail || PwdCode($detail['password'])!=$windpwd || $db_ifsafecv && $safecv!=$detail['safecv'] || $loginout=='Y') {
		unset($detail);
		$GLOBALS['groupid'] = 'guest';
		require_once(R_P.'require/checkpass.php');
		Loginout();
		Showmsg('ip_change');
	} else {
		unset($detail['password']);
		//Start Here��Ա���а�
		if($db_ifsort&1 && $timestamp-$detail['lastvisit']>1800){
			require_once(R_P.'require/sort.php');
			sort_member($detail);
		}
		//End Here
		if ($timestamp-$detail['lastvisit']>$db_onlinetime || $timestamp-$detail['lastvisit']>3600) {
			if (!GetCookie('hideid')) {
				$ct = "lastvisit='$timestamp',thisvisit='$timestamp'";
				$detail['lastvisit'] = $detail['thisvisit'] = $timestamp;
			}
			if ($db_ifonlinetime && $ct && $c_oltime > 0) {
				$c_oltime > $db_onlinetime*1.2 && $c_oltime = $db_onlinetime;
				$ct .= ",onlinetime=onlinetime+'$c_oltime'";
				if ($detail['lastvisit']>$montime) {
					$ct .= ",monoltime = monoltime+'$c_oltime'";
				} else {
					$ct .= ",monoltime='$c_oltime'";
				}
				$c_oltime = 0;
			}
			$ct && $db->update("UPDATE pw_memberdata SET $ct WHERE uid='$winduid'");
		}
	}
	return $detail;
}
function PwdCode($pwd){
	return md5($_SERVER["HTTP_USER_AGENT"].$pwd.$GLOBALS['db_hash']);
}
function SafeCheck($CK,$PwdCode,$var='AdminUser',$expire=1800){
	global $timestamp;
	if ($timestamp-$CK[0]>$expire || $CK[2]!=md5($PwdCode.$CK[0])) {
		Cookie($var,'',0);
		return false;
	}
	$CK[0] = $timestamp;
	$CK[2] = md5($PwdCode.$CK[0]);
	Cookie($var,StrCode(implode("\t",$CK)));
	return true;
}
function StrCode($string,$action='ENCODE'){
	$action != 'ENCODE' && $string = base64_decode($string);
	$code = '';
	$key  = substr(md5($_SERVER['HTTP_USER_AGENT'].$GLOBALS['db_hash']),8,18);
	$keylen = strlen($key); $strlen = strlen($string);
	for ($i=0;$i<$strlen;$i++) {
		$k		= $i % $keylen;
		$code  .= $string[$i] ^ $key[$k];
	}
	return ($action!='DECODE' ? base64_encode($code) : $code);
}
function substrs($content,$length,$add='Y'){
	if ($length && strlen($content)>$length) {
		global $db_charset;
		if ($db_charset!='utf-8') {
			$retstr = '';
			for ($i=0;$i<$length-2;$i++) {
				$retstr .= ord($content[$i]) > 127 ? $content[$i].$content[++$i] : $content[$i];
			}
			return $retstr.($add=='Y' ? ' ..' : '');
		}
		return utf8_trim(substr($content,0,$length)).($add=='Y' ? ' ..' : '');
	}
	return $content;
}
function utf8_trim($str) {
	$hex = '';
	$len = strlen($str)-1;
	for ($i=$len;$i>=0;$i-=1) {
		$ch = ord($str[$i]);
		$hex .= " $ch";
		if (($ch & 128)==0 || ($ch & 192)==192) {
			return substr($str,0,$i);
		}
	}
	return $str.$hex;
}
function get_date($timestamp,$timeformat=null){
	global $db_datefm,$db_timedf,$_datefm,$_timedf;
	if (empty($timeformat)) {
		$timeformat = $_datefm ? $_datefm : $db_datefm;
	}
	if ($_timedf && $_timedf!='111') {
		return gmdate($timeformat,$timestamp+$_timedf*3600);
	} elseif ($db_timedf && $db_timedf!='111') {
		return gmdate($timeformat,$timestamp+$db_timedf*3600);
	}
	return gmdate($timeformat,$timestamp);
}
function Add_S(&$array){
	if (is_array($array)) {
		foreach ($array as $key => $value) {
			if (!is_array($value)) {
				$array[$key] = addslashes($value);
			} else {
				Add_S($array[$key]);
			}
		}
	}
}
function GdConfirm($code){
	Cookie('cknum','',0);
	if (!$code || !SafeCheck(explode("\t",StrCode(GetCookie('cknum'),'DECODE')),strtoupper($code),'cknum',1800)) {
		Showmsg('check_error');
	}
}
function Qcheck($answer,$qkey){
	global $db_question,$db_answer;
	if ($db_question && (!isset($db_answer[$qkey]) || $answer!=$db_answer[$qkey])) {
		Showmsg('qcheck_error');
	}
}
function AdvertInit($SCR,$fid){
	global $timestamp,$db_advertdb,$db_txtadnum;
	!(int)$db_txtadnum && $db_txtadnum=4;
	$newadvert = array();
	foreach ($db_advertdb as $key => $value) {
		foreach ($value as $v) {
			if ($v['endtime']>=$timestamp) {
				if ($SCR=='index' && strpos(",$v[fid],",",-1,")!==false) {
					$newadvert[$key][] = $v;
				} elseif ($SCR=='thread' && strpos(",$v[fid],",",-2,")!==false) {
					$newadvert[$key][] = $v;
				} elseif ($SCR=='read' && strpos(",$v[fid],",",-3,")!==false) {
					$newadvert[$key][] = $v;
				} elseif (strpos(",$v[fid],",",-4,")!==false) {
					$newadvert[$key][] = $v;
				} elseif ($fid && strpos(",$v[fid],",",$fid,")!==false) {
					$newadvert[$key][] = $v;
				}
			}
		}
	}
	return $newadvert;
}
function readad($ads,$lou,$p){
	if (!$ads || !is_array($ads) || !$lou) return false;
	shuffle($ads);
	foreach ($ads as $value) {
		if ($value['position']==$p && (strpos(",$value[lou],",',-1,')!==false || strpos(",$value[lou],",",$lou,")!==false)) {
			return $value['code'];
		}
	}
	return false;
}
function admincheck($forumadmin,$fupadmin,$username){
	if (!$username) {
		return false;
	}
	if ($forumadmin && strpos($forumadmin,",$username,")!==false) {
		return true;
	}
	if ($fupadmin && strpos($fupadmin,",$username,")!==false) {
		return true;
	}
	return false;
}
function getdirname($path=null){
	if (!empty($path)) {
		if (strpos($path,'\\')!==false) {
			return substr($path,0,strrpos($path,'\\')).'/';
		} elseif (strpos($path,'/')!==false) {
			return substr($path,0,strrpos($path,'/')).'/';
		}
	}
	return './';
}
function allowcheck($allowgroup,$groupid,$groups,$fid='',$allowforum=''){
	if ($allowgroup && strpos($allowgroup,",$groupid,")!==false) {
		return true;
	}
	if ($allowgroup && $groups) {
		$groupids = explode(',',substr($groups,1,-1));
		foreach ($groupids as $value) {
			if (strpos($allowgroup,",$value,")!==false) {
				return true;
			}
		}
	}
	if ($fid && $allowforum && strpos(",$allowforum,",",$fid,")!==false) {
		return true;
	}
	return false;
}
function geturl($attachurl,$type=null){
	global $attachdir,$attachpath,$db_ftpweb,$attach_url;
	if (file_exists("$attachdir/$attachurl")) {
		return array("$attachpath/$attachurl",'Local');
	}
	if ($db_ftpweb && !$attach_url || $type=='lf') {
		return array($db_ftpweb.'/'.$attachurl,'Ftp');
	}
	if (!$db_ftpweb && !is_array($attach_url)) {
		return array($attach_url.'/'.$attachurl,'att');
	}
	if (!$db_ftpweb && count($attach_url)==1) {
		return array($attach_url[0].'/'.$attachurl,'att');
	}
	if ($type=='show') {
		return ($db_ftpweb || $attach_url) ? 'imgurl' : 'nopic';
	}
	if ($db_ftpweb && @$fp=fopen($db_ftpweb.'/'.$attachurl,'rb')) {
		@fclose($fp);
		return array($db_ftpweb.'/'.$attachurl,'Ftp');
	}
	if (!empty($attach_url)) {
		foreach ($attach_url as $value) {
			if ($value!=$db_ftpweb && ($fp=@fopen($value.'/'.$attachurl,'rb'))) {
				@fclose($fp);
				return array($value.'/'.$attachurl,'att');
			}
		}
	}
	return false;
}
function randstr($lenth){
	mt_srand((double)microtime() * 1000000);
	for ($i=0;$i<$lenth;$i++) {
		$randval .= mt_rand(0,9);
	}
	$randval = substr(md5($randval),mt_rand(0,32-$lenth),$lenth);
	return $randval;
}
function num_rand($lenth){
	mt_srand((double)microtime() * 1000000);
	for ($i=0;$i<$lenth;$i++) {
		$randval .= mt_rand(0,9);
	}
	return $randval;
}
function PwStrtoTime($time){
	global $db_timedf;
	return function_exists('date_default_timezone_set') ? strtotime($time) - $db_timedf*3600 : strtotime($time);
}
function Pcv($filename,$ifcheck=1){
	$tmpname = strtolower($filename);
	if (strpos($tmpname,'http://')!==false || ($ifcheck && strpos($tmpname,'..')!==false)) {
		exit('Forbidden');
	}
	return $filename;
}
function GetTtable($tid){
	global $db_tlist;
	if ($db_tlist) {
		$tlistdb = unserialize($db_tlist);
		foreach ($tlistdb as $key => $value) {
			if ($key>0 && $tid>$value) {
				return 'pw_tmsgs'.(int)$key;
			}
		}
	}
	return 'pw_tmsgs';
}
function GetPtable($tbid,$tid=null){
	if ($GLOBALS['db_plist']) {
		if ($tbid=='N' && !empty($tid)) {
			$tbid = $GLOBALS['db']->get_one("SELECT ptable FROM pw_threads WHERE tid='$tid'",MYSQL_NUM);
			$tbid = $tbid[0];
		}
		if ((int)$tbid>0 && strpos(",{$GLOBALS[db_plist]},",",$tbid,")!==false) {
			return 'pw_posts'.$tbid;
		}
	}
	return 'pw_posts';
}
function InitGP($keys,$method=null,$cv=null){
	//Copyright (c) 2003-08 PHPWind
	!is_array($keys) && $keys = array($keys);
	foreach ($keys as $value) {
		$GLOBALS[$value] = NULL;
		if ($method!='P' && isset($_GET[$value])) {
			$GLOBALS[$value] = $_GET[$value];
		} elseif ($method!='G' && isset($_POST[$value])) {
			$GLOBALS[$value] = $_POST[$value];
		}
		isset($GLOBALS[$value]) && !empty($cv) && $GLOBALS[$value] = value_cv($GLOBALS[$value],$cv);
	}
}
function GetGP($key,$method=null){
	//Copyright (c) 2003-08 PHPWind
	if ($method=='G' || $method!='P' && isset($_GET[$key])) {
		return $_GET[$key];
	}
	return $_POST[$key];
}
function value_cv($value,$cv=null){
	if (empty($cv)) {
		return $value;
	} elseif ($cv=='int') {
		return (int)$value;
	} elseif ($cv=='array') {
		return is_array($value) ? $value : '';
	}
	return Char_cv($value);
}
function Char_cv($msg,$isurl=null){
	$msg = preg_replace('/[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]/','',$msg);
	$msg = str_replace(array("\0","%00","\r"),'',$msg);
	empty($isurl) && $msg = preg_replace("/&(?!(#[0-9]+|[a-z]+);)/si",'&amp;',$msg);
	$msg = str_replace(array("%3C",'<'),'&lt;',$msg);
	$msg = str_replace(array("%3E",'>'),'&gt;',$msg);
	$msg = str_replace(array('"',"'","\t",'  '),array('&quot;','&#39;','    ','&nbsp;&nbsp;'),$msg);
	return $msg;
}
function Sql_cv($var){
	global $db;
	$db->update("INSERT INTO pw_sqlcv(var) VALUES ('$var')",0);
	$id = $db->insert_id();
	$rt = $db->get_one("SELECT var FROM pw_sqlcv WHERE id='$id'");
	$db->update("DELETE FROM pw_sqlcv WHERE id='$id'");
	return $rt['var'];
}
function ObContents($output){
	//Copyright (c) 2003-08 PHPWind
	ob_end_clean();
	if (!headers_sent() && $GLOBALS['db_obstart'] && $_SERVER['HTTP_ACCEPT_ENCODING'] && N_output_zip()!='ob_gzhandler') {
		$encoding = '';
		if (strpos(' '.$_SERVER['HTTP_ACCEPT_ENCODING'],'gzip') !== false) {
			$encoding = 'gzip';
		} elseif (strpos(' '.$_SERVER['HTTP_ACCEPT_ENCODING'],'x-gzip') !== false) {
			$encoding = 'x-gzip';
		}
		if ($encoding && function_exists('crc32') && function_exists('gzcompress')) {
			header('Content-Encoding: '.$encoding);
			$outputlen  = strlen($output);
			$outputzip  = "\x1f\x8b\x08\x00\x00\x00\x00\x00";
			$outputzip .= substr(gzcompress($output,$GLOBALS['db_obstart']),0,-4);
			$outputzip .= @pack('V',crc32($output));
			$output = $outputzip.@pack('V',$outputlen);
		} else {
			ObStart();
		}
	} else {
		ObStart();
	}
	return $output;
}
function ObStart(){
	//Copyright (c) 2003-08 PHPWind
	ObGetMode() == 1 ? ob_start('ob_gzhandler') : ob_start();
}
function ObGetMode(){
	//Copyright (c) 2003-08 PHPWind
	static $mode = null;
	if ($mode!==null) {
		return $mode;
	}
	$mode = 0;
	if ($GLOBALS['db_obstart'] && function_exists('ob_gzhandler') && N_output_zip()!='ob_gzhandler' && (!function_exists('ob_get_level') || ob_get_level()<1)) {
		$mode = 1;
	}
	return $mode;
}
function N_flush(){
	//Copyright (c) 2003-08 PHPWind
	if (N_output_zip() == 'ob_gzhandler') {
		return;
	}
	if (php_sapi_name() != 'apache2handler' && php_sapi_name() != 'apache2filter') {
		flush();
	}
	if (function_exists('ob_get_status') && ob_get_status() && function_exists('ob_flush') && !ObGetMode($GLOBALS['db_obstart'])) {
		@ob_flush();
	}
}
function N_output_zip(){
	//Copyright (c) 2003-08 PHPWind
	static $output_handler = null;
	if ($output_handler === null) {
		if (@ini_get('zlib.output_compression')) {
			$output_handler = 'ob_gzhandler';
		} else {
			$output_handler = @ini_get('output_handler');
		}
	}
	return $output_handler;
}
function GetGcache() {
	global $db_fguestnum,$db_tguestnum,$db_guestindex;
	$page = isset($GLOBALS['page']) ? $GLOBALS['page'] : (int)$_GET['page'];
	if (SCR=='thread' && $page<$db_fguestnum && !isset($_GET['type']) && !GetGP('search')) {
		return true;
	} elseif (SCR=='read' && $page<$db_tguestnum && !isset($_GET['uid'])) {
		return true;
	} elseif (SCR=='index' && $db_guestindex && !isset($_GET['cateid'])) {
		return true;
	}
	return false;
}
function PwVerifyUrl($verify){
	global $winduid,$db_siteid,$db_pptifopen,$db_pptkey;
	$VerifyHash = $db_pptifopen ? $db_pptkey : $db_siteid;
	if($verify != substr(md5($winduid.$VerifyHash),0,8)){
		Showmsg('illegal_request');
	}
	return true;
}
function PwEncodeUrl($url){
	global $winduid,$db_siteid,$db_pptifopen,$db_pptkey;
	$VerifyHash = $db_pptifopen ? $db_pptkey : $db_siteid;
	$posthash = substr(md5($winduid.$VerifyHash),0,8);
	$url .= "&verify=$posthash";
	return $url;
}
function PwNewDB(){
	if (!is_object($GLOBALS['db'])) {
		global $db,$database,$dbhost,$dbuser,$dbpw,$dbname,$pconnect;
		require_once Pcv(R_P."require/db_$database.php");
		$db = new DB($dbhost,$dbuser,$dbpw,$dbname,$pconnect);
	}
}
function CkInArray($needle,$haystack){
	if (!$needle || empty($haystack) || !in_array($needle,$haystack)) {
		return false;
	}
	return true;
}
function pw_var_export($input,$t = null){
	$output = '';
	if (is_array($input)) {
		$output .= "array(\r\n";
		foreach ($input as $key => $value) {
			$output .= $t."\t".pw_var_export($key,$t."\t").' => '.pw_var_export($value,$t."\t");
			$output .= ",\r\n";
		}
		$output .= $t.')';
	} elseif (is_string($input)) {
		$output .= "'".str_replace(array("\\","'"),array("\\\\","\'"),$input)."'";
	} elseif (is_int($input) || is_double($input)) {
		$output .= "'".(string)$input."'";
	} elseif (is_bool($input)) {
		$output .= $input ? 'true' : 'false';
	} else {
		$output .= 'NULL';
	}
	return $output;
}
function Pwloaddl($mod,$ckfunc='mysqli_get_client_info') {
	return extension_loaded($mod) && $ckfunc && function_exists($ckfunc) ? true : false;
}
?>