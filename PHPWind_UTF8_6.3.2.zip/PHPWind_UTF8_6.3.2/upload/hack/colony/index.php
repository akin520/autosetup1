<?php
!function_exists('readover') && exit('Forbidden');

include_once(D_P.'data/bbscache/cn_config.php');

$groupid != 3 && !$cn_open && Showmsg('colony_close');
!$winduid && Showmsg('not_login');
InitGP(array('job','action','cyid','page'));
$hk_name = $db_hackdb['colony'][0];
$cyid = (int)$cyid;
$pages = '';
$iscyer = $istruecyer = $ismanager = false;
$alldb = $admindb = $memberdb = array();
$settinga = array('view','set','member','joinlog','currency','currencylog','transfer','boardlist','addboard','readboard','editboard','delboard','topboard','delboardlist','honor','donate','donatelog','update','editmember','seemember','cancel');
$photoa = array('album','creatalbum','editalbum','delalbum','viewalbum','addphoto','editphoto','delphoto','viewphoto');
if ($cyid && in_array($job,array_merge(array('join','quit'),$settinga,$photoa))) {
	$select = $leftjoin = '';
	$sqladd = " cm.colonyid='".$cyid."'";
	if (in_array($job,array_merge($settinga,$photoa))) {
		$select = ',cm.username,cm.ifadmin';
		if ($job == 'member') {
			$select .= ',cm.realname,cm.gender,cm.tel,cm.email,md.thisvisit';
			$leftjoin = ' LEFT JOIN pw_memberdata md ON cm.uid=md.uid';
			//zhudong
			if($action == 'msearch'){
				InitGP(array('username','realname','gender'));
				if(strlen($username)>0){
					$sqladd .= ($sqladd ? ' AND' : '')." cm.username LIKE '%".str_replace('*','%',$username)."%'";
					$addpage .= "username=$username&";
				}
				if(strlen($realname)>0){
					$sqladd .= ($sqladd ? ' AND' : '')." cm.realname LIKE '%".str_replace('*','%',$realname)."%'";
					$addpage .= "realname=$realname&";
				}
				if($gender == 1 || $gender == 2){
					$sqladd .= ($sqladd ? ' AND' : '')." cm.gender='".$gender."'";
					$addpage .= "gender=$gender&";
				}
			}
			//end zhudong
		} elseif ($job == 'honor') {
			$select .= ',cm.honor';
		}
	}
	$query = $db->query("SELECT cm.uid$select,cy.classid,cy.cname,cy.admin,cy.cnimg,cy.annouce,cy.members,cy.albumopen,cy.albumnum,cy.intomoney,cy.createtime,cy.level,cy.ifcheck,cy.ifopen,cy.descrip,cy.cmoney,cy.tdtcontrol,cy.tviews,cy.allviews FROM pw_cmembers cm LEFT JOIN pw_colonys cy ON cm.colonyid=cy.id$leftjoin WHERE{$sqladd}");
	while ($rt = $db->fetch_array($query)) {
		$rt['createtime'] = get_date($rt['createtime'],'Y-m-d');
		$rt['tmpimg'] = $rt['cnimg'];
		if ($rt['cnimg']) {
			list($rt['cnimg'],$rt['tmpimgtype']) = geturl("cn_img/$rt[cnimg]",'lf');
		} else {
			$rt['cnimg'] = "$hkimg/nophoto.gif";
		}
		if (empty($alldb)) {
			foreach ($rt as $key => $value) {
				if (in_array($key,array('classid','cname','admin','cnimg','tmpimg','tmpimgtype','annouce','members','albumopen','albumnum','intomoney','createtime','level','ifcheck','ifopen','descrip','cmoney','tviews','allviews'))) {
					$alldb[$key] = $value;
				}
			}
		}
		$memberdb[] = $rt;
		$rt['admin'] == $windid && $ismanager = true;
		$rt['uid'] == $winduid && $iscyer = true;
		if ($rt['ifadmin']!=-1) {
			$rt['ifadmin']==1 && $admindb[$rt['uid']] = $rt['username'];
			$iscyer && $istruecyer = true;
		}
		$tdtcontrol = $rt['tdtcontrol'];
		$tviews = $rt['tviews'];
		$allviews = $rt['allviews'];
		if ($iscyer && !$select) break;
	}
	$db->free_result($query);
	empty($alldb) && Showmsg('colony_not_exists');
	if (!$alldb['ifopen'] && $groupid!=3 && !$iscyer && !in_array($job,array('join','viewphoto')) && !in_array($action,array('msearch'))) {
		Showmsg('colony_openlimit');
	}
	//zhudong ����ͳ��
	if(in_array($job,array('view'))){
		if($tdtcontrol == $tdtime){
			if(GetCookie('cyolip') != md5($onlineip)){
				$db->update("UPDATE pw_colonys SET tviews=tviews+1,allviews=allviews+1 WHERE id='$cyid'");
				Cookie('cyolip',md5($onlineip),$timestamp+$cn_visittime*60);
			}
		}else{
			$db->update("UPDATE pw_colonys SET tdtcontrol='$tdtime',tviews='' WHERE id='$cyid'");
		}
	}
	//end zhudong ����ͳ��
}
!$cyid && $job && !in_array($job,array('search','creat')) && Showmsg('undefined_action');

if (!$job || in_array($job,array('search','creat','join','quit'))) {
	require_once(H_P.'require/default.php');
} elseif (in_array($job,array_merge($settinga,$photoa))) {
	require_once(H_P.'require/home.php');
} else {
	Showmsg('undefined_action');
}
function getsmallurl($path){
	global $hkimg,$db_attachname;
	if (!$path) {
		return "$hkimg/nophoto.gif";
	}
	$usepath = "/$path";
	$usepath = $db_attachname.substr($usepath,0,strrpos($usepath,'/')+1).'s_'.substr($usepath,strrpos($usepath,'/')+1);
	!file_exists(R_P.$usepath) && list($usepath) = geturl($path);
	return $usepath;
}
?>