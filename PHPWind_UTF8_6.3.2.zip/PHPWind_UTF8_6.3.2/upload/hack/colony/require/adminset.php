<?php
!function_exists('readover') && exit('Forbidden');

!$admindb[$winduid] && $groupid!=3 && Showmsg('colony_nocheck');
if ($job == 'set') {
	!$admindb[$winduid] && $groupid!=3 && Showmsg('colony_adminright');
	if ($_POST['step']!=2) {
		require_once PrintHack('home');
		@include_once(D_P.'data/bbscache/cn_class.php');
		$options = '';
		if (is_array($cnclassdb)) {
			foreach ($cnclassdb as $key => $value) {
				$select = ($key == $alldb['classid']) ? 'SELECTED' : '';
				$options .= "<option value=\"$key\" $select>$value[cname]</option>";
			}
		}
		ifcheck(array('ifcheck' => $alldb['ifcheck'],'ifopen' => $alldb['ifopen'],'albumopen' => $alldb['albumopen']));
	} else {
		InitGP(array('cname','attachment','annouce','descrip'),'P',1);
		!$cname && Showmsg('colony_emptyname');
		strlen($cname) > 20 && Showmsg('colony_cnamelimit');
		(!$descrip || strlen($descrip) > 255) && Showmsg('colony_descriplimit');
		strlen($annouce) > 255 && Showmsg('colony_annoucelimit');
		if ($alldb['cname'] != $cname){
			$rt = $db->get_one("SELECT id FROM pw_colonys WHERE cname='$cname'");
			$rt['id'] && Showmsg('colony_samename');
		}
		InitGP(array('classid','ifcheck','ifopen','albumopen','intomoney'),'P');
		$classid = (int)$classid;
		$ifcheck = (int)$ifcheck;
		$ifopen = (int)$ifopen;
		$albumopen = (int)$albumopen;
		(int)$intomoney < 0 && $intomoney = 0;
		if($cn_joinmoney && $intomoney < $cn_joinmoney){
			$intomoney = $cn_joinmoney;
		}
		require_once(R_P.'require/postfunc.php');
		!$cn_imgsize && $cn_imgsize = 100;
		$db_uploadfiletype = array();
		$db_uploadfiletype['gif'] = $db_uploadfiletype['jpg'] = $db_uploadfiletype['jpeg'] = $db_uploadfiletype['bmp'] = $db_uploadfiletype['png'] = $cn_imgsize;
		$ftp = null;
		if ($db_ifftp) {
			require_once(R_P.'require/ftp.php');
			$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
		}
		$uploaddb = UploadFile($cyid,'cnlogo');
		if ($ftp) {
			$ftp->close(); unset($ftp);
		}
		$cnimg = $uploaddb[0]['attachurl'] ? ",cnimg='".substr(strrchr($uploaddb[0]['attachurl'],'/'),1)."'" : '';
		$db->update("UPDATE pw_colonys SET cname='$cname',classid='$classid',ifcheck='$ifcheck',albumopen='$albumopen' $cnimg,intomoney='$intomoney',annouce='$annouce',ifopen='$ifopen',descrip='$descrip' WHERE id='$cyid'");
		refreshto("$basename&cyid=$cyid&job=view",'colony_setsuccess');
	}
} elseif ($job=='joinlog') {
	!$admindb[$winduid] && $groupid!=3 && Showmsg('colony_adminright');
	require_once PrintHack('home');
	(int)$page < 1 && $page = 1;
	$pageid = ($page-1)*$db_perpage;
	$limit = "LIMIT $pageid,$db_perpage";
	$logdb = array();
	$query = $db->query("SELECT username1,username2,timestamp,descrip FROM pw_forumlog WHERE field2='$cyid' AND type='cy_join' ORDER BY id DESC $limit");
	while ($rt = $db->fetch_array($query)) {
		$rt['timestamp'] = get_date($rt['timestamp']);
		$rt['descrip'] = str_replace(array('[b]','[/b]'),array('<b>','</b>'),$rt['descrip']);
		$logdb[] = $rt;
	}
	$db->free_result($query);
	@extract($db->get_one("SELECT COUNT(*) AS count FROM pw_forumlog WHERE field2='$cyid' AND type='cy_join'"));
	if ($count > $db_perpage) {
		require_once(R_P.'require/forum.php');
		$pages = numofpage($count,$page,ceil($count/$db_perpage),"$basename&cyid=$cyid&job=joinlog&");
	}
} elseif ($job=='currency') {
	$windid != $alldb['admin']  && Showmsg('colony_currency_right');
	!$cn_virement && Showmsg('colony_currency');
	if ($_POST['step'] != 2) {
		require_once PrintHack('home');
	} else {
		InitGP(array('pwuser','pwpwd','currency'));
		@extract($db->get_one("SELECT uid as touid FROM pw_cmembers WHERE colonyid='$cyid' AND username='$pwuser'"));
		!$touid && Showmsg('no_colony_member');
		(!is_numeric($currency) || $currency < 0) && Showmsg('illegal_nums');
		if ($pwpwd) {
			$rt = $db->get_one("SELECT password FROM pw_members WHERE uid='$winduid'");
			$rt['password'] != md5($pwpwd) && Showmsg('password_error');
		} else {
			Showmsg('empty_password');
		}
		$tax = round($currency*$cn_rate/100);
		$needcurrency = $currency + $tax;
		$alldb['cmoney'] < $needcurrency && Showmsg('colony_noenough_currency');
		$db->update("UPDATE pw_colonys SET cmoney=cmoney-'$needcurrency' WHERE id='$cyid'");
		if (in_array($cn_moneytype,array('money','rvrc','credit','currency'))) {
			$currencys = $cn_moneytype == 'rvrc' ? $currency*10 : $currency;
			$db->update("UPDATE pw_memberdata SET $cn_moneytype=$cn_moneytype+'$currencys' WHERE uid='$touid'");
		} elseif (is_numeric($cn_moneytype) && isset($_CREDITDB[$cn_moneytype])) {
			$db->update("UPDATE pw_membercredit SET value=value+'$currency' WHERE uid='$touid' AND cid='$cn_moneytype'");
		}
		if ($cn_moneytype == 'currency') {
			require_once(R_P.'require/tool.php');
			$logdata = array(
				'type'		=>	'vire',
				'nums'		=>	0,
				'money'		=>	0,
				'descrip'	=>	'cyvire_descrip',
				'uid'		=>	$winduid,
				'username'	=>	$windid,
				'ip'		=>	$onlineip,
				'time'		=>	$timestamp,
				'currency'	=>	$currency,
				'toname'	=>	$pwuser,
				'tax'		=>	$tax
			);
			writetoollog($logdata);
		}
		$log = array(
			'type'      => 'cy_vire',
			'username1' => Char_cv($pwuser),
			'username2' => Char_cv($windid),
			'field1'    => $currency,
			'field2'    => $cyid,
			'field3'    => Char_cv($alldb['cname']),
			'timestamp' => $timestamp,
			'ip'        => $onlineip,
			'cname'		=> $alldb['cname'],
			'tax'		=> $tax
		);
		require GetLang('log');
		$log['descrip'] = Char_cv($lang['cy_vire_descrip']);
		$db->update("INSERT INTO pw_forumlog (type,username1,username2,field1,field2,field3,descrip,timestamp,ip) VALUES('$log[type]','$log[username1]','$log[username2]','$log[field1]','$log[field2]','$log[field3]','$log[descrip]','$log[timestamp]','$log[ip]')");
		require_once(R_P.'require/msg.php');
		writenewmsg(array($pwuser,$winduid,'cyvire_title',$timestamp,'cyvire_content','',$windid),1);
		Showmsg('virement_success');
	}
} elseif ($job=='currencylog') {
	require_once PrintHack('home');
	@extract($db->get_one("SELECT COUNT(*) AS count FROM pw_forumlog WHERE field2='$cyid' AND type='cy_vire'"));
	if ($count > $db_perpage) {
		(int)$page < 1 && $page = 1;
		require_once(R_P.'require/forum.php');
		$pages = numofpage($count,$page,ceil($count/$db_perpage),"$basename&job=donatelog&cyid=$cyid&");
	} else {
		$page = 1;
	}
	$logdb = array();
	$query = $db->query("SELECT username1,username2,descrip,timestamp FROM pw_forumlog WHERE field2='$cyid' AND type='cy_vire' ORDER BY id DESC LIMIT ".($page-1)*$db_perpage.",$db_perpage");
	while ($rt = $db->fetch_array($query)) {
		$rt['timestamp'] = get_date($rt['timestamp'],"Y-m-d H:i");
		$rt['descrip'] = str_replace(array('[b]','[/b]'),array('<b>','</b>'),$rt['descrip']);
		$logdb[] = $rt;
	}
	$db->free_result($query);
} elseif ($job=='update') {
	$alldb['level']>0 && Showmsg('colony_update');
	if ($_POST['step']!=2) {
		require_once PrintHack('home');
	} else {
		$alldb['cmoney'] < $cn_updatemoney && Showmsg('colony_updatemoney');
		$db->update("UPDATE pw_colonys SET level=1,cmoney=cmoney-'$cn_updatemoney' WHERE id='$cyid'");
		refreshto("$basename&job=view&cyid=$cyid",'operate_success');
	}
} elseif ($job=='cancel') {
	!$cn_remove && Showmsg('colony_cancelclose');
	if($alldb['admin']!=$windid){
		Showmsg('colony_cancel');
	} else {
		$alldb['members']>1 && Showmsg('colony_del_members');
		@extract($db->get_one("SELECT COUNT(*) as count FROM pw_cnalbum WHERE cyid='$cyid'"));
		$count > 0 && Showmsg('colony_del_photo');
	}
	if ($db_ifftp && $alldb['tmpimgtype'] == 'Ftp') {
		require_once(R_P.'require/ftp.php');
		$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
		$ftp->delete("cn_img/$alldb[tmpimg]");
		$ftp->close();
	} else {
		P_unlink("$attachdir/cn_img/$alldb[tmpimg]");
	}
	$db->update("DELETE FROM pw_cmembers WHERE colonyid='$cyid'");
	$db->update("DELETE FROM pw_colonys WHERE id='$cyid'");
	$db->update("UPDATE pw_cnclass SET cnsum=cnsum-1 WHERE cid='$alldb[classid]' AND cnsum>0");
	updatecache_cnc();
	refreshto($basename,'colony_cancelsuccess');
} elseif ($job == 'transfer'){
	require_once(R_P.'require/credit.php');
	$windid != $alldb['admin'] && Showmsg('colony_adminright');
	$moneyname = CreditName($cn_moneytype);
	$cn_transfer > UserCredit($winduid,$cn_moneytype) && Showmsg('colony_transferfailed');
	if ($_POST['step'] != 2){
		require_once PrintHack('home');
	} else {
		InitGP(array('username','ttype'));
		$ismanager == false && Showmsg('colony_transferright');
		empty($username) && Showmsg('colony_username_empty');
		$username == $windid && Showmsg('colony_transfer_same');
		if($username){
			$rt = $db->get_one("SELECT uid FROM pw_members WHERE username='$username'");
			if(!$rt){
				$errorname = Char_cv($pwuser);
				Showmsg('user_not_exists');
			}
		}
		$ck_in_colony = $db->get_value("SELECT uid FROM pw_cmembers WHERE username='$username' AND colonyid='$cyid'");
		empty($ck_in_colony) && Showmsg('colony_user_notin');
		UserCredit($winduid,$cn_moneytype,'set',"-$cn_transfer");
		$db->update("UPDATE pw_colonys SET admin='$username',iftransfer='1' WHERE id='$cyid'");
		if($ttype == '2'){
			$db->update("UPDATE pw_cmembers SET ifadmin='0' WHERE colonyid='$cyid' AND uid='$winduid'");
		}elseif($ttype == '3'){
			$db->update("UPDATE pw_colonys SET members=members-1 WHERE id='$cyid'");
			$db->update("DELETE FROM pw_cmembers WHERE colonyid='$cyid' AND uid='$winduid'");
		}
		$db->update("UPDATE pw_cmembers SET ifadmin='1' WHERE colonyid='$cyid' AND username='$username'");
		refreshto("$basename&job=view&cyid=$cyid",'operate_success');
	}
}
function ifcheck($array,$yn = 'Y_N'){
	!is_array($array) && adminmsg('undefined_actions');
	list($y,$n) = explode('_',$yn);
	foreach ($array as $key => $value) {
		global ${$key.'_'.$y},${$key.'_'.$n};
		if ($value) {
			${$key.'_'.$y} = 'CHECKED';
			${$key.'_'.$n} = '';
		} else {
			${$key.'_'.$y} = '';
			${$key.'_'.$n} = 'CHECKED';
		}
	}
}

function updatecache_cnc(){
	global $db;
	$cnclassdb = array();
	$query = $db->query('SELECT cid,cname,cnsum FROM pw_cnclass ORDER BY cid');
	while ($rt = $db->fetch_array($query)) {
		$cnclassdb[$rt['cid']] = array('cname' => $rt['cname'],'cnsum' => $rt['cnsum']);
	}
	writeover(D_P."data/bbscache/cn_class.php","<?php\r\n\$cnclassdb=".pw_var_export($cnclassdb).";\r\n?>");
}
?>