<?php
!function_exists('readover') && exit('Forbidden');

@include_once(D_P.'data/bbscache/cn_class.php');

if (!$job) {
	(int)$page < 1 && $page = 1;
	$query = $db->query("SELECT colonyid,ifadmin FROM pw_cmembers WHERE uid='$winduid'");
	while ($rt = $db->fetch_array($query,MYSQL_NUM)) {
		if ($rt[1]!=-1) {
			$passids .= ",'$rt[0]'";
		} else {
			$unpassids .= ",'$rt[0]'";
		}
	}
	$db->free_result($query);
	$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
	$passids && $passids = substr($passids,1);
	$unpassids && $unpassids = substr($unpassids,1);
	$query = $db->query("SELECT id,cnimg,cname,descrip,admin,members,level,ifcheck,ifopen,createtime,tviews,allviews FROM pw_colonys c ORDER BY createtime DESC $limit");
	while($rt = $db->fetch_array($query)){
		$rt['createtime'] = get_date($rt['createtime'],'Y-m-d');
		if ($unpassids && strpos($unpassids,"'$rt[id]'")!==false) {
			$rt['stat'] = 3;
		} elseif ($passids && strpos($passids,"'$rt[id]'")!==false) {
			$rt['stat'] = 2;
		} elseif ($rt['ifcheck']) {
			$rt['stat'] = 1;
		} else {
			$rt['stat'] = 0;
		}
		$rt['cnimg'] && list($rt['cnimg']) = geturl("cn_img/$rt[cnimg]",'lf');
		$colonydb[] = $rt;
	}
	$db->free_result($query);
	if ($db_perpage) {
		@extract($db->get_one("SELECT COUNT(*) AS count FROM pw_colonys"));
		if ($count > $db_perpage) {
			require_once(R_P.'require/forum.php');
			$numofpage = ceil($count/$db_perpage);
			$pages = numofpage($count,$page,$numofpage,"$basename&job=search&$addpages");
		}
	}
} elseif ($job == 'search') {
	InitGP(array('cid','type','keyword'));
	$addpages = $passids = $unpassids = '';
	(int)$page < 1 && $page = 1;
	$sql = '1';
	$query = $db->query("SELECT colonyid,ifadmin FROM pw_cmembers WHERE uid='$winduid'");
	while ($rt = $db->fetch_array($query,MYSQL_NUM)) {
		if ($rt[1]!=-1) {
			$passids .= ",'$rt[0]'";
		} else {
			$unpassids .= ",'$rt[0]'";
		}
	}
	$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
	$order = 'ORDER BY level DESC,createtime DESC';
	$passids && $passids = substr($passids,1);
	$unpassids && $unpassids = substr($unpassids,1);
	if ($type=='pass' || $type=='unpass') {
		$typeids = ${$type.'ids'};
		!$typeids && Showmsg('colony_unjoin');
		$addpages = "type=$type&";
		$sql = "id IN ($typeids)";
	} elseif ($type == 'money') {
		$addpages = "type=$type&";
		$order = 'ORDER BY cmoney DESC';
		$limit = 'LIMIT 10';
		$db_perpage = 0;
	} elseif ($type == 'member') {
		$addpages = "type=$type&";
		$order = 'ORDER BY members DESC';
		$limit = 'LIMIT 10';
		$db_perpage = 0;
	} elseif ($keyword) {
		$sql = "cname LIKE '%$keyword%'";
	}
	if ((int)$cid > 0) {
		$addpages .= "cid=$cid&";
		$sql .= " AND classid='$cid'";
	}
	$query = $db->query("SELECT id,cnimg,cname,descrip,admin,members,level,ifcheck,ifopen,createtime,tviews,allviews FROM pw_colonys c WHERE $sql $order $limit");
	while($rt = $db->fetch_array($query)){
		$rt['createtime'] = get_date($rt['createtime'],'Y-m-d');
		if ($unpassids && strpos($unpassids,"'$rt[id]'")!==false) {
			$rt['stat'] = 3;
		} elseif ($passids && strpos($passids,"'$rt[id]'")!==false) {
			$rt['stat'] = 2;
		} elseif ($rt['ifcheck']) {
			$rt['stat'] = 1;
		} else {
			$rt['stat'] = 0;
		}
		$rt['cnimg'] && list($rt['cnimg']) = geturl("cn_img/$rt[cnimg]",'lf');
		$colonydb[] = $rt;
	}
	$db->free_result($query);
	if ($db_perpage) {
		@extract($db->get_one("SELECT COUNT(*) AS count FROM pw_colonys WHERE $sql"));
		if ($count > $db_perpage) {
			require_once(R_P.'require/forum.php');
			$numofpage = ceil($count/$db_perpage);
			$pages = numofpage($count,$page,$numofpage,"$basename&job=search&$addpages");
		}
	}
} elseif ($job=='creat') {
	require_once(R_P.'require/credit.php');
	!$cn_newcolony && Showmsg('colony_reglimit');
	strpos($cn_groups,",$groupid,")===false && Showmsg('colony_groupright');
	$moneyname = CreditName($cn_moneytype);
	$cn_createmoney > UserCredit($winduid,$cn_moneytype) && Showmsg('colony_creatfailed');
	if ($_POST['step'] == 2) {
		if ($cn_allowcreate) {
			$rt = $db->get_one("SELECT COUNT(*) AS count FROM pw_colonys WHERE admin='$windid'");
			$rt['count'] >= $cn_allowcreate && Showmsg('colony_numlimit');
		}
		InitGP(array('newname','newdescrip','newclass'),'P',1);
		!$newname && Showmsg('colony_emptyname');
		(!$newdescrip || strlen($newdescrip) > 255) && Showmsg('colony_descrip');
		$newclass = (int)$newclass;
		!$newclass && Showmsg('colony_class');
		$rt = $db->get_one("SELECT id FROM pw_colonys WHERE cname='$newname'");
		$rt['id'] > 0 && Showmsg('colony_samename');
		UserCredit($winduid,$cn_moneytype,'set',"-$cn_createmoney");
		$db->update("INSERT INTO pw_colonys(cname,classid,admin,members,ifcheck,cmoney,createtime,intomoney,descrip) VALUES('$newname','$newclass','".addslashes($windid)."','1','1','$cn_createmoney','$timestamp','$cn_joinmoney','$newdescrip')");
		$cid = $db->insert_id();
		$db->update("INSERT INTO pw_cmembers(uid,username,ifadmin,colonyid) VALUES('$winduid','".addslashes($windid)."','1','$cid')");
		$db->update("UPDATE pw_cnclass SET cnsum=cnsum+1 WHERE cid='$newclass'");
		require_once(R_P.'require/tool.php');
		$logdata = array(
			'type'		=>	'colony',
			'nums'		=>	0,
			'money'		=>	0,
			'descrip'	=>	'colony_descrip',
			'uid'		=>	$winduid,
			'username'	=>	$windid,
			'ip'		=>	$onlineip,
			'time'		=>	$timestamp,
			'currency'	=>	$cn_createmoney,
			'cname'	=>	$newname
		);
		writetoollog($logdata);
		updatecache_cnc();
		refreshto("$basename&cyid=$cid&job=set",'colony_regsuccess');
	}
} elseif ($job=='join') {
	$iscyer && Showmsg('colony_alreadyjoin');
	$cn_memberfull = (int)$cn_memberfull;
	$cn_memberfull_a = (int)$cn_memberfull_a;
	if ($alldb['level']) {
		$cn_memberfull = $cn_memberfull_a;
	}
	$cn_memberfull && $alldb['members'] >= $cn_memberfull && Showmsg('colony_memberlimit');
	!$alldb['ifcheck'] && Showmsg('colony_joinrefuse');
	(int)$alldb['intomoney'] < 0 && Showmsg('numerics_checkfailed');
	$cn_joinmoney && !$alldb['intomoney'] && $alldb['intomoney'] = $cn_joinmoney;
	if ($alldb['intomoney']) {
		require_once(R_P.'require/credit.php');
		$moneyname = CreditName($cn_moneytype);
		$alldb['intomoney'] > UserCredit($winduid,$cn_moneytype) && Showmsg('colony_joinfail');
	}
	if ($cn_allowjoin) {
		$rt = $db->get_one("SELECT COUNT(*) as sum FROM pw_cmembers WHERE uid='$winduid'");
		$rt['sum'] >=  $cn_allowjoin && Showmsg('colony_joinlimit');
	}
	if ($_POST['step'] != 2) {
		require_once PrintHack('default');footer();
	} else {
		InitGP(array('realname','tel','email','introduce','gender'),'P',1);
		!$realname && Showmsg('colony_realname');
		strlen($realname) > 20 && Showmsg('realname_limit');
		strlen($tel) > 15 && Showmsg('tel_limit');
		strlen($introduce) > 255 && Showmsg('intro_limit');
		$rt = $db->get_one("SELECT realname FROM pw_cmembers WHERE colonyid='$cyid'");
		$rt['realname']==$realname && Showmsg('colony_samerealname');
		$gender = (int)$gender;
		$db->update("INSERT INTO pw_cmembers SET uid='$winduid',username='".addslashes($windid)."', realname='$realname',ifadmin='-1',gender='$gender',tel='$tel',email='$email',introduce='$introduce',colonyid='$cyid'");
		$db->update("UPDATE pw_colonys SET members=members+1 WHERE id='$cyid'");
		refreshto("$basename&cyid=$cyid",'colony_joinsuccess');
	}
} elseif ($job=='quit') {
	$ismanager && Showmsg('colony_quitfail');
	!$iscyer && Showmsg('undefined_action');
	$db->update("UPDATE pw_colonys SET members=members-1 WHERE id='$cyid'");
	$db->update("DELETE FROM pw_cmembers WHERE colonyid='$cyid' AND uid='$winduid'");
	refreshto($basename,'colony_quitsuccess');
}
require_once PrintHack('default');footer();

function updatecache_cnc(){
	global $db;
	$cnclassdb = array();
	$query = $db->query('SELECT cid,cname,cnsum FROM pw_cnclass ORDER BY cid');
	while ($rt = $db->fetch_array($query)) {
		$cnclassdb[$rt['cid']] = array('cname' => $rt['cname'],'cnsum' => $rt['cnsum']);
	}
	writeover(D_P."data/bbscache/cn_class.php","<?php\r\n\$cnclassdb=".pw_var_export($cnclassdb).";\r\n?>");
}
?>