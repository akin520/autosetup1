<?php
!function_exists('readover') && exit('Forbidden');

require_once(R_P.'require/credit.php');
$cn_albumnum = (int)$cn_albumnum;
$cn_memberfull = (int)$cn_memberfull;
$cn_albumnum_a = (int)$cn_albumnum_a;
$cn_memberfull_a = (int)$cn_memberfull_a;
if ($alldb['level']) {
	$cn_albumnum = $cn_albumnum_a;
	$cn_memberfull = $cn_memberfull_a;
}
list($moneyname,$moneyunit) = GetCreditValue($cn_moneytype);
if ($job != 'member' && $job != 'view' && $job != 'honor') {
	unset($memberdb);
}

if ($job == 'view') {
	require_once(H_P.'require/view.php');
} elseif (in_array($job,$photoa)) {
	require_once(H_P.'require/photo.php');
} else {
	if ($groupid!=3 && (!$iscyer || ($job != 'editmember' && !$istruecyer)) && !in_array($action,array('msearch'))) {
		Showmsg('colony_nocheck');
	}
	if ($admindb[$winduid] || $groupid==3) {
		require_once(H_P.'require/adminset.php');
	}
	require_once(H_P.'require/setting.php');
}
footer();
?>