<?php
!function_exists('readover') && exit('Forbidden');

!$cn_phopen && Showmsg('colony_phopen');
!in_array($job,array('album','viewalbum','viewphoto')) && !$istruecyer && Showmsg('colony_nocheck');
if ($job=='album') {
	if(!$alldb['albumopen'] && !$istruecyer && $groupid!=3){
		Showmsg('colony_opentocn');
	}
	require_once PrintHack('home');
	(int)$page < 1 && $page = 1;
	@extract($db->get_one("SELECT COUNT(*) AS count FROM pw_cnalbum WHERE cyid='$cyid'"));
	if ($count > $db_perpage) {
		require_once(R_P.'require/forum.php');
		$pages = numofpage($count,$page,ceil($count/$db_perpage),"$basename&job=album&cyid=$cyid&");
	} else {
		$page = 1;
	}
	$albumdb = array();
	$query = $db->query("SELECT aid,aname,atype,uid,username,photonum,lastphoto,crtime FROM pw_cnalbum WHERE cyid='$cyid' ORDER BY crtime DESC LIMIT ".($page-1)*$db_perpage.",$db_perpage");
	while ($rt = $db->fetch_array($query)) {
		$rt['aname'] = substrs($rt['aname'],15);
		$rt['lastphoto'] = getsmallurl($rt['lastphoto']);
		$rt['crtime'] = get_date($rt['crtime'],'Y-m-d');
		$albumdb[] = $rt;
	}
	$db->free_result($query);
} elseif ($job=='creatalbum') {
	if ($_POST['step']!=2) {
		require_once PrintHack('home');
		$disable = !$admindb[$winduid] ? 'disabled' : '';
		$check_2 = 'CHECKED';
	} else {
		InitGP(array('aname','aintro','atype'),'P');
		!$aname && Showmsg('colony_aname_empty');
		$atype = (int)$atype;
		if ($atype==1) {
			!$admindb[$winduid] && Showmsg('colony_pubalbum');
			$alldb['cmoney']<$cn_camoney && Showmsg('colony_moneylimit');
			$rt = $db->get_one("SELECT albumnum FROM pw_colonys WHERE id='$cyid'");
			$rt['albumnum'] >= $cn_albumnum && Showmsg('colony_album_num');
			$db->update("UPDATE pw_colonys SET cmoney=cmoney-'$cn_camoney' WHERE id='$cyid'");
		} else {
			$rt = $db->get_one("SELECT COUNT(*) AS count FROM pw_cnalbum WHERE uid='$winduid' AND atype>1");
			$rt['count']>=$cn_albumnum2 && Showmsg('colony_album_num2');
			$cn_camoney > UserCredit($winduid,$cn_moneytype) && Showmsg('colony_moneylimit2');
			if (in_array($cn_moneytype,array('money','rvrc','credit','currency'))) {
				$cn_moneytype == 'rvrc' && $cn_camoney *= 10;
				$db->update("UPDATE pw_memberdata SET $cn_moneytype=$cn_moneytype-'$cn_camoney' WHERE uid='$winduid'");
			} elseif (is_numeric($cn_moneytype) && isset($_CREDITDB[$cn_moneytype])) {
				$db->update("UPDATE pw_membercredit SET value=value-'$cn_camoney' WHERE uid='$winduid' AND cid='$cn_moneytype'");
			}
		}
		$aname = Char_cv($aname);
		$aintro = Char_cv($aintro);
		$db->update("INSERT INTO pw_cnalbum(aname,aintro,atype,cyid,uid,username,crtime) VALUES('$aname','$aintro','$atype','$cyid','$winduid','$windid','$timestamp')");
		$db->update("UPDATE pw_colonys SET albumnum=albumnum+1 WHERE id='$cyid'");
		refreshto("$basename&job=album&cyid=$cyid",'operate_success');
	}
} elseif ($job=='editalbum') {
	@extract($db->get_one("SELECT aid,aname,aintro,atype,uid FROM pw_cnalbum WHERE aid='".GetGP('aid')."'"));
	!$aid && Showmsg("data_error");
	if ($atype==1 && !$admindb[$winduid] && $groupid!=3) {
		Showmsg('mawhole_right');
	} elseif (!$admindb[$winduid] && $groupid!=3 && $winduid!=$uid) {
		Showmsg('mawhole_right');
	}
	if ($_POST['step']!=2) {
		require_once PrintHack('home');
		$disable = !$admindb[$winduid] ? 'disabled' : '';
		${'check_'.$atype} = 'CHECKED';
	} else {
		InitGP(array('aname','aintro','atype'),'P');
		!$aname && Showmsg('colony_aname_empty');
		require_once PrintHack('home');
		$atype==1 && !$admindb[$winduid] && Showmsg('colony_pubalbum');
		$atype = (int)$atype;
		$aname = Char_cv($aname);
		$aintro = Char_cv($aintro);
		$db->update("UPDATE pw_cnalbum SET aname='$aname',aintro='$aintro',atype='$atype' WHERE aid='$aid'");
		refreshto("$basename&cyid=$cyid&job=viewalbum&aid=$aid",'operate_success');
	}
} elseif ($job=='delalbum') {//noizy
	$aid = GetGP('aid');
	if ($_POST['step']!=2) {
		require_once PrintHack('home');
		@extract($db->get_one("SELECT aname FROM pw_cnalbum WHERE aid='$aid'"));
	} else {
		@extract($db->get_one("SELECT photonum,uid FROM pw_cnalbum WHERE aid='$aid'"));
		!$uid && Showmsg('data_error');
		!$admindb[$winduid] && $winduid!=$uid && $groupid!=3 && Showmsg('mawhole_right');
		$photonum>0 && Showmsg('colony_photonum');
		$db->update("DELETE FROM pw_cnalbum WHERE aid='$aid'");
		$db->update("UPDATE pw_colonys SET albumnum=albumnum-1 WHERE id='$cyid'");
		refreshto("$basename&cyid=$cyid&job=album",'operate_success');
	}
} elseif ($job=='viewalbum') {
	$aid = GetGP('aid','G');
	$albumdb = $db->get_one("SELECT aname,aintro,atype,uid,username,photonum,crtime FROM pw_cnalbum WHERE aid='$aid'");
	!$albumdb['aname'] && Showmsg('data_error');
	if ($albumdb['atype']==1 && !$alldb['albumopen'] && !$istruecyer && $groupid!=3) {
		Showmsg('colony_opentocn');
	} elseif ($albumdb['atype']==2 && !$istruecyer && $groupid!=3) {
		Showmsg('colony_nocheck');
	} elseif ($albumdb['atype']==3 && $winduid!=$albumdb['uid'] && $groupid!=3) {
		Showmsg('colony_opentome');
	}
	require_once PrintHack('home');
	$albumdb['crtime'] = get_date($albumdb['crtime'],'Y-m-d');
	(int)$page < 1 && $page = 1;
	if ($albumdb['photonum'] > $db_perpage) {
		require_once(R_P.'require/forum.php');
		$pages = numofpage($albumdb['photonum'],$page,ceil($albumdb['photonum']/$db_perpage),"$basename&job=viewalbum&cyid=$cyid&aid=$aid&");
	} else {
		$page = 1;
	}
	$photos = array();
	$query = $db->query("SELECT pid,pname,path,uploader,uptime FROM pw_cnphoto WHERE aid='$aid' ORDER BY uptime DESC LIMIT ".($page-1)*$db_perpage.",$db_perpage");
	while ($rt = $db->fetch_array($query)) {
		$rt['pname'] = substrs($photodb['pname'],15);
		$rt['path'] = getsmallurl($rt['path']);
		$rt['uptime'] = get_date($rt['uptime'],'Y-m-d');
		$photos[] = $rt;
	}
	$db->free_result($query);
} elseif ($job=='addphoto') {
	$aid = GetGP('aid');
	$pid = 0;
	if ($_POST['step']!=2) {
		$albumselect = $pname = $pintro = '';
		$query = $db->query("SELECT aid,aname,uid,atype FROM pw_cnalbum WHERE cyid='$cyid'");
		while ($rt = $db->fetch_array($query)) {
			if ($rt['uid']==$winduid || $rt['atype']==1 || $groupid==3) {
				$selected = '';
				if ($aid == $rt['aid']) {
					$aname = $rt['aname'];
					$selected = 'selected';
				}
				$albumselect .= "<option value=\"$rt[aid]\" $selected>$rt[aname]</option>";
			}
		}
		$db->free_result($query);
		!$albumselect && Showmsg('colony_unfined');
		require_once PrintHack('home');
	} else {
		!$aid && Showmsg('colony_albumclass');
		$rt = $db->get_one("SELECT photonum,uid,cyid,atype FROM pw_cnalbum WHERE aid='$aid'");
		if ($rt['cyid']!=$cyid) {
			Showmsg('undefined_action');
		} elseif ($rt['atype']!=1 && $winduid!=$rt['uid'] && $groupid!=3) {
			Showmsg('colony_phototype');
		}
		$rt['photonum'] >= $cn_maxphotonum && Showmsg('colony_photofull');
		require_once(R_P.'require/postfunc.php');
		$db_attachdir = $cn_mkdir;
		!$cn_maxfilesize && $cn_maxfilesize = 1000;
		$db_uploadfiletype = array();
		$db_uploadfiletype['gif'] = $db_uploadfiletype['jpg'] = $db_uploadfiletype['jpeg'] = $db_uploadfiletype['bmp'] = $db_uploadfiletype['png'] = $cn_maxfilesize;
		list($db_thumbw,$db_thumbh) = explode("\t",$db_athumbsize);
		$db_athumbsize = "100\t100";
		InitGP(array('oldaid','pname','pintro'),'P',1);
		!$pname && Showmsg('colony_pname_empty');
		!$pintro && Showmsg('colony_uploadintro');
		$ftp = null;
		if ($db_ifftp) {
			require_once(R_P.'require/ftp.php');
			$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
		}
		$uploaddb = UploadFile(randstr(4).$timestamp,'photo');
		if ($ftp) {
			$ftp->close(); unset($ftp);
		}
		!$uploaddb[0]['attachurl'] && Showmsg('colony_uploadnull');
		$fileuplodeurl = $uploaddb[0]['attachurl'];
		$db->update("INSERT INTO pw_cnphoto(aid,pname,pintro,path,uploader,uptime) VALUES('$aid','$pname','$pintro','$fileuplodeurl','$windid','$timestamp')");
		if ($oldaid!=$aid) {
			$db->update("UPDATE pw_cnalbum SET photonum=photonum-1 WHERE aid='$oldaid'");
		}
		$db->update("UPDATE pw_cnalbum SET lastphoto='$fileuplodeurl',photonum=photonum+1 WHERE aid='$aid'");
		refreshto("$basename&cyid=$cyid&aid=$aid&job=viewalbum",'operate_success');
	}
} elseif ($job=='editphoto') {
	$pid = GetGP('pid');
	@extract($db->get_one("SELECT aid,pname,pintro,path FROM pw_cnphoto WHERE pid='$pid'"));
	empty($aid) && Showmsg('data_error');
	if ($_POST['step']!=2) {
		list($path) = geturl($path,'lf');
		$size = ceil(filesize($path)/1024);
		$albumselect = '';
		$query = $db->query("SELECT aid,aname,uid,atype FROM pw_cnalbum WHERE cyid='$cyid'");
		while ($rt = $db->fetch_array($query)) {
			if ($rt['uid']==$winduid || $rt['atype']==1 || $groupid==3) {
				$selected = '';
				if ($aid == $rt['aid']) {
					$aname = $rt['aname'];
					$selected = 'selected';
				}
				$albumselect .= "<option value=\"$rt[aid]\" $selected>$rt[aname]</option>";
			}
		}
		$db->free_result($query);
		!$albumselect && Showmsg('colony_unfined');
		require_once PrintHack('home');
	} else {
		$rt = $db->get_one("SELECT photonum,uid,cyid,atype FROM pw_cnalbum WHERE aid='$aid'");
		if ($rt['cyid']!=$cyid) {
			Showmsg('undefined_action');
		} elseif ($rt['atype']!=1 && $winduid!=$rt['uid'] && $groupid!=3) {
			Showmsg('colony_phototype');
		}
		require_once(R_P.'require/postfunc.php');
		$replacedb[$pid] = $path;
		$db_attachdir = $cn_mkdir;
		!$cn_maxfilesize && $cn_maxfilesize = 1000;
		$db_uploadfiletype = array();
		$db_uploadfiletype['gif'] = $db_uploadfiletype['jpg'] = $db_uploadfiletype['jpeg'] = $db_uploadfiletype['bmp'] = $db_uploadfiletype['png'] = $cn_maxfilesize;
		list($db_thumbw,$db_thumbh) = explode("\t",$db_athumbsize);
		$db_athumbsize = "100\t100";
		InitGP(array('oldaid','pname','pintro'),'P',1);
		!$pname && Showmsg('colony_pname_empty');
		!$pintro && Showmsg('colony_uploadnull');
		$ftp = null;
		if ($db_ifftp) {
			require_once(R_P.'require/ftp.php');
			$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
		}
		$uploaddb = UploadFile('','photo');
		if ($ftp) {
			$ftp->close(); unset($ftp);
		}
		$updatesql = $uploaddb[0]['attachurl'] ? ",path='".$uploaddb[0]['attachurl']."'" : '';
		$db->update("UPDATE pw_cnphoto SET aid='$aid',pname='$pname',pintro='$pintro'$updatesql WHERE pid='$pid'");
		if ($oldaid!=$aid) {
			$db->update("UPDATE pw_cnalbum SET photonum=photonum-1 WHERE aid='$oldaid'");
			$db->update("UPDATE pw_cnalbum SET photonum=photonum+1 WHERE aid='$aid'");
		}
		refreshto("$basename&cyid=$cyid&aid=$aid&job=viewalbum",'operate_success');
	}
} elseif ($job=='delphoto') {
	$pid = GetGP('pid');
	@extract($db->get_one("SELECT uploader,aid,path FROM pw_cnphoto WHERE pid='$pid'"));
	@extract($db->get_one("SELECT COUNT(*) AS count FROM pw_cnalbum WHERE cyid='$cyid'"));
	!$count && Showmsg('undefined_action');
	!$admindb[$winduid] && $uploader!=$winduid && $groupid!=3 && Showmsg('mawhole_right');
	@extract($db->get_one("SELECT path as lastphoto FROM pw_cnphoto WHERE aid='$aid' ORDER BY uptime DESC LIMIT 1"));
	$db->update("DELETE FROM pw_cnphoto WHERE pid='$pid'");
	$db->update("UPDATE pw_cnalbum SET lastphoto='$lastphoto',photonum=photonum-1 WHERE aid='$aid'");
	$tmpurl = strrchr($path,'/');
	$fileuplodename = $tmpurl ? substr($tmpurl,1) : $path;
	$thumbdir = str_replace($fileuplodename,'s_'.$fileuplodename,$path);
	$a_url = geturl($path);
	$b_url = geturl($thumbdir);
	if ($db_ifftp && ($a_url[1]=='Ftp' || $b_url[1]=='Ftp')) {
		require_once(R_P.'require/ftp.php');
		$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
	}
	if ($a_url[1]=='Local') {
		P_unlink("$attachdir/$path");
	} elseif ($ftp) {
		$ftp->delete($path);
	}
	if ($b_url[1]=='Local') {
		P_unlink("$attachdir/$thumbdir");
	} elseif ($ftp) {
		$ftp->delete($thumbdir);
	}
	if ($ftp) {
		$ftp->close();
		unset($ftp);
	}
	refreshto("$basename&job=viewalbum&cyid=$cyid&aid=$aid",'operate_success');
} elseif ($job=='viewphoto') {
	InitGP(array('aid','pid'),'G');
	$count = $thisp = 0;
	$photodb = $sphotodb = $thisdb = array();
	$query = $db->query("SELECT c.pid,c.path,c.pname,c.uploader,c.pintro,c.uptime,a.aname,a.atype,a.atype,a.uid FROM pw_cnphoto c LEFT JOIN pw_cnalbum a ON c.aid=a.aid WHERE c.aid='$aid' ORDER BY uptime DESC");
	while ($rt = $db->fetch_array($query)) {
		if ($rt['path']) {
			if($rt['atype']==1 && !$alldb['albumopen'] && !$istruecyer && $groupid!=3){
				Showmsg('colony_opentocn');
			} elseif ($rt['atype']==3 && $rt['uid']!=$winduid && $groupid!=3) {
				Showmsg('colony_opentome');
			}
			if ($count<6) {
				$rt['small'] = getsmallurl($rt['path']);
				$sphotodb[$count] = $rt;
			}
			list($rt['path']) = geturl($rt['path']);
			$rt['uptime'] = get_date($rt['uptime'],'Y-m-d H:i');
			foreach ($rt as $key => $value) {
				if (in_array($key,array('pid','path','pname','uploader','pintro','uptime'))) {
					if (in_array($key,array('path','pname','uploader','pintro'))) {
						$key == 'pintro' && $value = '����'.$value;
						$value = addslashes($value);
					}
					$photodb[$key] .= ($photodb[$key] ? "\t" : '').$value;
				}
			}
			if ($rt['pid']==$pid) {
				$thisdb = $rt;
				$thisp = $count+1;
			}
			$count++;
		}
	}
	$db->free_result($query);
	empty($thisdb) && Showmsg('data_error');
}
require_once PrintHack('photo');footer();
?>