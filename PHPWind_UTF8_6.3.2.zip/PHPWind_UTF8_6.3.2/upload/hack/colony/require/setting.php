<?php
!function_exists('readover') && exit('Forbidden');

if ($job=='member') {
	if ($_POST['step']!=2) {
		require_once PrintHack('home');
		(int)$page < 1 && $page = 1;
		$pageid = ($page-1)*$db_perpage;
		$count = count($memberdb);
		$memberdb = array_slice($memberdb,$pageid,$db_perpage);
		$cymembers = array();
		foreach ($memberdb as $key => $value) {
			if (!$admindb[$winduid] && $value['ifadmin'] == -1) continue;
			$cymembers[$key] = $value;
		}
		unset($memberdb);
		if ($count > $db_perpage) {
			require_once(R_P.'require/forum.php');
			$pages = numofpage($count,$page,ceil($count/$db_perpage),"$basename&cyid=$cyid&job=member&$addpage");
		}
	} else {
		$selids = '';
		InitGP(array('selid','action'),'P',1);
		if (is_array($selid)) {
			foreach ($selid as $value) {
				if (is_numeric($value) && $value!=$winduid) {
					$selids .= ($selids ? ',' : '')."'$value'";
				}
			}
		}
		$passdb = array();
		$ifadmin = $select = $leftjoin = '';
		if ($selids && in_array($action,array('deladmin','pass','del'))) {
			if ($action == 'pass') {
				$select = ',md.onlineip';
				$leftjoin = ' LEFT JOIN pw_memberdata md ON cm.uid=md.uid';
			}
			$query = $db->query("SELECT cm.uid,cm.username,cm.ifadmin$select FROM pw_cmembers cm$leftjoin WHERE cm.colonyid='$cyid' AND cm.uid IN ($selids)");
			while ($rt = $db->fetch_array($query)) {
				if ($rt['ifadmin'] != -1 && $action=='deladmin') {
					$alldb['admin'] == $rt['username'] && Showmsg('colony_delladminfail');
					$ifadmin .= ($ifadmin ? ',' : '')."'$rt[uid]'";
				} elseif ($rt['ifadmin'] == -1 && $action=='pass') {
					$alldb['intomoney'] > UserCredit($rt['uid'],$cn_moneytype) && Showmsg('colony_passfail');
					$passdb[] = $rt;
					$ifadmin .= ($ifadmin ? ',' : '')."'$rt[uid]'";
				} elseif ($action=='del') {
					if ($alldb['admin'] == $rt['username']) {
						Showmsg('colony_delfail');
					} elseif ($windid != $alldb['admin'] && $rt['ifadmin'] == '1') {
						Showmsg('colony_manager');
					}
					$ifadmin .= ($ifadmin ? ',' : '')."'$rt[uid]'";
				}
			}
			$selids = $ifadmin;
			$ifadmin = 0;
		}
		!$selids && Showmsg('selid_illegal');
		$selids = strpos($selids,',')!==false ? "IN ($selids)" : "= $selids";
		if ($action=='addamin' || $action=='deladmin') {
			$action=='addamin' && $ifadmin = 1;
			$db->update("UPDATE pw_cmembers SET ifadmin='$ifadmin' WHERE colonyid='$cyid' AND uid $selids");
			Showmsg("colony_$action");
		} elseif ($action == 'pass') {
			$cn_moneytype == 'currency' && require_once(R_P.'require/tool.php');
			$count = count($passdb);
			foreach ($passdb as $value) {
				if ($cn_moneytype == 'currency') {
					list($value['onlineip']) = explode('|',$value['onlineip']);
					$logdata = array(
						'type'		=>	'join',
						'nums'		=>	0,
						'money'		=>	0,
						'descrip'	=>	'join_descrip',
						'uid'		=>	$value['uid'],
						'username'	=>	$value['username'],
						'ip'		=>	$value['onlineip'],
						'time'		=>	$timestamp,
						'currency'	=>	$alldb['intomoney'],
						'cname'  	=>	$alldb['cname'],
					);
					writetoollog($logdata);
				}
				$log = array(
					'type'      => 'cy_join',
					'username1' => Char_cv($value['username']),
					'username2' => Char_cv($windid),
					'field1'    => (int)$alldb['intomoney'],
					'field2'    => $cyid,
					'field3'    => Char_cv($alldb['cname']),
					'timestamp' => $timestamp,
					'ip'        => $onlineip,
				);
				require GetLang('log');
				$log['descrip']  = Char_cv($lang['join_descrip']);
				$db->update("INSERT INTO pw_forumlog (type,username1,username2,field1,field2,field3,descrip,timestamp,ip) VALUES('$log[type]','$log[username1]','$log[username2]','$log[field1]','$log[field2]','$log[field3]','$log[descrip]','$log[timestamp]','$log[ip]')");
				require_once(R_P.'require/msg.php');
				$message = array(
					$value['username'],
					$winduid,
					'join_title',
					$timestamp,
					'join_content',
					'',
					$windid
				);
				writenewmsg($message,1);
			}
			if (in_array($cn_moneytype,array('money','rvrc','credit','currency'))) {
				$temprvrc = $cn_moneytype == 'rvrc' ? $alldb['intomoney']*10 : $alldb['intomoney'];
				$db->update("UPDATE pw_memberdata SET $cn_moneytype=$cn_moneytype-'$temprvrc' WHERE uid $selids");
			} elseif (is_numeric($cn_moneytype) && isset($_CREDITDB[$cn_moneytype])) {
				$db->update("UPDATE pw_membercredit SET value=value-'$alldb[intomoney]' WHERE uid $selids AND cid='$cn_moneytype'");
			}
			$db->update("UPDATE pw_cmembers SET ifadmin=0 WHERE colonyid='$cyid' AND uid $selids");
			$db->update("UPDATE pw_colonys SET cmoney=cmoney+'".($alldb['intomoney']*$count)."' WHERE id='$cyid'");
			Showmsg('colony_pass');
		} elseif ($action == 'del') {
			$db->update("DELETE FROM pw_cmembers WHERE colonyid='$cyid' AND uid $selids");
			$count = strpos($selids,',')!==false ? $db->affected_rows() : 1;
			$db->update("UPDATE pw_colonys SET members=members-'$count' WHERE id='$cyid'");
			Showmsg('colony_del');
		}
	}
} elseif ($job=='seemember') {
	$uid = (int)$_GET['uid'];
	$uid != $winduid && !$admindb[$winduid] && $groupid!=3 && Showmsg('colony_cnmenber');
	@extract($db->get_one("SELECT id,username,realname,gender,tel,email,address,introduce FROM pw_cmembers WHERE colonyid='$cyid' AND uid='$uid'"));
	!$id && Showmsg('colony_noseecard');
	require_once PrintHack('home');
} elseif ($job=='editmember') {
	$rt = $db->get_one("SELECT id,realname,gender,tel,email,address,introduce FROM pw_cmembers WHERE colonyid='$cyid' AND uid='$winduid'");
	if ($_POST['step']!=2) {
		@extract($rt);
		!$id && Showmsg('colony_nocard');
		${'gender_'.$gender} = 'selected';
		require_once PrintHack('home');
	} else {
		InitGP(array('realname','tel','email','address','introduce'),'P',1);
		$gender = (int)$_POST['gender'];
		!$realname && Showmsg('colony_realname');
		if ($realname != $rt['realname']) {
			$rts = $db->get_one("SELECT id FROM pw_cmembers WHERE realname='$realname' AND colonyid='$cyid'");
			$rts['id'] && Showmsg('colony_samerealname');
			$updatesql = ",realname='$realname'";
		}
		$db->update("UPDATE pw_cmembers SET gender='$gender',tel='$tel',email='$email',address='$address',introduce='$introduce'$updatesql WHERE colonyid='$cyid' AND uid='$winduid'");
		refreshto("$basename&cyid=$cyid&job=seemember&uid=$winduid",'colony_cardsuccess');
	}
} elseif ($job=='boardlist') {
	require_once PrintHack('home');
	$ifsort=0;
	(int)$page < 1 && $page = 1;
	$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
	$argudb = array();
	$query  = $db->query("SELECT tid,author,authorid,lastpost,subject,topped,toppedtime FROM pw_argument WHERE gid='$cyid' AND tpcid='0' ORDER BY topped DESC,lastpost DESC $limit");
	while ($rt = $db->fetch_array($query)) {
		if($rt[topped]>0 && $rt[toppedtime] && ($timestamp > $rt[toppedtime])){
			$db->update("UPDATE pw_argument SET topped='0',toppedtime='0' WHERE tid='$rt[tid]'");
		}
		$rt[topped] && $ifsort=1;
		$rt['lastpost'] = get_date($rt['lastpost']);
		$argudb[] = $rt;
	}
	$db->free_result($query);
	@extract($db->get_one("SELECT COUNT(*) AS count FROM pw_argument WHERE gid='$cyid' AND tpcid='0'"));
	if ($count > $db_perpage) {
		require_once(R_P.'require/forum.php');
		$pages = numofpage($count,$page,ceil($count/$db_perpage),"$basename&cyid=$cyid&job=boardlist&");
	}
} elseif($job=='delboardlist'){
	if(!$admindb[$winduid] && $groupid!=3){
		Showmsg('colony_delright');
	}
	$selids = '';
	InitGP(array('selid'),'P',1);
	if (is_array($selid)) {
		foreach ($selid as $value) {
			if (is_numeric($value)) {
				$selids .= ($selids ? ',' : '')."'$value'";
			}
		}
	}
	!$selids && Showmsg('selid_illegal');
	$selids = strpos($selids,',')!==false ? "IN ($selids)" : "= $selids";
	if($_POST['step'] != 2){
		require_once PrintHack('home');
		$query = $db->query("SELECT tid,author,authorid,lastpost,subject FROM pw_argument WHERE gid='$cyid' AND tpcid='0' AND tid $selids ORDER BY lastpost DESC");
		while($rt = $db->fetch_array($query)){
			$rt['lastpost'] = get_date($rt['lastpost']);
			$argudb[] = $rt;
		}
	}else{
		$db->update("DELETE FROM pw_argument WHERE tid $selids");
		$db->update("DELETE FROM pw_argument WHERE gid='$cyid' AND tpcid $selids");
		refreshto("$basename&cyid=$cyid&job=boardlist",'colony_delsuccess');
	}
} elseif ($job=='addboard') {
	if ($_POST['step']!=2) {
		$tid = 0;
		$subject = $content = '';
		require_once PrintHack('home');
	} else {
		InitGP(array('subject','content'),'P',1);
		$tid <= 0 && !$subject && Showmsg('colony_posterror');
		strlen($subject)>50 && Showmsg('colony_subject');
		!$content && Showmsg('colony_posterror');
		$tid>0 && strlen($content)>255 && $content = substrs($content,255,'N');
		require_once(R_P.'require/postfunc.php');
		$content = autourl($content);
		$db->update("INSERT INTO pw_argument(tpcid,gid,author,authorid,postdate,lastpost,subject,content) VALUES('$tid','$cyid','".addslashes($windid)."','$winduid','$timestamp','$timestamp','$subject','$content')");
		if ($tid) {
			$db->update("UPDATE pw_argument SET lastpost='$timestamp' WHERE tid='$tid'");
		} else {
			$tid = $db->insert_id();
		}
		refreshto("$basename&job=readboard&cyid=$cyid&tid=$tid",'colony_postsuccess');
	}
} elseif ($job=='editboard') {
	if ($_POST['step']!=2) {
		@extract($db->get_one("SELECT subject,content FROM pw_argument WHERE tid='$tid'"));
		!$subject && Showmsg('illegal_tid');
		require_once PrintHack('home');
	} else {
		InitGP(array('subject','content'),'P',1);
		(!$subject || !$content) && Showmsg('colony_posterror');
		strlen($subject)>50 && Showmsg('colony_subject');
		strlen($content)>255 && $content = substrs($content,255,'N');
		require_once(R_P.'require/postfunc.php');
		$content = autourl($content);
		$db->update("UPDATE pw_argument SET subject='$subject',content='$content' WHERE tid='$tid'");
		refreshto("$basename&job=readboard&cyid=$cyid&tid=$tid",'colony_postsuccess');
	}
} elseif ($job=='delboard') {
	@extract($db->get_one("SELECT tpcid,gid,authorid FROM pw_argument WHERE tid='$tid'"));
	!$authorid && Showmsg('illegal_tid');
	if ($cyid != $gid || ($authorid!=$winduid && !$admindb[$winduid] && $groupid!=3)) {
		Showmsg('colony_delright');
	}
	$db->update("DELETE FROM pw_argument WHERE tid='$tid'");
	if (!$tpcid) {
		$db->update("DELETE FROM pw_argument WHERE gid='$gid' AND tpcid='$tid'");
		$refreshto = "$basename&job=boardlist&cyid=$gid";
	} else {
		$refreshto = "$basename&job=readboard&cyid=$gid&tid=$tpcid";
	}
	refreshto($refreshto,'colony_delsuccess');
} elseif ($job=='readboard') {
	@extract($db->get_one("SELECT a.tpcid,a.gid,a.author,a.authorid,a.postdate,a.lastpost,a.subject,a.content,cm.ifadmin FROM pw_argument a LEFT JOIN pw_cmembers cm ON a.authorid=cm.uid WHERE a.tid='$tid'"));
	(!$subject || $cyid != $gid || $tpcid != 0) && Showmsg('illegal_tid');
	require_once PrintHack('home');
	$adminimg = $ifadmin==1 ? "<img src=\"$imgpath/$stylepath/group/3.gif\" align=\"absmiddle\"> " : "<img src=\"$imgpath/$stylepath/group/6.gif\" align=\"absmiddle\"> ";
	require_once(R_P.'require/bbscode.php');
	$havereply = $postdate != $lastpost ? true : false;
	$postdate = get_date($postdate);
	$content = convert(nl2br($content),$db_windpost);
	$count = (int)$count;
	$readdb = array();
	if ($havereply) {
		(int)$page < 1 && $page = 1;
		@extract($db->get_one("SELECT COUNT(*) AS count FROM pw_argument WHERE gid='$gid' AND tpcid='$tid'"));
		if ($count > $db_perpage) {
			require_once(R_P.'require/forum.php');
			$pages = numofpage($count,$page,ceil($count/$db_perpage),"$basename&job=readboard&cyid=$gid&tid=$tid&");
		} else {
			$page = 1;
		}
		$start_limit = ($page-1)*$db_perpage;
		$query = $db->query("SELECT DISTINCT a.tid,a.tpcid,a.gid,a.author,a.authorid,a.postdate,a.subject,a.content,cm.ifadmin FROM pw_argument a LEFT JOIN pw_cmembers cm ON a.authorid=cm.uid WHERE a.gid='$gid' AND a.tpcid='$tid' AND cm.colonyid='$gid' ORDER BY postdate DESC LIMIT $start_limit,$db_perpage");
		while ($rt = $db->fetch_array($query)) {
			$start_limit++;
			$rt['lou'] = $start_limit;
			$rt['postdate'] = get_date($rt['postdate']);
			$rt['content'] = convert(nl2br($rt['content']),$db_windpost);
			$rt['adminimg'] = $rt['ifadmin']==1 ? "<img src=\"$imgpath/$stylepath/group/3.gif\" align=\"absmiddle\"> " : "<img src=\"$imgpath/$stylepath/group/6.gif\" align=\"absmiddle\"> ";
			$readdb[] = $rt;
		}
		$db->free_result($query);
	}
} elseif ($job=='topboard'){
	if(!$admindb[$winduid] && $groupid!=3){
		Showmsg('colony_topright');
	}
	$selids = '';
	InitGP(array('selid'),'P',1);
	if (is_array($selid)) {
		foreach ($selid as $value) {
			if (is_numeric($value)) {
				$selids .= ($selids ? ',' : '')."'$value'";
			}
		}
	}
	!$selids && Showmsg('selid_illegal');
	$selids = strpos($selids,',')!==false ? "IN ($selids)" : "= $selids";
	if($_POST['step'] != 2){
		require_once PrintHack('home');
		$query = $db->query("SELECT tid,author,authorid,lastpost,subject FROM pw_argument WHERE gid='$cyid' AND tpcid='0' AND tid $selids ORDER BY lastpost DESC");
		while($rt = $db->fetch_array($query)){
			$rt['lastpost'] = get_date($rt['lastpost']);
			$argudb[] = $rt;
		}
	}else{
		InitGP(array('topped','toppedtime'),'P');
		$toppedtime = (int)$toppedtime;
		$toppedtime && $toppedtime = $timestamp + 86400*$toppedtime;
		$db->update("UPDATE pw_argument SET topped='$topped',toppedtime='$toppedtime' WHERE tid $selids");
		refreshto("$basename&cyid=$cyid&job=boardlist",'colony_topsuccess');
	}
} elseif ($job=='honor') {
	require_once PrintHack('home');
	$honordb = $honor_order = array();
	foreach ($memberdb as $key => $value) {
		$honor_order[$key] = (int)$value['honor'];
	}
	array_multisort($honor_order,SORT_DESC,$memberdb);
	$num = 0;
	foreach ($memberdb as $key => $value) {
		if ($num < 10 && $value['ifadmin']!=-1) {
			$num++;
			$value['order'] = $num;
			$honordb[$key] = $value;
		}
	}
	unset($memberdb);
} elseif ($job=='donate') {
	$usermoney = UserCredit($winduid,$cn_moneytype);
	if ($_POST['step']!=2) {
		require_once PrintHack('home');
	} else {
		$sendmoney = (int)GetGP('sendmoney','P');
		$sendmoney < 1 && Showmsg('colony_donateerror');
		$sendmoney > $usermoney && Showmsg('colony_donatefail');
		$honor = $sendmoney*1;//���������Ǯ�ı���
		
		$lockfile = D_P.'data/bbscache/lock_bank.txt';
		$fp = fopen($lockfile,'wb+');
		flock($fp,LOCK_EX);
	
		if (in_array($cn_moneytype,array('money','rvrc','credit','currency'))) {
			$temprvrc = $cn_moneytype == 'rvrc' ? $sendmoney*10 : $sendmoney;
			$db->update("UPDATE pw_memberdata SET $cn_moneytype=$cn_moneytype-'$temprvrc' WHERE uid='$winduid'",0);
		} elseif (is_numeric($cn_moneytype) && isset($_CREDITDB[$cn_moneytype])) {
			$db->update("UPDATE pw_membercredit SET value=value-'$sendmoney' WHERE uid='$winduid' AND cid='$cn_moneytype'",0);
		}
		$db->update("UPDATE pw_colonys SET cmoney=cmoney+'$sendmoney' WHERE id='$cyid'");
		$db->update("UPDATE pw_cmembers SET honor=honor+'$honor' WHERE uid='$winduid' AND colonyid='$cyid'");
		
		fclose($fp);
		if ($cn_moneytype == 'currency') {
			require_once(R_P.'require/tool.php');
			$logdata = array(
				'type'		=>	'donate',
				'nums'		=>	0,
				'money'		=>	0,
				'descrip'	=>	'donate_descrip',
				'uid'		=>	$winduid,
				'username'	=>	$windid,
				'ip'		=>	$onlineip,
				'time'		=>	$timestamp,
				'currency'	=>	$sendmoney,
				'cname'		=>	$alldb['cname']
			);
			writetoollog($logdata);
		}
		$log = array(
			'type'      => 'cy_donate',
			'username1' => Char_cv($windid),
			'username2' => '',
			'field1'    => $sendmoney,
			'field2'    => $cyid,
			'field3'    => Char_cv($alldb['cname']),
			'timestamp' => $timestamp,
			'ip'        => $onlineip,
			'cname'		=> $alldb['cname']
		);
		require GetLang('log');
		$log['descrip'] = Char_cv($lang['donate_descrip']);
		$db->update("INSERT INTO pw_forumlog (type,username1,username2,field1,field2,field3,descrip,timestamp,ip) VALUES('$log[type]','$log[username1]','$log[username2]','$log[field1]','$log[field2]','$log[field3]','$log[descrip]','$log[timestamp]','$log[ip]')");
		require_once(R_P.'require/msg.php');
		writenewmsg(array($alldb['admin'],$winduid,'donate_title',$timestamp,'donate_content','',$windid),1);
		Showmsg('colony_donatesuccess');
	}
} elseif ($job=='donatelog') {
	require_once PrintHack('home');
	(int)$page < 1 && $page = 1;
	@extract($db->get_one("SELECT COUNT(*) AS count FROM pw_forumlog WHERE field2='$cyid' AND type='cy_donate'"));
	if ($count > $db_perpage) {
		require_once(R_P.'require/forum.php');
		$pages = numofpage($count,$page,ceil($count/$db_perpage),"$basename&job=donatelog&cyid=$cyid&");
	} else {
		$page = 1;
	}
	$logdb = array();
	$query = $db->query("SELECT username1,descrip,timestamp FROM pw_forumlog WHERE field2='$cyid' AND type='cy_donate' ORDER BY id DESC LIMIT ".($page-1)*$db_perpage.",$db_perpage");
	while ($rt = $db->fetch_array($query)) {
		$rt['timestamp'] = get_date($rt['timestamp'],"Y-m-d H:i");
		$rt['descrip'] = str_replace(array('[b]','[/b]'),array('<b>','</b>'),$rt['descrip']);
		$logdb[] = $rt;
	}
	$db->free_result($query);
}
require_once PrintHack('setting');footer();
?>