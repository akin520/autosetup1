<?php
!function_exists('readover') && exit('Forbidden');

require_once PrintHack('home');
$num = 0;
$members = array();
foreach ($memberdb as $key => $value) {
	if ($num<10) {
		$value['adminimg'] = $value['ifadmin']==1 ? "<img src=\"$imgpath/$stylepath/group/3.gif\" align=\"absmiddle\"> " : "<img src=\"$imgpath/$stylepath/group/6.gif\" align=\"absmiddle\"> ";
		$members[$key] = $value;
		$num++;
	} else {
		break;
	}
}
unset($memberdb);
$argudb = $photodb = array();
$query	= $db->query("SELECT tid,subject,author,authorid,lastpost FROM pw_argument WHERE gid='$cyid' AND tpcid='0' ORDER BY lastpost DESC LIMIT 10");
while ($rt = $db->fetch_array($query)) {
	$rt['lastpost'] = get_date($rt['lastpost']);
	$argudb[] = $rt;
}
$query = $db->query("SELECT a.aid,p.pid,p.path FROM pw_cnphoto p LEFT JOIN pw_cnalbum a USING(aid) WHERE a.cyid='$cyid' ORDER BY p.uptime DESC LIMIT 4");
while($rt = $db->fetch_array($query)){
	$rt['path'] = getsmallurl($rt['path']);
	$photodb[] = $rt;
}
$db->free_result($query);
require_once PrintHack('view');
?>