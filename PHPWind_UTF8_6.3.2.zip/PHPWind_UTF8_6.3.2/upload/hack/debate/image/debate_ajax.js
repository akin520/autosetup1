// PHPWind AJAX Module
// written by fengyu
// Copyright (C) 2006 phpwind.net - http://www.phpwind.net

var http_request = false;
function send_request(url,callback,data){
	
	http_request=false;
	if(window.XMLHttpRequest){
		http_request=new XMLHttpRequest();
		if(http_request.overrideMimeType){
			http_request.overrideMimeType("text/xml");
		}
	}else if(window.ActiveXObject){
		try{
			http_request=new ActiveXObject("Msxml2.XMLHTTP");
		}catch(e){
			try{
				http_request=new ActiveXObject("Microsoft.XMLHTTP");
				
			}catch(e){}
		}
	}
	if(!http_request){
		window.alert("Can't creat XMLHttpRequest Object.");
		return false;
	}
	nowtime	 = new Date().getTime();
	url		+= (url.indexOf("?") >= 0) ? "&nowtime=" + nowtime : "?nowtime=" + nowtime;
	if(typeof(data) =='undefined'){
		http_request.open("GET",url,true);
		http_request.send(null);
	}else{
		http_request.open('POST' , url, true);
		http_request.setRequestHeader("Content-Length",data.length);
		http_request.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		http_request.send(data);
	}
	if(typeof(callback) == "function" ){
		http_request.onreadystatechange = function (){
			if (http_request.readyState == 4){
				if(http_request.status == 200 || http_request.status == 304){
					//GE("process").style.display='none';
					callback(http_request);
				}else{
					alert("Error loading page\n" + http_request.status + ":" + http_request.statusText);
				}
			}else{
				//GE("process").style.display='';
			}
		}
	}
}

function ajax_convert(str){
	f = new Array(/\r?\n/g, /\+/g, /\&/g);
	r = new Array('%0A', '%2B', '%26');
	for (var i = 0; i < f.length; i++){
		str = str.replace(f[i], r[i]);
	}
	return str;
}
function GE(id){
	if (document.getElementById){
		return document.getElementById(id);
	}else if (document.all){
		return document.all[id];
	}else if (document.layers){
		return document.layers[id];
	}else{
		return null;
	}
}
function Char_cv($msg){
	$msg = str_replace('&amp;','&',$msg);
	$msg = str_replace('&nbsp;',' ',$msg);
	$msg = str_replace('"','&quot;',$msg);
	$msg = str_replace("'",'&#39;',$msg);
	$msg = str_replace("<","&lt;",$msg);
	$msg = str_replace(">","&gt;",$msg);
	$msg = str_replace("\t"," &nbsp; &nbsp;",$msg);
	$msg = str_replace("\r","",$msg);
	$msg = str_replace("   "," &nbsp; ",$msg);
	return $msg;
}