var startTime = (new Date()).getTime();
var Temp;
var timerID = null;
var timerRunning = false;

function showtime()
{
    now = new Date();
    var ts=parseInt((startTime-now.getTime())/1000)+auctionDate;
    var dateLeft = 0;
    var hourLeft = 0;
    var minuteLeft = 0;
    var secondLeft = 0;
    if(ts < 0)
    {
        ts = 0;
        CurHour = 0;
        CurMinute = 0;
        CurSecond = 0;
    } else {
        dateLeft =parseInt(ts/86400);
        ts = ts - dateLeft * 86400;
        hourLeft = parseInt(ts/3600);
        ts = ts - hourLeft * 3600;
        minuteLeft = parseInt(ts/60);
        secondLeft = ts - minuteLeft * 60;
    }
    if(hourLeft < 10) hourLeft = '0' +hourLeft;
    if(minuteLeft < 10) minuteLeft = '0' +minuteLeft;
    if(secondLeft<10) secondLeft='0'+secondLeft;
    if( dateLeft > 0 )
        dateLeft = dateLeft + _day ;
    else
        dateLeft = "";
    if( hourLeft > 0 )
        hourLeft = hourLeft + _hour ;
    else
    {
        if( dateLeft != "" )
            hourLeft = "00" + _hour;
        else
            hourLeft = "";
    }
    if( minuteLeft > 0 )
        minuteLeft = minuteLeft + _minute ;
    else
    {
        if( dateLeft !="" || hourLeft != "")
            minuteLeft = "00" + _minute;
        else
            minuteLeft = "";
    }
    if( secondLeft > 0 )
        secondLeft = secondLeft + _second ;
    else
    {
        if( dateLeft !="" || hourLeft != "" || minuteLeft != "")
            secondLeft = "00" + _second;
        else
            secondLeft = "";
    }
	if (dateLeft == '') {
   		Temp=dateLeft+hourLeft+minuteLeft+secondLeft ;
   	}else {
   		Temp=dateLeft+hourLeft;
   	}
    if(auctionDate <= 0 || dateLeft <=0 && hourLeft<=0 && minuteLeft<=0 && secondLeft <=0)
    {
        Temp = "<strong class=\"H\">"+_end+"</strong>";
        stopclock();
    }
	for (var iii = 0; iii < showTimeElement.length; ++iii)
	{
		var showTime = showTimeElement[iii];
		if (document.getElementById(showTime)) document.getElementById(showTime).innerHTML=Temp;
	}
    timerID = setTimeout("showtime()",1000);
    timerRunning = true;
}
var timerID = null;
var timerRunning = false;
function stopclock()
{
    if(timerRunning)
        clearTimeout(timerID);
    timerRunning = false;
}
function macauclock()
{
    stopclock();
    showtime();
}
function onloadall()
{
    macauclock();
    try
    {
        initprovcity();
    }
    catch(e)
    {
    }
}
try
{
    onload=onloadall();
}
catch(e)
{
}
