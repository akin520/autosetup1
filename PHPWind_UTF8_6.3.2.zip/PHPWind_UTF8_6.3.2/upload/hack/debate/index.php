<?php
!function_exists('readover') && exit('Forbidden');

@include_once(D_P.'data/bbscache/debate_config.php');
!$debate_open && Showmsg('debate_close');
InitGP(array('job','action','page','sortid'));
$rfile = $job;
!$rfile && $rfile = 'default';
@include_once(D_P.'data/bbscache/debate_class.php');
if (empty($debateclassdb)) Showmsg('debate_noclass');
if (!file_exists(H_P."require/$rfile.php")) {
	Showmsg('undefined_action');
}
require_once Pcv((H_P."require/$rfile.php"));footer();
?>