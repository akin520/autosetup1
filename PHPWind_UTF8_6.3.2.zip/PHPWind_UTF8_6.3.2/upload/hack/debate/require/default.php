<?php
!function_exists('readover') && exit('Forbidden');

$dedb = $replydb = array();
@include_once(D_P.'data/bbscache/debatesort_cache.php');
$newnum = $hotnum = $debatenum = 0;
if (!$sortid) {
	$newdebatedb = $hotdebatedb = array();
	@include_once(D_P.'data/bbscache/debateindex_cache.php');
	$newnum = count($newdebatedb);
	$hotnum = count($hotdebatedb);
	require_once(PrintHack('default'));
} else {
	require_once(H_P.'require/function.php');
	$pages = '';
	(int)$page < 1 && $page = 1;
	$rt = $db->get_one("SELECT COUNT(*) FROM pw_debatethreads WHERE sortid='$sortid' AND isvisible=1",MYSQL_NUM);
	if ($rt[0] > $db_perpage) {
		require_once(R_P.'require/forum.php');
		$pages = numofpage($rt[0],$page,ceil($rt[0]/$db_perpage),"$basename&sortid=$sortid&");
	} else {
		$page = 1;
	}
	$limit	= ($page-1)*$db_perpage.",$db_perpage";
	if (!is_array(($debatedb = dtsarray('dateline',$limit,$sortid)))) {
		$debatedb = array();
	}
	$debatenum = count($debatedb);
	require_once(PrintHack('default'));
}
?>