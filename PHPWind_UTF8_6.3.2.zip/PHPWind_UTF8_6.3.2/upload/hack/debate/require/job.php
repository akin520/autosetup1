<?php
!function_exists('readover') && exit('Forbidden');
define('AJAX','1');
ob_end_clean();
$db_obstart && function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
header("Content-Type: text/html;charset=utf-8");
require_once(R_P.'require/ajaxfunc.php');
if (CkInArray($windid,$manager) || ($windid && strpos(",$debate_admin,",",$windid,")!==false)) {
	$admincheck=1;
} else {
	$admincheck=0;
}
$did = (int)GetGP('did','P');
if ($action == 'dedigest') {
	if ($did && $admincheck) {
		$rt = $db->get_one("SELECT digest,isvisible FROM pw_debatethreads WHERE did='$did'");
		if (!$rt['isvisible']) Showmsg('debate_isvisible');
		if ($rt['digest'] == 1) {
			$db->update("UPDATE pw_debatethreads SET digest=0 WHERE did='$did'");
			echo 0;ajax_footer();
		} else {
			$db->update("UPDATE pw_debatethreads SET digest=1 WHERE did='$did'");
			echo 1;ajax_footer();
		}
	} else {
		Showmsg('undefined_action');
	}
} elseif ($action == 'judgment') {
	$rt = $db->get_one("SELECT judg,judgment,isvisible FROM pw_debatethreads WHERE did='$did'");
	if (!$did || $windid!=$rt['judgment']) Showmsg('data_error');
	if (!$rt['isvisible']) Showmsg('debate_isvisible');
	$judg = (int)GetGP('judg','P');
	if (!in_array($judg,array(-1,1,2,3))) {
		echo 'judg_false';ajax_footer();
	}
	if ($judg != -1) {
		$updatesql = ",judg='$judg'";
	} else {
		$judg = $rt['judg'];
		$updatesql = '';
	}
	$judgcontent = Char_cv(GetGP('judgcontent','P'));
	if ($judgcontent && $db_charset!='utf-8') {
		$judgcontent = ajax_convert($judgcontent,$db_charset);
	}
	$db->update("UPDATE pw_debatethreads SET judgcontent='$judgcontent'$updatesql WHERE did='$did'");
	require_once GetLang('other');
	echo $lang['judg_'.$judg]."\t".$judgcontent;ajax_footer();
} elseif ($action == 'obverse') {
	$pid = (int)GetGP('pid','P');
	if (!$winduid) Showmsg('not_login');
	$rt = $db->get_one("SELECT voteuid,endtime,isvisible FROM pw_debatethreads WHERE did='$did'");
	if (!$rt['isvisible']) {
		Showmsg('debate_isvisible');
	} elseif ($rt['endtime']<=$timestamp) {
		Showmsg('debate_over');
	}
	if (($pid==1 || $pid==2) && strpos(",$rt[voteuid],",",$winduid,")===false) {
		if ($pid==2) {
			$field = 'revote';
		} else {
			$field = 'obvote';
		}
		$rt['voteuid'] .= $rt['voteuid'] ? ",$winduid" : $winduid;
		$db->update("UPDATE pw_debatethreads SET voteuid='$rt[voteuid]',$field=$field+1 WHERE did = '$did'");
		require_once GetLang('other');
		echo $lang['debate_'.$pid]."\t".$pid;ajax_footer();
	} else {
		Showmsg('debate_voted');
	}
} elseif ($action == 'agree') {
	if (!$winduid) Showmsg('not_login');
	$aid = (int)GetGP('aid','P');
	$rt = $db->get_one("SELECT r.did,r.debatetype,t.endtime,t.isvisible FROM pw_debatereplys r LEFT JOIN pw_debatethreads t USING(did) WHERE r.aid='$aid'");
	if ($rt['did']!=$did) {
		Showmsg('data_error');
	} elseif (!$rt['isvisible']) {
		Showmsg('debate_isvisible');
	} elseif ($rt['endtime']<=$timestamp) {
		Showmsg('debate_over');
	}
	$ckuid = "vote_$aid";
	if (GetCookie($ckuid)==$winduid) {
		Showmsg('debate_voted');
	} else {
		$field = '';
		if ($rt['debatetype']==1) {
			$field = 'obrvote';
		} elseif ($rt['debatetype']==2) {
			$field = 'rervote';
		} else {
			Showmsg('data_error');
		}
		$db->update("UPDATE pw_debatereplys SET vote=vote+1 WHERE aid='$aid'");
		$field && $db->update("UPDATE pw_debatethreads SET $field=$field+1 WHERE did='$did'");
		Cookie($ckuid,$winduid);
		require_once GetLang('other');
		echo $lang['debate_vote']."\t".$aid."\t".$rt['debatetype'];ajax_footer();
	}
} elseif ($action == 'modifyreply') {
	if (!$winduid) Showmsg('not_login');
	$aid = (int)GetGP('aid','P');
	InitGP(array('title','content'),'P',1);
	if (!$title || strlen($title)>$db_titlemax) {
		Showmsg('postfunc_subject_limit');
	}
	if (!$content || strlen($content)<$db_postmin || strlen($content)>$db_postmax) {
		Showmsg('postfunc_content_limit');
	}
	$rt = $db->get_one("SELECT r.did,t.endtime,t.isvisible FROM pw_debatereplys r LEFT JOIN pw_debatethreads t USING(did) WHERE r.aid='$aid'");
	if ($rt['did']!=$did) {
		Showmsg('data_error');
	} elseif (!$rt['isvisible']) {
		Showmsg('debate_isvisible');
	} elseif ($rt['endtime']<=$timestamp) {
		Showmsg('debate_over');
	}
	require_once(R_P.'require/bbscode.php');
	$ifconvert = $content!=convert($content,'') ? 1 : 0;
	$db->update("UPDATE pw_debatereplys SET title='$title',content='$content',ifconvert='$ifconvert' WHERE aid='$aid'");
	require_once GetLang('other');
	echo $lang['debate_mreply']."\t".$aid."\t".$title."\t".$content;ajax_footer();
} elseif ($action == 'delreply') {
	if (!$winduid) Showmsg('not_login');
	$aid = (int)GetGP('aid','P');
	$rt = $db->get_one("SELECT r.did,r.debatetype,r.vote,t.endtime,t.isvisible FROM pw_debatereplys r LEFT JOIN pw_debatethreads t USING(did) WHERE r.aid='$aid'");
	if ($rt['did']!=$did) {
		Showmsg('data_error');
	} elseif (!$rt['isvisible']) {
		Showmsg('debate_isvisible');
	} elseif ($rt['endtime']<=$timestamp) {
		Showmsg('debate_over');
	}
	if ($rt['debatetype']==1) {
		$field = 'obrvote';
	} else {
		$field = 'rervote';
	}
	$db->update("DELETE FROM pw_debatereplys WHERE aid='$aid'");
	$db->update("UPDATE pw_debatethreads SET $field=$field-$rt[vote] WHERE did='$rt[did]'");
	require_once GetLang('other');
	echo $lang['debate_dreply']."\t".$aid."\t".$rt['debatetype']."\t".$rt['vote'];ajax_footer();
}
?>