<?php
!function_exists('readover') && exit('Forbidden');

if (!$winduid) Showmsg('not_login');
require_once(R_P.'require/bbscode.php');
$nowydb = $nowmdb = $nowddb = array();
list($nowy,$nowm,$nowd) = explode('-',get_date($timestamp,'Y-n-j'));
if (strpos(",$debate_admin,",",$windid,")===false && $action=='add'){
	$dbadmins = "$debate_admin,$windid";
}else{
	$dbadmins = $debate_admin;
}
$judgmentdb = explode(',',$dbadmins);
if ($action == 'add') {
	if ($_POST['step'] != 2) {
		$nowmdb[$nowm] = $nowddb[$nowd+1] = 'SELECTED';
		$juclass = '';
		foreach ($judgmentdb as $key=>$value) {
			$selected = $value==$windid ? 'selected' : '';
			$juclass .= "<option value=\"$value\" $selected> $value </option>";
		}
		unset($judgmentdb);
		require_once(PrintHack('newdebate'));
	} else {
		InitGP(array('title','atc_content','judgment','obtitle','retitle'),'P',1);
		!$title && Showmsg('debate_title');
		if (!$judgment) {
			Showmsg('debate_noadmin');
		}
		if (!$obtitle || !$retitle) {
			Showmsg('debate_choice');
		}
		InitGP(array('endtimey','endtimem','endtimed'),'P');
		$endtime = PwStrtoTime((int)$endtimey.'-'.(int)$endtimem.'-'.(int)$endtimed);
		$endtime < $timestamp && Showmsg('debate_time');
		require_once(R_P.'require/credit.php');
		require_once(H_P.'require/function.php');
		UserCredit($winduid,$debate_posttype,'set',$debate_postmoney);
		$db->pw_update(
			"SELECT uid FROM pw_debateinfo WHERE uid='$winduid'",
			"UPDATE pw_debateinfo SET posts=posts+1,author='$windid' WHERE uid='$winduid'",
			"INSERT INTO pw_debateinfo(uid,posts,author) VALUES('$winduid',1,'$windid')"
		);
		$isvisible = ($groupid==3 || !$debate_topicopen) ? 1 : 0;
		$ifconvert = $atc_content!=convert($atc_content,'') ? 1 : 0;
		$db->update("INSERT INTO pw_debatethreads (sortid,authorid,author,judgment,title,obtitle,retitle,content,ifconvert,dateline,endtime,isvisible) VALUES ('$sortid','$winduid','$windid','$judgment','$title','$obtitle', '$retitle','$atc_content','$ifconvert','$timestamp','$endtime','$isvisible')");
		debatesort_cache();
		debateindex_cache();
		if ($isvisible) {
			$did = $db->insert_id();
			refreshto("$basename&job=viewdebate&did=$did",'debate_post_success');
		} else {
			refreshto($basename,'debate_post_check');
		}
	}
} elseif ($action == 'modify') {
	$SQL_S = $_POST['step']!=2 ? ',sortid,authorid,author,judgment,title,obtitle,retitle,content,dateline,endtime' : '';
	$did = (int)GetGP('did');
	$rt = $db->get_one("SELECT authorid,endtime$SQL_S FROM pw_debatethreads WHERE did='$did'");
	if (empty($rt) || !$winduid || ($rt['authorid']!=$winduid && !CkInArray($windid,$manager) && strpos(",$debate_admin,",",$windid,")===false)) {
		Showmsg('debate_cantedit');
	}
	if ($_POST['step'] != 2) {
		list($dy,$dm,$dd) = explode('-',get_date($rt['dateline'],'Y-n-j'));
		$nowmdb[$dy] = $nowddb[$dm] = $nowddb[$dd] = 'SELECTED';
		$juclass = '';
		foreach ($judgmentdb as $value) {
			$selected = $value == $rt['judgment'] ? 'SELECTED' : '';
			$juclass .= "<option value=\"$value\" $selected> $value </option>";
		}
		$rt['atc_content'] = $rt['content'];
		unset($rt['dateline'],$rt['judgment'],$rt['content'],$judgmentdb);
		extract($rt);
		require_once(PrintHack('newdebate'));
	} else {
		require_once(H_P.'require/function.php');
		InitGP(array('title','atc_content','judgment','obtitle','retitle'),'P',1);
		!$title && Showmsg('debate_title');
		if (!$judgment) {
			Showmsg('debate_noadmin');
		}
		if (!$obtitle || !$retitle) {
			Showmsg('debate_choice');
		}
		InitGP(array('endtimey','endtimem','endtimed'),'P');
		$endtime = PwStrtoTime((int)$endtimey.'-'.(int)$endtimem.'-'.(int)$endtimed);
		$endtime!=$rt['endtime'] && $endtime < $timestamp && Showmsg('debate_time');
		$ifconvert = $atc_content!=convert($atc_content,'') ? 1 : 0;
		$db->update("UPDATE pw_debatethreads SET judgment='$judgment',title='$title',obtitle='$obtitle',retitle='$retitle',content='$atc_content',ifconvert='$ifconvert',endtime='$endtime' WHERE did='$did'");
		debatesort_cache();
		refreshto("$basename&job=viewdebate&did=$did",'debate_edit_success');
	}
} elseif ($action == 'del') {
	$did = (int)GetGP('did','G');
	$rt = $db->get_one("SELECT authorid FROM pw_debatethreads WHERE did='$did'");
	if (empty($rt) || !$winduid || ($rt['authorid']!=$winduid && !CkInArray($windid,$manager) && strpos(",$debate_admin,",",$windid,")===false)) {
		Showmsg('debate_cantedit');
	}
	require_once(R_P.'require/credit.php');
	require_once(H_P.'require/function.php');
	UserCredit($rt['authorid'],$debate_posttype,'set',"-$debate_postmoney");
	$db->update("UPDATE pw_debateinfo SET posts=posts-1 WHERE uid='$rt[authorid]'");
	$db->update("DELETE FROM pw_debatethreads WHERE did='$did'");
	debatesort_cache();
	debateindex_cache();
	refreshto($basename,'debate_del_success');
} else {
	Showmsg('undefined_action');
}
?>