<?php
!function_exists('readover') && exit('Forbidden');

require_once(R_P.'require/bbscode.php');
$did = (int)GetGP('did');
$step = (int)GetGP('step');
if ($step!=2) {
	if (CkInArray($windid,$manager) || ($windid && strpos(",$debate_admin,",",$windid,")!==false)) {
		$admincheck = 1;
	} else {
		$admincheck = 0;
	}
	$thread_S = $pages = '';
	$debatetype = (int)GetGP('debatetype','G');
	if ($action != 'reply') {
		$keynum = 3;
		$debatetype = 0;
		$thread_S = ',typecache';
	} else {
		$keynum = $debatetype;
		$page = (int)GetGP('page','G');
		$page<1 && $page = 1;
		$limit = ($page-1)*$db_perpage.",$db_perpage";
		$replycount = 0;
		if (!is_array(($rcache = drsarray($did,'',$debatetype,$limit)))) {
			$rcache = array();
		}
		if ($replycount > $db_perpage) {
			require_once(R_P.'require/forum.php');
			$numofpage = ceil($replycount/$db_perpage);
			$pages = numofpage($replycount,$page,$numofpage,"$basename&job=viewdebate&action=reply&did=$did&debatetype=$debatetype&");
		}
	}
	$thread = $db->get_one("SELECT sortid,authorid,author,title,judg,judgment,judgcontent,digest,views,content,ifconvert,dateline,endtime,obvote,revote,obrvote,rervote,obtitle,retitle,isvisible$thread_S FROM pw_debatethreads WHERE did='$did'");
	if (empty($thread)) Showmsg('data_error');
	if (!$thread['isvisible'] && $thread['authorid']!=$winduid) Showmsg('debate_isvisible');
	require_once GetLang('other');
	$thread['judg'] = $lang['judg_'.$thread['judg']];
	$thread['sortname'] = $debateclassdb[$thread['sortid']];
	$thread['digest'] = $thread['digest'] ? '' : 'none';
	$limittime = floor(($thread['endtime']-$timestamp));
	$thread['dateline'] = get_date($thread['dateline']);
	$thread['endtimes'] = get_date($thread['endtime']);
	$displayjc = $thread['judgcontent'] ? '' : 'none';
	$thread['obvote'] += $thread['obrvote'] + 0;
	$thread['revote'] += $thread['rervote'] + 0;
	$sumvote = $thread['obvote']+$thread['revote'];
	$obimgwidth = floor(300*$thread['obvote']/($sumvote+1));
	$reimgwidth = floor(300*$thread['revote']/($sumvote+1));
	if ($thread['typecache']) {
		if (is_array(($thread['typecache'] = unserialize($thread['typecache'])))) {
			$thread['typecache'] = implode(',',$thread['typecache']);
			if (!is_array(($rcache = drsarray($did,$thread['typecache'])))) {
				$rcache = array();
			}
		}
		unset($thread['typecache']);
	}
	$thread['content'] = str_replace("\n",'<br>',$thread['content']);
	if ($thread['ifconvert']) {
		$thread['content'] = convert($thread['content'],$db_windpost);
	}
	if (strpos($thread['content'],'[s:')!==false) {
		$thread['content'] = showface($thread['content']);
	}
	if (GetCookie("did_$did")!=$winduid) {
		$db->update("UPDATE pw_debatethreads SET views=views+1 WHERE did='$did'");
		Cookie("did_$did",$winduid,$timestamp+300);
	}
	require_once(PrintHack('viewdebate'));
} else {
	$debatetype = (int)GetGP('debatetype','P');
	if(empty($winduid) && $debate_gcmtopen == '0'){
		Showmsg('debate_guest');
	}
	if (!$debatetype) {
		Showmsg('debate_choice');
	}
	InitGP(array('title','atc_content'),'P',1);
	if (!$title || strlen($title)>$db_titlemax) {
		Showmsg('postfunc_subject_limit');
	}
	if (!$atc_content || strlen($atc_content)<$db_postmin || strlen($atc_content)>$db_postmax) {
		Showmsg('postfunc_content_limit');
	}
	$rt = $db->get_one("SELECT did,endtime,isvisible,typecache FROM pw_debatethreads WHERE did='$did'");
	if ($rt['did']!=$did) {
		Showmsg('data_error');
	} elseif (!$rt['isvisible']) {
		Showmsg('debate_isvisible');
	} elseif ($rt['endtime']<=$timestamp) {
		Showmsg('debate_over');
	}
	$ifconvert = $atc_content!=convert($atc_content,'') ? 1 : 0;
	$db->update("INSERT INTO pw_debatereplys(did,authorid,author,debatetype,title,content,ifconvert,dateline,isvisible) VALUES ('$did','$winduid','$windid','$debatetype','$title','$atc_content','$ifconvert','$timestamp',1)");
	$aid = $db->insert_id();
	$newcache = array();
	if ($rt['typecache']) {
		if (is_array(($rt['typecache'] = unserialize($rt['typecache'])))) {
			foreach ($rt['typecache'] as $key => $value) {
				if ($key==$debatetype) {
					if ($value) {
						$array = explode(',',$value);
						if (count($array)>=5) {
							@array_pop($array);
						}
						$value = "$aid,".implode(',',$array);
					} else {
						$value = $aid;
					}
				}
				$newcache[$key] = $value;
			}
		}
		unset($rt['typecache']);
	}
	for ($key=1;$key<4;$key++) {
		if (!$newcache[$key] && $key==$debatetype) {
			$newcache[$key] = $aid;
		}
	}
	$db->update("UPDATE pw_debatethreads SET typecache='".addslashes(serialize($newcache))."' WHERE did='$did'");
	$db->update("UPDATE pw_debateinfo SET replys=replys+1 WHERE uid='$winduid'");
	require_once(R_P.'require/credit.php');
	UserCredit($winduid,$debate_replytype,'set',$debate_replymoney);
	refreshto("$basename&job=viewdebate&did=$did",'debate_reply_success');
}

function drsarray($did,$where=null,$debatetype=null,$limit=null){
	global $timestamp,$db,$replycount,$db_windpost;
	$configdb = array();
	if ($where) {
		$where = "aid IN ('".str_replace(',',"','",$where)."')";
	} else {
		$where = "did='$did' AND debatetype='$debatetype'";
		$rt = $db->get_one("SELECT COUNT(*) FROM pw_debatereplys WHERE $where",MYSQL_NUM);
		$replycount = $rt[0];
	}
	$limit && $limit = "LIMIT $limit";
	$query = $db->query("SELECT aid,debatetype,vote,title,dateline,content,ifconvert,authorid,author FROM pw_debatereplys WHERE $where ORDER BY dateline DESC $limit");
	while ($rt = $db->fetch_array($query)) {
		$lastDate = $timestamp-$rt['dateline'];
		$dateLeft = floor($lastDate/86400);
		$hourLeft = floor($lastDate/3600);
		$minuteLeft = floor($lastDate/60);
		if ($dateLeft>0) {
			$rt['dateline'] = $dateLeft.'day';
		} elseif ($hourLeft>0) {
			$rt['dateline'] = $hourLeft.'hour';
		} elseif ($minuteLeft>0) {
			$rt['dateline'] = $minuteLeft.'min';
		} elseif ($lastDate>0) {
			$rt['dateline'] = $lastDate.'sec';
		}
		$rt['content'] = str_replace("\n",'<br>',$rt['content']);
		if ($rt['ifconvert']) {
			$rt['content'] = convert($rt['content'],$db_windpost);
		}
		if (strpos($thread['content'],'[s:')!==false) {
			$rt['content'] = showface($rt['content']);
		}
		$configdb[$rt['debatetype']][] = $rt;
	}
	$db->free_result($query);
	return $configdb;
}
?>