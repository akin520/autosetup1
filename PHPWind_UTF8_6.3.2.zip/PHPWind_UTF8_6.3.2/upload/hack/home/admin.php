<?php
!function_exists('adminmsg') && exit('Forbidden');

if(!$action){
	$home  = $ads = $mode = array();
	$query = $db->query("SELECT id,name,title,position,vieworder,ifopen FROM pw_home ORDER BY position,vieworder");
	while($rt=$db->fetch_array($query)){
		!$rt['title'] && $rt['title'] = $rt['name'];
		if($rt['ifopen']){
			$home[$rt['position']][] = $rt;
		}
		if(substr($rt['name'],0,4)=='ads_'){
			$ads[] = $rt;
		} elseif(strpos($rt['name'],'_')===false){
			$mode[] = $rt;
		}
	}
	$ajaxurl = EncodeUrl($basename);
	include PrintHack('admin');
	$output = ob_get_contents();
	$output = str_replace(array('<!--<!---->','<!---->'),array('',''),ob_get_contents());
	ob_end_clean();
	$db_obstart && function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	echo $output;exit;
} elseif($action=='save'){
	InitGP(array('p'));
	header("Content-Type: text/html; charset=utf-8");
	require_once(R_P.'require/ajaxfunc.php');
	$db->update("UPDATE pw_home SET ifopen='0'");
	foreach($p as $key=>$value){
		$p1 = explode(',',$value);
		foreach($p1 as $k=>$v){
			if($v = substr($v,2)){
				$rt = $db->get_one("SELECT id FROM pw_home WHERE name='$v'");
				if(!$rt){
					$title = '';
					if(substr($v,0,7)=='forums_'){
						$id = substr($v,7);
						$title = $forum[$id]['name'];
					}
					$db->update("INSERT INTO pw_home (name,title,position,vieworder,upstep,ifopen) VALUES('$v','$title','$key','$k','3600','1')");
				} else{
					$db->update("UPDATE pw_home SET position='$key',vieworder='$k',ifopen='1' WHERE name='$v'");
				}
			}
		}
	}
	ajaxmsg('home_save');
} elseif($action=='edit'){
	InitGP(array('type'));
	header("Content-Type: text/html; charset=utf-8");
	require_once(R_P.'require/ajaxfunc.php');

	if(!$_POST['step']){
		$ajaxurl = EncodeUrl($basename."&action=edit");
		$rt = $db->get_one("SELECT name,title,upstep,config,cache FROM pw_home WHERE name='$type'");
		$rt['config'] = $rt['config'] ? unserialize($rt['config']) : array();
		@extract($rt['config']);
		!$rt['title'] && $rt['title'] = $rt['name'];
		include PrintHack('admin');ajax_footer();
	} else{
		InitGP(array('title','upstep','config','cache'));	
		$upstep = (int)$upstep;
		if($db_charset!='utf-8'){
			$title = ajax_convert($title,$db_charset);
			foreach($config as $key=>$value){
				$config[$key] = ajax_convert($value,$db_charset);
			}
			$cache && $cache = ajax_convert($cache,$db_charset);
		}
		if(substr($type,0,4)=='ads_'){
			$sql = ",cache='$cache'";
		} else{
			$config = $config ? addslashes(serialize($config)) : '';
			$sql = ",config='$config'";
		}
		$db->update("UPDATE pw_home SET title='$title',upstep='$upstep' $sql WHERE name='$type'");
		ajaxmsg('operate_success');
	}
} elseif($action=='addads'){
	InitGP(array('type'));
	require_once(R_P.'require/ajaxfunc.php');
	if(!$_POST['step']){
		$ajaxurl = EncodeUrl($basename."&action=addads");
		include PrintHack('admin');ajax_footer();
	} else{
		InitGP(array('id','title','cache'));
		$name = 'ads_'.(int)$id;
		$rt   = $db->get_one("SELECT id FROM pw_home WHERE name='$name'");
		if($rt){
			ajaxmsg('home_add_error');
		}
		if($db_charset!='utf-8'){
			$title = ajax_convert($title,$db_charset);
			$cache = ajax_convert($cache,$db_charset);
		}
		$db->update("INSERT INTO pw_home (name,title,cache) VALUES('$name','$title','$cache')");
		ajaxmsg('home_addads');
	}
} elseif($action=='update'){
	InitGP(array('type'));
	header("Content-Type: text/html; charset=utf-8");
	require_once(R_P.'require/ajaxfunc.php');
	
	if(substr($type,0,4)=='ads_'){
		$db->update("UPDATE pw_home SET ifopen='1' WHERE name='$type'");
	} else{
		require_once(R_P.'hack/home/pw_home.php');
		$home = new HOME();
		$home->update($type);
	}
	ajaxmsg('operate_success');
} elseif($action=="updatecache"){
	InitGP(array('time'));
	!$time && $time = $timestamp;
	
	require_once(R_P.'hack/home/pw_home.php');
	$home = new HOME();

	$query = $db->query("SELECT name FROM pw_home WHERE ifopen='1' AND lastupdate<'$time' AND name NOT LIKE 'ads_%' ORDER BY lastupdate LIMIT 2");
	$goon = 0;
	while($rt = $db->fetch_array($query)){
		$home->update($rt['name']);
		$goon = 1;
	}
	if($goon){
		adminmsg('update_home',"$basename&action=$action&time=$time");
	} else{
		adminmsg('operate_success');
	}
}
function ajaxmsg($msg){
	extract($GLOBALS, EXTR_SKIP);
	require_once GetLang('cpmsg');
	$lang[$msg] && $msg=$lang[$msg];
	echo $msg;ajax_footer();
}
function ObContents($output){
	ob_end_clean();
	$GLOBALS['db_obstart'] && function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	return $output;
}
?>