<?php
!function_exists('readover') && exit('Forbidden');

Class HOME {

	function update($type=''){//���»�������
		global $db,$num,$timestamp;
		if($type == 'all'){
			$query = $db->query("SELECT name,title,config FROM pw_home WHERE ifopen='1'");
		} elseif($type){
			$query = $db->query("SELECT name,title,config FROM pw_home WHERE name='$type'");
		} else{
			$query = $db->query("SELECT name,title,config FROM pw_home WHERE ifopen='1' AND lastupdate<$timestamp-upstep ORDER BY lastupdate ASC LIMIT $num");
		}
		while($rt = $db->fetch_array($query)){
			$config = unserialize($rt['config']);
			if(substr($rt['name'],0,7)=='forums_'){
				$this->forums($rt['name'],$rt['title'],$config);
			} elseif(method_exists($this,$rt['name'])){
				$this->$rt['name']($rt['name'],$rt['title'],$config);
			}
		}
	}

	function eye($name,$title,$config){// �����õ���ģ��
		global $db,$timestamp,$imgpath;
		
		/**   Ĭ������   **/
		$config['nums']<1 && $config['nums'] = 5;
		if(!in_array($config['order'],array('hits','replies','dig'))){
			$config['order'] = 'hits';
		}
		$flashpics   = '';
		$flashlinks  = '';
		$flashtitles = '';
		$extra       = '';

		if($config['tids']){
			$tids = explode(',',$config['tids']);
			foreach($tids as $tid){
				$pw_tmsgs = GetTtable($tid);
				$rt = $db->get_one("SELECT t.tid,t.subject,tm.aid FROM pw_threads t LEFT JOIN $pw_tmsgs tm USING(tid) WHERE t.tid='$tid' AND tm.aid!=''");
				if(!$rt) continue;
				$aid = unserialize($rt['aid']);
				foreach($aid as $key=>$value){
					if($value['type']=='img'){
						$value['attachurl'] = geturl($value['attachurl'],'lf');
						$flashpics   .= $extra.$value['attachurl'][0];
						$flashlinks  .= $extra."read.php?tid=$tid";
						$flashtitles .= $extra.$rt['subject'];
						$extra = '|';
						$config['nums']--;break;
					}
				}
			}
		}
		if($config['nums']>0){
			if($GLOBALS['db_tlist']){
				@extract($db->get_one("SELECT MAX(tid) as mtid FROM pw_threads"));
				$pw_tmsgs = GetTtable($mtid);
			} else{
				$pw_tmsgs = 'pw_tmsgs';
			}
			$sql = $config['time']>0 ? " AND t.postdate>".($timestamp-86400*$config['time']) : '';

			$query = $db->query("SELECT t.tid,t.subject,tm.aid FROM pw_threads t LEFT JOIN $pw_tmsgs tm ON t.tid=tm.tid LEFT JOIN pw_forums f ON t.fid=f.fid WHERE 1 $sql AND t.ifupload='1' AND tm.aid!='' AND f.password='' AND f.allowvisit='' AND f.f_type<>'hidden' ORDER BY $config[order] LIMIT $config[nums]");
			while($rt = $db->fetch_array($query)){
				$aid = unserialize($rt['aid']);
				foreach($aid as $key=>$value){
					if($value['type']=='img'){
						$value['attachurl'] = geturl($value['attachurl'],'lf');
						$flashpics   .= $extra.$value['attachurl'][0];
						$flashlinks  .= $extra."read.php?tid=$rt[tid]";
						$flashtitles .= $extra.$rt['subject'];
						$extra = '|';break;
					}
				}
			}
		}

		$html = "<div id=\"eye\"><h5 class=\"h\"><span class=\"fr gray f10\"></span>$title </h5><div class=\"tac\" style=\"padding-top:10px\">
			<SCRIPT type=text/javascript>
				var focus_width=306;
				var focus_height=190;
				var text_height=20;
				var swf_height = focus_height+text_height;
				var pics='$flashpics';
				var links='$flashlinks';
				var texts='$flashtitles';
				document.write('<object classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" codebase=\"http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0\" width=\"'+ focus_width +'\" height=\"'+ swf_height +'\" wmode=\"transparent\">');
				document.write('<param name=\"allowScriptAccess\" value=\"sameDomain\"><param name=\"movie\" value=\"$imgpath/pic.swf\"><param name=\"quality\" value=\"high\"><param name=\"bgcolor\" value=\"#ffffff\">');
				document.write('<param name=\"menu\" value=\"false\"><param name=wmode value=\"opaque\">');
				document.write('<param name=\"FlashVars\" value=\"pics='+pics+'&links='+links+'&texts='+texts+'&borderwidth='+focus_width+'&borderheight='+focus_height+'&textheight='+text_height+'\">');
				document.write('<embed src=\"$imgpath/pic.swf\" wmode=\"opaque\" FlashVars=\"pics='+pics+'&links='+links+'&texts='+texts+'&borderwidth='+focus_width+'&borderheight='+focus_height+'&textheight='+text_height+'\" menu=\"false\" bgcolor=\"#ffffff\" quality=\"high\" width=\"'+ focus_width +'\" height=\"'+ focus_height +'\" allowScriptAccess=\"sameDomain\" type=\"application/x-shockwave-flash\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" />');
				document.write('</object>');
			</SCRIPT></div></div>";
		$html = addslashes($html);
		$db->update("UPDATE pw_home SET lastupdate='$timestamp',cache='$html' WHERE name='eye'");
	}

	function tags($name,$title,$config){//����tagģ��
		global $db,$timestamp;
		
		/**   Ĭ������   **/
		$config['nums']<1 && $config['nums'] = 25;

		$tagdb = $config['tags'] ? explode(',',$config['tags']) : array();
		$query = $db->query("SELECT tagname FROM pw_tags ORDER BY num DESC LIMIT $config[nums]");
		while($rt = $db->fetch_array($query)){
			if(!in_array($rt['tagname'],$tagdb)){
				$tagdb[] = $rt['tagname'];
			}
		}
		$html = "<div id=\"tags\" class=\"tags\"><h5 class=\"h\">$title</h5><ul>";
		foreach($tagdb as $tag){
			$html .= "<li><a href=\"job.php?action=tag&tagname=".rawurlencode($tag)."\" target=\"_blank\">$tag</a></li>";
		}
		$html .= "</ul></div><div class=\"c\"></div>";
		$html = addslashes($html);
		$db->update("UPDATE pw_home SET lastupdate='$timestamp',cache='$html' WHERE name='tags'");
	}

	function recommend($name,$title,$config){// �Ƽ�����
		global $db,$timestamp,$imgpath,$lang;
		require_once GetLang('other');
		
		/**   Ĭ������   **/
		$config['nums']<1 && $config['nums'] = 15;
		!$config['pic'] && $config['pic'] = "hack/home/image/none.bmp";
		if(!in_array($config['order'],array('hits','replies','dig'))){
			$config['order'] = 'dig';
		}

		$read = array();
		$tids = $this->checktids($config['tids']);
		if($tids){
			$query = $db->query("SELECT tid,subject FROM pw_threads WHERE tid IN($tids)");
			while($rt = $db->fetch_array($query)){
				$read[] = $rt;
			}
		}
		$config['nums'] -= count($read);
		if($config['nums']>0){
			$sql   = $config['time']>0 ? " AND t.postdate>".($timestamp-86400*$config['time']) : '';
			$query = $db->query("SELECT t.tid,t.subject FROM pw_threads t LEFT JOIN pw_forums f ON t.fid=f.fid WHERE 1 $sql AND f.password='' AND f.allowvisit='' AND f.f_type<>'hidden' ORDER BY t.$config[order] LIMIT $config[nums]");
			while($rt = $db->fetch_array($query)){
				$read[] = $rt;
			}
		}
		$readone = $read[0];
		unset($read[0]);
		$pw_tmsgs = GetTtable($readone['tid']);
		$rs = $db->get_one("SELECT content FROM $pw_tmsgs WHERE tid='$readone[tid]'");
		$readone['content'] = substrs($rs['content'],60);

		$html = "<h5 class=\"h\">$title </h5><div><dl class=\"dlA\"><dd class=\"pic\"><img src=\"$config[pic]\" /></dd><dt class=\"h2A\"><a href=\"read.php?tid=$readone[tid]\" class=\"cl1\">$readone[subject]</a></dt><dd class=\"txt\">$readone[content]<div class=\"tar\"><a href=\"read.php?tid=$readone[tid]\">($lang[home_detail])</a></div></dd><dd class=\"c\"></dd></dl></div><div class=\"c\"></div><div><ul class=\"listA\">";

		foreach($read as $value){
			$html .= "<li><a href=\"read.php?tid=$value[tid]\">$value[subject]</a></li>";
		}
		$html .= "</ul></div><div class=\"c\"></div>";

		$html = addslashes($html);
		$db->update("UPDATE pw_home SET lastupdate='$timestamp',cache='$html' WHERE name='recommend'");
	}

	function hottopic($name,$title,$config){//��������
		global $db,$timestamp;
		
		/**   Ĭ������   **/
		$config['nums']<1 && $config['nums'] = 10;
		if(!in_array($config['order'],array('hits','replies','dig'))){
			$config['order'] = 'replies';
		}
		$sql  = $config['time']>0 ? " AND t.postdate>".($timestamp-86400*$config['time']) : '';

		$html = "<div id=\"hottopic\" class=\"remen\"><h5 class=\"h\">$title</h5><ul class=\"listB\">";
		$query = $db->query("SELECT t.tid,t.subject FROM pw_threads t LEFT JOIN pw_forums f ON t.fid=f.fid WHERE 1 $sql AND f.password='' AND f.allowvisit='' AND f.f_type<>'hidden' ORDER BY t.$config[order] LIMIT $config[nums]");
		while($rt = $db->fetch_array($query)){
			$html .= "<li><a href=\"read.php?tid=$rt[tid]\">$rt[subject]</a></li>";
		}
		$html .= "</ul></div>";
		$html = addslashes($html);
		$db->update("UPDATE pw_home SET lastupdate='$timestamp',cache='$html' WHERE name='hottopic'");
	}

	function bbsinfo($name,$title,$config){//վ����Ϣ
		global $db,$imgpath,$timestamp,$lang;
		require_once GetLang('other');
		@include_once(D_P.'data/bbscache/olcache.php');
		$usertotal = $guestinbbs + $userinbbs;

		@extract($db->get_one("SELECT * FROM pw_bbsinfo WHERE id='1'"));
		@extract($db->get_one("SELECT SUM(tpost) AS tposts,SUM(topic) AS threads,SUM(article) AS posts FROM pw_forumdata"));
		$higholtime = get_date($higholtime);
		$html = "<div id=\"bbsinfo\"><h5 class=\"h\">$title </h5><div class=\"boxA\">".str_replace(array("\n",'{$totalmember}','{$newmember}','{$threads}','{$posts}','{$tposts}','{$yposts}','{$hposts}','{$usertotal}','{$userinbbs}','{$guestinbbs}','{$higholnum}','{$higholtime}'),array("<br />",$totalmember,$newmember,$threads,$posts,$tposts,$yposts,$hposts,$usertotal,$userinbbs, $guestinbbs,$higholnum,$higholtime),$config['info'])."</div></div><div class=\"c\"></div>";
		$html = addslashes($html);
		$db->update("UPDATE pw_home SET lastupdate='$timestamp',cache='$html' WHERE name='bbsinfo'");
	}

	function forumsort($name,$title,$config){//������а�
		global $db,$imgpath,$timestamp,$lang;
		require_once GetLang('other');

		/**   Ĭ������   **/
		$config['nums']<1 && $config['nums'] = 10;

		$i    = 1;
		$html = "<div id=\"forumsort\"><h5 class=\"h\">$title </h5><div class=\"boxA\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"paihang\"><tr class=\"tr2\"><td class=\"gray\">{$lang[home_forums]}</td><td class=\"gray\">{$lang[home_posts]}</td></tr>";

		$query  = $db->query("SELECT f.fid,f.name,fd.topic FROM pw_forumdata fd LEFT JOIN pw_forums f USING(fid) WHERE f.password='' AND f.allowvisit='' AND f.f_type<>'hidden' AND f.type<>'category' ORDER BY fd.topic DESC LIMIT $config[nums]");
		while($forums = $db->fetch_array($query)){
			$html .= "<tr><td>";
			$i<4 && $html .= '<span class="cl2">';
			$html .= ($i<10 ? '0' : '').$i.'.';
			$i<4 && $html .= '</span>';
			$forums['name']=strip_tags($forums['name']);
			$fname=substrs($forums['name'],10);
			$html .= "<a href=\"thread.php?fid=$forums[fid]\" title=\"$forums[name]\">$fname</a></td><td class=\"gray\">($forums[topic])</td></tr>";
			$i++;
		}
		$html .= "</table></div></div>";
		$html = addslashes($html);
		$db->update("UPDATE pw_home SET lastupdate='$timestamp',cache='$html' WHERE name='forumsort'");
	}

	function newreply($name,$title,$config){//���»ظ�
		global $db,$imgpath,$timestamp;
		
		/**   Ĭ������   **/
		$config['nums']<1 && $config['nums'] = 15;

		$fids   = '-99';
		$query  = $db->query("SELECT fid FROM pw_forums WHERE password='' AND allowvisit='' AND f_type<>'hidden'");
		while($rt = $db->fetch_array($query)){
			$fids .= ','.$rt['fid'];
		}
		$sql  = $config['time']>0 ? " AND postdate>".($timestamp-86400*$config['time']) : '';
		$html = "<div id=\"newreply\"><h5 class=\"h\">$title </h5><ul class=\"listC\">";

		$query  = $db->query("SELECT tid,subject,postdate FROM pw_threads WHERE fid IN($fids) AND topped<'1' $sql ORDER BY topped,lastpost DESC LIMIT $config[nums]");
		while($rt = $db->fetch_array($query)){
			$html .= "<li><em>".get_date($rt['postdate'],'m-d')."</em><a href=\"read.php?tid=$rt[tid]\" target=\"_blank\">$rt[subject]</a></li>";
		}
		$html .= "</ul></div>";
		$html = addslashes($html);
		$db->update("UPDATE pw_home SET lastupdate='$timestamp',cache='$html' WHERE name='newreply'");
	}

	function newtopic($name,$title,$config){//���·�������
		global $db,$imgpath,$timestamp,$windid,$groupid,$db_anonymousname;

		/**   Ĭ������   **/
		$config['nums']<1 && $config['nums'] = 15;

		$fids   = '-99';
		$query  = $db->query("SELECT fid FROM pw_forums WHERE password='' AND allowvisit='' AND f_type<>'hidden'");
		while($rt = $db->fetch_array($query)){
			$fids .= ','.$rt['fid'];
		}
		$html   = "<div><h5 class=\"h\">$title </h5><ul class=\"listD\">";

		$sql   = $config['time']>0 ? " AND postdate>".($timestamp-86400*$config['time']) : '';
		$query = $db->query("SELECT tid,subject,author,authorid,postdate,anonymous FROM pw_threads WHERE fid IN($fids) $sql ORDER BY postdate DESC LIMIT $config[nums]");
		while($rt = $db->fetch_array($query)){
			if ($rt['anonymous']) {
				$rt['author'] = $db_anonymousname;
				$rt['authorid'] = 0;
			}
			$html .= "<li><em><cite><a class=\"gray\" href=\"profile.php?action=show&uid=$rt[authorid]\">$rt[author]</a></cite>".get_date($rt['postdate'],'m-d')."</em><a href=\"read.php?tid=$rt[tid]\">$rt[subject]</a></li>";
		}
		$html .= "</ul></div>";
		$html = addslashes($html);
		$db->update("UPDATE pw_home SET lastupdate='$timestamp',cache='$html' WHERE name='newtopic'");
	}

	function usersort($name,$title,$config){//��Ա�������а�
		global $db,$imgpath,$timestamp,$lang;
		require_once GetLang('other');
		
		/**   Ĭ������   **/
		$config['nums']<1 && $config['nums'] = 10;
		if(!in_array($config['order'],array('postnum','rvrc','money'))){
			$config['order'] = 'postnum';
		}

		$i    = 1;
		$html = "<div id=\"usersort\"><h5 class=\"h\">$title </h5><div class=\"boxA\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" class=\"paihang\"><tr class=\"tr2\"><td class=\"gray\">{$lang[home_user]}</td><td class=\"gray\">".$lang['home_'.$config['order']]."</td></tr>";

		$query = $db->query("SELECT m.uid,m.username,md.$config[order] FROM pw_memberdata md LEFT JOIN pw_members m USING(uid) ORDER BY md.$config[order] DESC LIMIT $config[nums]");
		while($men = $db->fetch_array($query)){
			$config['order'] == 'rvrc' && $men[$config['order']] = floor($men[$config['order']]/10);
			$html .= "<tr><td>";
			$i<4 && $html .= '<span class="cl2">';
			$html .= ($i<10 ? '0' : '').$i.'.';
			$i<4 && $html .= '</span>';
			$html .= "<a href=\"profile.php?action=show&uid=$men[uid]\">$men[username]</a></td><td class=\"gray\">({$men[$config[order]]})</td></tr>";
			$i++;
		}
		$html .= "</table></div></div>";
		$html = addslashes($html);
		$db->update("UPDATE pw_home SET lastupdate='$timestamp',cache='$html' WHERE name='usersort'");
	}

	function forums($name,$title,$config){//�����Ϣ����
		global $db,$imgpath,$timestamp,$lang;
		require_once GetLang('other');

		/**   Ĭ������   **/
		$config['nums']<1 && $config['nums'] = 10;
		!$config['pic'] && $config['pic'] = "hack/home/image/none.bmp";
		$fid = substr($name,7);
		
		$sql   = $config['time']>0 ? " AND postdate>".($timestamp-86400*$config['time']) : '';
		$read  = array();
		$query = $db->query("SELECT tid,subject,postdate FROM pw_threads WHERE fid='$fid' $sql ORDER BY postdate DESC LIMIT $config[nums]");
		while($rt = $db->fetch_array($query)){
			$read[] = $rt;
		}
		$readone = $read[0];
		unset($read[0]);
		$pw_tmsgs = GetTtable($readone['tid']);
		$rs = $db->get_one("SELECT content FROM $pw_tmsgs WHERE tid='$readone[tid]'");
		$readone['content'] = substrs(strip_tags($rs['content']),60);
		$html = "<div id=\"forums_$fid\"><h5 class=\"h\"><a href=\"thread.php?fid=$fid\" class=\"fr fn cl4\"><img src=\"hack/home/image/dotE.gif\" /> {$lang[home_more]}</a>{$title}</h5><dl class=\"dlB\"><dd class=\"pic\"><img src=\"$config[pic]\" /></dd><dt class=\"b\"><a href=\"read.php?tid=$readone[tid]\" class=\"cl3\">$readone[subject]</a></dt><dd class=\"txt\">$readone[content]<div class=\"tar\"><a href=\"read.php?tid=$readone[tid]\">({$lang[home_detail]})</a></div></dd></dl><div class=\"c\"></div><ul class=\"listC listE\">";

		foreach($read as $key=>$value){
			$html .= "<li><em>".get_date($value['postdate'],'m-d')."</em><a href=\"read.php?tid=$value[tid]\" target=\"_blank\">$value[subject]</a></li>";
		}
		$html .= "</ul></div>";
		$html = addslashes($html);
		$db->update("UPDATE pw_home SET lastupdate='$timestamp',cache='$html' WHERE name='$name'");
	}

	function checktids($tids){
		$t = '';
		$s = explode(',',$tids);
		foreach($s as $v){
			is_numeric($v) && $t .= $t ? ','.$v : $v;
		}
		return $t;
	}
}
?>