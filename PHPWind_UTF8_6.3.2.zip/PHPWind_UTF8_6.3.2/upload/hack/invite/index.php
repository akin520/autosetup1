<?php
!function_exists('readover') && exit('Forbidden');
require_once(R_P."require/forum.php");
include_once(D_P."data/bbscache/inv_config.php");

$inv_open!='1' && Showmsg('inv_close');

InitGP(array('action'));

if (!$windid && !in_array($action,array('pay','alipay'))) {
	Showmsg('not_login');
}
list($db_moneyname,$db_moneyunit,$db_rvrcname,$db_rvrcunit,$db_creditname,$db_creditunit)=explode("\t",$db_credits);

$usrecredit = ${'db_'.$inv_credit.'name'};
$creditto = array(
	'rvrc'    => $userrvrc,
	'money'   => $winddb['money'],
	'credit'  => $winddb['credit'],
	'currency'=> $winddb['currency']
);
!array_key_exists($inv_credit,$creditto) && exit('Forbidden');

$allowinvite = allowcheck($inv_groups,$groupid,$winddb['groups']) ? 1 : 0;

if (empty($action)) {
	$page = GetGP('page');
	$db_perpage = 10;
	(!is_numeric($page) || $page<1) && $page = 1;
	$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
	$rt    = $db->get_one("SELECT COUNT(*) AS sum FROM pw_invitecode WHERE uid='$winduid'");
	$pages = numofpage($rt['sum'],$page,ceil($rt['sum']/$db_perpage),"$basename&");

	$query = $db->query("SELECT * FROM pw_invitecode WHERE uid='$winduid' ORDER BY id DESC $limit");
	$invdb = array();
	while ($rt=$db->fetch_array($query)) {
		$rt['uselate']=0;
		if ($rt['ifused']!=2 && $timestamp-$rt['createtime']>$inv_days*86400) {
			$rt['uselate']=1;
		}
		$rt['createtime'] = get_date($rt['createtime'],'Y-m-d H:i:s');
		$rt['usetime'] = $rt['usetime'] ? get_date($rt['usetime'],'Y-m-d H:i:s') : '';
		$invdb[] = $rt;
	}
	require_once PrintHack('index');footer();

} elseif ($action=='send') {

	if (!$_POST['step']) {

		$inv_dayss = $inv_days*86400;
		InitGP(array('id'));
		if ($id) {
			$invcode = $db->get_one("SELECT * FROM pw_invitecode WHERE id='$id' AND ifused='0' AND uid='$winduid'");
			if ($timestamp-$invcode['createtime']>$inv_dayss) {
				Showmsg('days_limit');
			}
		} else {
			$invcode = $db->get_one("SELECT * FROM pw_invitecode WHERE uid='$winduid' AND ifused='0' AND $timestamp-createtime<'$inv_dayss' ORDER BY id ASC limit 0,1");
		}
		!$invcode && Showmsg('invcode_error');
		include GetLang('other');
		$subject = $lang['invite'];
		$atc_content = $lang['invite_content'];
		require_once PrintHack('index');footer();

	} elseif ($_POST['step']=='3') {

		InitGP(array('id','subject','atc_content','sendtoemail'),'P');
		if (empty($subject)) {
			Showmsg('sendeamil_subject_limit');
		}
		if (empty($atc_content) || strlen($atc_content)<=20) {
			Showmsg('sendeamil_content_limit');
		} elseif (!ereg("^[-a-zA-Z0-9_\.]+\@([0-9A-Za-z][0-9A-Za-z-]+\.)+[A-Za-z]{2,5}$",$sendtoemail)){
			Showmsg('illegal_email');
		}
		require_once(R_P.'require/sendemail.php');
		$additional = "From:{$winddb[email]}\r\nReply-To:{$winddb[email]}\r\nX-Mailer: PHPWind mailer";
		$sendinfo = sendemail($sendtoemail,$subject,$atc_content,$additional);
		if ($sendinfo === true) {
			$db->update("UPDATE pw_invitecode SET ifused='1' WHERE id='$id' AND uid='$winduid'");
			refreshto($basename,'mail_success');
		} else {
			Showmsg('mail_failed');
		}
	}
} elseif ($action=='buy') {

	$allowinvite==0 && Showmsg('group_invite');
	if ($inv_limitdays) {
		$rt = $db->get_one("SELECT createtime FROM pw_invitecode WHERE uid='$winduid' ORDER BY createtime DESC LIMIT 0,1");
		if ($timestamp-$rt['createtime']<$inv_limitdays*86400) {
			Showmsg('inv_limitdays');
		}
	}
	if (!$_POST['step']) {

		require_once PrintHack('index');footer();

	} else {

		InitGP(array('invnum'),'P');
		(!is_numeric($invnum) || $invnum<1) && $invnum=1;
		if ($invnum>10) {
			Showmsg('invite_buy');
		}
		if ($creditto[$inv_credit]<$invnum*$inv_costs) {
			Showmsg('invite_costs');
		}
		for ($i=0;$i<$invnum;$i++) {
			$invcode=randstr(16);
			$db->update("INSERT INTO pw_invitecode(invcode,uid,createtime) VALUES ('$invcode','$winduid','$timestamp')");
		}
		$cutcredit=$invnum*$inv_costs;
		$inv_credit=='rvrc' && $cutcredit*=10;
		$db->update("UPDATE pw_memberdata SET $inv_credit=$inv_credit-'$cutcredit' WHERE uid='$winduid'");
		refreshto($basename,'operate_success');
	}
} elseif ($_POST['action']=='delete') {

	InitGP(array('selid'),'P');
	(!$selid || !is_array($selid)) && Showmsg('del_error');
	$delids = '';
	foreach ($selid as $value) {
		is_numeric($value) && $delids.= $delids ? ','.$value : $value;
	}
	$db->update("DELETE FROM pw_invitecode WHERE id IN ($delids) AND uid='$winduid'");
	refreshto($basename,'operate_success');

} elseif ($action == 'pay') {

	empty($inv_onlinesell) && Showmsg('invite_onlinesell');
	include_once(D_P.'data/bbscache/ol_config.php');

	if (empty($_POST['step'])) {

		$num	= 1;
		$email	= '';
		require_once PrintHack('index');footer();

	} else {

		InitGP(array('invnum','email','method'));
		include GetLang('other');

		(!is_numeric($invnum) || $invnum<1) && $invnum = 1;
		$order_no = ($method-1).str_pad('0',10,"0",STR_PAD_LEFT).get_date($timestamp,'YmdHis').num_rand(5);

		$rt = $db->get_one("SELECT * FROM pw_clientorder WHERE payemail='$email' AND uid='0' AND state='0'");

		if ($rt) {
			if (!isset($_POST['submit'])) {
				$num	= $rt['number'];
				$email	= $rt['payemail'];
				require_once PrintHack('index');footer();
			}
			$db->Update("UPDATE pw_clientorder SET order_no='$order_no',number='$invnum' WHERE id='$rt[id]'");
		} else {
			$db->update("INSERT INTO pw_clientorder(order_no,uid,subject,body,price,payemail,number,date,state,descrip) VALUES('$order_no','0','$lang[invitecode]','$lang[buy_invitecode]','$inv_price','$email','$invnum','$timestamp','0','$lang[unpay_list]')");
		}

		switch ($method) {
			case 2 :
				if (!$ol_payto) {
					Showmsg('olpay_alipayerror');
				}
				$url  = "http://pay.phpwind.com/pay/create_payurl.php?";
				$para = array(
					'_input_charset'=> $db_charset,
					'service'		=> 'create_direct_pay_by_user',
					'return_url'	=> "{$db_bbsurl}/hack.php?H_name=invite&action=alipay",
					'payment_type'	=> '1',
					'subject'		=> $lang['invitecode'],
					'body'			=> $lang['buy_invitecode'],
					'out_trade_no'	=> $order_no,
					'total_fee'		=> $invnum * $inv_price,
					'seller_email'	=> $ol_payto,
				);
				$arg = '';
				foreach ($para as $key => $value) {
					if ($value) {
						$url  .= "$key=".urlencode($value)."&";
					}
				}
				ObHeader($url);
			case 4 :
				if(!$ol_tenpay || !$ol_tenpaycode){
					Showmsg('olpay_tenpayerror');
				}
				$strBillDate = get_date($timestamp,'Ymd');
				$strSpBillNo = substr($order_no,-10);
				$strTransactionId = $ol_tenpay.$strBillDate.$strSpBillNo;
				$db->update("UPDATE pw_clientorder SET order_no='$strTransactionId' WHERE order_no='$order_no'");
				$url  = "http://pay.phpwind.com/pay/create_payurl.php?";
				$para = array(
					'cmdno' => '1',
					'date' => $strBillDate,
					'bargainor_id' => $ol_tenpay,
					'transaction_id' => $strTransactionId,
					'sp_billno' => $strSpBillNo,
					'total_fee' => $invnum*$inv_price*100,
					'bank_type' => 0,
					'fee_type' => 1,
					'return_url' => "{$db_bbsurl}/hack.php?H_name=invite&action=tenpay",
					'attach' => 'my_magic_string',
				);
				$arg='';
				foreach($para as $key => $value){
					if($value){
						$url .= "$key=".urlencode($value)."&";
						$arg .= "$key=$value&";
					}
				}
				$strSign = strtoupper(md5($arg."key=$ol_tenpaycode"));
				$url .= "desc=$lang[currency]&sign=$strSign";
				ObHeader($url);
		}
		Showmsg('undefined_action');
	}
} elseif ($action == 'alipay') {
	include_once(D_P.'data/bbscache/ol_config.php');
	if (!$ol_onlinepay) {
		Showmsg($ol_whycolse);
	}
	if (!$ol_payto) {
		Showmsg('olpay_seterror');
	}
	InitGP(array('out_trade_no','trade_status','buyer_email','notify_id'));
	$veryfy_result = get_verify("http://notify.alipay.com/trade/notify_query.do?notify_id=$notify_id&partner=2088001505801569");
	if (!eregi("true$",$veryfy_result)) {
		refreshto('userpay.php','��ȫ��֤����У��ʧ�ܣ��޷���ɳ�ֵ��');
	}

	$rt = $db->get_one("SELECT * FROM pw_clientorder WHERE order_no='$out_trade_no'");
	if (!$rt) {
		refreshto('userpay.php','ϵͳ��û�����ĳ�ֵ�������޷���ɳ�ֵ��');
	}
	if ($trade_status == 'TRADE_FINISHED') {
		if ($rt['state'] == 2) {
			refreshto('userpay.php','�ö����Ѿ���ֵ�ɹ���');
		}
		$db->update("UPDATE pw_clientorder SET payemail='$buyer_email',state=2,descrip='����ɶ���' WHERE order_no='$out_trade_no'");

		$invcodes = '';
		for ($i=0;$i<$rt['number'];$i++) {
			$invcode = randstr(16);
			$invcodes .= ($invcodes ? "\n" : '').$invcode;
			$db->update("INSERT INTO pw_invitecode(invcode,uid,createtime) VALUES ('$invcode','0','$timestamp')");
		}

		require_once(R_P.'require/sendemail.php');
		$sendinfo = sendemail($rt['payemail'],'email_invite_subject','email_invite_content','email_additional');

		if ($sendinfo === true) {
			Showmsg('email_invite_success',1);
		} else {
			Showmsg(is_string($sendinfo) ? $sendinfo : 'email_fail',1);
		}
	} else {
		refreshto('index.php','֧��ʧ�ܣ��޷���ɳ�ֵ��');
	}
} elseif ($action == 'alipay') {
	include_once(D_P.'data/bbscache/ol_config.php');
	if(!$ol_onlinepay){
		Showmsg($ol_whycolse);
	}
	if(!$ol_tenpay || !$ol_tenpaycode){
		Showmsg('olpay_tenpayerror');
	}
	
	InitGP(array('cmdno','pay_result','date','bargainor_id','transaction_id','sp_billno','total_fee','fee_type','attach','sign'));
	
	$text = "cmdno=$cmdno&pay_result=$pay_result&date=$date&transaction_id=$transaction_id&sp_billno=$sp_billno&total_fee=$total_fee&fee_type=$fee_type&attach=$attach&key=$ol_tenpaycode";
	$mac = strtoupper(md5($text));     
	
	if($mac != $sign){
		Showmsg( "��֤MD5ǩ��ʧ��"); 
	}  
	if( $ol_tenpay != $bargainor_id ){
		Showmsg( "������̻���"); 
	}
	if($pay_result != "0" ){
		Showmsg( "֧��ʧ��"); 
	}
	
	$rt = $db->get_one("SELECT * FROM pw_clientorder WHERE order_no='$transaction_id'");
	if(!$rt){
		refreshto('userpay.php','ϵͳ��û�����ĳ�ֵ�������޷���ɳ�ֵ��');
	}
	if($rt['state'] == 2){
		refreshto('userpay.php','�ö����Ѿ���ֵ�ɹ���');
	}
	$db->update("UPDATE pw_clientorder SET payemail='$buyer_email',state=2,descrip='����ɶ���' WHERE order_no='$transaction_id'");
	
	$invcodes = '';
	for ($i=0;$i<$rt['number'];$i++) {
		$invcode = randstr(16);
		$invcodes .= ($invcodes ? "\n" : '').$invcode;
		$db->update("INSERT INTO pw_invitecode(invcode,uid,createtime) VALUES ('$invcode','0','$timestamp')");
	}

	require_once(R_P.'require/sendemail.php');
	$sendinfo = sendemail($rt['payemail'],'email_invite_subject','email_invite_content','email_additional');

	if ($sendinfo === true) {
		Showmsg('email_invite_success',1);
	} else {
		Showmsg(is_string($sendinfo) ? $sendinfo : 'email_fail',1);
	}
}

function get_verify($url,$time_out='60'){
	$urlarr= parse_url($url);
	$errno = $errstr = '';
	$urlarr['port'] = '80';
	$fp = @fsockopen('tcp://'.$urlarr['host'],$urlarr['port'],$errno,$errstr,$time_out);
	if (!$fp) {
		die("ERROR: $errno - $errstr<br />\n");
	} else {
		fputs($fp, 'POST '.$urlarr['path']." HTTP/1.1\r\n");
		fputs($fp, 'Host: '.$urlarr['host']."\r\n");
		fputs($fp, "Content-type: application/x-www-form-urlencoded\r\n");
		fputs($fp, 'Content-length: '.strlen($urlarr['query'])."\r\n");
		fputs($fp, "Connection: close\r\n\r\n");
		fputs($fp, $urlarr['query'] . "\r\n\r\n");
		while (!feof($fp)) {
			$info[] = @fgets($fp, 1024);
		}
		fclose($fp);
		$info = implode(',',$info);
		return $info;
	}
}
?>