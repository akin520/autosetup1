<?php
!function_exists('adminmsg') && exit('Forbidden');

$rt = $db->get_one("SELECT ifopen,nexttime FROM pw_plan WHERE filename='team'");

if (empty($action)) {

	require_once(R_P.'require/credit.php');
	@include_once(D_P.'data/bbscache/tm_config.php');
	ifcheck($rt['ifopen'],'ifopen');
	ifcheck($_tmconf['ifmsg'],'ifmsg');
	ifcheck($_tmconf['arouse'],'arouse');
	$nexttime = get_date($rt['nexttime']);
	
	$query = $db->query("SELECT gid,grouptitle FROM pw_usergroups WHERE gptype='system' AND gid NOT IN(6,7)");
	$group = array();
	while ($rs = $db->fetch_array($query)) {
		$group[] = $rs;
	}
	$creditType = GetCreditType();

	include PrintHack('admin');exit;

} elseif ($action=='sort') {

	require_once(R_P.'require/credit.php');
	@include_once(D_P.'data/bbscache/tm_config.php');
	
	$hours	 = gmdate('G',$timestamp+$db_timedf*3600);
	$tddays  = get_date($timestamp,'j');
	$tdtime	 = (floor($timestamp/3600)-$hours)*3600;
	$montime = $tdtime-($tddays-1)*86400;
	
	$creditType = GetCreditType();

	$gids = 0;
	if (!empty($_tmconf['group'])) {
		$gids = implode(',',$_tmconf['group']);
	}
	$admindb = array();
	$query = $db->query("SELECT m.uid,m.username,m.groupid,md.monthpost,md.monoltime,md.lastvisit,md.lastpost FROM pw_members m LEFT JOIN pw_memberdata md USING(uid) WHERE groupid IN($gids) ORDER BY groupid");

	while ($rs = $db->fetch_array($query)) {
		$rs['lastvisit'] < $montime && $rs['monoltime'] = 0;
		$rs['lastpost']  < $montime && $rs['monthpost'] = 0;
		$admindb[$rs['username']] = array(
			'uid'		=> $rs['uid'],
			'groupid'	=> $rs['groupid'],
			'monoltime'	=> round($rs['monoltime']/3600),
			'monthpost'	=> $rs['monthpost'],
			'total'		=> 0
		);
	}
	$query = $db->query("SELECT COUNT(*) AS count,username2 AS manager FROM pw_adminlog WHERE timestamp>'$montime' GROUP BY username2");

	while ($rs = $db->fetch_array($query)) {
		if (isset($admindb[$rs['manager']])) {
			$admindb[$rs['manager']]['total'] = $rs['count'];
		}
	}
	foreach ($admindb as $key=>$value) {
		$gid = $value['groupid'];
		$admindb[$key]['assess'] = $value['total'] * $_tmconf['param']['opr'] + $value['monoltime'] * $_tmconf['param']['oltime'] + $value['monthpost'] * $_tmconf['param']['post'];
		$admindb[$key]['wages'] = $_tmconf['wages'][$gid];
		foreach ($admindb[$key]['wages'] as $k=>$v) {
			$admindb[$key]['wages'][$k] += round($admindb[$key]['assess'] * $_tmconf['bonus'][$k]);
		}
	}

	include PrintHack('admin');exit;

} elseif ($_POST['action']=='set') {

	InitGP(array('set','ifopen'));

	foreach ($set['wages'] as $k=>$value) {
		if (!in_array($k,$set['group'])) {
			unset($set['wages'][$k]);
		}
	}
	$set = addslashes(serialize($set));
	$db->Update("REPLACE INTO pw_hack (hk_name,hk_value) VALUES ('tm_setting','$set')");

	updatecache_tm();

	if ($rt['ifopen'] != $ifopen) {
		if ($ifopen && $rt['nexttime'] < $timestamp) {
			adminmsg('tm_error');
		}
		$db->Update("UPDATE pw_plan SET ifopen='$ifopen' WHERE filename='team'");
		updatecache_plan();
	}

	adminmsg('operate_success');

} elseif ($_POST['action']=='payoff') {
	
	InitGP(array('credit','arouse'));
	@include_once(D_P.'data/bbscache/tm_config.php');
	require_once(R_P.'require/credit.php');

	$creditType = GetCreditType();

	$gids = 0;
	if (!empty($_tmconf['group'])) {
		$gids = implode(',',$_tmconf['group']);
	}
	$admindb = array();
	$query = $db->query("SELECT uid,username FROM pw_members WHERE groupid IN($gids)");
	while ($rt = $db->fetch_array($query)) {
		$admindb[$rt['uid']] = $rt['username'];
	}
	$msg_a = array();
	$msgdata = Char_cv($_tmconf['msgdata']);
	$arousemsg = Char_cv($_tmconf['arousemsg']);

	foreach ($credit as $uid => $value) {
		$a_sql = $addcredit = '';
		foreach ($value as $k => $v) {
			if (empty($v) || !is_numeric($v)) continue;
			
			$addcredit .= ($addcredit ? ',' : '')."[color=#0000ff]{$v}[/color]".$creditType[$k];
			if (is_numeric($k)) {
				$db->pw_update(
					"SELECT value FROM pw_membercredit WHERE uid='$uid' AND cid='$k'",
					"UPDATE pw_membercredit SET value=value+'$v' WHERE uid='$uid' AND cid='$k'",
					"INSERT INTO pw_membercredit (uid,cid,value) VALUES ('$uid','$k','$value')"
				);
			} else {
				$k == 'rvrc' && $v *= 10;
				$a_sql .= ($a_sql ? ',' : '')."$k=$k+'$v'";
			}
		}
		if (!empty($a_sql)) {
			$db->update("UPDATE pw_memberdata SET $a_sql WHERE uid='$uid'");
			if ($_tmconf['arouse'] && in_array($uid,$arouse) || $_tmconf['ifmsg']) {
				$msg_a[] = array($uid,'0','SYSTEM','rebox','1',$timestamp,$_tmconf['msgtitle'], str_replace(array('$username','$db_bbsname','$credit','$time'),array($admindb[$uid],$db_bbsname,$addcredit,get_date($timestamp)),($_tmconf['arouse'] && in_array($uid,$arouse)) ? $arousemsg : $msgdata));
			}
		}
	}
	if ($msg_a) {
		require_once(R_P.'require/msg.php');
		send_msgc($msg_a);
	}

	adminmsg('operate_success');
}

function updatecache_tm() {
	global $db;
	$rs = $db->get_one("SELECT hk_value FROM pw_hack WHERE hk_name='tm_setting'");
	$ar = (array)unserialize($rs['hk_value']);
	writeover(D_P.'data/bbscache/tm_config.php',"<?php\r\n\$_tmconf=".pw_var_export($ar).";\r\n?>");
}
?>