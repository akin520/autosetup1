<?php
!function_exists('adminmsg') && exit('Forbidden');

require_once(R_P.'require/credit.php');
$CreditType = GetCreditType();

if(!$job){
	$basename="$admin_file?adminjob=hack&hackset=toolcenter";
	if(!$_POST['step']){
		ifcheck($db_toolifopen,'toolifopen');
		ifcheck($db_allowtrade,'allowtrade');
		include PrintHack('admin');exit;
	} else{
		InitGP(array('toolifopen','allowtrade'),'P');
		$db->pw_update(
			"SELECT db_name FROM pw_config WHERE db_name='db_toolifopen'",
			"UPDATE pw_config SET db_value='$toolifopen' WHERE db_name='db_toolifopen'",
			"INSERT INTO pw_config SET db_value='$toolifopen',db_name='db_toolifopen'"
		);
		$db->pw_update(
			"SELECT db_name FROM pw_config WHERE db_name='db_allowtrade'",
			"UPDATE pw_config SET db_value='$allowtrade' WHERE db_name='db_allowtrade'",
			"INSERT INTO pw_config SET db_value='$allowtrade',db_name='db_allowtrade'"
		);
		updatecache_c();
		adminmsg('operate_success');
	}
} elseif($job=='toolinfo'){
	$basename="$admin_file?adminjob=hack&hackset=toolcenter&job=toolinfo";
	if(!$action){
		$query = $db->query("SELECT * FROM pw_tools");
		while($rt = $db->fetch_array($query)){
			!$rt['creditype'] && $rt['creditype'] = 'currency';
			$tooldb[] = $rt;
		}
		include PrintHack('admin');exit;
	} elseif($action == 'submit'){
		InitGP(array('tools'),'P');
		$toolids = 0;
		if(is_array($tools)){
			foreach($tools as $key => $value){
				is_numeric($key) && $toolids .= ','.$key;
			}
		}
		if($toolids){
			$db->update("UPDATE pw_tools SET state='1' WHERE id IN($toolids)");
			$db->update("UPDATE pw_tools SET state='0' WHERE id NOT IN($toolids)");
		} else{
			$db->update("UPDATE pw_tools SET state='0'");
		}
		adminmsg('operate_success');
	} elseif($action == 'edit' || $action == 'add'){
		if(!$_POST['step']){
			if($action == 'edit'){
				InitGP(array('id'));
				$rt = $db->get_one("SELECT * FROM pw_tools WHERE id='$id'");
				!$rt && adminmsg('operate_fail');
			} else{
				$rt = array();
			}
			!$rt['creditype'] && $rt['creditype'] = 'currency';
			$condition = unserialize($rt['conditions']);
			$groupids  = $condition['group'];
			$fids      = $condition['forum'];
			ifcheck($rt['state'],'state');
			${'type_'.$rt['type']} = 'checked';
			foreach($condition['credit'] as $key => $value){
				$key == 'rvrc' && $value /= 10;
				$condition['credit'][$key] = (int)$value;
			}
			$CreditList = '';
			foreach($CreditType as $key=>$value){
				$CreditList	.= "<option value=\"$key\"".($rt['creditype']==$key ? ' selected' : '').">$value</option>";
			}
			$usergroup  = "<table cellspacing='0' cellpadding='0' border='0' width='100%' align='center'><tr>";
			foreach($ltitle as $key=>$value){
				if($key != 1 && $key != 2){
					$num++;
					$htm_tr = $num%5 == 0 ?  '</tr><tr>' : '';
					if(strpos($groupids,','.$key.',') !== false){
						$checked = 'checked';
					} else{
						$checked = '';
					}
					$usergroup .=" <td width='20%'><input type='checkbox' name='groupids[]' value='$key' $checked>$value</td>$htm_tr";
				}
			}
			$usergroup .= "</tr></table>";

			$num        = 0;
			$forumcheck = "<table cellspacing='0' cellpadding='0' border='0' width='100%' align='center'><tr>";
			$sqladd     = " AND f_type!='hidden' AND cms='0'";
			$query      = $db->query("SELECT fid,name FROM pw_forums WHERE type<>'category' $sqladd");
			while($fm = $db->fetch_array($query)){
				$num ++;
				$htm_tr = $num % 5 == 0 ? '</tr><tr>' : '';
				if(strpos($fids,','.$fm['fid'].',') !== false){
					$checked = 'checked';
				} else{
					$checked = '';
				}
				$forumcheck .= "<td width='20%'><input type='checkbox' name='fids[]' value='$fm[fid]' $checked>$fm[name]</td>$htm_tr";
			}
			$forumcheck.="</tr></table>";
			include PrintHack('admin');exit;
		} else{
			InitGP(array('id','name','filename','vieworder','descrip','logo','state','price','stock','groupids','fids','condition','type','creditype'),'P');
			if($groupids){
				$condition['group'] = ','.implode(',',$groupids).',';
			}
			if($fids){
				$condition['forum'] = ','.implode(',',$fids).',';
			}
			foreach($condition['credit'] as $key => $value){
				$key == 'rvrc' && $value *= 10;
				$condition['credit'][$key] = (int)$value;
			}
			$condition = addslashes(serialize($condition));
			if($action=='edit'){
				$db->update("UPDATE pw_tools SET name='$name',filename='$filename',vieworder='$vieworder',descrip='$descrip',logo='$logo',state='$state',price='$price',creditype='$creditype',type='$type',stock='$stock',conditions='$condition' WHERE id='$id'");
			} else{
				$db->update("INSERT INTO pw_tools SET name='$name',filename='$filename',vieworder='$vieworder',descrip='$descrip',logo='$logo',state='$state',price='$price',creditype='$creditype',type='$type',stock='$stock',conditions='$condition'");
			}
			adminmsg('operate_success');
		}
	}
} elseif($job=='usertool'){
	$basename="$admin_file?adminjob=hack&hackset=toolcenter&job=usertool";
	require_once(R_P."require/forum.php");
	if(!$action || $action == 'search'){
		InitGP(array('username','page'));
		if($action == 'search' && $username){
			$rt     = $db->get_one("SELECT uid FROM pw_members WHERE username='$username'");
			$sqladd = "WHERE u.uid='$rt[uid]'";
		} else{
			$sqladd = '';
		}
		if(!is_numeric($page) || $page<1){
			$page = 1;
		}
		$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
		$rt    = $db->get_one("SELECT COUNT(*) AS sum FROM pw_usertool u $sqladd");
		$sum   = $rt['sum'];
		$total = ceil($sum/$db_perpage);
		$pages = numofpage($sum,$page,$total,"$basename&action=search&username=".rawurlencode($username)."&");

		$tooldb= array();
		$query = $db->query("SELECT u.*,t.name,t.stock,t.price,t.creditype,m.username FROM pw_usertool u LEFT JOIN pw_members m USING(uid) LEFT JOIN pw_tools t ON t.id=u.toolid $sqladd ORDER BY uid $limit");
		while($rt = $db->fetch_array($query)){
			!$rt['creditype'] && $rt['creditype'] = 'currency';
			$tooldb[] = $rt;
		}
		include PrintHack('admin');exit;
	} elseif($action == 'edit'){
		InitGP(array('uid','id'));
		(!is_numeric($uid) || !is_numeric($id)) && adminmsg('numerics_checkfailed');
		if(!$_POST['step']){
			$rt=$db->get_one("SELECT u.*,t.name,t.stock,t.price,m.username FROM pw_usertool u LEFT JOIN pw_members m USING(uid) LEFT JOIN pw_tools t ON t.id=u.toolid WHERE u.uid='$uid' AND u.toolid='$id'");
			!$rt['creditype'] && $rt['creditype'] = 'currency';
			include PrintHack('admin');exit;
		} else{
			InitGP(array('nums','sellnums','sellprice'));
			$db->update("UPDATE pw_usertool SET nums='$nums',sellnums='$sellnums',sellprice='$sellprice' WHERE uid='$uid' AND toolid='$id'");
			adminmsg('operate_success');
		}
	} elseif($action == 'del'){
		InitGP(array('uid','id'));
		(!is_numeric($uid) || !is_numeric($id)) && adminmsg('numerics_checkfailed');
		$db->update("DELETE FROM pw_usertool WHERE uid='$uid' AND toolid='$id'");
		adminmsg('operate_success');
	}
} elseif($job=='tradelog'){
	$basename="$admin_file?adminjob=hack&hackset=toolcenter&job=tradelog";
	require_once(R_P."require/forum.php");
	InitGP(array('username','page'));
	if($action == 'search' && $username){
		$rt     = $db->get_one("SELECT uid FROM pw_members WHERE username='$username'");
		$sqladd = "AND u.uid='$rt[uid]'";
	} else{
		$sqladd = '';
	}
	if(!is_numeric($page) || $page<1){
		$page = 1;
	}
	$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
	$rt    = $db->get_one("SELECT COUNT(*) AS sum FROM pw_usertool u WHERE sellnums!=0 $sqladd");
	$sum   = $rt['sum'];
	$total = ceil($sum/$db_perpage);
	$pages = numofpage($sum,$page,$total,"$basename&action=search&username=".rawurlencode($username)."&");

	$tooldb= array();
	$query = $db->query("SELECT u.*,t.name,t.descrip,t.logo,t.creditype,m.username FROM pw_usertool u LEFT JOIN pw_members m USING(uid) LEFT JOIN pw_tools t ON t.id=u.toolid WHERE sellnums!=0 $sqladd $limit");
	while($rt = $db->fetch_array($query)){
		$rt['descrip']	= substrs($rt['descrip'],45);
		!$rt['creditype'] && $rt['creditype'] = 'currency';
		$tooldb[]		= $rt;
	}
	include PrintHack('admin');exit;
} elseif($job=='toollog'){
	$basename="$admin_file?adminjob=hack&hackset=toolcenter&job=toollog";
	if(empty($action)){
		require_once(R_P."require/forum.php");
		require_once(R_P.'require/bbscode.php');
		InitGP(array('page','keyword'));
		if($keyword){
			$sqladd = "WHERE descrip LIKE '%$keyword%'";
		} else{
			$sqladd = '';
		}
		if(!is_numeric($page) || $page<1){
			$page = 1;
		}
		$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
		$rt    = $db->get_one("SELECT COUNT(*) AS sum FROM pw_toollog $sqladd");
		$sum   = $rt['sum'];
		$total = ceil($sum/$db_perpage);
		$pages = numofpage($sum,$page,$total,"$basename&keyword=".rawurlencode($keyword)."&");
		$logdb = array();
		$query = $db->query("SELECT * FROM pw_toollog $sqladd ORDER BY time DESC $limit");
		while($rt = $db->fetch_array($query)){
			$rt['time']   = get_date($rt['time']);
			$rt['descrip']= convert($rt['descrip'],array());
			$logdb[]      = $rt;
		}
	}elseif($action == 'del'){
		InitGP(array('selid'));
		if(!$selid = checkselid($selid)){
			$basename="javascript:history.go(-1);";
			adminmsg('operate_error');
		}
		$db->update("DELETE FROM pw_toollog WHERE id IN($selid)");
		adminmsg('operate_success');
	}
	include PrintHack('admin');exit;
}
?>