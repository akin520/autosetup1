<?php
!function_exists('readover') && exit('Forbidden');

/****

@name:���տ�
@type:��Ա��
@effect:���ض��û�ʹ�á�

****/
InitGP(array('uid'));
if($tooldb['type']!=2){
	Showmsg('tooluse_type_error');  // �жϵ��������Ƿ����ô���
}
if(!$uid){
	Showmsg('tooluse_nobirther');
}
require_once(R_P.'require/msg.php');
$men = $db->get_one("SELECT username FROM pw_members WHERE uid='$uid'");
if(!$men['username']){
	Showmsg('tooluse_nobirther');
}
$db->update("UPDATE pw_usertool SET nums=nums-1 WHERE uid='$winduid' AND toolid='$toolid'");
$msg = array(
	$men['username'],
	$winduid,
	'birth_title',
	$timestamp,
	'birth_content',
	'N',
	$windid
);
writenewmsg($msg,1);

$logdata = array(
	'type'		=>	'use',
	'descrip'	=>	'tool_16_descrip',
	'uid'		=>	$winduid,
	'username'	=>	$windid,
	'toname'	=>	$men['username'],
	'ip'		=>	$onlineip,
	'time'		=>	$timestamp,
	'toolname'	=>	$tooldb['name'],
	'subject'	=>	$subject,
);

writetoollog($logdata);

Showmsg("�������ĺ��ѷ��������պؿ�");
?>