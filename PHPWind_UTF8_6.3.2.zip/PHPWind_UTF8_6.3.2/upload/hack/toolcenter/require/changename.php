<?php
!function_exists('readover') && exit('Forbidden');

/****

@name:�����û�������
@type:��Ա��
@effect:�ɸ�����������̳���û���

****/

if($tooldb['type']!=2){
	Showmsg('tooluse_type_error');  // �жϵ��������Ƿ����ô���
}
if(!$_POST['step']){
	require_once PrintHack('index');footer();
} else{
	include_once(D_P."data/bbscache/dbreg.php");
	if (isset($rg_namelen)) {
		list($rg_regminname,$rg_regmaxname) = explode("\t",$rg_namelen);
	} else {
		$rg_regminname = 3;
		$rg_regmaxname = 12;
	}
	InitGP(array('pwuser'),'P',1);
	!$pwuser && Showmsg('username_empty');
	if(strlen($pwuser)>$rg_regmaxname || strlen($pwuser)<$rg_regminname){
		Showmsg('reg_username_limit');
	}
	$S_key=array('&',' ',"'",'"','/','*',',','<','>',"\r","\t","\n",'#');
	foreach($S_key as $value){
		if (strpos($pwuser,$value)!==false){
			Showmsg('illegal_username');
		}
	}
	if(!$rg_rglower){
		for($asc=65;$asc<=90;$asc++){
			if(strpos($pwuser,chr($asc))!==false){
				Showmsg('username_limit');
			}
		}
	}
	$pwuser=='guest' && Showmsg('illegal_username');
	$rg_banname=explode(',',$rg_banname);
	foreach($rg_banname as $value){
		if(strpos($pwuser,$value)!==false){
			Showmsg('illegal_username');
		}
	}
	if($pwuser!==Sql_cv($pwuser)){
		Showmsg('illegal_username');
	}
	$rt = $db->get_one("SELECT uid FROM pw_members WHERE username='$pwuser'");
	if($rt['uid']){
		Showmsg('username_same');
	}
	$db->update("UPDATE pw_members SET username='$pwuser' WHERE uid='$winduid'");
	$db->update("UPDATE pw_threads SET author='$pwuser' WHERE authorid='$winduid'");
	$ptable_a=array('pw_posts');
	if($db_plist){
		$p_list=explode(',',$db_plist);
		foreach($p_list as $val){
			$ptable_a[]='pw_posts'.(int)$val;
		}
	}
	foreach($ptable_a as $val){
		$db->update("UPDATE $val SET author='$pwuser' WHERE authorid='$winduid'");
	}
	$db->update("UPDATE pw_cmembers SET username='$pwuser' WHERE uid='$winduid'");
	$db->update("UPDATE pw_argument SET author='$pwuser' WHERE authorid='$winduid'");
	$db->update("UPDATE pw_colonys SET admin='$pwuser' WHERE admin='$windid'");
	$db->update("UPDATE pw_announce SET author='$pwuser' WHERE author='$windid'");

	$query = $db->query("SELECT fid,forumadmin,fupadmin FROM pw_forums WHERE forumadmin LIKE '%,".addslashes($windid).",%' OR fupadmin LIKE '%,".addslashes($windid).",%'");
	while($rt = $db->fetch_array($query)){
		$rt['forumadmin']	= str_replace(",$windid,",",$pwuser,",$rt['forumadmin']);
		$rt['fupadmin']		= str_replace(",$windid,",",$pwuser,",$rt['fupadmin']);
		$db->update("UPDATE pw_forums SET forumadmin='".addslashes($rt['forumadmin'])."',fupadmin='".addslashes($rt['fupadmin'])."' WHERE fid='$rt[fid]'");
	}

	$db->update("UPDATE pw_usertool SET nums=nums-1 WHERE uid='$winduid' AND toolid='$toolid'");
	$logdata=array(
		'type'		=>	'use',
		'nums'		=>	'',
		'money'		=>	'',
		'descrip'	=>	'tool_8_descrip',
		'uid'		=>	$winduid,
		'username'	=>	$windid,
		'ip'		=>	$onlineip,
		'time'		=>	$timestamp,
		'toolname'	=>	$tooldb['name'],
		'newname'	=>	$pwuser,
		'tid'		=>	$tid,
	);
	writetoollog($logdata);
	Showmsg('toolmsg_8_success');
}
?>