<?php
!function_exists('readover') && exit('Forbidden');

/****

@name:��ԭ��
@type:��Ա��
@effect:�����ͷ����Ч����

****/
InitGP(array('uid'));
if($tooldb['type']!=2){
	Showmsg('tooluse_type_error');  // �жϵ��������Ƿ����ô���
}
if(!$uid){
	Showmsg('tooluse_nopig');
}
$rt   = $db->get_one("SELECT icon,username FROM pw_members WHERE uid='$uid'");
$user_a=explode('|',addslashes($rt['icon']));
if(empty($user_a[4])){
	Showmsg('tooluse_nousepig');
}else{
	$userface="$user_a[0]|$user_a[1]|$user_a[2]|$user_a[3]";
}
$db->update("UPDATE pw_members SET icon='$userface' WHERE uid='$uid'");
$db->update("UPDATE pw_usertool SET nums=nums-1 WHERE uid='$winduid' AND toolid='$toolid'");
$logdata=array(
	'type'		=>	'use',
	'descrip'	=>	'tool_19_descrip',
	'uid'		=>	$winduid,
	'username'	=>	$windid,
	'toname'	=>	$rt['username'],
	'ip'		=>	$onlineip,
	'time'		=>	$timestamp,
	'toolname'	=>	$tooldb['name'],
);
writetoollog($logdata);
Showmsg('toolmsg_success');
?>