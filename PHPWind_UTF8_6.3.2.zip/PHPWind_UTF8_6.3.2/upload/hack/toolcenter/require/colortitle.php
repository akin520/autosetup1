<?php
!function_exists('readover') && exit('Forbidden');

/****

@name:��������
@type:������
@effect:���Խ��Լ������ӱ��������ʾ

****/

if($tooldb['type']!=1){
	Showmsg('tooluse_type_error');  // �жϵ��������Ƿ����ô���
}

if(!$_POST['step']){
	require_once PrintHack('index');footer();
} else{
	if($tpcdb['authorid'] != $winduid){
		Showmsg('tool_authorlimit');
	}
	InitGP(array('title1','title2','title3','title4','title5','title6'));
	$titlefont = Char_cv("$title1~$title2~$title3~$title4~$title5~$title6~");
	$db->update("UPDATE pw_threads SET titlefont='$titlefont',toolinfo='$tooldb[name]' WHERE tid='$tid'");
	$db->update("UPDATE pw_usertool SET nums=nums-1 WHERE uid='$winduid' AND toolid='$toolid'");
	$logdata=array(
		'type'		=>	'use',
		'nums'		=>	'',
		'money'		=>	'',
		'descrip'	=>	'tool_3_descrip',
		'uid'		=>	$winduid,
		'username'	=>	$windid,
		'ip'		=>	$onlineip,
		'time'		=>	$timestamp,
		'toolname'	=>	$tooldb['name'],
		'subject'	=>	substrs($tpcdb['subject'],15),
		'tid'		=>	$tid,
	);
	writetoollog($logdata);
	Showmsg('toolmsg_success');
}
?>