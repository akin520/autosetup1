<?php
!function_exists('readover') && exit('Forbidden');

/****

@name:͸�Ӿ�
@type:��Ա��
@effect:�鿴�û�IP.

****/
InitGP(array('uid'));
if($tooldb['type']!=2){
	Showmsg('tooluse_type_error');  // �жϵ��������Ƿ����ô���
}
if(!$uid){
	Showmsg('tooluse_noiper');
}
$ipdb='';
$rt  = $db->get_one("SELECT onlineip FROM pw_memberdata WHERE uid='$uid'");
$ipdb=explode('|',$rt['onlineip']);
$db->update("UPDATE pw_usertool SET nums=nums-1 WHERE uid='$winduid' AND toolid='$toolid'");
$logdata=array(
	'type'		=>	'use',
	'descrip'	=>	'tool_20_descrip',
	'uid'		=>	$winduid,
	'username'	=>	$windid,
	'ip'		=>	$onlineip,
	'time'		=>	$timestamp,
	'toolname'	=>	$tooldb['name'],
);
writetoollog($logdata);
Showmsg($ipdb[0]);
?>