<?php
!function_exists('readover') && exit('Forbidden');

/****

@name:���㿨
@type:��Ա��
@effect:�ɽ����Ѹ���������

****/

if($tooldb['type']!=2){
	Showmsg('tooluse_type_error');  // �жϵ��������Ƿ����ô���
}
$rt = $db->get_one("SELECT rvrc FROM pw_memberdata WHERE uid='$winduid'");
if($rt['rvrc'] < 0){
	$db->update("UPDATE pw_memberdata SET rvrc=0 WHERE uid='$winduid'");
	$db->update("UPDATE pw_usertool SET nums=nums-1 WHERE uid='$winduid' AND toolid='$toolid'");
	$logdata=array(
		'type'		=>	'use',
		'nums'		=>	'',
		'money'		=>	'',
		'descrip'	=>	'tool_1_descrip',
		'uid'		=>	$winduid,
		'username'	=>	$windid,
		'ip'		=>	$onlineip,
		'time'		=>	$timestamp,
		'toolname'	=>	$tooldb['name'],
		'from'		=>	'',
	);
	writetoollog($logdata);
	list(,,$db_rvrcname,)=explode("\t",$db_credits);
	Showmsg('toolmsg_1_success');
} else{
	list(,,$db_rvrcname,)=explode("\t",$db_credits);
	Showmsg('toolmsg_1_failed');
}
?>