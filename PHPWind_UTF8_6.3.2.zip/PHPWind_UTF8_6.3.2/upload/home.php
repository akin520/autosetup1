<?php
require_once('global.php');
include_once(D_P.'data/bbscache/forum_cache.php');

if(file_exists(D_P."data/style/$skin.php") && strpos($skin,'..')===false){
	@include Pcv(D_P."data/style/$skin.php");
} elseif(file_exists(D_P."data/style/$db_defaultstyle.php") && strpos($db_defaultstyle,'..')===false){
	@include Pcv(D_P."data/style/$db_defaultstyle.php");
} else{
	@include(D_P."data/style/wind.php");
}
$db_skindb = array();
$fp = opendir(D_P.'data/style/');
while ($skinfile = readdir($fp)) {
	if (preg_match('/([^\.]+?)\.php$/i',$skinfile,$skindb)) {
		$db_skindb[] = $skindb[1];
	}
}
closedir($fp);

/* ��̳���������Сʱ�������ӷ��������ض��� */
$step = 300;

/* ��̳����������������ƣ��ӷ��������ض��� */
$num  = 3;

$lastupdate = $ifupdate = $maxpz = 0;
$cate  = $mode = $forums = array();
$query = $db->query("SELECT name,position,lastupdate,upstep,cache FROM pw_home WHERE ifopen='1' ORDER BY position,vieworder");
while($rt = $db->fetch_array($query)){
	$rt['lastupdate'] > $lastupdate && $lastupdate = $rt['lastupdate'];
	if($timestamp - $rt['lastupdate'] > $rt['upstep']){
		$ifupdate = 1;
	}
	$cate[$rt['position']][] = $rt;
	if(substr($rt['name'],0,7)=='forums_'){
		$fid = substr($rt['name'],7);
		$forums[$fid] = $forum[$fid]['name'];
	}
	$rt['position'] > $maxpz && $maxpz = $rt['position'];
}

if($timestamp - $lastupdate > $step && $ifupdate){
	require_once(R_P.'hack/home/pw_home.php');
	$home = new HOME();
	$home->update();
}
$updatetime = get_date($lastupdate,'H:i');
$ft_time    = get_date($timestamp,'m-d H:i');

@include_once(D_P.'data/bbscache/index_cache.php');
if($db_indexmqshare && $sharelink[1]){
	$sharelink[1]="<marquee scrolldelay=\"100\" scrollamount=\"4\" onmouseout=\"if (document.all!=null){this.start()}\" onmouseover=\"if (document.all!=null){this.stop()}\" behavior=\"alternate\">$sharelink[1]</marquee>";
}
$css_path = D_P."data/style/{$tplpath}_css.htm";
!file_exists($css_path) && $css_path = D_P."data/style/wind_css.htm";

require_once PrintEot('home');

$output = str_replace(array('<!--<!---->','<!---->'),array('',''),ob_get_contents());
ob_end_clean();
$db_obstart && function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
echo $output;exit;
?>