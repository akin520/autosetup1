<?php
define('SCR','index');
$wind_in = 'hm';
require_once('global.php');
if ($db_setindex && strpos($_SERVER['REQUEST_URI'],'/index')===false) {
	require_once(R_P.'home.php');
}
include_once(D_P.'data/bbscache/cache_index.php');
include_once(D_P.'data/bbscache/forum_cache.php');

$ajaxlogin = false;
$sqlwhere = $notice = $index_whosonline = $qcheck = '';
if ($groupid!='guest') {
	require_once(R_P.'require/showimg.php');
	list($faceurl) = showfacedesign($winddb['icon'],1);
	$lastlodate = get_date($winddb['lastvisit'],'Y-m-d');
	$level = $ltitle[$groupid];
} else {
	if ($db_question) {
		list(,$qcheck) = explode("\t",$db_qcheck);
		if ($qcheck) {
			$qkey = array_rand($db_question);
		}
	}
	if ($db_pptifopen || !($db_ajax & 16)) {
		$actionurl = 'action="login.php"';
	} else {
		$ajaxlogin = true;
		$actionurl = 'action="pw_ajax.php?action=login" onsubmit="return ajax_login(this);"';
	}
}
unset($lneed,$lpic);

$cateid = (int)GetGP('cateid');
$forumdb = $catedb = $showsub = $noticedb = array();//��ʼ������
if ($db_forumdir) {
	require_once(R_P.'require/dirname.php');
} elseif ($cateid>0) {
	$catestyle = $forum[$cateid]['style'];
	if ($catestyle && file_exists(D_P."data/style/$catestyle.php")) {
		$skin = $catestyle;
	}
	$metakeyword = strip_tags($forum[$cateid]['name']);
	$subject = $metakeyword.' - ';
	$db_metakeyword = $metakeyword;
	$sqlwhere = "AND (f.fid='$cateid' OR f.fup='$cateid')";
}
if (!$db_showcms) $sqlwhere .= " AND f.cms!='1'";
require_once(R_P.'require/header.php');
//���沿��
foreach ($notice_A as $value) {
	if ($value['startdate']<=$timestamp && (!$value['enddate'] || $value['enddate']>=$timestamp)) {
		$value['startdate'] = get_date($value['startdate'],'y-m-d');
		!$value['url'] && $value['url'] = "notice.php#$value[aid]";
		$noticedb[$value['aid']] = array('url' => $value['url'],'subject' => $value['subject'],'startdate' => $value['startdate']);
	}
}
$notice_A = $noticedb;

$topics = $article = $tposts = $c_htm = 0;
$newpic = (int)GetCookie('newpic');

$query  = $db->query("SELECT f.fid,f.childid,f.fup,f.logo,f.descrip,f.forumadmin,f.across,f.allowhtm,f.password,f.allowvisit,f.showsub,fd.tpost,fd.topic,fd.article,fd.subtopic,fd.top1,fd.lastpost FROM pw_forums f LEFT JOIN pw_forumdata fd USING(fid) WHERE f.ifsub='0' $sqlwhere ORDER BY f.vieworder");
while ($forums = $db->fetch_array($query)) {
	$forums['name'] = $forum[$forums['fid']]['name'];
	$forums['type'] = $forum[$forums['fid']]['type'];
	if ($forums['type']==='category') {
		$forums['deploy_img'] = 'fold';
		$forums['tbody_style'] = $forums['admin'] = '';
		if (strpos($_COOKIE['deploy'],"\t".$forums['fid']."\t")!==false) {
			$forums['deploy_img'] = 'open';
			$forums['tbody_style'] = 'none';
		}
		if ($forums['forumadmin']) {
			$forumadmin = explode(',',$forums['forumadmin']);
			foreach ($forumadmin as $key => $value) {
				if ($value) {
					if ($key==10) {
						$forums['admin'] .= '...';
						break;
					}
					$forums['admin'] .= '<a href="profile.php?action=show&username='.rawurlencode($value)."\" class=\"cfont\">$value</a> ";
				}
			}
		}
		$catedb[] = array('fid' => $forums['fid'],'across' => $forums['across'],'name' => $forums['name'],'admin' => $forums['admin'],'tbody_style' => $forums['tbody_style'],'deploy_img' => $forums['deploy_img']);
	} elseif ($forums['type']==='forum') {
		if ($forums['showsub'] && $forums['childid']) {
			$showsub[$forums['fid']] = '';
		}
		$forums['topics'] = $forums['topic']+$forums['subtopic'];
		if ($db_topped) {
			$forums['topics'] += $forums['top1'];
			$forums['article'] += $forums['top1'];
		}
		$article += $forums['article'];
		$topics += $forums['topics'];
		$tposts += $forums['tpost'];
		$forums['au'] = $forums['admin'] = '';
		if (!$forums['password'] && (!$forums['allowvisit'] || allowcheck($forums['allowvisit'],$groupid,$winddb['groups'],$forums['fid'],$winddb['visit']))) {
			list($forums['t'],$forums['au'],$forums['newtitle'],$forums['ft']) = explode("\t",$forums['lastpost']);
			$forums['pic'] = $newpic<$forums['newtitle'] && ($forums['newtitle']+$db_newtime>$timestamp) ? 'new' : 'old';
			$forums['newtitle'] = get_date($forums['newtitle']);
			$forums['t'] = substrs($forums['t'],26);
		} elseif ($forum[$forums['fid']]['f_type']==='hidden' && $groupid!=3) {
			if($forums['password'] && allowcheck($forums['allowvisit'],$groupid,$winddb['groups'],$forums['fid'],$winddb['visit'])){
				$forums['pic'] = 'lock';
			}else{
				continue;
			}
		} else {
			$forums['pic'] = 'lock';
		}
		$forums['allowhtm']==1 && $c_htm=1;
		if ($db_indexfmlogo==1 && file_exists("$imgdir/$stylepath/forumlogo/$forums[fid].gif")) {
			$forums['logo'] = "$imgpath/$stylepath/forumlogo/$forums[fid].gif";
		} elseif ($db_indexfmlogo!=2) {
			$forums['logo'] = '';
		}
		if ($forums['forumadmin']) {
			$forumadmin = explode(',',$forums['forumadmin']);
			foreach ($forumadmin as $value) {
				if ($value) {
					if (!$db_adminshow) {
						$forums['admin'] .= '<a href="profile.php?action=show&username='.rawurlencode($value)."\">$value</a> ";
					} else {
						$forums['admin'] .= "<option value=\"$value\">$value</option>";
					}
				}
			}
		}
		$forumdb[$forums['fup']][] = array('fid' => $forums['fid'],'name' => $forums['name'],'topics' => $forums['topics'],'article' => $forums['article'],'tpost' => $forums['tpost'],'admin' => $forums['admin'],'pic' => $forums['pic'],'logo' => $forums['logo'],'descrip' => $forums['descrip'],'au' => $forums['au'],'ft' => $forums['ft'],'t' => $forums['t'],'newtitle' => $forums['newtitle']);
	}
}
$db->free_result($query);

// View sub
if(!empty($showsub)){
	foreach ($forum as $value) {
		if (isset($showsub[$value['fup']]) && $value['f_type']!='hidden') {
			$showsub[$value['fup']] .= ($showsub[$value['fup']] ? ' | ' : '')."<a href=\"thread.php?fid=$value[fid]\">$value[name]</a>";
		}
	}
}
unset($forums,$forum);
// Share union
if ($db_indexmqshare && $sharelink[1]) {
	$sharelink[1] = "<marquee scrolldelay=\"100\" scrollamount=\"4\" onmouseout=\"if (document.all!=null){this.start()}\" onmouseover=\"if (document.all!=null){this.stop()}\" behavior=\"alternate\">$sharelink[1]</marquee>";
}

if (strpos($_COOKIE['deploy'],"\tinfo\t")!==false) {
	$cate_img  = 'open';
	$cate_info = 'none';
} else {
	$cate_img  = 'fold';
	$cate_info = '';
}

// online users
Update_ol();
if (!$db_online && file_exists(D_P.'data/bbscache/olcache.php')) {
	include_once(D_P.'data/bbscache/olcache.php');
}
$online = '';
if (GetGP('online')) {
	$online = Char_cv(GetGP('online'));
} elseif (GetCookie('online')) {
	$online = GetCookie('online');
}
if ($online=='yes' || $db_indexonline && $online!='no') {
	if (!$db_online && $guestinbbs+$userinbbs>2000 && !CkInArray($windid,$manager)) {
		$online = 'no';
	} else {
		include_once Pcv(R_P."require/online_$db_online.php");
	}
} elseif ($db_online) {
	$userinbbs = $guestinbbs = 0;
	$query = $db->query("SELECT uid!=0 as ifuser,COUNT(*) AS count FROM pw_online GROUP BY uid!='0'");
	while($rt = $db->fetch_array($query)){
		if($rt['ifuser']) $userinbbs=$rt['count']; else	$guestinbbs=$rt['count'];
	}
}
Cookie('online',$online);
$usertotal = $guestinbbs+$userinbbs;
$showgroup = $db_showgroup ? explode(',',$db_showgroup) : array();

@extract($db->get_one("SELECT * FROM pw_bbsinfo WHERE id=1"));
$rawnewuser = rawurlencode($newmember);
if ($tdtcontrol!=$tdtime) {
	if ($db_hostweb == 1 && !$cateid && $groupid != 'guest') {
		$db->update("UPDATE pw_bbsinfo SET yposts='$tposts', tdtcontrol='$tdtime' WHERE id=1");
		$db->update("UPDATE pw_forumdata SET tpost=0 WHERE tpost<>'0'");
	}
}

// update posts hits
if($c_htm || $db_hithour){
	$db_hithour==0 && $db_hithour=4;
	$hit_wtime=$hit_control*$db_hithour;
	if ($hit_wtime>24) $hit_wtime=0;
	$hitsize = @filesize(D_P.'data/bbscache/hits.txt');
	if (($timestamp-$hit_tdtime)>$hit_wtime*3600 || $hitsize>1024) {
		require_once(R_P.'require/hitupdate.php');
	}
}
if ($higholnum<$usertotal) {
	$db->update("UPDATE pw_bbsinfo SET higholnum='$usertotal',higholtime='$timestamp' WHERE id=1");
	$higholnum = $usertotal;
}
if ($hposts<$tposts) {
	$db->update("UPDATE pw_bbsinfo SET hposts='$tposts' WHERE id=1");
	$hposts = $tposts;
}
$mostinbbstime = get_date($higholtime);
if ($db_onlinelmt!=0 && $usertotal>=$db_onlinelmt && !$ol_offset) {
	Cookie('ol_offset','',0);
	Showmsg('most_online');
}

list($db_moneyname,$db_moneyunit,$db_rvrcname,$db_rvrcunit,$db_creditname,$db_creditunit)=explode("\t",$db_credits);
if ($plantime && $timestamp>$plantime) {
	require_once(R_P.'require/task.php');
}
// update birth day
$brithcache = '';
if ($db_indexshowbirth) {
	require_once(R_P.'require/birth.php');
}
//if($db_newinfoifopen){
//	@include_once(D_P.'data/bbscache/newinfo_config.php');
//	if($nf_order['dig'] && (!$nf_newinfodb['dig'] || $timestamp-$nf_digtime > 86400)){
//		require_once(R_P.'require/newinfo.php');
//		$nf_newinfodb['dig']=updatedigpost();
//	}
//}
require_once PrintEot('index');
$db_newinfoifopen && require_once(R_P."require/newinfo.php");
footer();
?>