
function PwAttach(){

}

PwAttach.prototype = {

	modify : function(aid){
		var s = getObj('attach_'+aid);
		var o = att.create(aid);
		s.parentNode.insertBefore(o,s);
		o.select();
		s.style.display = 'none';
		att.change(aid,2);
	},

	create : function(aid){
		var o		= document.createElement('input');
		o.type		= 'file';
		o.className	= 'input file';
		o.size		= 20;
		o.maxLength	= 100;
		o.name		= 'replace_'+aid;
		o.id		= 'replace_'+aid;
		o.onmouseover = function(){att.show(aid)};
		return o;
	},
	
	cancle : function(aid){
		var o = getObj('replace_'+aid);
		var s = getObj('attach_'+aid);
		o.parentNode.removeChild(o);
		s.style.display = '';
		att.change(aid,1);
	},

	change : function(aid,type){
		var s = getObj('md_'+aid);
		if(type==2){
			s.innerHTML = '取消';
			s.onclick = function(){att.cancle(aid)};
		} else{
			s.innerHTML = '更新';
			s.onclick = function(){att.modify(aid)};
		}
	},
	
	show : function(aid){
		if(IsElement('replace_'+aid)){
			var path = getObj('replace_'+aid).value;
			var attach_ext = path.substr(path.lastIndexOf('.') + 1, path.length).toLowerCase();
			if(!is_ie || !in_array(attach_ext,['jpg','gif','png','bmp','jpeg']))
				return;
			getObj('viewimg').innerHTML = getimage(path,320);
			read.open('viewimg','att_'+aid,3);
		} else{
			var path = getObj('atturl_'+aid).innerHTML;
			getObj('viewimg').innerHTML = getimage(path,320);
			read.open('viewimg','att_'+aid,3);
		}
	}
}

var att = new PwAttach();