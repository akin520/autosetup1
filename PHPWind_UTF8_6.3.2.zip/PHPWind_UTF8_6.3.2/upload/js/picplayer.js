var tcount = 15;
var garTransitions = new Array();
garTransitions[0] = "progid:DXImageTransform.Microsoft.Fade(duration=1)";
garTransitions[1] = "progid:DXImageTransform.Microsoft.Blinds(Duration=1,bands=20)";
garTransitions[2] = "progid:DXImageTransform.Microsoft.Checkerboard(Duration=1,squaresX=20,squaresY=20)";
garTransitions[3] = "progid:DXImageTransform.Microsoft.Strips(Duration=1,motion=rightdown)";
garTransitions[4] = "progid:DXImageTransform.Microsoft.Barn(Duration=1,orientation=vertical)";
garTransitions[5] = "progid:DXImageTransform.Microsoft.GradientWipe(duration=1)";
garTransitions[6] = "progid:DXImageTransform.Microsoft.Iris(Duration=1,motion=out)";
garTransitions[7] = "progid:DXImageTransform.Microsoft.Wheel(Duration=1,spokes=12)";
garTransitions[8] = "progid:DXImageTransform.Microsoft.Pixelate(maxSquare=10,duration=1)";
garTransitions[9] = "progid:DXImageTransform.Microsoft.RadialWipe(Duration=1,wipeStyle=clock)";
garTransitions[10] = "progid:DXImageTransform.Microsoft.RandomBars(Duration=1,orientation=vertical)";
garTransitions[11] = "progid:DXImageTransform.Microsoft.Slide(Duration=1,slideStyle=push)";
garTransitions[12] = "progid:DXImageTransform.Microsoft.RandomDissolve(Duration=1,orientation=vertical)";
garTransitions[13] = "progid:DXImageTransform.Microsoft.Spiral(Duration=1,gridSizeX=40,gridSizeY=40)";
garTransitions[14] = "progid:DXImageTransform.Microsoft.Stretch(Duration=1,stretchStyle=push)";
function player(pid,imgpics,imglinks,imgtitle,imgnum){
	if(imgpics){
		setTimeout("changeimg("+pid+",0,'"+imgpics+"','"+imglinks+"','"+imgtitle+"','"+imgnum+"')",100);
	}
}
function changeimg(pid,n,imgpics,imglinks,imgtitle,imgnum){
	if (n>=imgnum){
		n=0;
	}
	showimg(pid,n,imgpics,imglinks,imgtitle,imgnum);
	n++;
	setTimeout("changeimg("+pid+","+n+",'"+imgpics+"','"+imglinks+"','"+imgtitle+"','"+imgnum+"')",3000);
}
function showimg(pid,n,imgpics,imglinks,imgtitle,imgnum){
	var imgpics=imgpics.split('|');
	var imglinks=imglinks.split('|');
	var imgtitle=imgtitle.split('|');
	if(imgpics[n]){
		var player=document.getElementById(pid+'_player');
		var imglink=document.getElementById(pid+'_imglink');
		var imgtiti=document.getElementById(pid+'_imgtitle');
		if (document.all && player.filters){
			var do_transition = Math.floor(Math.random() * tcount);
			player.style.filter=garTransitions[do_transition];
			player.filters[0].Apply();
		}
		var imgdiv  = document.createElement("div");
		var imgarea = document.createElement("img");
		imgarea.src=imgpics[n];
		if(!imgarea.width || imgarea.width > player.offsetWidth){
			imgarea.width = player.offsetWidth - 10;
		}
		if(!imgarea.height || imgarea.height > player.offsetHeight){
			imgarea.height = player.offsetHeight - 10;
		}
		imgdiv.appendChild(imgarea);
		imglink.innerHTML=imgdiv.innerHTML;
		imglink.href=imglinks[n];
		imgtiti.href=imglinks[n];
		imgtiti.innerHTML=imgtitle[n];
		if (document.all && player.filters) {
			player.filters[0].Play();
		}
	}
}