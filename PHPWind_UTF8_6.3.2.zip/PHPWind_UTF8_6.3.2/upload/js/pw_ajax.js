
function AjaxObj(){
	this.responseText = null;
	var s = document.createElement('div');
	s.style.display = 'none';
	s.innerHTML = '<iframe id="ajaxiframe" name="ajaxiframe" width="0" height="0"></iframe>';
	document.body.appendChild(s);
	this.iframe = s.firstChild;

	this.post = function(url,data){
		if(typeof data == 'string' && data!=''){
			var f = document.createElement('form');
			f.name	 = 'ajaxform';
			f.target = 'ajaxiframe';
			f.method = 'post';
			f.action = url;
			var ds = data.split("&");
			for(var i=0;i<ds.length;i++){
				if(ds[i]){
					var v	 = ds[i];
					var el	 = document.createElement('input');
					el.type  = 'hidden';
					el.name  = v.substr(0,v.indexOf('='));
					el.value = v.substr(v.indexOf('=')+1);
					f.appendChild(el);
				}
			}
			document.body.appendChild(f);
			f.submit();
			document.body.removeChild(f);
		} else if(typeof data == 'object'){
			data.target = 'ajaxiframe';
			data.submit();
		} else{
			self.ajaxiframe.location = url;
		}
	}
}
function XMLhttp(){
	this.request = null;
	this.recall	 = null;
	this.time    = null;
	this.t       = null;
	this.last	 = 0;
}

XMLhttp.prototype = {

	send : function(url,data,callback){
		if(this.request == null){
			this.request = new AjaxObj();
		}
		this.request.responseText = '';

		var nowtime	= new Date().getTime();
		if(nowtime-this.last<1500){
			clearTimeout(this.t);
			this.t = setTimeout(function(){ajax.send(url,data,callback)},1500+this.last-nowtime);
			return;
		}
		this.last = nowtime;
		url	+= (url.indexOf("?") >= 0) ? "&nowtime=" + nowtime : "?nowtime=" + nowtime;
		this.request.post(url,data);
		this.recall = callback;
		if(typeof this.recall == "function"){
			if(this.request.iframe.attachEvent){
				this.request.iframe.detachEvent('onload',ajax.load);
				this.request.iframe.attachEvent('onload',ajax.load);
			} else{
				this.request.iframe.addEventListener('load',ajax.load,true);
			}
		}
	},

	load : function(){
		if(is_ie){
			ajax.request.responseText = ajax.request.iframe.contentWindow.document.XMLDocument.text;
			ajax.request.iframe.detachEvent('onload',ajax.load);
		} else{
			ajax.request.responseText = ajax.request.iframe.contentWindow.document.documentElement.firstChild.nodeValue;
			ajax.request.iframe.removeEventListener('load',ajax.load,true);
		}
		ajax.recall();
	},

	XmlDocument : function(obj){
		return is_ie ? ajax.request.iframe.contentWindow.document.XMLDocument : ajax.request.iframe.contentWindow.document;
	},

	submit : function(obj,recall){
		if(typeof recall == 'undefined' || typeof recall != 'function'){
			recall = ajax.guide;
		}
		ajax.send(obj.action,obj,recall);
		closep();
	},

	get : function(){
		if(ajax.request.responseText.indexOf('<') != -1){
			read.menu.innerHTML = ajax.request.responseText;
			read.menu.className = 'menu';
			read.menupz(read.obj,1);
		} else{
			closep();
			ajax.guide();
		}
	},

	guide : function(){
		var rText = ajax.request.responseText.split('\t');
		var o = ajax.create();
		o.innerHTML  = rText[0];
		o.style.top  = (ietruebody().scrollTop + 170) + 'px';
		o.style.left = (ietruebody().clientWidth - o.offsetWidth)/2 + ietruebody().scrollLeft + 'px';
		ajax.time = setTimeout("ajax.clear();",3000);

		if(typeof(rText[1]) != 'undefined' && in_array(rText[1],['jump','nextto','reload'])){
			if(rText[1]=='jump'){
				setTimeout("window.location.href='"+rText[2]+"';",200);
			} else if(rText[1]=='nextto'){
				sendmsg(rText[2],rText[3],rText[4]);
			} else if(rText[1]=='reload'){
				setTimeout("window.location.reload();",200);
			}
		}
	},

	clear : function(){
		if(IsElement('ajax_guide')) document.body.removeChild(getObj('ajax_guide'));
	},

	create : function(){
		if(!IsElement('ajax_guide')){
			var o = document.createElement('div');
			o.style.cssText = 'border:#EFEF9D 1px solid;background:url('+imgpath+'/important.gif) no-repeat .5em center #FFFFD8;font:bold 14px Helvetica;text-align:center;padding:1em 1.5em 1em 4.5em;position:absolute;z-index:3005;';
			o.id  = 'ajax_guide';
			document.body.appendChild(o);
		} else{
			clearTimeout(ajax.time);
			var o = getObj('ajax_guide');
		}
		return o;
	},
	
	convert : function(str){
		return str.replace(/\&/g,'%26');
	},

	quickpost : function(event,obj){
		if((event.ctrlKey && event.keyCode == 13) || (event.altKey && event.keyCode == 83)){
			try{obj.ajaxsubmit.click();}catch(e){}
		}
	}
}

var ajax = new XMLhttp();

function sendmsg(url,data,id){
	read.obj = typeof id == 'undefined' ? null : getObj(id);
	read.guide();
	setTimeout(function(){ajax.send(url,data,ajax.get);},300);
}