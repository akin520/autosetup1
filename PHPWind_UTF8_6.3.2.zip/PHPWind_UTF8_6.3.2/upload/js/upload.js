var aid = 0;

function newAttach(){
	if (!IsElement('attach'))
		return;
	aid++;
	attachnum--;
	var s = getObj('att_mode').firstChild.cloneNode(true);
	var id = aid;
	s.id = 'att_div' + id;
	var tags = s.getElementsByTagName('input');
	for(var i=0;i<tags.length;i++){
		tags[i].name += id;
		tags[i].id = tags[i].name;
		if(tags[i].name == 'attachment_'+id){
			tags[i].onchange = function(){upAttach(id);};
		}
	}
	getObj('attach').appendChild(s);
}
function upAttach(id){
	var div  = getObj('att_div'+id);
	var path = getObj('attachment_'+id).value;
	var attach_ext = path.substr(path.lastIndexOf('.') + 1, path.length).toLowerCase();
	if(allow_ext != '  ' && (attach_ext == '' || allow_ext.indexOf(' ' + attach_ext + ' ') == -1)){
		if(IsElement('att_span'+id)){
			div.removeChild(getObj('att_span'+id));
		}
		if(path != '') alert('附件类型不匹配!');
		return false;
	}
	getObj('attachment_'+id).onmouseover = function(){viewimg(id)};
	if(!IsElement('att_span'+id)){
		var span = document.createElement("span");
		var s    = document.createElement("a");
		s.className    = 'abtn';
		s.unselectable = 'on';
		s.onclick      = function(){addupload(id)};
		s.innerHTML    = '插入';
		span.appendChild(s);
		var s    = document.createElement("a");
		s.className    = 'abtn';
		s.unselectable = 'on';
		s.onclick      = function(){delupload(id)};
		s.innerHTML    = '删除';
		span.appendChild(s);
		span.id = 'att_span'+id;
		span.style.marginLeft = '1px';
		div.appendChild(span);
	}
	if(attachnum>0 && getObj('attach').lastChild.id == 'att_div'+id){
		newAttach();
	}
}
function viewimg(id){
	var path = getObj('attachment_'+id).value;
	var attach_ext = path.substr(path.lastIndexOf('.') + 1, path.length).toLowerCase();
	if(!is_ie || !in_array(attach_ext,['jpg','gif','png','bmp','jpeg']))
		return;
	getObj('viewimg').innerHTML = getimage(path,320);
	read.open('viewimg','att_div'+id,3);
}
function getimage(path,maxwh){
	var img = new Image();
	img.src = path;
	return '<div style="padding:6px"><img src="' + path + '"' + ((img.width>maxwh || img.height>maxwh) ? (img.width > img.height ? ' width' : ' height') + '="' + maxwh + '"' : '') + ' /></div>';
}
function addupload(attid){
	if(typeof WYSIWYD == 'function'){
		editor.focusEditor();
		if (editor._editMode=='textmode' || !is_ie) {
			AddCode(' [upload='+attid+'] ','');
		} else if(IsElement('attachment_'+attid)) {
			var img = imgmaxwh(getObj('attachment_'+attid).value,320);
			editor.insertHTML('<img src="'+img.src+'" type="upload_'+attid+'" width="'+img.width+'" />');
		}
	} else{
		var atc = document.FORM.atc_content;
		var text = ' [upload='+attid+'] ';
		if (document.selection) {
			var sel = document.selection.createRange();
			alert(sel.text);
			if (sel.parentElement().name == 'atc_content') {
				sel.text = text;
				sel.select();
			} else {
				atc.value += text;
			}
		} else if (typeof atc.selectionStart != 'undefined') {
			var prepos = atc.selectionStart;
			atc.value = atc.value.substr(0,atc.selectionStart) + text + atc.value.substr(atc.selectionEnd);
			atc.selectionStart = prepos + text.length;
			atc.selectionEnd = prepos + text.length;
		} else {
			atc.value += ' [upload='+attid+'] ';
		}
	}
}
function delupload(id){
	getObj('att_div'+id).parentNode.removeChild(getObj('att_div'+id));
	attachnum++;
	if(getObj('attach').hasChildNodes()==false){
		newAttach();
	}
}