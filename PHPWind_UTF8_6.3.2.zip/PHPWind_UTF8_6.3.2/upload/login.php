<?php
define('PRO','1');
require_once('global.php');

if ($db_pptifopen && $db_ppttype=='client') {
	Showmsg('passport_login');
}
$action  = GetGP('action');
$forward = $db_pptifopen ? GetGP('forward') : '';
$pre_url = $_SERVER['HTTP_REFERER'] ? $_SERVER['HTTP_REFERER'] : $db_bbsurl.'/'.$db_bfn;

if (strpos($pre_url,'login.php')!==false || strpos($pre_url,$db_registerfile)!==false) {
	$pre_url = $db_bfn;
}
!$action && $action = "login";

if ($groupid!='guest' && $action!="quit") {
	if ($db_pptifopen && $db_ppttype == 'server' && ($db_ppturls || $forward)) {
		$jumpurl = $forward ? $forward : $db_ppturls;
		$forward = $pre_url;
		require_once(R_P.'require/passport_server.php');
	} else {
		Showmsg('login_have');
	}
}
list(,$loginq)	= explode("\t",$db_qcheck);

if ($action=="login") {

	if (!$_POST['step']) {

		$jumpurl = $pre_url;
		require_once(R_P.'require/header.php');
		require_once PrintEot('login');footer();

	} elseif ($_POST['step']==2) {

		($db_gdcheck & 2) && GdConfirm($_POST['gdcode']);
		$loginq && Qcheck($_POST['qanswer'],$_POST['qkey']);

		require_once(R_P.'require/checkpass.php');
		include_once(D_P."data/bbscache/dbreg.php");

		InitGP(array('pwuser','pwpwd','question','customquest','answer','cktime','hideid','jumpurl','lgt'),'P');

		if ($pwuser && $pwpwd) {
			$md5_pwpwd = md5($pwpwd);
			$safecv = $db_ifsafecv ? questcode($question,$customquest,$answer) : '';
			list($winduid,$groupid,$pwpwd) = checkpass($pwuser,$md5_pwpwd,$safecv,$lgt);
		} else {
			Showmsg('login_empty');
		}
		if (file_exists(D_P."data/groupdb/group_$groupid.php")) {
			require_once Pcv(D_P."data/groupdb/group_$groupid.php");
		} else {
			require_once(D_P."data/groupdb/group_1.php");
		}
		$windpwd = $pwpwd;
		$cktime != 0 && $cktime += $timestamp;
		Cookie("winduser",StrCode($winduid."\t".$windpwd."\t".$safecv),$cktime);
		Cookie('lastvisit','',0);//��$lastvist����Խ���ע��Ļ�Ա������յ��û�Ա��
		if ($db_autoban) {
			require_once(R_P.'require/autoban.php');
			autoban($winduid);
		}
		($gp_allowhide && $hideid) ? Cookie('hideid',"1",$cktime) : Loginipwrite($winduid);
		empty($jumpurl) && $jumpurl=$db_bfn;

		//passport
		if ($db_pptifopen && $db_ppttype == 'server' && ($db_ppturls || $forward)) {
			$tmp = $jumpurl;
			$jumpurl = $forward ? $forward : $db_ppturls;
			$forward = $tmp;
			require_once(R_P.'require/passport_server.php');
		}
		//passport
		refreshto($jumpurl,'have_login');
	}
} elseif ($action=="quit") {
	if(!$db_pptifopen || !$db_pptcmode){
		$verify = GetGP('verify');
		PwVerifyUrl($verify);
	}
	require_once(R_P.'require/checkpass.php');

	if ($groupid=='6') {
		$bandb = $db->get_one("SELECT type FROM pw_banuser WHERE uid='$winduid'");
		if ($bandb['type']==3) {
			Cookie('force',$winduid);
		}
	}
	Loginout();

	//passport
	if ($db_pptifopen && $db_ppttype == 'server' && ($db_ppturls || $forward)) {
		$jumpurl = $forward ? $forward : $db_ppturls;
		$forward = $pre_url;
		require_once(R_P.'require/passport_server.php');
	}
	//passport

	refreshto($pre_url,'login_out');/*�˳�url ��Ҫʹ��$pre_url ��Ϊ������޸����������һ��ѭ����ת*/
}
?>