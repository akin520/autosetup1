<?php
if (isset($_GET['ajax'])) {
	define('AJAX','1');
}
require_once('global.php');
require_once(R_P.'require/forum.php');
require_once(R_P.'require/msg.php');
require_once(R_P.'require/writelog.php');
require_once(R_P.'require/updateforum.php');
include_once(D_P.'data/bbscache/forum_cache.php');

InitGP(array('action'));
InitGP(array('atc_content'),'P',1);

if (!in_array($action,array('banuser','delatc','shield','remind','commend','check','inspect'))) {
	Showmsg('undefined_action');
}
$foruminfo = $db->get_one("SELECT * FROM pw_forums f LEFT JOIN pw_forumsextra fe USING(fid) WHERE f.fid='$fid' AND f.type<>'category'");
!$foruminfo && Showmsg('data_error');
wind_forumcheck($foruminfo);

$secondurl="thread.php?fid=$fid";
/**
* ��ȫ��֤
*/
$groupid=='guest'&&	Showmsg('not_login');

/**
* ��ȡ��ʼ�˺Ͱ���Ȩ��
*/
if (CkInArray($windid,$manager) || admincheck($foruminfo['forumadmin'],$foruminfo['fupadmin'],$windid)) {
	$admincheck = 1;
} else {
	$admincheck = 0;
}
!$windid && $admincheck=0;

if(!$admincheck && $groupid!=5){
	/*
	* ��ȡ�û���Ȩ��
	*/
	if($SYSTEM['rightwhere'] && strpos(",".$SYSTEM['rightwhere'].",",",".$fid.",")===false){
		Showmsg('rightwhere');
	}
	if($action=="banuser" && $SYSTEM['banuser']){
		$admincheck=1;
	} elseif($action=="delatc" && $SYSTEM['modother']){
		$admincheck=1;
	} elseif($SYSTEM[$action]){
		$admincheck=1;
	}
}
if (!$admincheck) {
	Showmsg('mawhole_right');
}

require_once GetLang('masigle');
list($db_moneyname,,$db_rvrcname,,$db_creditname)=explode("\t",$db_credits);

$template = 'ajax_masingle';

if (empty($_POST['step']) && !defined('AJAX')) {
	require_once(R_P.'require/header.php');
	$template = 'masingle';
} elseif ($_POST['step']=='3') {
	if ($db_enterreason && !$atc_content) {
		Showmsg('enterreason');
	}
}
if ($action=="banuser") {
	InitGP(array('pid','page'));
	(!$tid || !$pid) && Showmsg('masingle_data_error');
	$page = (int)$page;
	$sqlsel = $sqltab = $sqladd = '';
	if(is_numeric($pid)){
		$pw_posts = GetPtable('N',$tid);
		$sqlsel = "t.anonymous,t.userip,";
		$sqltab = "$pw_posts t LEFT JOIN pw_members m ON t.authorid=m.uid";
		$sqladd = " AND t.pid='$pid'";
	} else{
		$pw_tmsgs = GetTtable($tid);
		$sqlsel = "t.anonymous,tm.userip,";
		$sqltab = "pw_threads t LEFT JOIN $pw_tmsgs tm ON t.tid=tm.tid LEFT JOIN pw_members m ON t.authorid=m.uid";
	}
	$userdb = $db->get_one("SELECT $sqlsel m.uid,m.username,m.groupid FROM $sqltab WHERE t.tid='$tid' AND t.fid='$fid' $sqladd");
	!$userdb && Showmsg('undefined_action');
	$username = $userdb['anonymous'] ? $db_anonymousname : $userdb['username'];

	if (!$_POST['step']) {
		if($userdb['groupid']=='6'){
			Showmsg('member_havebanned');
		} elseif($userdb['groupid']!='-1'){
			Showmsg('masigle_ban_fail');
		}
		require_once PrintEot($template);footer();

	} else {

		if ($userdb['groupid']=='-1') {
			InitGP(array('limit','type','ifmsg','banip'),'P');
			if($limit>$SYSTEM['banmax']){
				Showmsg('masigle_ban_limit');
			}
			if(!$SYSTEM['bantype'] && $type==2){
				Showmsg('masigle_ban_right');
			}

			$db->update("UPDATE pw_members SET groupid='6' WHERE uid='$userdb[uid]'");
			$db->update("REPLACE INTO pw_banuser VALUES('$userdb[uid]','$type','$timestamp','$limit','".addslashes($windid)."','$atc_content')");
			if($ifmsg){
				if($type==1){
					$msginfo=$lang['banuser_1'];
					$msginfo=str_replace('_limit',$limit,$msginfo);
				} else{
					$msginfo=$lang['banuser_2'];
				}
				$message=array($userdb['username'],$winduid,$lang['banuser_2'],$timestamp,addslashes($msginfo)."\n".$atc_content,'',$windid);
				writenewmsg($message,1);
			}
			if($banip && $userdb['userip']){
				require_once(R_P.'admin/cache.php');
				$rs = $db->get_one("SELECT db_name,db_value FROM pw_config WHERE db_name='db_ipban'");
				$rs['db_value'] .= ($rs['db_value'] ? ',' : '').$userdb['userip'];
				if($rs){
					$db->update("UPDATE pw_config SET db_value='$rs[db_value]' WHERE db_name='db_ipban'");
				} else{
					$db->update("INSERT INTO pw_config(db_name,db_value) VALUES ('db_ipban','$rs[db_value]')");
				}
				updatecache_c();
			}
			if($foruminfo['allowhtm']){
				require_once(R_P.'require/template.php');
			}
			if (defined('AJAX')) {
				Showmsg('banuser_success');
			} else {
				refreshto("read.php?tid=$tid&page=$page",'operate_success');
			}
		} elseif($userdb['groupid']=='6'){
			Showmsg('member_havebanned');
		} else{
			Showmsg('masigle_ban_fail');
		}
	}
} elseif ($action=="shield") {
	InitGP(array('pid','page'));
	(!$tid || !$pid) && Showmsg('masingle_data_error');
	$sqlsel = $sqltab = $sqladd = '';
	if(is_numeric($pid)){
		$pw_posts = GetPtable('N',$tid);
		$sqlsel = "t.subject,t.content,t.postdate,t.ifshield,t.anonymous,";
		$sqltab = "$pw_posts t LEFT JOIN pw_members m ON t.authorid=m.uid";
		$sqladd = " AND t.pid='$pid'";
	} else{
		$sqlsel = "t.subject,t.postdate,t.ifshield,t.anonymous,";
		$sqltab = "pw_threads t LEFT JOIN pw_members m ON t.authorid=m.uid";
	}
	$readdb = $db->get_one("SELECT $sqlsel m.uid,m.username,m.groupid FROM $sqltab WHERE t.tid='$tid' $sqladd");
	!$readdb && Showmsg('illegal_tid');
	$readdb['ifshield'] == '2' && Showmsg('illegal_data');

	if($groupid != 3 && $groupid != 4){
		if($readdb['groupid'] == 3 || $readdb['groupid'] == 4){
			Showmsg('modify_admin');
		}
	}
	$readdb['subject'] = substrs($readdb['subject'],35);
	!$readb['subject'] && is_numeric($pid) && $readdb['subject']=substrs($readdb['content'],35);
	if(!$_POST['step']){
		$readdb['ifshield'] ? $check_N = 'checked' : $check_Y = 'checked';
		$readdb['postdate'] = get_date($readdb['postdate']);
		$reason_sel='';
		$reason_a=explode("\n",$db_adminreason);
		foreach($reason_a as $k=>$v){
			if($v=trim($v)){
				$reason_sel .= "<option value=\"$v\">$v</option>";
			} else{
				$reason_sel .= "<option value=\"\">-------</option>";
			}
		}
		require_once PrintEot($template);footer();

	} elseif($_POST['step']){
		if($_POST['step']==3){
			$readdb['ifshield']==1 && Showmsg('read_shield');
			$ifshield = 1;
		} else{
			$readdb['ifshield']==0 && Showmsg('read_unshield');
			$ifshield = 0;
		}
		if(is_numeric($pid)){
			$db->update("UPDATE $pw_posts SET ifshield='$ifshield' WHERE pid='$pid' AND tid='$tid'");
		} else{
			$db->update("UPDATE pw_threads SET ifshield='$ifshield' WHERE tid='$tid'");
		}
		if($_POST['ifmsg']){
			$msg = array(
				$readdb['username'],
				$winduid,
				'shield_title_'.$ifshield,
				$timestamp,
				'shield_content_'.$ifshield,
				'N',
				$windid,
				'fid'		=> $fid,
				'tid'		=> $tid,
				'subject'	=> $readdb['subject'],
				'postdate'	=> get_date($readdb['postdate']),
				'forum'		=> strip_tags($forum[$fid]['name']),
				'admindate'	=> get_date($timestamp),
				'reason'	=> $atc_content
			);
			writenewmsg($msg,1);
		}
		if($_POST['step']==3){
			$log = array(
				'type'      => 'shield',
				'username1' => $readdb['username'],
				'username2' => $windid,
				'field1'    => $fid,
				'field2'    => '',
				'field3'    => '',
				'descrip'   => 'shield_descrip',
				'timestamp' => $timestamp,
				'ip'        => $onlineip,
				'tid'		=> $tid,
				'forum'		=> $forum[$fid]['name'],
				'subject'	=> substrs($readdb['subject'],28),
				'reason'	=> $atc_content
			);
			writelog($log);
		}
		if($foruminfo['allowhtm'] && $page==1){
			require_once(R_P.'require/template.php');
		}
		refreshto("read.php?tid=$tid&page=$page",'operate_success');
	}
} elseif($action=='remind'){
	InitGP(array('pid','page'));
	(!$tid || !$pid) && Showmsg('masingle_data_error');
	$sqlsel = $sqltab = $sqladd = '';
	if(is_numeric($pid)){
		$pw_posts = GetPtable('N',$tid);
		$sqlsel = "t.subject,t.content,t.postdate,t.remindinfo,t.anonymous,";
		$sqltab = "$pw_posts t LEFT JOIN pw_members m ON t.authorid=m.uid";
		$sqladd = " AND t.pid='$pid'";
	} else{
		$pw_tmsgs = GetTtable($tid);
		$sqlsel = "t.subject,t.postdate,t.anonymous,tm.remindinfo,";
		$sqltab = "pw_threads t LEFT JOIN $pw_tmsgs tm ON t.tid=tm.tid LEFT JOIN pw_members m ON t.authorid=m.uid";
	}
	$readdb = $db->get_one("SELECT $sqlsel m.uid,m.username,m.groupid FROM $sqltab WHERE t.tid='$tid' AND t.fid='$fid' $sqladd");
	!$readdb && Showmsg('illegal_tid');

	if($groupid != 3 && $groupid != 4){
		if($readdb['groupid'] == 3 || $readdb['groupid'] == 4){
			Showmsg('modify_admin');
		}
	}
	$readdb['subject'] = substrs($readdb['subject'],35);
	!$readb['subject'] && is_numeric($pid) && $readdb['subject']=substrs($readdb['content'],35);

	if(!$_POST['step']){
		$readdb['remindinfo'] ? $check_N = 'checked' : $check_Y = 'checked';
		$readdb['postdate'] = get_date($readdb['postdate']);
		$reason_sel='';
		$reason_a=explode("\n",$db_adminreason);
		list($remindinfo)=explode("\t",$readdb['remindinfo']);
		foreach($reason_a as $k=>$v){
			if($v=trim($v)){
				$reason_sel .= "<option value=\"$v\">$v</option>";
			} else{
				$reason_sel .= "<option value=\"\">-------</option>";
			}
		}
		$remindinfo = str_replace('&nbsp;',' ',$remindinfo);
		require_once PrintEot($template);footer();
	} elseif($_POST['step']==3){
		!$atc_content && Showmsg('remind_data_empty');

		$remindinfo = $atc_content."\t".addslashes($windid)."\t".$timestamp;
		if(strlen($remindinfo)>150)Showmsg('remind_length');
		if(is_numeric($pid)){
			$db->update("UPDATE $pw_posts SET remindinfo='$remindinfo' WHERE pid='$pid' AND tid='$tid'");
		} else{
			$db->update("UPDATE $pw_tmsgs SET remindinfo='$remindinfo' WHERE tid='$tid'");
		}
		if($_POST['ifmsg']){
			$msg = array(
				$readdb['username'],
				$winduid,
				'remind_title',
				$timestamp,
				'remind_content',
				'N',
				$windid,
				'fid'		=> $fid,
				'tid'		=> $tid,
				'subject'	=> $readdb['subject'],
				'postdate'	=> get_date($readdb['postdate']),
				'forum'		=> strip_tags($forum[$fid]['name']),
				'admindate'	=> get_date($timestamp),
				'reason'	=> $atc_content
			);
			writenewmsg($msg,1);
		}
		$log = array(
			'type'      => 'remind',
			'username1' => $readdb['username'],
			'username2' => $windid,
			'field1'    => $fid,
			'field2'    => '',
			'field3'    => '',
			'descrip'   => 'remind_descrip',
			'timestamp' => $timestamp,
			'ip'        => $onlineip,
			'tid'		=> $tid,
			'forum'		=> $forum[$fid]['name'],
			'subject'	=> substrs($readdb['subject'],28),
			'reason'	=> $atc_content
		);
		writelog($log);
		if (defined('AJAX')) {
			echo "success\t".str_replace(array("\n","\t"),array('<br />',''),$atc_content)."\t$windid";ajax_footer();
		} else {
			refreshto("read.php?tid=$tid&page=$page",'operate_success');
		}
	} elseif($_POST['step']==5){
		if(is_numeric($pid)){
			$db->update("UPDATE $pw_posts SET remindinfo='' WHERE pid='$pid' AND tid='$tid'");
		} else{
			$db->update("UPDATE $pw_tmsgs SET remindinfo='' WHERE tid='$tid'");
		}
		if (defined('AJAX')) {
			echo "cancle\t";ajax_footer();
		} else {
			refreshto("read.php?tid=$tid&page=$page",'operate_success');
		}
	}
} elseif ($action=="delatc") {

	InitGP(array('selid'));
	empty($selid) && Showmsg('mawhole_nodata');
	$pw_tmsgs = GetTtable($tid);
	$tpcdb = $db->get_one("SELECT t.tid,t.fid,t.author,t.authorid,t.postdate,t.subject,t.topped,t.anonymous,t.ifshield,t.ptable,tm.aid FROM pw_threads t LEFT JOIN $pw_tmsgs tm ON tm.tid=t.tid WHERE t.tid='$tid'");
	if (!$tpcdb || $tpcdb['fid'] != $fid) {
		Showmsg('undefined_action');
	}
	$pw_posts = GetPtable($tpcdb['ptable']);
	$deltpc = $pids = '';
	foreach ($selid as $k=>$v) {
		if ($v=='tpc') {
			$deltpc='1';
		} elseif (is_numeric($v)) {
			$pids .= $pids ? ','.$v : $v;
		}
	}
	$threaddb = array();
	if ($deltpc) {
		$tpcdb['ifshield'] == '2' && Showmsg('illegal_data');
		if ($groupid != 3 && $groupid != 4) {
			$authordb = $db->get_one("SELECT groupid FROM pw_members WHERE uid='$tpcdb[authorid]'");
			if ($authordb['groupid'] == 3 || $authordb['groupid'] == 4) {
				Showmsg('modify_admin');
			}
		}
		$tpcdb['pid'] = 'tpc';
		$tpcdb['postdate'] = get_date($tpcdb['postdate']);
		$threaddb[] = $tpcdb;
	}
	if ($pids) {
		$query = $db->query("SELECT pid,fid,tid,aid,author,authorid,postdate,subject,content,anonymous FROM $pw_posts WHERE tid='$tid' AND fid='$fid' AND pid IN($pids)");
		while ($rt = $db->fetch_array($query)) {
			if ($groupid != 3 && $groupid != 4) {
				$authordb = $db->get_one("SELECT groupid FROM pw_members WHERE uid='$rt[authorid]'");
				if ($authordb['groupid'] == 3 || $authordb['groupid'] == 4) {
					Showmsg('modify_admin');
				}
			}
			if (!$rt['subject']) {
				$rt['subject'] = substrs($rt['content'],35);
			}
			$rt['postdate'] = get_date($rt['postdate']);
			$threaddb[] = $rt;
		}
	}
	if (empty($_POST['step'])) {

		$reason_sel = '';
		$reason_a	= explode("\n",$db_adminreason);
		foreach ($reason_a as $k=>$v) {
			if ($v = trim($v)) {
				$reason_sel .= "<option value=\"$v\">$v</option>";
			} else {
				$reason_sel .= "<option value=\"\">-------</option>";
			}
		}
		$count = count($threaddb);
		require_once PrintEot($template);footer();

	} else {

		$attachdb  = array();
		$creditset = get_creditset($foruminfo['creditset'],$db_creditset);
		foreach ($threaddb as $key=>$val) {
			if ($val['pid'] == 'tpc') {
				$db->update("UPDATE pw_threads SET ifshield='2' WHERE tid='$tid'");
				if ($db_recycle) {
					$db->update("REPLACE INTO pw_recycle (pid,tid,fid,deltime,admin) VALUES ('0','$tid','$fid','$timestamp','".addslashes($windid)."')");
				} else {
					delete_tag($tid);
				}
				$val['aid'] && $attachdb[] = $val['aid'];
				if ($_POST['ifdel']) {
					dtchange($val['authorid'],-$creditset['rvrc']['Delete'],-1,-$creditset['money']['Delete']);
					customcredit($val['authorid'],$creditset,'Delete');
					$msg_delrvrc  = floor($creditset['rvrc']['Delete']/10);
					$msg_delmoney = $creditset['money']['Delete'];
				} else {
					$msg_delrvrc  = $msg_delmoney = 0;
				}

				if ($_POST['ifmsg']) {
					$msg = array(
						$val['author'],
						$winduid,
						'deltpc_title',
						$timestamp,
						'deltpc_content',
						'N',
						$windid,
						'fid'		=> $fid,
						'tid'		=> $tid,
						'subject'	=> $val['subject'],
						'postdate'	=> $val['postdate'],
						'forum'		=> strip_tags($forum[$fid]['name']),
						'affect'	=> "{$db_rvrcname}��-{$msg_delrvrc}��{$db_moneyname}��-{$msg_delmoney}",
						'admindate'	=> get_date($timestamp),
						'reason'	=> $atc_content
					);
					writenewmsg($msg,1);
				}
				$log = array(
					'type'      => 'delete',
					'username1' => $val['author'],
					'username2' => $windid,
					'field1'    => $fid,
					'field2'    => '',
					'field3'    => '',
					'descrip'   => 'deltpc_descrip',
					'timestamp' => $timestamp,
					'ip'        => $onlineip,
					'tid'		=> $tid,
					'forum'		=> $forum[$fid]['name'],
					'subject'	=> substrs($val['subject'],28),
					'affect'	=> "{$db_rvrcname}��-{$msg_delrvrc}��{$db_moneyname}��-{$msg_delmoney}",
					'reason'	=> $atc_content
				);
				writelog($log);
			} else {
				if ($db_recycle) {
					$db->update("UPDATE $pw_posts SET tid='0',fid='0' WHERE pid='$val[pid]'");
					$db->update("REPLACE INTO pw_recycle (pid,tid,fid,deltime,admin) VALUES ('$val[pid]','$tid','$fid','$timestamp','".addslashes($windid)."')");
				} else {
					$db->update("DELETE FROM $pw_posts WHERE pid='$val[pid]'");
				}
				$val['aid'] && $attachdb[] = $val['aid'];
				if ($_POST['ifdel']) {
					dtchange($val['authorid'],-$creditset['rvrc']['Deleterp'],-1, -$creditset['money']['Deleterp']);
					customcredit($val['authorid'],$creditset,'Deleterp');
					$msg_delrprvrc = floor($creditset['rvrc']['Deleterp']/10);
					$msg_delmoney  = $creditset['money']['Deleterp'];
				} else {
					$msg_delrvrc  = $msg_delmoney = 0;
				}

				if ($_POST['ifmsg']) {
					$msg = array(
						$val['author'],
						$winduid,
						'delrp_title',
						$timestamp,
						'delrp_content',
						'N',
						$windid,
						'fid'		=> $fid,
						'tid'		=> $tid,
						'subject'	=> $val['subject'],
						'postdate'	=> $val['postdate'],
						'forum'		=> strip_tags($forum[$fid]['name']),
						'affect'	=> "{$db_rvrcname}��-{$msg_delrvrc}��{$db_moneyname}��-{$msg_delmoney}",
						'admindate'	=> get_date($timestamp),
						'reason'	=> $atc_content
					);
					writenewmsg($msg,1);
				}
				$log = array(
					'type'      => 'delete',
					'username1' => $val['author'],
					'username2' => $windid,
					'field1'    => $fid,
					'field2'    => '',
					'field3'    => '',
					'descrip'   => 'delrp_descrip',
					'timestamp' => $timestamp,
					'ip'        => $onlineip,
					'tid'		=> $tid,
					'forum'		=> $forum[$fid]['name'],
					'subject'	=> $val['subject'] ? substrs($val['subject'],28) : substrs($val['content'],28),
					'affect'	=> "{$db_rvrcname}��-{$msg_delrprvrc}��{$db_moneyname}��-{$msg_delmoney}",
					'reason'	=> $atc_content
				);
				writelog($log);
			}
		}
		if($tid && $db_ifsort&30){
			require_once(R_P.'require/sort.php');
			sort_delete($tid);
		}
		if ($attachdb) {
			$ftp = null;
			if ($db_ifftp) {
				require_once(R_P.'require/ftp.php');
				$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
			}
			delete_att($attachdb,!$db_recycle);
			if ($ftp) {
				$ftp->close(); unset($ftp);
			}
		}
		P_unlink(R_P."$db_htmdir/$fid/".date('ym',$tpcdb['postdate'])."/$tid.html");

		$rt = $db->get_one("SELECT count(*) AS replies FROM $pw_posts WHERE tid='$tid' AND ifcheck='1'");
		$replies = $rt['replies'];
		if ($db_guestread) {
			require_once(R_P.'require/guestfunc.php');
			clearguestcache($tid,$replies);
		}
		$refreshto = "read.php?tid=$tid";

		if (!$replies) {
			$tpcdb['anonymous'] && $tpcdb['author'] = $db_anonymousname;
			if ($deltpc) {
				if ($db_recycle) {
					$db->update("UPDATE pw_threads SET fid='0' WHERE tid='$tid'");
				} else {
					$db->update("DELETE FROM pw_threads WHERE tid='$tid'");
					$db->update("DELETE FROM $pw_tmsgs WHERE tid='$tid'");
				}
				$refreshto = "thread.php?fid=$fid";
			} else {
				$db->update("UPDATE pw_threads SET replies='0',lastpost=postdate,lastposter='$tpcdb[author]' WHERE tid='$tid'");
			}
		} else {
			$pt = $db->get_one("SELECT postdate,author,anonymous FROM $pw_posts WHERE tid='$tid' ORDER BY postdate DESC LIMIT 1");
			Add_S($pt);
			$pt['anonymous'] && $pt['author'] = $db_anonymousname;
			$db->update("UPDATE pw_threads SET replies='$replies',lastpost='$pt[postdate]',lastposter='$pt[author]' WHERE tid='$tid'");
		}
		updateforum($fid);
		if ($tpcdb['topped'] && $deltpc) {
			updatetop();
		}
		if ($foruminfo['allowhtm']) {
			require_once(R_P.'require/template.php');
		}
		if (defined('AJAX')) {
			Showmsg(($deltpc && !$replies) ? "ajax_operate_success" : "ajaxma_success");
		} else {
			refreshto($refreshto,'operate_success');
		}
	}
} elseif($action=='commend') {

	$forumset = unserialize($foruminfo['forumset']);
	if (!$forumset['commend']) {
		Showmsg('commend_close');
	}
	if (strpos(",$forumset[commendlist],",",$tid,")!==false) {
		Showmsg('commend_exists');
	}
	$count = count(explode(',',$forumset['commendlist']));

	if ($forumset['commendnum'] && $count>=$forumset['commendnum']) {
		Showmsg('commendnum_limit');
	}
	$forumset['commendlist'] .= ($forumset['commendlist'] ? ',' : '').$tid;

	updatecommend($fid,$forumset);
	Showmsg('operate_success');

} elseif ($action=='check') {

	$db->update("UPDATE pw_threads SET ifcheck='1' WHERE tid='$tid' AND fid='$fid' AND ifcheck='0'");
	if ($db->affected_rows()>0) {
		$rt = $db->get_one("SELECT tid,author,postdate,subject FROM pw_threads WHERE fid='$key' AND ifcheck='1' ORDER BY lastpost DESC LIMIT 1");
		$lastpost = $rt['subject']."\t".$rt['author']."\t".$rt['postdate']."\t"."read.php?tid=$rt[tid]&page=e#a";
		$db->update("UPDATE pw_forumdata SET topic=topic+'1',article=article+'1',tpost=tpost+'1',lastpost='$lastpost' WHERE fid='$fid'");
	}
	Showmsg('operate_success');

} elseif ($action=='inspect') {

	$forumset = unserialize($foruminfo['forumset']);
	if (empty($forumset['inspect'])) {
		Showmsg('undefined_action');
	}
	InitGP(array('pid'));

	$rt = $db->get_one("SELECT inspect FROM pw_threads WHERE tid='$tid'");
	empty($rt) && Showmsg('undefined_action');
	list($lou) = explode("\t",$rt['inspect']);
	$pid > $lou && $lou = $pid;
	$inspect = $lou."\t".addslashes($windid);
	$db->update("UPDATE pw_threads SET inspect='$inspect' WHERE tid='$tid'");
	delfcache($fid,$db_fcachenum);
	Showmsg('operate_success');
}
?>