<?php
$wind_in='nt';
require_once('global.php');
require_once(R_P.'require/forum.php');
require_once(R_P.'require/bbscode.php');
require_once(R_P.'require/header.php');
include_once(D_P.'data/bbscache/forum_cache.php');

$sql_select = '';
if ($fid && $fid!='-1' && $fid!='-2') {
	$rt = $db->get_one("SELECT * FROM pw_forums WHERE fid='$fid'");
	if ($rt['type']!='category') {
		!$rt['fid'] && Showmsg('data_error');
		wind_forumcheck($rt);
		$guide[$fid] = array($forum[$fid]['name'],"thread.php?fid=$fid");
	} else {
		$guide[$fid] = array($forum[$fid]['name'],"index.php?cateid=$fid");
		$sql_select = ',url';
	}
} elseif ($fid==-2) {
	$guide[$fid] = array($db_wwwname,$db_wwwurl);
} else {
	$fid = -1;
	$guide[$fid] = array($db_bbsname,'index.php');
	$sql_select = ',url';
}

$noticedb = array();
$query = $db->query("SELECT aid,author,startdate,enddate,subject,content $sql_select FROM pw_announce WHERE fid='$fid' AND ifopen='1' AND startdate<=$timestamp AND (enddate=0 OR enddate>=$timestamp) ORDER BY vieworder,startdate DESC");
while ($rt = $db->fetch_array($query)) {
	$rt['rawauthor'] = rawurlencode($rt['author']);
	$rt['startdate'] = get_date($rt['startdate']);
	if ($sql_select && $rt['url']) {
		$rt['content'] = "<a href=\"$rt[url]\" target=\"_blank\">{$rt[url]}</a>";
	} else {
		$rt['content'] = convert(str_replace(array("\n","\r\n"),'<br />',$rt['content']),$db_windpost,2);
	}
	$noticedb[] = $rt;
}
$db->free_result($query);
list($msg_guide,$forumlist) = headguide($guide);
require_once(PrintEot('notice'));footer();
?>