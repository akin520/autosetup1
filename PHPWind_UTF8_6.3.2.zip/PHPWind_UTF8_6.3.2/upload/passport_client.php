<?php
require_once('global.php');
require_once(R_P.'require/checkpass.php');

InitGP(array('action','userdb','forward','verify'));
if(!$db_pptifopen || $db_ppttype!='client'){
	Showmsg('ϵͳû�п���ͨ��֤���ܣ�');
}
if(md5($action.$userdb.$forward.$db_pptkey) != $verify){
	Showmsg('��ȫ����ʧ�ܣ�����ͨ��֤�����Ƿ���ȷ��');
}
$_db_hash=$db_hash;

$db_hash=$db_pptkey;
parse_str(StrCode($userdb,'DECODE'),$userdb);

if($action=='login'){
	foreach($userdb as $key=>$val){
		$userdb[$key] = Char_cv($val);
	}
	if(!$userdb['time'] || !$userdb['username'] || !$userdb['password']){
		Showmsg('���ݼ���ʧ�ܣ�ȱ�ٲ�����lack_data');
	}
	if($timestamp-$userdb['time']>3600){
		Showmsg('���ݼ���ʧ�ܣ���Ч���ݣ�expired_error');
	}

	$member_field = array('username','password','email');
	$memberdata_field = array('rvrc','money','credit','currency');

	$sql='';
	foreach($member_field as $key=>$val){
		$sql .= ','.$val;
	}
	$rt=$db->get_one("SELECT uid $sql FROM pw_members WHERE username='$userdb[username]'");
	if($rt){
		$sql=$sql2='';
		foreach($userdb as $key=>$val){
			if(in_array($key,$member_field) && $rt[$key] != $val){
				$sql  .= $sql ? ",$key='$val'" : "$key='$val'";
			}elseif(in_array($key,$memberdata_field) && strpos(",$db_pptcredit,",",$key,")!==false){
				$sql2 .= $sql2 ? ",$key='$val'" : "$key='$val'";
			}
		}
		$sql  && $db->update("UPDATE pw_members SET $sql WHERE uid='$rt[uid]'");
		$sql2 && $db->update("UPDATE pw_memberdata SET $sql2 WHERE uid='$rt[uid]'");

		$winduid = $rt['uid'];
	} else{
		$sql1=$sql2=$sql3=$sql4='';
		foreach($userdb as $key=>$val){
			if(in_array($key,$member_field)){
				$sql1 .= $sql1 ? ','.$key  : $key;
				$sql2 .= $sql2 ? ",'$val'" : "'$val'";
			}elseif(in_array($key,$memberdata_field) && strpos(",$db_pptcredit,",",$key,")!==false){
				$val = (int)$val;
				$sql3 .= ",$key";
				$sql4 .= ",'$val'";
			}
		}
		$db->update("REPLACE INTO pw_members($sql1,groupid,memberid,gender,regdate,signchange) VALUES($sql2,'-1','8','0','$timestamp','1')");
		$winduid = $db->insert_id();
		$db->update("REPLACE INTO pw_memberdata (uid,postnum,lastvisit,thisvisit,onlineip $sql3) VALUES ('$winduid','0','$timestamp','$timestamp','$onlineip' $sql4)");

		$db->update("UPDATE pw_bbsinfo SET newmember='$userdb[username]',totalmember=totalmember+1 WHERE id='1'");
	}
	$db_hash=$_db_hash;
	$windpwd = PwdCode($userdb['password']);
	Cookie("winduser",StrCode($winduid."\t".$windpwd),$userdb['cktime']);
	Cookie('lastvisit','',0);
	Loginipwrite();
	ObHeader($forward ? $forward : $db_bbsurl);
} elseif($action=='quit'){
	$db_hash=$_db_hash;
	Loginout();
	ObHeader($forward ? $forward : $db_bbsurl);
}
?>