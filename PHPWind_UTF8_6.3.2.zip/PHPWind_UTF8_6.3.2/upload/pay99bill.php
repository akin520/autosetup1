<?PHP
/**
 * Copyright (c) 2003-08  PHPWind.net. All rights reserved.
 * 
 * @filename: pay99bill.php
 * @author: Noizy 
 * @modify: Thu Jan 31 16:42:58 CST 2008
 */
require_once('global.php');

include_once(D_P.'data/bbscache/ol_config.php');
!$ol_onlinepay && Showmsg($ol_whycolse);
if (!$ol_99bill || !$ol_99billcode) {
	Showmsg('olpay_seterror');
}
strlen($ol_99bill)==11 && $ol_99bill .= '01';
if (trim(GetGP('merchantAcctId'))!=$ol_99bill) {
	Showmsg('olpay_seterror');
}
$para = array('payType','bankId','orderId','orderTime','orderAmount','dealId','bankDealId','dealTime','payAmount','fee','payResult','errCode');

InitGP($para);
$cksignMsg = "merchantAcctId=$ol_99bill&version=v2.0&language=1&signType=1";
foreach ($para as $value) {
	$postvalue = trim(${$value});
	if (strlen($postvalue)>0) {
		$cksignMsg .= "&$value=$postvalue";
	}
}
if (strtoupper(md5($cksignMsg."&key=$ol_99billcode"))!=strtoupper(trim(GetGP('signMsg')))) {
	Showmsg('olpay_seterror');
}
require_once(R_P.'require/header.php');
if ($payResult=='10') {
	$rt = $db->get_one("SELECT c.uid,c.number,c.state,m.username FROM pw_clientorder c LEFT JOIN pw_members m USING(uid) WHERE c.order_no='$orderId'");
	$rt['state'] && refreshto('userpay.php','complete_list');
	$number = $payAmount/100;
	$rt['number']!=$number && Showmsg('gross_error');
	$currency = $number*$db_rmbrate;
	include(GetLang('other'));
	$db->update("UPDATE pw_memberdata SET currency=currency+'$currency' WHERE uid='$rt[uid]'");
	$db->update("UPDATE pw_clientorder SET state=2,descrip='$lang[succeed_order]' WHERE order_no='$orderId'");
	require_once(R_P.'require/tool.php');
	writetoollog(array('type' => 'olpay','nums' => 0,'money' => 0,'descrip'	=> 'olpay_descrip','uid' => $rt['uid'],'username' =>	$rt['username'],'ip' => $onlineip,'time' => $timestamp,'number' => $number,'currency'=> $currency));
	require_once(R_P.'require/msg.php');
	writenewmsg(array($rt['username'],'','olpay_title',$timestamp,'olpay_content_2','','SYSTEM'),1);
	$cksignMsg = explode('&',$cksignMsg);
	foreach ($cksignMsg as $key => $value) {
		$cksignMsg[$key] = urlencode($value);
	}
	$cksignMsg['date'] = get_date($timestamp,'Y-m-d-H:i:s');
	$cksignMsg['site'] = $_SERVER['HTTP_HOST'];
	$cksignMsg = implode('&',$cksignMsg);
	@file("http://www.phpwind.com/pay/paypal.php?$cksignMsg");
}
require_once PrintEot('pay99bill');footer();
?>