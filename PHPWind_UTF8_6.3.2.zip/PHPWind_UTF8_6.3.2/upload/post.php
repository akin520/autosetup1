<?php
define('SCR','post');
require_once('global.php');
require_once(R_P.'require/forum.php');
include_once(D_P.'data/bbscache/cache_post.php');
/**
* ��黺���ļ�
*/
$foruminfo = $db->get_one("SELECT * FROM pw_forums f LEFT JOIN pw_forumsextra fe USING(fid) WHERE f.fid='$fid' AND type<>'category'");
!$foruminfo && Showmsg('data_error');
$forumset  = unserialize($foruminfo['forumset']);
$creditset = $foruminfo['creditset'];
wind_forumcheck($foruminfo);
empty($fid) && Showmsg('undefined_action');
list($db_moneyname,$db_moneyunit,$db_rvrcname,$db_rvrcunit,$db_creditname,$db_creditunit)=explode("\t",$db_credits);
/*
* ��ȡ����Ȩ��
*/
if ($groupid==3 || admincheck($foruminfo['forumadmin'],$foruminfo['fupadmin'],$windid)) {
	$admincheck=1;
} else {
	$admincheck=0;
}
!$windid && $admincheck=0;
if (!CkInArray($windid,$manager) && $groupid != 3 && !$foruminfo['allowvisit'] && !admincheck($foruminfo['forumadmin'],$foruminfo['fupadmin'],$windid)) {
	forum_creditcheck();
}

if ($forumset['allowtime'] && !$admincheck && !allowcheck($forumset['allowtime'],"$t[hours]",'')) {
	Showmsg('forum_allowtime');
}
list($uploadcredit,$uploadmoney,,) = explode("\t",$forumset['uploadset']);

InitGP(array('action','special','article','pid','p_type'));
$replacedb = array();
$special   = (int)$special;
$secondurl = "thread.php?fid=$fid";
$top_post  = 0;
!$action && $action = "new";

if ($action=='new' && !($foruminfo['allowtype'] & pow(2,$special))) {
	if (empty($special) && $foruminfo['allowtype'] > 0) {
		$special = (int)log($foruminfo['allowtype'],2);
	} else {
		Showmsg('post_allowtype');
	}
}
list($db_openpost,$db_poststart,$db_postend) = explode("\t",$db_openpost);

if ($db_openpost == 1 && $groupid != 3 && $groupid != 4) {
	if ($db_poststart < $db_postend && ($t['hours'] < $db_poststart || $t['hours'] >= $db_postend)) {
		Showmsg('post_openpost');
	} elseif ($db_poststart > $db_postend && ($t['hours'] < $db_poststart && $t['hours'] >= $db_postend)) {
		Showmsg('post_openpost');
	}
}
/**
* ��ֹ�������û�����
*/
if ($groupid=='6') {
	$bandb = $db->get_one("SELECT * FROM pw_banuser WHERE uid='$winduid'");
	if (!$bandb) {
		$db->update("UPDATE pw_members SET groupid='-1' WHERE uid='$winduid'");
	} elseif ($bandb['type']==1 && $timestamp-$bandb['startdate']>$bandb['days']*86400) {
		$db->update("DELETE FROM pw_banuser WHERE uid='$winduid'");
		$db->update("UPDATE pw_members SET groupid='-1' WHERE uid='$winduid'");
	} else {
		if ($bandb['type']==1) {
			$s_date = get_date($bandb['startdate']);
			$e_date = $bandb['startdate']+$bandb['days']*86400;
			$e_date = get_date($e_date);
			Showmsg('ban_info1');
		} else {
			if ($bandb['type']==3) {
				Cookie('force',$winduid);
				Showmsg('ban_info3');
			} else {
				Showmsg('ban_info2');
			}
		}
	}
}
if (GetCookie('force') && $winduid != GetCookie('force')) {
	$force = GetCookie('force');
	$bandb = $db->get_one("SELECT type FROM pw_banuser WHERE uid='$force'");
	if ($bandb['type']==3) {
		Showmsg('ban_info3');
	} else {
		Cookie('force','',0);
	}
}
/**
* ��Ҫ��֤�û�ֻ��ͨ������Ա��֤����ܷ���
*/
if ($groupid=='7') {
	Showmsg('post_check');
}
/*
* ��ע���Ա����ʱ������
*/
if ($db_postallowtime && $timestamp-$winddb['regdate']<$db_postallowtime*60) {
	Showmsg('post_newrg_limit');
}
$userlastptime = $groupid != 'guest' ?  $winddb['lastpost'] : GetCookie('userlastptime');
/**
* ��ˮԤ��
*/
$tdtime  >= $winddb['lastpost'] && $winddb['todaypost'] = 0;
$montime >= $winddb['lastpost'] && $winddb['monthpost'] = 0;
if ($_G['postlimit'] && $winddb['todaypost'] >= $_G['postlimit']) {
	Showmsg('post_gp_limit');
}
if ($action!="modify" && !$SYSTEM['postpers'] && $gp_postpertime && $timestamp>=$userlastptime && $timestamp-$userlastptime<=$gp_postpertime) {
	Showmsg('post_limit');
}
list(,,$postq)  = explode("\t",$db_qcheck);
$_G['uploadtype'] && $db_uploadfiletype = $_G['uploadtype'];
$db_uploadfiletype = !empty($db_uploadfiletype) ? unserialize($db_uploadfiletype) : array();
$db_sellset = !empty($db_sellset) ? unserialize($db_sellset) : array();

if (!$_POST['step']) {
	$editor  = $winddb['editor'] ? 'wysiwyg' : 'textmode';
	$verify  = substr(md5($winduid.$db_hash.$fid),0,8);
	!is_numeric($db_attachnum) && $db_attachnum=1;
	$htmlpost   = $htmlatt = ($foruminfo['allowhide'] && $gp_allowhidden) ? '' : "disabled";
	$htmlsell   = ($foruminfo['allowsell'] && $gp_allowsell) ? '' : "disabled";
	$htmlhide   = ($forumset['allowencode'] && $_G['allowencode']) ? '' : "disabled";
	$ifanonymous= ($forumset['anonymous'] && $_G['anonymous']) ? '' : "disabled";
	$groupid   =='guest' && $userrvrc = 0;
	$atc_title  = $atc_content = $ifmailck = $selltype = '';
	$uploadfiletype = $uploadfilesize = ' ';
	foreach ($db_uploadfiletype as $key=>$value) {
		$uploadfiletype .= $key.' ';
		$uploadfilesize .= $key.':'.$value.'KB; ';
	}
	!is_array($db_sellset['type']) && $db_sellset['type'] = array('money');
	foreach ($db_sellset['type'] as $key=>$value) {
		$selltype .= "<option value=\"$value\">".(is_numeric($value) ? $_CREDITDB[$value][0] : ${'db_'.$value.'name'})."</option>";
	}
	/**
	* �������
	*/
	$icondb = array(
		'1'=>'1.gif',	'2'=>'2.gif',
		'3'=>'3.gif',	'4'=>'4.gif',
		'5'=>'5.gif',	'6'=>'6.gif',
		'7'=>'7.gif',	'8'=>'8.gif'
	);
} elseif ($_POST['step']) {

	$postcheck = $_POST['verify']==substr(md5($winduid.$db_hash.$fid),0,8) ? 1 : 0;
	if ($postcheck==0) {
		if ($action!='reply' || $foruminfo['allowhtm']==0 || $_POST['verify']!='verify') {
			Showmsg('illegal_request');
		}
	}
	!$windid && $windid='guest';
	($db_gdcheck & 4) && $winddb['postnum'] < $db_postgd && GdConfirm($_POST['gdcode']);
	$winddb['postnum'] < $postq && Qcheck($_POST['qanswer'],$_POST['qkey']);

	require_once(R_P.'require/bbscode.php');
	require_once(R_P.'require/postfunc.php');
	if(@include(D_P."data/bbscache/wordsfb.php")){
		foreach ($wordsfb as $key => $value) {
			$banword = (string) stripslashes($key);
			if (strpos($_POST['atc_title'],$banword)!==false) {
				Showmsg('title_wordsfb');
			} elseif (strpos($_POST['atc_content'],$banword)!==false) {
				Showmsg('content_wordsfb');
			} elseif (strpos($_POST['atc_tags'],$banword)!==false) {
				Showmsg("tag_wordsfb");
			}
		}
		foreach ($replace as $key => $value) {
			$banword = (string) stripslashes($key);
			if (strpos($_POST['atc_title'],$banword)!==false) {
				Showmsg('post_wordsfb');
			} elseif (strpos($_POST['atc_tags'],$banword)!==false) {
				Showmsg("tag_wordsfb");
			}
		}
	}
	list($lastip,$ipfrom) = explode("\t",str_replace('<','&lt;',$ipfrom));
	if ($lastip != md5($onlineip)) {
		$ipfrom = cvipfrom($onlineip);
		$ipfrom = str_replace("\n","",$ipfrom);
		Cookie('ipfrom',md5($onlineip)."\t".$ipfrom);
	}
	$atc_usesign = $_POST['atc_usesign'] ? 1 : 0;
	if ($gp_htmlcode && $_POST['atc_html']) {
		$atc_usesign += 2;
	}
	/**
	* �õ������id
	*/
	$fatherid = $foruminfo['type']=='sub' ? $foruminfo['fup']:'';
}
//Ĭ�϶������鴦��
if ($db_windmagic && ($action == 'new' || ($action == 'modify' && $pid == 'tpc'))) {
	$mDef      = '';
	@include_once(D_P."data/bbscache/myshow_default.php");
}
if ($action=="new") {
	require_once(R_P.'require/postnew.php');
} elseif ($action=="reply" || $action=="quote") {
	require_once(R_P.'require/postreply.php');
} elseif ($action=="modify") {
	require_once(R_P.'require/postmodify.php');
} else {
	Showmsg('undefined_action');
}
?>