<?php
define('PRO','1');
require_once('global.php');
!$winduid && Showmsg('not_login');

require_once(R_P.'require/bbscode.php');
require_once(R_P.'require/postfunc.php');
include_once(D_P.'data/bbscache/level.php');
require_once(R_P.'require/header.php');

$action = GetGP('action');
if ($action=='show') {
	@include_once(D_P.'data/bbscache/customfield.php');
	InitGP(array('uid','username'));
	!$uid && !$username && $uid = $winduid;
	$sql = $uid ? "m.uid='$uid'" : "m.username='$username'";
	list($db_moneyname,$db_moneyunit,$db_rvrcname,$db_rvrcunit,$db_creditname,$db_creditunit) = explode("\t",$db_credits);
	$fieldadd = '';
	!is_array($customfield) && $customfield = array();
	foreach ($customfield as $key => $value) {
		$customfield[$key]['id'] = $value['id'] = (int)$value['id'];
		$value['type']==3 && $customfield[$key]['options'] = explode("\n",$value['options']);
		$fieldadd .= ",mb.field_$value[id]";
	}
	$userdb = $db->get_one("SELECT m.uid,m.username,m.email,m.publicmail,m.groupid,m.memberid,m.icon,m.gender,m.regdate,m.signature,m.introduce,m.oicq,m.icq,m.msn,m.yahoo,m.site,m.honor,m.bday,m.signchange,m.medals,md.thisvisit,md.onlinetime,md.postnum,md.digests,md.rvrc,md.money,md.credit,md.lastvisit,md.lastpost,md.todaypost,md.onlineip$fieldadd,mb.tooltime,mb.customdata FROM pw_members m LEFT JOIN pw_memberdata md USING(uid) LEFT JOIN pw_memberinfo mb USING(uid) WHERE $sql");
	if (empty($userdb)) {
		$errorname = '';
		Showmsg('user_not_exists');
	}
	if ($winduid!=$userdb['uid'] && !$gp_allowprofile) {
		Showmsg('profile_right');
	}

	include_once(D_P.'data/bbscache/md_config.php');
	require_once(R_P.'require/showimg.php');
	require_once(R_P.'require/credit.php');
	$customdata = $custominfo = $colonydb = array();

	$usericon = showfacedesign($userdb['icon'],true);
	if ($usericon[0]=="$imgpath/pig.gif" && $userdb['tooltime'] && $userdb['tooltime']<$timestamp-3600*24) {
		$usericon[0] = "$imgpath/face/none.gif";
		$tempicon = addslashes("$usericon[4]|$usericon[1]|$usericon[2]|$usericon[3]");
		$db->update("UPDATE pw_members SET icon='$tempicon' WHERE uid='$winduid'");
	}
	$imglen = '';
	if ($usericon[1]=='2' || $usericon[1]=='3') {
		$usericon[2] && $imglen .= " width=\"$usericon[2]\"";
		$usericon[3] && $imglen .= " height=\"$usericon[3]\"";
	}
	$usericon = "<img class=\"pic\" src=\"$usericon[0]\"$imglen border=\"0\" />";

	$query = $db->query("SELECT cy.id,cy.cname FROM pw_cmembers c LEFT JOIN pw_colonys cy ON cy.id=c.colonyid WHERE c.uid='$userdb[uid]'");
	while ($rt = $db->fetch_array($query)) {
		$colonydb[] = $rt;
	}

	if ($md_ifopen && $userdb['medals']) {
		include_once(D_P.'data/bbscache/medaldb.php');
		$query=$db->query("SELECT id,awardee,level FROM pw_medalslogs WHERE awardee='$userdb[username]' AND action='1' AND state='0' AND timelimit>0 AND $timestamp-awardtime>timelimit*2592000");
		if($db->num_rows($query)){
			include_once(R_P.'require/msg.php');
			include(GetLang('msg'));
			$lang['medal_reason'] && $reason = Char_cv($lang['medal_reason']);
			$ids = $medals = array();
			while($rt = $db->fetch_array($query)){
				$ids[] = $rt['id'];
				$medals[] = $rt['level'];
				$db->update("INSERT INTO pw_medalslogs(awardee,awarder,awardtime,level,action,why) VALUES('$rt[awardee]','SYSTEM','$timestamp','$rt[level]','2','$reason')");
				$message=array(
					$rt['awardee'],
					0,
					'metal_cancel',
					$timestamp,
					"metal_cancel_text",
					'N',
					''
				);
				writenewmsg($message,1);
			}
			if(count($ids)){
				$ids = implode(',',$ids);
				$db->update("UPDATE pw_medalslogs SET state='1' WHERE id IN($ids)");
				$userdb['medals'] = explode(',',$userdb['medals']);
				$userdb['medals'] = array_diff($userdb['medals'],$medals);
				$userdb['medals'] = implode(',',$userdb['medals']);
				$db->update("UPDATE pw_members SET medals='$userdb[medals]' WHERE uid='$userdb[uid]'");
				updatemedal_list();
			}
		}
		$userdb['medals'] = explode(',',$userdb['medals']);
	}

	$usercredit = array(
		'postnum'	 => $userdb['postnum'],
		'digests'	 => $userdb['digests'],
		'rvrc'		 => $userdb['rvrc'],
		'money'		 => $userdb['money'],
		'credit'	 => $userdb['credit'],
		'onlinetime' => $userdb['onlinetime']
	);
	$creditdb = GetCredit($userdb['uid']);
	foreach ($creditdb as $key => $value) {
		$usercredit[$key] = $value[1];
	}
	$totalcredit = CalculateCredit($usercredit,unserialize($db_upgrade));

	$newmemberid = getmemberid($totalcredit);
	if ($userdb['memberid']!=$newmemberid) {
		$userdb['memberid'] = $newmemberid;
		$db->update("UPDATE pw_members SET memberid='$newmemberid' WHERE uid='$userdb[uid]'");
	}

	if ($db_autoban) {
		require_once(R_P.'require/autoban.php');
		autoban($userdb['uid']);
	}

	if ($userdb['groupid']=='6') {
		$bandb = $db->get_one("SELECT type,startdate,days FROM pw_banuser WHERE uid='$userdb[uid]'");
		if (empty($bandb)) {
			$db->update("UPDATE pw_members SET groupid='-1' WHERE uid='$userdb[uid]'");
			$userdb['groupid']=-1;
		} elseif ($bandb['type']==1 && $timestamp-$bandb['startdate']>$bandb['days']*86400) {
			$db->update("DELETE FROM pw_banuser WHERE uid='$userdb[uid]'");
			$db->update("UPDATE pw_members SET groupid='-1' WHERE uid='$userdb[uid]'");
			$userdb['groupid']=-1;
		}
		$bandb['startdate'] = get_date($bandb['startdate']);
	}

	$userdb['rvrc'] = floor($userdb['rvrc']/10);
	if ($userdb['site'] && substr($userdb['site'],0,4)!='http') {
		$userdb['site'] = "http://$userdb[site]";
	}
	$systitle = $userdb['groupid']=='-1' ? '' : $ltitle[$userdb['groupid']];
	$memtitle = $ltitle[$userdb['memberid']];

	if (!$userdb['publicmail'] && !CkInArray($windid,$manager)) {
		$userdb['email'] = "<img src=\"$imgpath/$stylepath/read/email.gif\" border=\"0\">";
	}

	list($userdb['onlineip']) = explode('|',$userdb['onlineip']);
	$userdb['lastvisit'] = get_date($userdb['lastvisit'],'Y-m-d');
	if (!$userdb['todaypost'] || $userdb['lastpost']<$tdtime) $userdb['todaypost'] = 0;
	$averagepost = floor($userdb['postnum']/(ceil(($timestamp-$userdb['regdate'])/(3600*24))));
	$userdb['regdate']=get_date($userdb['regdate'],'Y-m-d');

	$db_union[7] && list($customdata,$custominfo) = Getcustom($userdb['customdata']);

	if ($userdb['signchange']==2 && $db_signwindcode) {
		if ($_G['imgwidth'] && $_G['imgheight']) {
			$db_windpic['picwidth']  = $_G['imgwidth'];
			$db_windpic['picheight'] = $_G['imgheight'];
		}
		$_G['fontsize'] && $db_windpic['size'] = $_G['fontsize'];
		$userdb['signature'] = convert($userdb['signature'],$db_windpic,2);
	}
	$userdb['signature'] = str_replace("\n","<br>",$userdb['signature']);
	$userdb['introduce'] = str_replace("\n","<br>",$userdb['introduce']);
	if ($db_ifonlinetime && $userdb['onlinetime']) {
		$userdb['onlinetime'] = floor($userdb['onlinetime']/3600);
	} else {
		$userdb['onlinetime'] = 0;
	}
	$db_plist = $gp_allowsearch==2 && $db_plist ? explode(',',$db_plist) : array();
	require_once(PrintEot('showuserdb'));footer();
} elseif ($action=='modify') {
	@include_once(D_P.'data/bbscache/customfield.php');
	require_once(R_P.'require/showimg.php');
	$ifppt = false;
	$madd = $mbadd = $mbjoin = '';
	if (!$db_pptifopen || $db_ppttype=='server') {
		$ifppt = true;
		$madd .= ',m.password,m.publicmail';
	}

	!is_array($customfield) && $customfield = array();
	foreach ($customfield as $key => $value) {
		$customfield[$key]['id'] = $value['id'] = (int)$value['id'];
		$customfield[$key]['field'] = "field_$value[id]";
		if ($value['type']==3 && $_POST['step']!=2) {
			$customfield[$key]['options'] = explode("\n",$value['options']);
		} elseif ($value['type']==2) {
			$SCR = 'post';
		}
		$mbadd .= ",mb.field_$value[id]";
	}
	$db_union[7] && $mbadd .= ',mb.customdata';
	$mbadd && $mbjoin = ' LEFT JOIN pw_memberinfo mb USING(uid)';

	$userdb = $db->get_one("SELECT m.email$madd,m.groupid,m.groups,m.icon,m.gender,m.signature,m.introduce,m.oicq,m.icq,m.msn,m.yahoo,m.site,m.location,m.honor,m.bday,m.receivemail,m.timedf,m.datefm,m.t_num,m.p_num,m.showsign,m.payemail$mbadd,md.currency,md.starttime,md.editor FROM pw_members m LEFT JOIN pw_memberdata md USING(uid)$mbjoin WHERE m.uid='$winduid'");
	list($iconurl,$icontype,$iconwidth,$iconheight,$iconfile,$iconpig) = showfacedesign($userdb['icon'],true);
	$t_num = array(10,20,30,40);
	$p_num = array(10,20,30);
	if ($groupid && in_array($groupid,array(3,4,5))) {
		$t_num[] = 100;
		$p_num[] = 100;
	}
	if ($_POST['step']!=2) {
		unset($iconpig);
		include_once(D_P.'data/bbscache/dbreg.php');
		require_once(R_P.'require/forum.php');
		require_once(R_P.'require/header.php');
		$customdata = $custominfo = $sexselect = $yearslect = $monthslect = $dayslect = array();
		$ifpublic = $iconsize = $groupselect = $editor_wys = $editor_com = $check_12 = $httpurl = '';
		$ifsign = false;

		$userdb['publicmail'] && $ifpublic = 'checked';

		if ($SYSTEM['selgroup'] && $userdb['groups']) {
			$groupselect = $userdb['groupid']=='-1' ? '<option></option>' : "<option value=\"$userdb[groupid]\">".$ltitle[$userdb['groupid']]."</option>";
			$groups = explode(',',$userdb['groups']);
			foreach ($groups as $value) {
				if ($value && array_key_exists($value,$ltitle)) {
					$groupselect .= "<option value=\"$value\">$ltitle[$value]</option>";
				}
			}
		}

		$db_union[7] && list($customdata,$custominfo) = Getcustom($userdb['customdata']);

		list($pay,$payemail) = explode("\t",$userdb['payemail']);
		if (!$pay || !is_numeric($pay) || !in_array($pay,array(1,4))) {
			$pay = 4;
			$payemail = '';
		}

		$check_24 = ${'pay_'.$pay} = $sexselect[(int)$userdb['gender']] = 'checked';

		!$rg_timestart && $rg_timestart = 1960;
		!$rg_timeend && $rg_timeend = 2000;
		$getbirthday = explode('-',$userdb['bday']);
		$yearslect[(int)$getbirthday[0]] = $monthslect[(int)$getbirthday[1]] = $dayslect[(int)$getbirthday[2]] = 'selected';

		$width2 = $width3 = $iconwidth;
		$height2 = $height3 = $iconheight;
		$iconwidth && $iconsize = " width=\"$iconwidth\"";
		$iconheight && $iconsize .= " height=\"$iconheight\"";
		if ($icontype == 2) {
			$httpurl = $iconurl;
			$width3 = $height3 = '';
		} elseif ($icontype == 3) {
			$width2 = $height2 = '';
		}

		if ($db_signmoney && strpos($db_signgroup,",$groupid,")!==false) {
			require_once(R_P.'require/credit.php');
			$cur = UserCredit($winduid,$db_signcurtype);
			$cur===false && Showmsg('numerics_checkfailed');
			$ifsign = true;
			$days = $cur < 0 ? 0 : floor($cur/$db_signmoney);
			if ($userdb['starttime'] && $userdb['starttime'] <= $tdtime) {
				$haveshow = floor(($tdtime-$userdb['starttime'])/86400)+1;
			} else {
				$haveshow = 0;
			}
			${'showsign_'.(int)$userdb['showsign']} = 'checked';
			$credittype = GetCreditValue($db_signcurtype);
		}

		$choseskin = getstyles($skin);
		$userdb['editor'] ? $editor_wys = 'checked' : $editor_com = 'checked';

		if ($userdb['timedf']) {
			$temptimedf = str_replace('.','_',abs($userdb['timedf']));
			$userdb['timedf'] < 0 ? ${'zone_0'.$temptimedf}='SELECTED' : ${'zone_'.$temptimedf} = 'selected';
		}

		if ($userdb['datefm']) {
			if (strpos($userdb['datefm'],'h:i A')!==false) {
				$userdb['datefm'] = str_replace(' h:i A','',$userdb['datefm']);
				$check_12 = 'checked';
				$check_24 = '';
			} else {
				$userdb['datefm'] = str_replace(' H:i','',$userdb['datefm']);
			}
			$userdb['datefm'] = str_replace(array('m','n','d','j','y','Y'), array('mm','m','dd','d','yy','yyyy'), $userdb['datefm']);
			$d_type_1 = 'checked';
		} else {
			$userdb['datefm'] = 'yyyy-mm-dd';
			$d_type_0 = 'checked';
		}

		${'T_'.(int)$userdb['t_num']} = ${'P_'.(int)$userdb['p_num']} = 'selected';//p_num step2 bug

		$userdb['receivemail'] ? $email_open = 'checked' : $email_close = 'checked';
		if ($userdb['signature'] || $userdb['introduce']) {
			$SCR = 'post';
		}
		require_once(PrintEot('profile'));footer();
	} else {
		Add_S($userdb);
		$upmembers = $upmemdata = $upmeminfo = '';
		if ($ifppt) {
			InitGP(array('propwd','proemail','question'),'P');
			if ($propwd || $userdb['email']!=$proemail || ($db_ifsafecv && $question!='-2')) {
				if ($_POST['oldpwd']) {
					if (strlen($userdb['password'])==16) {
						$_POST['oldpwd'] = substr(md5($_POST['oldpwd']),8,16);//֧�� 16 λ md5��ȡ����
					} else {
						$_POST['oldpwd'] = md5($_POST['oldpwd']);
					}
				}
				$userdb['password']!=$_POST['oldpwd'] && Showmsg('pwd_confirm_fail');
				if ($propwd) {
					CkInArray($windid,$manager) && Showmsg('pro_manager');
					$propwd!=$_POST['check_pwd'] && Showmsg('password_confirm');
					if ($propwd!=str_replace(array("\\",'&',' ',"'",'"','/','*',',','<','>',"\r","\t","\n",'#','%'),'',$propwd)) {
						Showmsg('illegal_password');
					}
					$upmembers .= ",password='".md5($propwd)."'";
				}
				if ($userdb['email']!=$proemail) {
					include_once(D_P.'data/bbscache/dbreg.php');
					$rg_emailcheck && Showmsg('pro_emailcheck');
				}
				if ($question!='-2') {
					$safecv = '';
					if ($db_ifsafecv) {
						require_once(R_P.'require/checkpass.php');
						$safecv = questcode($question,$_POST['customquest'],$_POST['answer']);
					}
					$upmembers .= ",safecv='$safecv'";
				}
			}
			$upmembers .= ",publicmail='".(int)$_POST['propublicemail']."'";
		} else {
			$proemail = $userdb['email'];
		}
		if (!preg_match('/^[-a-zA-Z0-9_\.]+\@([0-9A-Za-z][0-9A-Za-z-]+\.)+[A-Za-z]{2,5}$/',$proemail)) {
			Showmsg('illegal_email');
		}
		InitGP(array('proicon','prosign','profrom','proyahoo','promsn','prohomepage','prohonor','prointroduce','tpskin','date_f','timedf'),'P',1);
		InitGP(array('newgroupid','prooicq','pricq','progender','proyear','promonth','proday','pay','payemail','showsign','editor','proreceivemail','facetype','customdata'),'P');

		$newgroupid = (int)$newgroupid;
		if ($newgroupid && $newgroupid!=$userdb['groupid'] && $SYSTEM['selgroup'] && $userdb['groups']) {
			if (strpos($userdb['groups'],','.$newgroupid.',')===false) {
				Showmsg('undefined_action');
			} else {
				if ($userdb['groupid']=='-1') {
					$groups = str_replace(",$newgroupid,",',',$userdb['groups']);
					$groups==',' && $groups='';
				} else {
					$groups = str_replace(",$newgroupid,",",$userdb[groupid],",$userdb['groups']);
				}
				$upmembers .= ",groupid='$newgroupid',groups='$groups'";
			}
		}

		$prooicq && !is_numeric($prooicq) && Showmsg('illegal_OICQ');
		$proicq && !is_numeric($proicq) && Showmsg('illegal_OICQ');

		if ($payemail && ($pay!=4 || ($pay==4 && !is_numeric($payemail))) && !preg_match('/^[-a-zA-Z0-9_\.]+\@([0-9A-Za-z][0-9A-Za-z-]+\.)+[A-Za-z]{2,5}$/',$payemail)) {
			Showmsg('illegal_pay');
		}

		strlen($prointroduce)>500 && Showmsg('introduce_limit');
		$gp_signnum && strlen($prosign)>$gp_signnum && Showmsg('sign_limit');
		if ($gp_allowhonor) {
			$prohonor = substrs($prohonor,100);
			$upmembers .= ",honor='$prohonor'";
		}
		@include_once(D_P.'data/bbscache/wordsfb.php');
		if (!empty($wordsfb) || !empty($replace)) {
			$wordsfb = (array)$wordsfb + (array)$replace;
			foreach ($wordsfb as $key => $value) {
				$banword = (string)stripslashes($key);
				if ($banword && (lowerstrpos($prosign,$banword) || lowerstrpos($prointroduce,$banword) || lowerstrpos($prohonor,$banword))) {
					Showmsg('sign_wordsfb');
				}
			}
		}
		//upmeminfo
		if ($db_union[7]) {
			list($customdata) = Getcustom($customdata,false,true);
			!empty($customdata) && $upmeminfo .= ",customdata='".addslashes(serialize($customdata))."'";
		}
		foreach ($customfield as $value) {
			$fieldvalue = Char_cv($_POST[$value['field']]);
			if ($value['required'] && !$userdb[$value['field']] && !$fieldvalue) {
				Showmsg('field_empty');
			}
			if ($fieldvalue && $userdb[$value['field']]!=$fieldvalue) {
				if ($value['maxlen'] && strlen($fieldvalue)>$value['maxlen']) {
					Showmsg('field_lenlimit');
				}
				$upmeminfo .= ",$value[field]='$fieldvalue'";
			}
		}
		//upmemdata
		$writelog = false;
		$showsign = $showsign ? 1 : 0;
		if ($userdb['showsign']==1 && $showsign==0) {
			$upmemdata .= ",starttime='0'";
		} elseif ($userdb['showsign']==0 && $showsign==1) {
			require_once(R_P.'require/credit.php');
			if (($cur = UserCredit($winduid,$db_signcurtype))===false) {
				Showmsg('numerics_checkfailed');
			}
			if ($cur < $db_signmoney) {
				Showmsg('noenough_currency');
			}
			if (!UserCredit($winduid,$db_signcurtype,'set',"-$db_signmoney")) {
				Showmsg('numerics_checkfailed');
			}
			$upmemdata .= ",starttime='$tdtime'";
			$writelog = true;
		}
		$editor = $editor ? 1 : 0;
		if ($editor!= $userdb['editor']) {
			$upmemdata .= ",editor='$editor'";
		}

		$ftp = null;
		if ($db_ifftp) {
			require_once(R_P.'require/ftp.php');
			$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
		}
		//user icon
		$iconfile = addslashes($iconfile);
		if ($gp_allowportait && $facetype==2) {
			$httpurl = $_POST['httpurl'];
			if (substr($httpurl[0],0,4)!='http' || strrpos($httpurl[0],'|')!==false) {
				Showmsg('illegal_customimg');
			}
			$icontype==3 && DelIcon($iconfile);
			$httpurl[1] = (int)$httpurl[1];
			$httpurl[2] = (int)$httpurl[2];
			$iconfile = $httpurl[0];
			list($iconwidth,$iconheight) = getfacelen($httpurl[1],$httpurl[2]);
			unset($httpurl);
		} elseif ($db_ifupload && $gp_upload && $facetype==3 && is_array($_POST['uploadurl'])) {
			UploadIcon($_POST['uploadurl']);
		}
		$facetype!=1 && $facetype!=2 && $facetype!=3 && $facetype = $icontype;
		$usericon = GetIcon($proicon);
		if ($ftp) {
			$ftp->close(); unset($ftp);
		}
		//update memdata
		if ($upmemdata) {
			if ($writelog) {
				require_once(R_P.'require/tool.php');
				$logdata = array(
					'type'		=>	'sign',
					'nums'		=>	0,
					'money'		=>	0,
					'descrip'	=>	'sign_descrip',
					'uid'		=>	$winduid,
					'username'	=>	$windid,
					'ip'		=>	$onlineip,
					'time'		=>	$timestamp,
					'curtype'	=>	GetCreditValue($db_signcurtype),
					'currency'	=>	$db_signmoney
				);
				writetoollog($logdata);
			}
			$db->update("UPDATE pw_memberdata SET ".substr($upmemdata,1)." WHERE uid='$winduid'");
		}
		//update meminfo
		if ($upmeminfo) {
			$db->pw_update(
				"SELECT uid FROM pw_memberinfo WHERE uid='$winduid'",
				"UPDATE pw_memberinfo SET ".substr($upmeminfo,1)." WHERE uid='$winduid'",
				"INSERT INTO pw_memberinfo SET uid='$winduid'$upmeminfo"
			);
		}
		unset($upmemdata,$upmeminfo,$iconurl,$icontype,$iconwidth,$iconheight,$iconfile,$iconpig,$facetype,$userdb,$customfield);
		//other
		$payemail = (int)$pay."\t$payemail";
		$prohomepage && substr($prohomepage,0,4)!='http' && $prohomepage = "http://$prohomepage";
		$progender = (int)$progender;
		$proreceivemail = (int)$proreceivemail;

		$probday = '';
		if ($proyear || $promonth || $proday) {
			$probday = (int)$proyear.'-'.(int)$promonth.'-'.(int)$proday;
		}
		if ($_POST['d_type'] && $date_f) {
			$date_f  = strpos($date_f,'mm')!==false ? str_replace('mm','m',$date_f) : str_replace('m','n',$date_f);
			$date_f  = strpos($date_f,'dd')!==false ? str_replace('dd','d',$date_f) : str_replace('d','j',$date_f);
			$date_f  = str_replace(array('yyyy','yy'),array('Y','y'),$date_f);
			$date_f .= $_POST['time_f']=='12' ? ' h:i A' :' H:i';
		} else {
			$date_f = '';
		}

		if ($_POST['t_num'] && !in_array($_POST['t_num'],$t_num)) {
			$t_num = 0;
		} else {
			$t_num = $_POST['t_num'];
		}
		if ($_POST['p_num'] && !in_array($_POST['p_num'],$p_num)) {
			$p_num = 0;
		} else {
			$p_num = $_POST['p_num'];
		}

		$cksign = convert($prosign,$db_windpic,2);
		$signchange = $cksign!=$prosign ? 2 : 1;
		if (GetCookie('skinco') && $tpskin!=GetCookie('skinco')) {
			Cookie('skinco','',0);
		}
		//update member
		$db->update("UPDATE pw_members SET email='$proemail'$upmembers,icon='$usericon',gender='$progender',signature='$prosign',introduce='$prointroduce',oicq='$prooicq',icq='$proicq',yahoo='$proyahoo',msn='$promsn',site='$prohomepage',location='$profrom',bday='$probday',style='$tpskin',datefm='$date_f',timedf='$timedf',t_num='$t_num',p_num='$p_num',receivemail='$proreceivemail',signchange='$signchange',showsign='$showsign',payemail='$payemail' WHERE uid='$winduid'");
		refreshto("profile.php?action=show&uid=$winduid",'operate_success');
	}
} elseif($action=='friend'){//phpwind
	InitGP(array('job'));
	if(!$job){
		$frienddb = array();
		$query = $db->query("SELECT f.*,m.username,md.thisvisit FROM pw_friends f LEFT JOIN pw_members m ON m.uid=f.friendid LEFT JOIN pw_memberdata md ON md.uid=f.friendid WHERE f.uid='$winduid' ORDER BY f.joindate DESC");
		while($rt = $db->fetch_array($query)){
			$rt['joindate'] = get_date($rt['joindate']);
			$frienddb[]=$rt;
		}
		require_once(PrintEot('profile'));footer();
	} elseif($_POST['job']=='submit'){
		InitGP(array('pwuser','descrip','selid','frienddb'),'P');
		if($pwuser){
			$rt = $db->get_one("SELECT uid FROM pw_members WHERE username='$pwuser'");
			if($rt['uid']==$winduid){
				Showmsg('friend_selferror');
			}
			if(!$rt){
				$errorname = Char_cv($pwuser);
				Showmsg('user_not_exists');
			}
			$rs = $db->get_one("SELECT uid FROM pw_friends WHERE uid='$winduid' AND friendid='$rt[uid]'");
			if($rs){
				Showmsg('friend_already_exists');
			}
			$descrip = Char_cv($descrip);
			$db->update("INSERT INTO pw_friends(uid,friendid,descrip,joindate) VALUES('$winduid','$rt[uid]','$descrip','$timestamp')");
		}
		foreach($selid as $key=>$val){
			if(is_numeric($val)){
				$db->update("DELETE FROM pw_friends WHERE uid='$winduid' AND friendid='$val'");
			}
		}
		if($frienddb){
			foreach($frienddb as $key=>$val){
				if(is_numeric($key)){
					$db->update("UPDATE pw_friends SET descrip='".Char_cv($val)."' WHERE uid='$winduid' AND friendid='$key'");
				}
			}
		}
		refreshto('profile.php?action=friend','friend_update_success');
	} elseif($job=='add'){
		$touid = (int)GetGP('touid');
		if($touid==$winduid){
			Showmsg('friend_selferror');
		}
		$rt=$db->get_one("SELECT uid,username FROM pw_members WHERE uid='$touid'");
		if(!$rt){
			$errorname = $$rt['username'];
			Showmsg('user_not_exists');
		}
		$rs = $db->get_one("SELECT uid FROM pw_friends WHERE uid='$winduid' AND friendid='$rt[uid]'");
		if($rs){
			Showmsg('friend_already_exists');
		}
		$db->update("INSERT INTO pw_friends(uid,friendid,joindate) VALUES('$winduid','$rt[uid]','$timestamp')");
		refreshto('profile.php?action=friend','friend_update_success');
	}
} elseif($action=='permission'){
	$gid = (int)GetGP('gid','G');
	$userdb = $db->get_one("SELECT m.groupid,m.groups,m.memberid,md.onlinetime,md.postnum,md.digests,md.rvrc,md.money,md.credit FROM pw_members m LEFT JOIN pw_memberdata md ON m.uid=md.uid WHERE m.uid='$winduid'");
	require_once(R_P.'require/credit.php');
	$creditdb = GetCredit($winduid);
	$usercredit = array(
		'postnum'	=> $userdb['postnum'],
		'digests'	=> $userdb['digests'],
		'rvrc'		=> $userdb['rvrc'],
		'money'		=> $userdb['money'],
		'credit'	=> $userdb['credit'],
		'onlinetime'=> $userdb['onlinetime']
	);
	foreach($creditdb as $key => $value){
		$usercredit[$key] = $value[1];
	}
	$upgradeset  = unserialize($db_upgrade);
	$totalcredit = CalculateCredit($usercredit,$upgradeset);
	$mygpdb = $_gmember = $_gspecial = $_gsystem = array();
	$winddb['groupid']!='-1' && $mygpdb[$winddb['groupid']] = $ltitle[$userdb['groupid']];
	if($winddb['groups']){
		$groups = explode(',',$winddb['groups']);
		foreach($groups as $value){
			$value && array_key_exists($value,$ltitle) && $mygpdb[$value] = $ltitle[$value];
		}
	}
	$mygpdb[$winddb['memberid']] = $ltitle[$winddb['memberid']];
	foreach(array_keys($mygpdb) as $value){
		!$gid && $gid = $value;
		break;
	}
	$query = $db->query("SELECT gid,gptype,grouptitle,grouppost FROM pw_usergroups WHERE gptype!='default' ORDER BY grouppost,gid");
	while($rt = $db->fetch_array($query)){
		if(strpos(",$_G[pergroup],",",$rt[gptype],")!==false){
			if($rt['gptype'] == 'member'){
				${'_g'.$rt['gptype']}[$rt['gid']] = array('title' => $rt['grouptitle'],'post' => $rt['grouppost']);
			} else{
				${'_g'.$rt['gptype']}[$rt['gid']] = array('title' => $rt['grouptitle']);
			}
		} else{
			$gid == $rt['gid'] && !$mygpdb[$gid] && Showmsg('per_error');
		}
	}
	$db->free_result($query);
	@include Pcv(D_P."data/groupdb/group_$gid.php");
	$per = array();
	$per['hide']	= $gp_allowhide		? 1 : 0;
	$per['read']	= $gp_allowread		? 1 : 0;
	$per['search']	= $gp_allowsearch	? 1 : 0;
	$per['member']	= $gp_allowmember	? 1 : 0;
	$per['profile']	= $gp_allowprofile	? 1 : 0;
	$per['show']	= $_G['show']		? 1 : 0;
	$per['report']	= $gp_allowreport	? 1 : 0;
	$per['upload']	= $gp_upload		? 1 : 0;
	$per['portait']	= $gp_allowportait	? 1 : 0;
	$per['honor']	= $gp_allowhonor	? 1 : 0;
	$per['post']	= $gp_allowpost		? 1 : 0;
	$per['rp']		= $gp_allowrp		? 1 : 0;
	$per['newvote']	= $gp_allownewvote	? 1 : 0;
	$per['vote']	= $gp_allowvote		? 1 : 0;
	$per['vwvt']	= $_G['viewvote']	? 1 : 0;
	$per['html']	= $gp_htmlcode		? 1 : 0;
	$per['hidden']	= $gp_allowhidden	? 1 : 0;
	$per['sell']	= $gp_allowsell		? 1 : 0;
	$per['mark']	= $_G['markable']	? 1 : 0;
	$per['attach']	= $gp_allowupload	? 1 : 0;
	$per['down']	= $gp_allowdownload	? 1 : 0;
	$per['sort']	= $gp_allowsort	? 1 : 0;
	$per['messege']	= $gp_allowmessege	? 1 : 0;
	$per['maxmsg']	= (int)$gp_maxmsg;
	$per['maxfavor'] = (int)$_G['maxfavor'];
	$per['maxgraft'] = !$_G['maxgraft'] ? 0 : $_G['maxgraft'];
	$per['signnum'] = (int)$gp_signnum;
	$per['active']	= $gp_allowactive	 ? 1 : 0;
	$per['reward']	= $_G['allowreward'] ? 1 : 0;
	$per['anonymous'] = $_G['anonymous'] ? 1 : 0;
	$per['leaveword'] = $_G['leaveword'] ? 1 : 0;
	$_G['uploadmaxsize'] = ceil(($_G['uploadmaxsize'] ? $_G['uploadmaxsize'] : $db_uploadmaxsize)/1024);
	!$_G['uploadtype'] && $_G['uploadtype'] = $db_uploadfiletype;
	$_G['uploadtype'] = unserialize($_G['uploadtype']);
	$_G['uptype'] = '';
	foreach($_G['uploadtype'] as $key => $value){
		$_G['uptype'] .= ($_G['uptype'] ? ',' : '')."$key:$value";
	}
	unset($_G['uploadtype']);
	list($db_moneyname,,$db_rvrcname,,$db_creditname,)=explode("\t",$db_credits);
	require_once(PrintEot('profile'));footer();
} elseif($action=='forumright'){
	require_once(R_P.'require/forum.php');

	list($db_moneyname,,$db_rvrcname,,,)=explode("\t",$db_credits);
	$rt=$db->get_one("SELECT f.name,f.type,f.f_type,f.password,f.allowvisit,f.allowpost,f.allowrp,f.allowdownload,f.allowupload,f.cms,fe.creditset FROM pw_forums f LEFT JOIN pw_forumsextra fe USING(fid) WHERE f.fid='$fid'");
	if(!$rt || $rt['type']=='category'){
		Showmsg('data_error');
	}
	wind_forumcheck($rt);
	$creditset    = get_creditset($rt['creditset'],$db_creditset);

	foreach($creditset as $key=>$val){
		if(is_numeric($key)){
			$creditset[$key]['name'] = $_CREDITDB[$key][0];
		} else{
			switch($key){
				case 'rvrc'   : $creditset[$key]['name'] = $db_rvrcname;break;
				case 'money'  : $creditset[$key]['name'] = $db_moneyname;break;
				case 'credit' : $creditset[$key]['name'] = $db_creditname;break;
			}
		}
		if($key=='rvrc'){
			foreach($val as $k=>$v){
				if($k != 'Reply' && $k != 'Deleterp'){
					$creditset[$key][$k] /= 10;
				}
			}
		}
	}
	if($rt['allowvisit'] && strpos($rt['allowvisit'],",$groupid,")===false){
		$per['visit'] = 0;
	} else{
		$per['visit'] = 1;
	}
	if($rt['allowpost'] && strpos($rt['allowpost'],",$groupid,")===false){
		$per['post'] = 0;
	} elseif(!$rt['allowpost'] && $gp_allowpost==0){
		$per['post'] = 0;
	} else{
		$per['post'] = 1;
	}
	if($rt['allowrp'] && strpos($rt['allowrp'],",$groupid,")===false){
		$per['rp'] = 0;
	} elseif(!$rt['allowrp'] && $gp_allowpost==0){
		$per['rp'] = 0;
	} else{
		$per['rp'] = 1;
	}
	if($rt['allowdownload'] && strpos($rt['allowdownload'],",$groupid,")===false){
		$per['down'] = 0;
	} elseif(!$rt['allowdownload'] && $gp_allowpost==0){
		$per['down'] = 0;
	} else{
		$per['down'] = 1;
	}
	if($rt['allowupload'] && strpos($rt['allowupload'],",$groupid,")===false){
		$per['upload'] = 0;
	} elseif(!$rt['allowupload'] && $gp_allowpost==0){
		$per['upload'] = 0;
	} else{
		$per['upload'] = 1;
	}

	require_once(PrintEot('profile'));footer();

} elseif ($action=='forumsell') {
	$f = $db->get_one("SELECT forumset FROM pw_forumsextra WHERE fid='$fid'");
	empty($f) && Showmsg('data_error');
	$forumset = unserialize($f['forumset']);
	if (!$forumset['forumsell']) {
		Showmsg('forumsell_error');
	}
	require_once(R_P.'require/credit.php');
	include_once(D_P.'data/bbscache/forum_cache.php');
	$credit_a = GetCreditType();
	$creditname = $credit_a[$forumset['forumsell']];

	if (empty($_POST['step'])) {

		InitGP(array('page'));
		require_once(R_P.'require/forum.php');
		(!is_numeric($page) || $page < 1) && $page = 1;
		$limit = "LIMIT ".($page-1)*10 .",10";
		$rt = $db->get_one("SELECT COUNT(*) AS sum FROM pw_forumsell WHERE uid='$winduid'");
		$pages = numofpage($rt['sum'],$page,ceil($rt['sum']/10),"profile.php?action=forumsell&fid=$fid&");
		$query = $db->query("SELECT * FROM pw_forumsell WHERE uid='$winduid' ORDER BY overdate DESC $limit");
		$buydb = array();
		while ($rt = $db->fetch_array($query)) {
			$rt['buydate']	= get_date($rt['buydate']);
			$rt['overdate']	= get_date($rt['overdate']);
			$buydb[] = $rt;
		}
		require_once(PrintEot('profile'));footer();

	} else {

		InitGP(array('date'));
		$rt = $db->get_one("SELECT MAX(overdate) AS u FROM pw_forumsell WHERE uid='$winduid' AND fid='$fid'");
		if ($rt['u'] > $timestamp) {
			Showmsg('forumsell_already');
		}
		if (!isset($forumset['sellprice'][$date])) {
			Showmsg('forumsell_date');
		}
		if (UserCredit($winduid,$forumset['forumsell']) < $forumset['sellprice'][$date]) {
			Showmsg('forumsell_price');
		}
		UserCredit($winduid,$forumset['forumsell'],'set',-$forumset['sellprice'][$date]);
		$overdate = $timestamp + $date * 86400;
		$db->update("INSERT INTO pw_forumsell (fid,uid,buydate,overdate,credit,cost) VALUES ('$fid','$winduid','$timestamp','$overdate','$forumset[forumsell]','{$forumset[sellprice][$date]}')");
		refreshto("thread.php?fid=$fid",'operate_success');
	}

} elseif($action=='log'){
	if(!$_G['atclog']){
		Showmsg('no_atclog_right');
	}
	InitGP(array('page','type'));
	require_once GetLang('log');
	require_once(R_P.'require/forum.php');
	include_once(D_P.'data/bbscache/forum_cache.php');
	$sqladd = "WHERE username1='".addslashes($windid)."'";
	if($type && $logtype[$type]){
		$sqladd .= " AND type='$type'";
	}
	$type_sel[$type] = 'selected';
	$db_perpage = 30;

	(!is_numeric($page) || $page < 1) && $page = 1;
	$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
	$rt    = $db->get_one("SELECT COUNT(*) AS sum FROM pw_adminlog $sqladd");
	$pages = numofpage($rt['sum'],$page,ceil($rt['sum']/$db_perpage),"profile.php?action=log&type=$type&");
	$logdb = array();
	$query = $db->query("SELECT * FROM pw_adminlog $sqladd ORDER BY id DESC $limit");
	while($rt = $db->fetch_array($query)){
		$rt['date']    = get_date($rt['timestamp']);
		$rt['descrip'] = str_replace("\n","<br>",$rt['descrip']);
		$rt['descrip'] = descriplog($rt['descrip']);
		$logdb[] = $rt;
	}
	require_once PrintEot('profile');footer();
} elseif($action=='change'){
	require_once(R_P.'require/credit.php');
	$rt = $db->get_one("SELECT db_value FROM pw_config WHERE db_name='jf_A'");
	$jf_A = $rt['db_value'] ? unserialize($rt['db_value']) : array();

	if(!$_POST['step']){
		list($db_moneyname,$db_moneyunit,$db_rvrcname,$db_rvrcunit,$db_creditname,$db_creditunit)=explode("\t",$db_credits);
		$creditdb = GetCredit($winduid);
		$credittype = GetCreditType();
		$jf = array();
		foreach($jf_A as $key=>$value){
			if($value[2]){
				list($j_1,$j_2) = explode('_',$key);
				$jf[$key] = array($credittype[$j_1],$credittype[$j_2],$value[0],$value[1]);
			}
		}
		!$jf && Showmsg('jfchange_empty');

		require_once PrintEot('profile');footer();
	} else{
		InitGP(array('type','change'));
		if(!$jf_A[$type] || !$jf_A[$type][2]){
			Showmsg('bk_credit_type_error');
		}
		$change = (int)$change;
		if(!is_numeric($change)||$change <= 0) Showmsg('bk_credit_fillin_error');
		$change%$jf_A[$type][0]!=0 && Showmsg('change_error');

		list($sell,$buy) = explode('_',$type);
		$credit1 = $change;
		$credit2 = intval($change/$jf_A[$type][0]*$jf_A[$type][1]);
		//$db->query("LOCK TABLES pw_memberdata WRITE,pw_membercredit WRITE");
		/*
		*  ��������
		*/
		$lockfile = D_P.'data/bbscache/lock_profile.txt';
		$fp = fopen($lockfile,'wb+');
		flock($fp,LOCK_EX);

		if($credit1>UserCredit($winduid,$sell)){
			Showmsg('bk_credit_change_error');
		}
		UserCredit($winduid,$sell,'set',-$credit1);
		$sellname = CreditName($sell);

		UserCredit($winduid,$buy,'set',$credit2);
		$buyname = CreditName($buy);

		fclose($fp);
		//$db->query("UNLOCK TABLES");

		require_once(R_P.'require/writelog.php');
		$log = array(
			'type'      => 'bk_credit',
			'username1' => $windid,
			'username2' => '',
			'field1'    => $credit1,
			'field2'    => $credit2,
			'field3'    => '',
			'descrip'   => 'bk_credit_descrip',
			'timestamp' => $timestamp,
			'ip'        => $onlineip,
			'sellname'	=> $sellname,
			'buyname'	=> $buyname,
		);
		writeforumlog($log);
		refreshto('profile.php?action=change','bank_creditsuccess');
	}
} elseif($action=='buy'){
	require_once(R_P.'require/pw_func.php');
	require_once(R_P.'require/credit.php');
	$credittype = GetCreditType();
	InitGP(array('job','gid'));
	if(!$job){
		$specialdb=array();
		$query=$db->query("SELECT gid,grouptitle,sright FROM pw_usergroups WHERE gptype='special'");
		while($rt=$db->fetch_array($query)){
			$rt['sright']=P_unserialize($rt['sright']);
			if($rt['sright']['allowbuy']){
				$rt['enddate'] = '-';
				$rt['sright']['selltype'] = $credittype[$rt['sright']['selltype']];
				$specialdb[$rt['gid']]=$rt;
			}
		}
		$query=$db->query("SELECT gid,startdate,days FROM pw_extragroups WHERE uid='$winduid'");
		while($rt=$db->fetch_array($query)){
			if(array_key_exists($rt['gid'],$specialdb)){
				$specialdb[$rt['gid']]['days']		= $rt['days'];
				$specialdb[$rt['gid']]['startdate']	= $rt['startdate'];
				$specialdb[$rt['gid']]['enddate']	= get_date($rt['startdate'] + $rt['days']*86400,'Y-m-d');
			}
		}
		require_once(PrintEot('profile'));footer();
	} elseif($job=='buy'){
		$rt=$db->get_one("SELECT uid,startdate,days FROM pw_extragroups WHERE uid='$winduid' AND gid='$gid'");
		if($rt && $timestamp <= $rt['startdate'] + $rt['days']*86400){
			$enddate = get_date($rt['startdate'] + $rt['days']*86400,'Y-m-d');
			Showmsg('specialgroup_exists');
		}
		$rt=$db->get_one("SELECT gid,grouptitle,sright FROM pw_usergroups WHERE gptype='special' AND gid='$gid'");
		if(!$rt){
			Showmsg('specialgroup_error');
		}
		$rt['sright']=P_unserialize($rt['sright']);
		if(!$rt['sright']['allowbuy']){
			Showmsg('special_allowbuy');
		}
		if(!$_POST['step']){
			$rt['sright']['selltype'] = $credittype[$rt['sright']['selltype']];
			require_once(PrintEot('profile'));footer();
		} else{
			InitGP(array('days','pwpwd','options'),'P');
			if(!is_numeric($days) || $days<=0){
				Showmsg('illegal_nums');
			}
			$mb = $db->get_one("SELECT password,groups FROM pw_members WHERE uid='$winduid'");
			if(md5($pwpwd) != $mb['password']){
				Showmsg('password_error');
			}
			if($gid==$groupid || strpos($mb['groups'],",$gid,")!==false){
				Showmsg('specialgroup_noneed');
			}
			if($days < $rt['sright']['selllimit']){
				Showmsg('special_selllimit');
			}
			$needcur = $days*$rt['sright']['sellprice'];
			$cur = UserCredit($winduid,$rt['sright']['selltype']);
			if($cur === false){
				Showmsg('numerics_checkfailed');
			}
			if($cur < $needcur){
				Showmsg('noenough_currency');
			}
			if(!UserCredit($winduid,$rt['sright']['selltype'],'set',"-$needcur")){
				Showmsg('numerics_checkfailed');
			}
			if($options==1){
				if($winddb['groupid']=='-1'){
					$db->update("UPDATE pw_members SET groupid='$gid' WHERE uid='$winduid'");
				} else{
					$groups = $mb['groups'] ? $mb['groups'].$winddb['groupid'].',' : ",$winddb[groupid],";
					$db->update("UPDATE pw_members SET groupid='$gid',groups='$groups' WHERE uid='$winduid'");
				}
			} else{
				$groups = $mb['groups'] ? $mb['groups'].$gid.',' : ",$gid,";
				$db->update("UPDATE pw_members SET groups='$groups' WHERE uid='$winduid'");
			}

			$db->pw_update(
				"SELECT uid FROM pw_extragroups WHERE uid='$winduid' AND gid='$gid'",
				"UPDATE pw_extragroups SET togid='$winddb[groupid]',startdate='$timestamp',days='$days' WHERE uid='$winduid'AND gid='$gid'",
				"INSERT INTO pw_extragroups SET uid='$winduid',togid='$winddb[groupid]',gid='$gid',startdate='$timestamp',days='$days'"
			);
			require_once(R_P.'require/tool.php');
			$logdata=array(
				'type'		=>	'group',
				'nums'		=>	0,
				'money'		=>	0,
				'descrip'	=>	'group_descrip',
				'uid'		=>	$winduid,
				'username'	=>	$windid,
				'ip'		=>	$onlineip,
				'time'		=>	$timestamp,
				'currency'	=>	$needcur,
				'curtype'	=>	$credittype[$rt['sright']['selltype']],
				'gptitle'	=>	$rt['grouptitle'],
				'days'		=>	$days
			);
			writetoollog($logdata);
			refreshto("profile.php",'group_buy_success');
		}
	}
} elseif ($action=='favor'){
	require_once(R_P."require/favor.php");
} elseif ($action=='ajaxface') {
	require_once(R_P.'require/showimg.php');
	define('AJAX',true);
	$facetype = $_POST['facetype'];
	list($iconurl,$icontype,$iconwidth,$iconheight,$iconfile,$iconpig) = showfacedesign($winddb['icon'],true);
	$iconfile = addslashes($iconfile);
	if ($facetype==3 && $db_ifupload && $gp_upload && is_array($_POST['uploadurl'])) {
		$ftp = null;
		if ($db_ifftp) {
			require_once(R_P.'require/ftp.php');
			$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
		}
		UploadIcon($_POST['uploadurl']);
		$usericon = GetIcon();
		if ($ftp) {
			$ftp->close(); unset($ftp);
		}
		$db->update("UPDATE pw_members SET icon='$usericon' WHERE uid='$winduid'");
		if ($iconpig) {
			$iconurl = "$imgpath/pig.gif";
		} elseif ($db_ftpweb && !file_exists("$attachdir/upload/$iconfile")) {
			$iconurl = "$db_ftpweb/upload/";
		} else {
			$iconurl = "$attachpath/upload/";
		}
		$showmsg = 'success';
	} else {
		$showmsg = 'undefined_action';
	}
	echo "<script language=\"JavaScript1.2\">parent.facepath('$iconurl','$iconfile','$showmsg','$iconwidth','$iconheight');</script>";exit;
} elseif ($action=='memo' && $_G['ifmemo']) {
	list($mmid,$mcontent) = $db->get_one("SELECT mid,content FROM pw_memo WHERE isuser='1' AND username='$windid'",MYSQL_NUM);
	$mmid = (int)$mmid;
	$mm_content = Char_cv($_POST['mm_content']);
	if (!$mmid) {
		$db->update("INSERT INTO pw_memo(username,postdate,content,isuser) VALUES('$windid','$timestamp','$mm_content','1')");
	} elseif ($mmid==(int)$_POST['mm_mid'] && $mcontent!=$mm_content) {
		$db->update("UPDATE pw_memo SET postdate='$timestamp',content='$mm_content' WHERE mid='$mmid'");
	}
	refreshto('profile.php','operate_success');
} else {
	list($db_moneyname,$db_moneyunit,$db_rvrcname,$db_rvrcunit,$db_creditname,$db_creditunit) = explode("\t",$db_credits);
	$userdb = $db->get_one("SELECT m.groupid,m.memberid,m.icon,m.regdate,m.honor,md.postnum,md.digests,md.rvrc,md.money,md.credit,md.currency,md.starttime,md.lastvisit,md.onlinetime,mb.deposit,mb.ddeposit FROM pw_members m LEFT JOIN pw_memberdata md USING(uid) LEFT JOIN pw_memberinfo mb USING(uid) WHERE m.uid='$winduid'");
	require_once(R_P.'require/showimg.php');
	require_once(R_P.'require/credit.php');
	$creditdb = GetCredit($winduid);
	$iconarray= explode('|',$userdb['icon']);
	$userface = showfacedesign($userdb['icon']);
	$systitle = $userdb['groupid']=='-1' ? '' : $ltitle[$userdb['groupid']];
	$memtitle = $ltitle[$userdb['memberid']];
	$userdb['rvrc'] = floor($userdb['rvrc']/10);
	if ($userdb['onlinetime']) {
		$userdb['onlinetime'] = floor($userdb['onlinetime']/3600);
	} else {
		$userdb['onlinetime'] = 0;
	}
	$userdb['regdate'] = get_date($userdb['regdate'],'Y-m-d');
	$userdb['lastvisit'] = get_date($userdb['lastvisit'],'Y-m-d');

	$msgdb = $favordb = $colonydb = array();
	$query = $db->query("SELECT m.mid,m.fromuid,m.touid,m.username,m.ifnew,m.mdate,mc.title FROM pw_msg m LEFT JOIN pw_msgc mc USING(mid) WHERE m.type='rebox' AND m.touid='$winduid' ORDER BY m.mdate DESC LIMIT 5");
	while ($rt = $db->fetch_array($query)) {
		$rt['title'] = substrs($rt['title'],35);
		$rt['mdate'] = get_date($rt['mdate']);
		$msgdb[] = $rt;
	}

	$ftids = $db->get_value("SELECT tids FROM pw_favors WHERE uid='$winduid'");
	if ($ftids) {
		$tids = '';
		$tids_a = explode(',',str_replace('|',',',$ftids));
		$num = 0;
		foreach ($tids_a as $value) {
			if (is_numeric($value)) {
				$num++;
				$tids .= ($tids ? ',' : '')."$value";
			}
			if ($num==5) break;
		}
		if ($tids) {
			include_once(D_P.'data/bbscache/forum_cache.php');
			$query = $db->query("SELECT fid,tid,subject,postdate,author,authorid,anonymous FROM pw_threads WHERE tid IN($tids) ORDER BY postdate DESC");
			while ($rt=$db->fetch_array($query)) {
				if ($rt['anonymous'] && $rt['author']!=$windid) {
					$rt['author'] = $db_anonymousname;
					$rt['authorid'] = 0;
				}
				$rt['subject'] = substrs($rt['subject'],35);
				$rt['postdate'] = get_date($rt['postdate']);
				$rt['forum'] = $forum[$rt['fid']]['name'];
				$favordb[] = $rt;
			}
		}
		unset($forum,$tids_a,$tids,$num);
	}

	$query = $db->query("SELECT cy.id,cy.cname FROM pw_cmembers c LEFT JOIN pw_colonys cy ON cy.id=c.colonyid WHERE c.uid='$winduid'");
	while ($rt = $db->fetch_array($query)) {
		$colonydb[] = $rt;
	}
	$db->free_result($query);

	if ($_G['ifmemo']) {
		list($userdb['mmid'],$userdb['postdate'],$userdb['mcontent']) = $db->get_one("SELECT mid,postdate,content FROM pw_memo WHERE isuser='1' AND username='$windid'",MYSQL_NUM);
		$userdb['mmid'] = (int)$userdb['mmid'];
		$userdb['postdate'] && $userdb['postdate'] = get_date($userdb['postdate'],'Y-m-d H:i:s');
		if ($userdb['mcontent']) {
			$userdb['mcontent'] = str_replace('<br />',"\n",$userdb['mcontent']);
			$SCR = 'post';
		}
	}
	require_once(PrintEot('profile'));footer();
}

function descriplog($message){
	$message = str_replace("[b]","<b>",$message);
	$message = str_replace("[/b]","</b>",$message);
	if(strpos($message,'[/URL]')!==false || strpos($message,'[/url]')!==false){
		$message=preg_replace("/\[url=(https?)([^\[]+?)\](.+?)\[\/url\]/is","<a href=\"\\1\\2\" target=\"_blank\">\\3</a>",$message);
	}
	return $message;
}
function Getcustom($data,$unserialize=true,$strips=null){
	global $db_union;
	$customdata = array();
	if (!$data || ($unserialize ? !is_array($data=unserialize($data)) : !is_array($data))) {
		$data = array();
	} elseif (!is_array($custominfo = unserialize($db_union[7]))) {
		$custominfo = array();
	}
	if (!empty($data) && !empty($custominfo)) {
		foreach ($data as $key => $value) {
			if (!empty($strips)) {
				$customdata[stripslashes(Char_cv($key))] = stripslashes(Char_cv($value));
			} elseif ($custominfo[$key] && $value) {
				$customdata[$key] = $value;
			}
		}
	}
	return array($customdata,$custominfo);
}
function lowerstrpos($haystack,$needle){
	$haystack && $haystack = strtolower($haystack);
	$needle = strtolower($needle);
	if ($haystack && strpos($haystack,$needle)!==false) {
		return true;
	}
	return false;
}
function UploadIcon($uploadurl){
	global $db_uploadfiletype,$db_imgsize,$iconfile,$icontype,$iconwidth,$iconheight,$facetype,$winduid;
	$db_uploadfiletype = array();
	$db_uploadfiletype['gif'] = $db_uploadfiletype['jpg'] = $db_uploadfiletype['bmp'] = $db_uploadfiletype['png'] = $db_imgsize;
	$uploadurl[1] = (int)$uploadurl[1];
	$uploadurl[2] = (int)$uploadurl[2];
	$uploaddb = UploadFile($winduid,'face',"1\t1");
	if (!empty($uploaddb)) {
		$attachurl = str_replace('upload/','',$uploaddb[0]['attachurl']);
		if ($icontype==3 && $iconfile!=$attachurl) {
			DelIcon($iconfile);
		}
		$iconfile = $attachurl;
		$uploadurl[1] > $uploaddb[0]['img_w'] && $uploadurl[1] = $uploaddb[0]['img_w'];
		$uploadurl[2] > $uploaddb[0]['img_h'] && $uploadurl[2] = $uploaddb[0]['img_h'];
		if (!$uploadurl[1] && !$uploadurl[2]) {
			$uploadurl[1] = $uploaddb[0]['img_w'];
			$uploadurl[2] = $uploaddb[0]['img_h'];
		}
		list($iconwidth,$iconheight) = getfacelen($uploadurl[1],$uploadurl[2]);
	} elseif ($icontype!=3) {
		$facetype = 1;
	} else {
		if (!$uploadurl[1] || !$uploadurl[2]) {
			global $iconurl;
			require_once(R_P.'require/imgfunc.php');
			$srcdata = GetImgSize($iconurl);
			$iconwidth = $srcdata['width'];
			$iconheight = $srcdata['height'];
		} elseif ($uploadurl[1]<$iconwidth || $uploadurl[2]<$iconheight) {
			list($iconwidth,$iconheight) = getfacelen($uploadurl[1],$uploadurl[2]);
		}
	}
}
function GetIcon($proicon=null){
	global $iconfile,$icontype,$iconwidth,$iconheight,$iconpig,$facetype,$db_imgheight,$db_imgwidth;
	if ($facetype==1) {
		if ($icontype!=1) {
			global $imgdir;
			$icontype==3 && DelIcon($iconfile);
			if (!file_exists("$imgdir/face/$proicon")) {
				$proicon = 'none.gif';
			}
		}
		if (!empty($proicon)) {
			if (strlen($proicon)>20 || !preg_match('/^[0-9A-Za-z]+\.[A-Za-z]{2,5}$/',$proicon)) {
				Showmsg('undefined_action');
			}
			$iconfile = $proicon;
		}
		$iconwidth = $iconheight = 0;
	}
	$iconwidth < 1 && $iconwidth = '';
	$iconheight < 1 && $iconheight = '';
	$usericon = "$iconfile|$facetype|$iconwidth|$iconheight";
	$iconpig && $usericon .= "|$iconpig";
	strlen($usericon)>100 && Showmsg('illegal_customimg');
	return $usericon;
}
function updatemedal_list(){
	global $db;
	$query   = $db->query("SELECT uid,medals FROM pw_members WHERE medals!=''");
	$medaldb = '<?php die;?>0';
	while ($rt = $db->fetch_array($query)) {
		if (str_replace(',','',$rt['medals'])) {
			$medaldb .= ','.$rt['uid'];
		}
	}
	writeover(D_P.'data/bbscache/medals_list.php',$medaldb);
}
?>