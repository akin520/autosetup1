<?php
define('AJAX','1');
require_once('global.php');

InitGP(array('action'));
if(!$windid && !in_array($action,array('login','showface','showsmile'))){
	Showmsg('not_login');
}
if($action=='leaveword'){
	!$_G['leaveword'] && Showmsg('leaveword_right');
	if(!$_POST['step']){
		InitGP(array('pid'));
		$tpc = $db->get_one("SELECT authorid,ptable FROM pw_threads WHERE tid='$tid'");
		if($tpc['authorid']!=$winduid){
			Showmsg('leaveword_error');
		}
		$pw_posts = GetPtable($tpc['ptable']);
		$rt = $db->get_one("SELECT leaveword FROM $pw_posts WHERE pid='$pid' AND tid='$tid'");
		$reason_sel = '';
		$reason_a = explode("\n",$db_adminreason);
		foreach($reason_a as $k=>$v){
			if($v=trim($v)){
				$reason_sel .= "<option value=\"$v\">$v</option>";
			} else{
				$reason_sel .= "<option value=\"\">-------</option>";
			}
		}
		$rt['leaveword'] = str_replace('&nbsp;',' ',$rt['leaveword']);
		require_once PrintEot('ajax');ajax_footer();
	} else{
		InitGP(array('pid','atc_content','ifmsg'),'P',1);
		$tpc = $db->get_one("SELECT t.authorid,t.ptable,f.forumadmin,f.fupadmin FROM pw_threads t LEFT JOIN pw_forums f USING(fid) WHERE t.tid='$tid'");
		if($tpc['authorid']!=$winduid && !CkInArray($windid,$manager) && !admincheck($tpc['forumadmin'],$tpc['fupadmin'],$windid)){
			Showmsg('leaveword_error');
		}
		require_once(R_P.'require/bbscode.php');
		$atc_content = str_replace('&#61;','=',$atc_content);
		if($db_charset!='utf-8'){
			$atc_content = ajax_convert($atc_content,$db_charset);
		}
		$ptable   = $tpc['ptable'];
		$content  = convert($atc_content,$db_windpost);
		$sqladd   = $atc_content == $content ? '' : ",ifconvert='2'";
		$pw_posts = GetPtable($ptable);
		if($ifmsg && !empty($atc_content)){
			require_once(R_P.'require/msg.php');
			include_once(D_P.'data/bbscache/forum_cache.php');
			$atc = $db->get_one("SELECT author,fid,subject,content,postdate FROM $pw_posts WHERE pid='$pid' AND tid='$tid'");
			!$atc['subject'] && $atc['subject']=substrs($atc['content'],35);
			$msg = array(
				$atc['author'],
				0,
				'leaveword_title',
				$timestamp,
				'leaveword_content',
				'N',
				'SYSTEM',
				'fid'		=> $atc['fid'],
				'tid'		=> $tid,
				'author'	=> $windid,
				'subject'	=> $atc['subject'],
				'postdate'	=> get_date($atc['postdate']),
				'forum'		=> strip_tags($forum[$atc['fid']]['name']),
				'affect'    => '',
				'admindate'	=> get_date($timestamp),
				'reason'	=> $atc_content
			);
			writenewmsg($msg,1);
		}
		$db->update("UPDATE $pw_posts SET leaveword='$atc_content' $sqladd WHERE pid='$pid' AND tid='$tid'");
		echo "success\t".str_replace(array("\n","\t"),array('<br />',''),stripslashes($content));
		ajax_footer();
	}
} elseif($action=='favor'){
	$rs = $db->get_one("SELECT tids,type FROM pw_favors WHERE uid='$winduid'");
	if($rs){
		$count = 0;
		$tiddb = getfavor($rs['tids']);
		foreach($tiddb as $key=>$t){
			if(is_array($t))$count+=count($t);
		}
		if($count>$_G['maxfavor']){
			Showmsg('job_favor_full');
		}
		foreach($tiddb as $key=>$t){
			if(in_array($tid,$t)){
				Showmsg('job_favor_error');
			}
		}
		InitGP(array('type'));
		if($rs['type'] && !isset($type)){
			$typeid = explode(',',$rs['type']);
			require_once PrintEot('ajax');ajax_footer();
		}
		$read = $db->get_one("SELECT subject FROM pw_threads WHERE tid='$tid'");
		!$read && Showmsg('data_error');
		require_once(R_P.'require/posthost.php');
		PostHost("http://push.phpwind.com/push.php?type=collect&url=".rawurlencode("$db_bbsurl/read.php?tid=$tid")."&tocharset=$db_charset&title=".rawurlencode($read['subject'])."&bbsname=".rawurlencode($db_bbsname),"");
		$type = (int)$type;
		$tiddb[$type][] = $tid;
		$newtids = makefavor($tiddb);
		$db->update("UPDATE pw_favors SET tids='$newtids' WHERE uid='$winddb[uid]'");
	} else{
		$db->update("INSERT INTO pw_favors(uid,tids) VALUES('$winddb[uid]','$tid')");
	}
	Showmsg('job_favor_success');
} elseif($action=='tag'){
	$cachetime = @filemtime(D_P."data/bbscache/tagdb.php");
	if(!file_exists(D_P."data/bbscache/tagdb.php") || $timestamp-$cachetime>3600){
		$tagnum=max($db_tagindex,200);
		$tagdb = array();
		$query = $db->query("SELECT * FROM pw_tags WHERE ifhot='0' ORDER BY num DESC LIMIT $tagnum");
		while($rs = $db->fetch_array($query)){
			$tagdb[$rs['tagname']] = $rs['num'];
		}
		writeover(D_P."data/bbscache/tagdb.php","<?php\r\n\$tagdb=".pw_var_export($tagdb).";\r\n?>");
	} else{
		include_once(D_P."data/bbscache/tagdb.php");
	}
	foreach($tagdb as $key=>$num){
		echo $key.','.$num."\t";
	}
	ajax_footer();
} elseif($action=='relatetag'){
	InitGP(array('tagname'));
	$rs = $db->get_one("SELECT tagid,num FROM pw_tags WHERE tagname='$tagname'");
	if(!$rs || $rs['num']<1){
		Showmsg('tag_limit');
	}
	$query = $db->query("SELECT tg.tid,t.subject FROM pw_tagdata tg LEFT JOIN pw_threads t USING(tid) WHERE tg.tagid='$rs[tagid]' LIMIT 5");
	$readdb = array();
	while($rt = $db->fetch_array($query)){
		$rt['subject'] = substrs($rt['subject'],65);
		$readdb[] = $rt;
	}
	require_once PrintEot('ajax');ajax_footer();
} elseif($action=='deldownfile'){
	InitGP(array('aid','pid','page'));
	(!$tid || !is_numeric($aid)) && Showmsg('job_attach_error');
	if(is_numeric($pid)){
		$table = $pw_posts = GetPtable('N',$tid);
		$where = "pid='$pid'";
		$post  = $db->get_one("SELECT fid,tid,aid AS oldaid,authorid FROM $pw_posts WHERE pid='$pid'");
	} else{
		$table = $pw_tmsgs = GetTtable($tid);
		$where = "tid='$tid'";
		$post  = $db->get_one("SELECT t.tid,t.fid,t.authorid,t.ptable,tm.aid AS oldaid FROM pw_threads t LEFT JOIN $pw_tmsgs tm USING(tid) WHERE t.tid='$tid'");
		$pw_posts = GetPtable($post['ptable']);
	}
	$tid    = $post['tid'];
	$fid    = $post['fid'];
	$attach = unserialize(stripslashes($post['oldaid']));
	$attachurl='';
	!$attach[$aid] && Showmsg('job_attach_error');
	@extract($attach[$aid]);
	if(!$attachurl || strpos($attachurl,'..')!==false){
		Showmsg('job_attach_error');
	}
	require_once(R_P.'require/forum.php');
	require_once(R_P.'require/updateforum.php');

	$foruminfo=$db->get_one("SELECT name,f_type,style,password,allowvisit,forumadmin,fupadmin,allowhtm,cms FROM pw_forums WHERE fid='$fid'");
	!$foruminfo && Showmsg('data_error');
	wind_forumcheck($foruminfo);
	/*
	*  ��ȡ����Ȩ��
	*/
	if(CkInArray($windid,$manager) || admincheck($foruminfo['forumadmin'],$foruminfo['fupadmin'],$windid)){
		$admincheck=1;
	} elseif($SYSTEM['delattach']){
		if(!$SYSTEM['rightwhere'] || strpos(",".$SYSTEM['rightwhere'].",",",".$fid.",")!==false){
			$admincheck=1;
		} else{
			$admincheck=0;
		}
	} else{
		$admincheck=0;
	}
	if($groupid!='guest' && ($admincheck || $post['authorid']==$winduid)){
		$a_url=geturl($attachurl);
		if($a_url[1]=='Local'){
			P_unlink("$attachdir/$attachurl");
			$ifthumb && P_unlink("$attachdir/thumb/$attachurl");
		} elseif($db_ifftp && $a_url[1]=='Ftp'){
			require_once(R_P.'require/ftp.php');
			$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
			$ftp->delete($attachurl);
			$ifthumb && $ftp->delete("thumb/$attachurl");
			$ftp->close();
			unset($ftp);
		}
		$attach=unserialize(stripslashes($post['oldaid']));
		unset($attach[$aid]);
		if($attach){
			$attach=addslashes(serialize($attach));
		} else{
			$attach='';
		}
		$db->update("UPDATE $table SET aid='$attach' WHERE $where");
		$db->update("DELETE FROM pw_attachs WHERE aid='$aid'");

		$ifupload=getattachtype($tid);
		$db->update("UPDATE pw_threads SET ifupload='$ifupload' WHERE tid='$tid'");
		if($foruminfo['allowhtm'] && $page==1){
			require_once(R_P.'require/template.php');
		}
		echo 'success';ajax_footer();
	} else{
		Showmsg('job_attach_right');
	}
} elseif($action=='draft'){
	!$_G['maxgraft'] && Showmsg('draft_right');

	if(!$_POST['step']){
		$db_showperpage = 5;
		$page = (int)GetGP('page');
		(!is_numeric($page) || $page<1) && $page = 1;
		$rt = $db->get_one("SELECT COUNT(*) AS sum FROM pw_draft WHERE uid='$winduid'");
		$maxpage = ceil($rt['sum']/$db_showperpage);
		$maxpage && $page > $maxpage && $page = $maxpage;
		$limit = "LIMIT ".($page-1)*$db_showperpage.",$db_showperpage";

		$query = $db->query("SELECT * FROM pw_draft WHERE uid='$winduid' $limit");
		if($db->num_rows($query)==0){
			Showmsg('draft_error');
		}
		$drdb = array();
		while($rt = $db->fetch_array($query)){
			$drdb[] = $rt;
		}
		require_once PrintEot('ajax');ajax_footer();
	} elseif($_POST['step']==2){
		InitGP(array('atc_content'),'P',1);
		!$atc_content && Showmsg('content_empty');
		$atc_content = str_replace('%26','&',$atc_content);
		if($db_charset!='utf-8'){
			$atc_content = ajax_convert($atc_content,$db_charset);
		}
		$rt = $db->get_one("SELECT COUNT(*) AS sum FROM pw_draft WHERE uid='$winduid'");
		if($rt['sum']>=$_G['maxgraft']){
			Showmsg('draft_full');
		}
		$db->update("INSERT INTO pw_draft(uid,content) VALUES('$winduid','$atc_content')");
		Showmsg('save_success');
	} elseif($_POST['step']==3){
		InitGP(array('atc_content','did'),'P',1);
		!$atc_content && Showmsg('content_empty');
		if($db_charset!='utf-8'){
			$atc_content = ajax_convert($atc_content,$db_charset);
		}
		$db->update("UPDATE pw_draft SET content='$atc_content' WHERE uid='$winduid' AND did='$did'");
		Showmsg('update_success');
	} else{
		InitGP(array('did'));
		$db->update("DELETE FROM pw_draft WHERE uid='$winduid' AND did='$did'");
		Showmsg('delete_success');
	}
} elseif($action=='login'){
	if(file_exists(D_P."data/style/$skin.php") && strpos($skin,'..')===false){
		@include Pcv(D_P."data/style/$skin.php");
	} elseif(file_exists(D_P."data/style/$db_defaultstyle.php") && strpos($db_defaultstyle,'..')===false){
		@include Pcv(D_P."data/style/$db_defaultstyle.php");
	} else{
		@include(D_P."data/style/wind.php");
	}
	$groupid!='guest' && Showmsg('login_have');
	list(,$loginq)	= explode("\t",$db_qcheck);

	($db_gdcheck & 2) && GdConfirm($_POST['gdcode']);
	require_once(R_P.'require/showimg.php');
	require_once(R_P.'require/checkpass.php');
	include_once(D_P.'data/bbscache/dbreg.php');
	include_once(D_P.'data/bbscache/level.php');

	InitGP(array('pwuser','pwpwd','question','customquest','answer','cktime','hideid','jumpurl','lgt'),'P');
	if($db_charset!='utf-8'){
		$pwuser		= ajax_convert($pwuser,$db_charset);
		$pwpwd		= ajax_convert($pwpwd,$db_charset);
		$customquest= ajax_convert($customquest,$db_charset);
		$answer		= ajax_convert($answer,$db_charset);
		$_POST['qanswer'] && $_POST['qanswer'] = ajax_convert($_POST['qanswer'],$db_charset);
	}
	$loginq && Qcheck($_POST['qanswer'],$_POST['qkey']);

	if($pwuser && $pwpwd){
		$md5_pwpwd=md5($pwpwd);
		$safecv=$db_ifsafecv ? questcode($question,$customquest,$answer) : '';
		list($winduid,$groupid,$pwpwd) = checkpass($pwuser,$md5_pwpwd,$safecv,$lgt);
	} else{
		Showmsg('login_empty');
	}
	if(file_exists(D_P."data/groupdb/group_$groupid.php")){
		require_once Pcv(D_P."data/groupdb/group_$groupid.php");
	} else{
		require_once(D_P."data/groupdb/group_1.php");
	}
	$windpwd = $pwpwd;
	$cktime != 0 && $cktime += $timestamp;
	Cookie("winduser",StrCode($winduid."\t".$windpwd."\t".$safecv),$cktime);
	Cookie('lastvisit','',0);
	if($db_autoban){
		require_once(R_P.'require/autoban.php');
		autoban($winduid);
	}
	($gp_allowhide && $hideid) ? Cookie('hideid',"1",$cktime) : Loginipwrite($winduid);
	list($db_moneyname,$db_moneyunit,$db_rvrcname,$db_rvrcunit,$db_creditname,$db_creditunit)=explode("\t",$db_credits);
	$winddb = $db->get_one("SELECT * FROM pw_members m LEFT JOIN pw_memberdata md USING(uid) WHERE m.uid='$winduid'");
	list($faceurl) = showfacedesign($winddb['icon'],1);
	$lastlodate = get_date($winddb['lastvisit'],'Y-m-d');
	$userrvrc	= (int)($winddb['rvrc']/10);
	$level		= $ltitle[$groupid];
	$loginouturl = PwEncodeUrl("login.php?action=quit");
	require_once PrintEot('ajax');ajax_footer();
} elseif($action=='msg'){
	$gp_allowmessege == 0 && Showmsg('msg_group_right');
	if($gp_postpertime || $_G['maxsendmsg']){
		$rp = $db->get_one("SELECT COUNT(*) AS tdmsg,MAX(mdate) AS lastwrite FROM pw_msg WHERE fromuid='$winduid' AND mdate>'$tdtime'");
		if($gp_postpertime && $timestamp - $rp['lastwrite'] <= $gp_postpertime){
			Showmsg('msg_limit');
		} elseif($_G['maxsendmsg'] && $rp['tdmsg']>=$_G['maxsendmsg']){
			Showmsg('msg_num_limit');
		}
	}
	list(,,,$msgq)	= explode("\t",$db_qcheck);
	if(!$_POST['step']){
		InitGP(array('touid'));
		$reinfo = $db->get_one("SELECT username FROM pw_members WHERE uid='$touid'");
		require_once PrintEot('ajax');ajax_footer();
	} else{
		($db_gdcheck & 8) && GdConfirm($_POST['gdcode']);

		InitGP(array('msg_title','atc_content','pwuser'),'P');
		$msg_title   = Char_cv(trim($msg_title));
		$atc_content = Char_cv(trim($atc_content));
		if(!$atc_content || !$msg_title || !$pwuser){
			Showmsg('msg_empty');
		} elseif(strlen($msg_title)>75 || strlen($atc_content)>1500){
			Showmsg('msg_subject_limit');
		}
		if($db_charset!='utf-8'){
			$pwuser		 = ajax_convert($pwuser,$db_charset);
			$msg_title	 = ajax_convert($msg_title,$db_charset);
			$atc_content = ajax_convert($atc_content,$db_charset);
			$_POST['qanswer'] && $_POST['qanswer'] = ajax_convert($_POST['qanswer'],$db_charset);
		}
		if(@include(D_P."data/bbscache/wordsfb.php")){
			foreach($wordsfb as $key => $value){
				$banword = (string) stripslashes($key);
				if(strpos($msg_title,$banword)!==false){
					Showmsg('title_wordsfb');
				} elseif(strpos($atc_content,$banword)!==false){
					Showmsg('content_wordsfb');
				}
			}
			foreach($replace as $key => $value){
				$banword = (string) stripslashes($key);
				if(strpos($msg_title,$banword)!==false){
					Showmsg('post_wordsfb');
				}
			}
		}
		$msgq && Qcheck($_POST['qanswer'],$_POST['qkey']);

		$rt = $db->get_one("SELECT uid,banpm,msggroups FROM pw_members WHERE username='$pwuser'");
		if(!$rt){
			$errorname = Char_cv($pwuser);
			Showmsg('user_not_exists');
		}
		if($rt['msggroups'] && strpos($rt['msggroups'],",$groupid,")!==false || strpos(",$rt[banpm],",",$windid,")!==false){
			$errorname = Char_cv($pwuser);
			Showmsg('msg_refuse');
		}
		require_once(R_P.'require/msg.php');
		$msg = array(
			$pwuser,
			$winduid,
			$msg_title,
			$timestamp,
			$atc_content,
			'N',
			$windid
		);
		writenewmsg($msg);
		Showmsg('send_success');
	}
} elseif($action=='usetool'){
	$tooldb = array();
	$i = $j = 0;
	$query  = $db->query("SELECT t.id,t.name,t.filename,t.descrip,u.nums FROM pw_tools t LEFT JOIN pw_usertool u ON t.id=u.toolid  AND u.uid='$winduid' WHERE t.state='1' AND t.type='1' ORDER BY vieworder");
	while($rt = $db->fetch_array($query)){
		$rt['nums']=(int)$rt['nums'];
		$tooldb[$i][$j] = $rt;
		$j++;
		if($j>1){
			$i++;$j=0;
		}
	}
	require_once PrintEot('ajax');ajax_footer();
} elseif($action=='usertool'){
	//����������
	$uid = (int)GetGP('uid');
	!$uid && Showmsg('undefined_action');
	$i = $j = 0;
	$query  = $db->query("SELECT t.id,t.name,t.filename,t.descrip,u.nums FROM pw_tools t LEFT JOIN pw_usertool u ON t.id=u.toolid  AND u.uid='$winduid' WHERE state='1' AND type='2' ORDER BY vieworder");
	while($rt = $db->fetch_array($query)){
		$rt['nums']=(int)$rt['nums'];
		$tooldb[$i][$j] = $rt;
		$j++;
		if($j>1){
			$i++;$j=0;
		}
	}
	require_once PrintEot('ajax');ajax_footer();
} elseif($action=='dig'){
	!$_G['dig'] && Showmsg("dig_right");
	$read = $db->get_one("SELECT t.author,t.subject,t.dig,f.forumset FROM pw_threads t LEFT JOIN pw_forumsextra f USING(fid) WHERE tid='$tid'");
	!$read && Showmsg('data_error');
	$forumset = unserialize($read['forumset']);
	!$forumset['dig'] && Showmsg('forum_dig_allow');
	$rt  = $db->get_one("SELECT uid,digtid FROM pw_memberinfo WHERE uid='$winduid'");
	Add_S($rt);
	if(strpos(",$rt[digtid],",",$tid,")===false){
		$read['dig']++;
		$db->update("UPDATE pw_threads SET dig=dig+1 WHERE tid='$tid'");
		if($rt){
			strlen($rt['digtid'])>2000 && $rt['digtid'] = '';
			$rt['digtid'] .= ($rt['digtid'] ? ',' : '').$tid;
			$db->update("UPDATE pw_memberinfo SET digtid='$rt[digtid]' WHERE uid='$winduid'");
		} else{
			$db->update("INSERT INTO pw_memberinfo (uid,digtid) VALUES('$winduid','$tid')");
		}
		require_once(R_P.'require/posthost.php');
		PostHost("http://push.phpwind.com/push.php?type=dig&url=".rawurlencode("$db_bbsurl/read.php?tid=$tid")."&tocharset=$db_charset&title=".rawurlencode($read['subject'])."&bbsname=".rawurlencode($db_bbsname),"");
		Showmsg('dig_success');
	} else{
		Showmsg("dig_limit");
	}
} elseif($action=='extend'){
	InitGP(array('type'));
	if($type=='pwcode'){
		$code  = array();
		$query = $db->query("SELECT * FROM pw_windcode");
		while($rt = $db->fetch_array($query)){
			$rt['descrip'] = str_replace("\n","|",$rt['descrip']);
			$code[] = $rt;
		}
	} else{
		@include_once(D_P.'data/bbscache/setform.php');
		$id = (int)GetGP('id');
		$setform = array();
		if(isset($setformdb[$id])){
			$setform = $setformdb[$id];
		}
	}
	require_once PrintEot('ajax');ajax_footer();
} elseif($action=='sharelink'){
	!$db_ifselfshare && Showmsg("sharelink_colse");
	if(!$_POST['step']){
		require_once PrintEot('ajax');ajax_footer();
	} else{
		InitGP(array('linkname','linkurl','linkdescrip','linklogo'),'P',1);
		(!$linkname || !$linkurl) && Showmsg('sharelink_link_empty');
		!$linkdescrip && $linkdescrip = '';
		!$linklogo && $linklogo = '';
		$linkurl = strtolower($linkurl);
		substr($linkurl,0,7)!="http://" && Showmsg('sharelink_link_error');
		$rs=$db->get_one("SELECT sid FROM pw_sharelinks WHERE username='$windid'");
		$rs && Showmsg('sharelink_apply_limit');
		if($db_charset!='utf-8'){
			$linkname = ajax_convert($linkname,$db_charset);
			$linkdescrip = ajax_convert($linkdescrip,$db_charset);
		}
		$db->update("INSERT INTO pw_sharelinks(name,url,descrip,logo,ifcheck,username) VALUES('$linkname','$linkurl','$linkdescrip','$linklogo','0','$windid')");
		Showmsg("sharelink_success");
	}
} elseif($action=='showface'){
	InitGP(array('page'));
	(!is_numeric($page) || $page < 1) && $page=1;
	$pre_page	= $page-1;
	$next_page	= $page+1;
	$db_perpage = 20;
	$img = @opendir("$imgdir/face");
	$imagearray	= @readdir($img);
	$imgselect	= "<span onClick=\"showimage('$imgpath','none.gif')\" class=\"fl face\"><img src='$imgpath/face/none.gif' width=\"50\" height=\"50\"></span>";
	$num = 0;
	while ($imagearray = @readdir($img)) {
		if ($imagearray != "." && $imagearray != ".." && $imagearray != "" && $imagearray != "none.gif" && eregi("\.(gif|jpg|png|bmp)$",$imagearray)) {
			++$num;
			if ($num > ($page-1)*$db_perpage && $num < $page*$db_perpage) {
				$imgselect .= "<span onClick=\"showimage('$imgpath','$imagearray')\" class=\"fl face\"><img src='$imgpath/face/$imagearray' width=\"50\" height=\"50\"></span>";
			}
		}
	}
	@closedir($img);
	require_once PrintEot('ajax');ajax_footer();
} elseif($action=='newrp'){
	if($db_replysitemail && $winddb['newrp']){
		include_once(D_P.'data/bbscache/forum_cache.php');
		$rt=$db->get_one("SELECT replyinfo FROM pw_memberinfo WHERE uid='$winduid'");
		$rt['replyinfo']=substr($rt['replyinfo'],1,-1);
		$replydb=array();
		$query=$db->query("SELECT tid,fid,subject,postdate,lastpost FROM pw_threads WHERE tid IN($rt[replyinfo]) LIMIT 20");
		if($db->num_rows($query)==0){
			Showmsg('newrp_error');
		}
		while($rt=$db->fetch_array($query)){
			$rt['subject']=substrs($rt['subject'],55);
			$rt['fname']=$forum[$rt['fid']]['name'];
			$rt['lastpost']=get_date($rt['lastpost'],'Y-m-d');
			$replydb[]=$rt;
		}
		require_once PrintEot('ajax');ajax_footer();
	} else{
		Showmsg('newrp_error');
	}
} elseif($action=='delnewrp'){
	!$tid && Showmsg('data_error');
	$rt = $db->get_one("SELECT replyinfo FROM pw_memberinfo WHERE uid='$winduid'");
	$rt['replyinfo'] = str_replace(",$tid,",',',$rt['replyinfo']);
	$rt['replyinfo'] == ',' && $rt['replyinfo'] = '';
	$db->update("UPDATE pw_memberinfo SET replyinfo='$rt[replyinfo]' WHERE uid='$winduid'");
	$db->update("UPDATE pw_threads SET ifmail='0' WHERE tid='$tid'");
	if($winddb['newrp'] && !$rt['replyinfo']){
		$db->update("UPDATE pw_members SET newrp='0' WHERE uid='$winduid'");
	}
	Showmsg('operate_success');
} elseif($action=='addfriend'){
	$touid = (int)GetGP('touid');
	if($touid==$winduid){
		Showmsg('friend_selferror');
	}
	$rt = $db->get_one("SELECT uid,username FROM pw_members WHERE uid='$touid'");
	if(!$rt){
		$errorname = $touid;
		Showmsg('user_not_exists');
	}
	$rs = $db->get_one("SELECT uid FROM pw_friends WHERE uid='$winduid' AND friendid='$rt[uid]'");
	if($rs){
		Showmsg('friend_already_exists');
	}
	$db->update("INSERT INTO pw_friends(uid,friendid,joindate) VALUES('$winduid','$rt[uid]','$timestamp')");
	Showmsg('friend_update_success');
} elseif($action == 'showsmile'){
	InitGP(array('subjectid','page','type'));
	$u         = "http://dm.phpwind.net/misc";
	$subjectid = (int)$subjectid;
	(!is_numeric($page) || $page<1) && $page = 1;
	$s         = '300.xml';
	if($type == 'general'){
		$s = $subjectid ? $subjectid.'_'.$page.'.xml' : '300.xml';
	} elseif($type == 'magic'){
		$s = $subjectid ? $subjectid.'_'.$page.'.xml' : '200.xml';
	}
	$cachefile = D_P."data/bbscache/myshow_{$s}";
	if(!file_exists($cachefile) || $timestamp - @filemtime($cachefile) > 43200){
		$data = '';
		if($subjectid){
			$url = "$u/list/$s?$timestamp";
		} else{
			$url = "$u/menu/$s?$timestamp";
		}
		require_once(R_P.'require/posthost.php');
		$data = PostHost($url);
		if($data && strpos($data,'<?xml')!==false){
			writeover($cachefile,$data);
		}
		writeover($cachefile,$data);
	}
	header("Content-Type: text/xml; charset=UTF-8");
	$data = readover($cachefile);
	echo $data;
	exit;
} elseif($action == 'honor'){
	!$gp_allowhonor && Showmsg('undefined_action');
	if(!$_POST['step']){
		require_once PrintEot('ajax');ajax_footer();
	} else{
		InitGP(array('content'),'P',1);
		if($db_charset!='utf-8'){
			$content = ajax_convert($content,$db_charset);
		}
		$content = str_replace("\n",'',$content);
		strlen($content)>100 && $content = substrs($content,100);
		$db->update("UPDATE pw_members SET honor='$content' WHERE uid='$winduid'");
		echo "success\t".stripslashes($content);ajax_footer();
	}
} elseif($action == 'readlog'){
	$readlog = explode(',',GetCookie('readlog'));
	@krsort($readlog);
	$tids = '';
	$i = 0;
	foreach($readlog as $key=>$value){
		if(is_numeric($value)){
			$tids .= ($tids ? ',' : '').$value;
			if(++$i>9) break;
		}
	}
	Cookie('readlog',",$tids,");
	!$tids && Showmsg('data_error');
	include_once(D_P.'data/bbscache/forum_cache.php');
	$readb = array();
	$query = $db->query("SELECT t.tid,t.fid,t.subject,t.author,t.authorid,t.anonymous,f.f_type,f.password,f.allowvisit FROM pw_threads t LEFT JOIN pw_forums f USING(fid) WHERE t.tid IN($tids)");
	while($rt = $db->fetch_array($query)){
		if(empty($rt['password']) && $rt['f_type']<>'hidden' && (empty($rt['allowvisit']) || allowcheck($rt['allowvisit'],$groupid,$winddb['groups']))){
			if ($rt['anonymous'] && !in_array($groupid,array('3','4')) && $rt['authorid']<>$winduid) {
				$rt['author']	= $db_anonymousname;
				$rt['authorid'] = 0;
			}
			$readb[] = $rt;
		}
	}
	require_once PrintEot('ajax');ajax_footer();
} elseif($action == 'threadlog'){
	$threadlog = explode(',',GetCookie('threadlog'));
	@krsort($threadlog);
	$fids = ',';
	$i = 0;
	foreach($threadlog as $key=>$value){
		if(is_numeric($value)){
			$fids .= $value.',';
			if(++$i>9) break;
		}
	}
	Cookie('threadlog',$fids);
	include_once(D_P.'data/bbscache/forum_cache.php');
	$threaddb = array();
	foreach($forum as $key=>$value){
		if(in_array($key,$threadlog)){
			$threaddb[$key] = $value['name'];
		}
	}
	require_once PrintEot('ajax');ajax_footer();
}
function getfavor($tids){
	$tids=explode('|',$tids);
	$tiddb=array();
	foreach($tids as $key=>$t){
		if($t){
			$v=explode(',',$t);
			foreach($v as $k=>$v1){
				$tiddb[$key][$v1]=$v1;
			}
		}
	}
	return $tiddb;
}
function makefavor($tiddb){
	$newtids=$ex='';
	$k=0;
	ksort($tiddb);
	foreach($tiddb as $key=>$val){
		$new_tids='';
		rsort($val);
		if($key!=$k){
			$s=$key-$k;
			for($i=0;$i<$s;$i++){
				$newtids .='|';
			}
		}
		foreach($val as $k=>$v){
			is_numeric($v) && $new_tids .= $new_tids ? ','.$v : $v;
		}
		$newtids .= $ex.$new_tids;
		$k=$key+1;
		$ex='|';
	}
	return $newtids;
}
?>