<?php
!function_exists('readover') && exit('Forbidden');

function Signfunc($showsign,$starttime,$currency){
	global $db,$winduid,$groupid,$tdtime,$db_signgroup,$db_signmoney,$db_signcurtype;
	if(!in_array($db_signcurtype,array('money','rvrc','credit','currency'))){
		return false;
	}
	if(!$starttime){
		$db_signcurtype=='rvrc' && $db_signmoney *= 10;
		$db->update("UPDATE pw_memberdata SET starttime='$tdtime',$db_signcurtype=$db_signcurtype-'$db_signmoney' WHERE uid='$winduid'");
	}elseif(!$db_signmoney || strpos($db_signgroup,",$groupid,") === false){
		$db->update("UPDATE pw_memberdata SET starttime='0' WHERE uid='$winduid'");
	}else{
		global $windid,$onlineip,$timestamp,$db_currencyname,$db_credits;
		$days = floor(($tdtime-$starttime)/86400);
		$cost = $days * $db_signmoney;
		$cost < 0 && $cost = 0;
		if($currency >= $cost){
			$db_signcurtype=='rvrc' && $cost *= 10;
			$db->update("UPDATE pw_memberdata SET starttime='$tdtime',$db_signcurtype=$db_signcurtype-'$cost' WHERE uid='$winduid'");
		} else {
			$days = floor($currency/$db_signmoney);
			$cost = $days * $db_signmoney;
			$cost < 0 && $cost = 0;
			$db_signcurtype=='rvrc' && $cost *= 10;
			$db->update("UPDATE pw_memberdata SET starttime='0',$db_signcurtype=$db_signcurtype-'$cost' WHERE uid='$winduid'");
		}
		if($cost){
			$curtype = array();
			$curtype['currency'] = array('name'=>$db_currencyname,'unit'=>'');
			list($curtype['money']['name'],$curtype['money']['unit'],$curtype['rvrc']['name'],$curtype['rvrc']['unit'],$curtype['credit']['name'],$curtype['credit']['unit'])=explode("\t",$db_credits);
			require_once(R_P.'require/tool.php');
			$logdata=array(
				'type'		=>	'sign',
				'nums'		=>	0,
				'money'		=>	0,
				'descrip'	=>	'sign_descrip',
				'uid'		=>	$winduid,
				'username'	=>	$windid,
				'ip'		=>	$onlineip,
				'time'		=>	$timestamp,
				'currency'	=>	$cost,
				'curtype'	=>	$curtype[$db_signcurtype]
			);
			writetoollog($logdata);
		}
	}
}
?>