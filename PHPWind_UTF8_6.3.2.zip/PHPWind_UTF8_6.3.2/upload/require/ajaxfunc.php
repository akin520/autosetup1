<?php
!function_exists('GdConfirm') && exit('Forbidden');

function ajax_footer(){
	global $db_charset;
//	$output = ob_get_contents();
	$output = str_replace(array('<!--<!---->','<!---->'),array('',''),ob_get_contents());
	/*
	if($db_charset!='utf-8'){
		$output = ajax_convert($output,'utf-8',$db_charset);
	}
	*/
	header("Content-Type: text/xml;charset=$db_charset");
	echo ObContents("<?xml version=\"1.0\" encoding=\"$db_charset\"?><ajax><![CDATA[".$output."]]></ajax>");exit;
}
function ajax_convert($str,$to_encoding,$from_encoding='utf-8'){
	return $str;
	/*
	if(function_exists('mb_convert_encoding')){
		return mb_convert_encoding($str,$to_encoding,$from_encoding);
	} else{
		require_once(R_P.'wap/chinese.php');
		$chs = new Chinese($from_encoding,$to_encoding);
		return $chs->Convert($str);
	}
	*/
}
?>