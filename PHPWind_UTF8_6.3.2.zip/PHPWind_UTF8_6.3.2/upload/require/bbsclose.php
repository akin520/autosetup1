<?php
!function_exists('readover') && exit('Forbidden');

$bbsclose = true;
$AdminUser = GetCookie('AdminUser');
$CK = $AdminUser ? explode("\t",StrCode(GetCookie('AdminUser'),'DECODE')) : array();
if ($CK[1] && CkInArray($CK[1],$manager)) {
	$v_key = array_search($CK[1],$manager);
	SafeCheck($CK,PwdCode($manager_pwd[$v_key])) && $bbsclose = false;
}

if (!$db_bbsifopen) {
	if ($_GET['logined'] && !$bbsclose) {
		Cookie('logined',1,$timestamp + 1800);
	} elseif (!GetCookie('logined') || $bbsclose) {
		$skin	 = $skinco ? $skinco : $db_defaultstyle;
		$groupid = '';
		Showmsg($db_whybbsclose,($bbsclose ? NULL : 'bbsclose'));
	}
} elseif ($db_bbsifopen==2) {
	if ($db_visituser) {
		$_POST['pwpwd'] && $windid = $_POST['pwuser'];
		if (!$windid) {
			Showmsg('visiter_login');
		} elseif (!CkInArray($windid,$manager) && strpos(','.strtolower($db_visituser).',',','.strtolower($windid).',')===false) {
			PwNewDB();
			require_once(R_P.'require/checkpass.php');
			Loginout(); Showmsg('visiter_login');
		}
	} elseif (!$windid && strpos($REQUEST_URI,'login')===false) {
		Showmsg($db_whybbsclose);
	}
}

unset($AdminUser,$CK,$bbsclose);
?>