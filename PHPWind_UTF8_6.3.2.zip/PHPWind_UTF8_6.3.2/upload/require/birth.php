<?php
!function_exists('readover') && exit('Forbidden');

$cachefile = D_P.'data/bbscache/brith_cache.php';
if (!file_exists($cachefile) || filemtime($cachefile)<=$tdtime) {
	require_once(GetLang('other'));
	list($nyear,$nmonth,$nday) = explode('-',get_date($timestamp,'Y-n-j'));
	$birthnum = 0;
	$query = $db->query("SELECT username,bday,gender FROM pw_members WHERE MONTH(bday)='$nmonth' AND DAYOFMONTH(bday)='$nday' LIMIT 200");
	while ($rt = $db->fetch_array($query)) {
		$birthnum++;
		if ($rt['gender']==1) {
			$rt['gender'] = $lang['men'];
		} elseif ($rt['gender']==2) {
			$rt['gender'] = $lang['women'];
		} else {
			$rt['gender'] = '';
		}
		$rt['age'] = $nyear - substr($rt['bday'],0,strpos($rt['bday'],'-'));
		$rt['indexbirth'] = str_replace('{#age}',$rt['age'],$lang['indexbirth']);
		$brithcache .= ' <a href="profile.php?action=show&username='.rawurlencode($rt['username'])."\" title=\"$rt[username]$rt[gender]$rt[indexbirth]\">$rt[username]</a>&nbsp;";
	}
	writeover($cachefile,"<?php\r\n\$birthnum='$birthnum';\r\n\$brithcache='$brithcache';\r\n?>");
} else {
	include_once($cachefile);
}
$db_bdayautohide && !$brithcache && $brithcache = 'empty';
?>