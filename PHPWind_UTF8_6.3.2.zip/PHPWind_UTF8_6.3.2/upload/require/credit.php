<?php
!function_exists('readover') && exit('Forbidden');

function GetCredit($uid){
	global $db,$_CREDITDB;
	$credit = array();
	if (is_array($_CREDITDB)) {
		foreach ($_CREDITDB as $key => $value) {
			$credit[$key] = array($value[0],0);
		}
	}
	$query = $db->query("SELECT cid,value FROM pw_membercredit WHERE uid='$uid'");
	while ($rt = $db->fetch_array($query)) {
		$credit[$rt['cid']] = array($_CREDITDB[$rt['cid']][0],$rt['value']);
	}
	return $credit;
}
function GetCreditType(){
	global $db_credits,$db_currencyname,$_CREDITDB;
	list($moneyname,,$rvrcname,,$creditname) = explode("\t",$db_credits);
	$credittype = array(
		'money'		=> $moneyname,
		'rvrc'		=> $rvrcname,
		'credit'	=> $creditname,
		'currency'	=> $db_currencyname
	);
	foreach ($_CREDITDB as $key => $value) {
		$credittype[$key] = $value[0];
	}
	return $credittype;
}
function GetCreditUnit(){
	global $db_credits,$_CREDITDB;
	list(,$moneyunit,,$rvrcunit,,$creditunit) = explode("\t",$db_credits);
	$creditunit = array(
		'money'		=> $moneyunit,
		'rvrc'		=> $rvrcunit,
		'credit'	=> $creditunit,
		'currency'	=> ''
	);
	foreach ($_CREDITDB as $key => $value) {
		$creditunit[$key] = $value[1];
	}
	return $creditunit;
}
function GetCreditValue($type = null){
	global $db_credits,$db_currencyname,$_CREDITDB;
	list($moneyname,$moneyunit,$rvrcname,$rvrcunit,$creditname,$creditunit) = explode("\t",$db_credits);
	if (!empty($type)) {
		if (in_array($type,array('money','rvrc','credit'))) {
			return array(${$type.'name'},${$type.'unit'});
		} elseif ($type == 'currency') {
			return array($db_currencyname,);
		} elseif (is_numeric($type) && $_CREDITDB[$type][0]) {
			return array($_CREDITDB[$type][0],$_CREDITDB[$type][1]);
		} else {
			return array();
		}
	}
	$creditvalue = array(
		'money'		=> array($moneyname,$moneyunit),
		'rvrc'		=> array($rvrcname,$rvrcunit),
		'credit'	=> array($creditname,$creditunit),
		'currency'	=> array($db_currencyname,),
	);
	foreach ($_CREDITDB as $key => $value) {
		$creditvalue[$key] = array($value[0],$value[1]);
	}
	return $creditvalue;
}
function CreditName($type){
	global $db_credits,$db_currencyname,$_CREDITDB;
	list($db_moneyname,,$db_rvrcname,,$db_creditname,) = explode("\t",$db_credits);
	return is_numeric($type) ? $_CREDITDB[$type][0] : ${'db_'.$type.'name'};
}
function UserCredit($uid,$type,$method='get',$point=0){
	global $db,$_CREDITDB;
	if(in_array($type,array('money','rvrc','credit','currency'))){
		if($method=='get'){
			$rt=$db->get_one("SELECT $type FROM pw_memberdata WHERE uid='$uid'");
			return $type=='rvrc' ? intval($rt[$type]/10) : $rt[$type];
		} else{
			$type=='rvrc' && $point *= 10;
			$db->update("UPDATE pw_memberdata SET $type=$type+'$point' WHERE uid='$uid'");
			return true;
		}
	}
	if(is_numeric($type) && isset($_CREDITDB[$type])){
		if($method=='get'){
			$rt=$db->get_one("SELECT value FROM pw_membercredit WHERE uid='$uid' AND cid='$type'");
			return $rt['value'] ? $rt['value'] : 0;
		} else{
			$db->pw_update(
				"SELECT value FROM pw_membercredit WHERE uid='$uid' AND cid='$type'",
				"UPDATE pw_membercredit SET value=value+'$point' WHERE uid='$uid' AND cid='$type'",
				"INSERT INTO pw_membercredit(uid,cid,value) VALUES('$uid','$type','$point')"
			);
			return true;
		}
	}
	return false;
}
?>