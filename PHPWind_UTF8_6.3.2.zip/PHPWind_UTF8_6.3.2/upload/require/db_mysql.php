<?php
!function_exists('readover') && exit('Forbidden');

Class DB {
	var $sql = 0;
	var $pconnect = 0;
	var $query_num = 0;
	function DB($dbhost,$dbuser,$dbpw,$dbname,$pconnect=0){
		$this->pconnect = $pconnect;
		$this->connect($dbhost,$dbuser,$dbpw,$dbname);
	}
	function connect($dbhost,$dbuser,$dbpw,$dbname){
		$this->sql = $this->pconnect==0 ? @mysql_connect($dbhost,$dbuser,$dbpw,true) : @mysql_pconnect($dbhost,$dbuser,$dbpw);
		mysql_errno($this->sql)!=0 && $this->halt("Connect($pconnect) to MySQL failed");
		$serverinfo = mysql_get_server_info($this->sql);
		if ($serverinfo > '4.1' && $GLOBALS['charset']) {
			mysql_query("SET character_set_connection=".$GLOBALS['charset'].",character_set_results=".$GLOBALS['charset'].",character_set_client=binary",$this->sql);
		}
		if ($serverinfo > '5.0') {
			mysql_query("SET sql_mode=''",$this->sql);
		}
		if ($dbname && !@mysql_select_db($dbname,$this->sql)) {
			$this->halt('Cannot use database');
		}
	}
	function select_db($dbname){
		if (!@mysql_select_db($dbname,$this->sql)) {
			$this->halt('Cannot use database');
		}
	}
	function server_info(){
		return mysql_get_server_info($this->sql);
	}
	function pw_update($SQL_1,$SQL_2,$SQL_3){
		$rt = $this->get_one($SQL_1,MYSQL_NUM);
		if (isset($rt[0])) {
			$this->update($SQL_2);
		} else {
			$this->update($SQL_3);
		}
	}
	function insert_id(){
		return $this->get_value('SELECT LAST_INSERT_ID()');
	}
	function get_value($SQL,$result_type = MYSQL_NUM,$field=0){
		$query = $this->query($SQL);
		$rt =& $this->fetch_array($query,$result_type);
		if (isset($rt[$field])) {
			return $rt[$field];
		}
		return false;
	}
	function get_one($SQL,$result_type = MYSQL_ASSOC){//MYSQL_ASSOC��MYSQL_NUM��MYSQL_BOTH
		$query = $this->query($SQL,'U_B');
		$rt =& $this->fetch_array($query,$result_type);
		return $rt;
	}
	function update($SQL,$lp=1){
		if ($GLOBALS['db_lp']==1 && $lp) {
			$tmpsql6 = substr($SQL,0,6);
			if (strtoupper($tmpsql6.'E')=='REPLACE') {
				$SQL = 'REPLACE LOW_PRIORITY'.substr($SQL,7);
			} else {
				$SQL = $tmpsql6.' LOW_PRIORITY'.substr($SQL,6);
			}
		}
		return $this->query($SQL,'U_B');
	}
	function query($SQL,$method = null,$error = true){
		$GLOBALS['PW']!='pw_' && $SQL = str_replace(array(' pw_','`pw_'," 'pw_"),array(" $GLOBALS[PW]","`$GLOBALS[PW]"," '$GLOBALS[PW]"),$SQL);
		if ($method=='U_B' && function_exists('mysql_unbuffered_query')) {
			$query = @mysql_unbuffered_query($SQL,$this->sql);
		} else {
			$query = @mysql_query($SQL,$this->sql);
		}
		if (in_array(mysql_errno($this->sql),array(2006,2013)) && empty($query) && $this->pconnect==0 && !defined('QUERY')) {
			define('QUERY',true); @mysql_close($this->sql); sleep(2);
			include(D_P.'data/sql_config.php');
			$this->connect($dbhost,$dbuser,$dbpw,$dbname);
			$query = $this->query($SQL);
		}
		$this->query_num++;
		!$query && $error && $this->halt('Query Error: '.$SQL);
		return $query;
	}
	function fetch_array($query, $result_type = MYSQL_ASSOC){
		return mysql_fetch_array($query,$result_type);
	}
	function affected_rows(){
		return mysql_affected_rows($this->sql);
	}
	function num_rows($query){
		if (!is_bool($query)) {
			return mysql_num_rows($query);
		}
		return 0;
	}
	function num_fields($query){
		return mysql_num_fields($query);
	}
	function escape_string($str){
		return mysql_escape_string($str);
	}
	function free_result(){
		$void = func_get_args();
		foreach ($void as $query) {
			if (is_resource($query) && get_resource_type($query)==='mysql result') {
				mysql_free_result($query);
			}
		}
		unset($void);
	}
	function close($linkid){
		return @mysql_close($linkid);
	}
	function halt($msg=null){
		require_once(R_P.'require/db_mysql_error.php');
		new DB_ERROR($msg);
	}
}
?>