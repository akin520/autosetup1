<?php
//Copyright (c) 2003-06 PHPWind
!function_exists('GdConfirm') && exit('Forbidden');
$ceversion = 0;
require_once(D_P.'data/bbscache/config.php');

if ($db_forcecharset && !defined('W_P') && !defined('AJAX')) {
	@header("Content-Type:text/html; charset=$db_charset");
}

if ($db_dir && $db_ext) {
	$_NGET = array();
	$self_array = explode('-',substr($_SERVER['QUERY_STRING'],0,strpos($_SERVER['QUERY_STRING'],$db_ext)));
	$s_count = count($self_array);
	for ($i=0;$i<$s_count-1;$i++) {
		$_key	= $self_array[$i];
		$_value	= $self_array[++$i];
		$_NGET[$_key] = addslashes(rawurldecode($_value));
	}
	!empty($_NGET) && $_GET = $_NGET;
	unset($_NGET);
}

if ($db_loadavg && substr(PHP_OS,0,3) != 'WIN' && !defined('W_P') && ($fp=@fopen('/proc/loadavg','rb'))) {
	list($loadavg) = explode(' ',fread($fp,6));
	fclose($fp);
	$loadavg>$db_loadavg && $db_cc = 2;
}

if ($db_cc && ((!$_COOKIE && !$_SERVER['HTTP_USER_AGENT']) || ($db_cc==2 && $c_agentip))) {
	exit('Forbidden');
}
?>