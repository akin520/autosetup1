<?php
!function_exists('readover') && exit('Forbidden');

function wind_forumcheck($forum){
	global $windid,$groupid,$tid,$fid,$skin,$winddb,$manager;

	if($forum['f_type']=='former' && $groupid=='guest' && $_COOKIE){
		Showmsg('forum_former');
	}
	if(!empty($forum['style']) && file_exists(D_P."data/style/$forum[style].php")){
		$skin=$forum['style'];
	}
	$pwdcheck=GetCookie('pwdcheck');
	if ($forum['password'] != '' && ($groupid=='guest' || $pwdcheck[$fid] != $forum['password'] && !CkInArray($windid,$manager))){
		require_once(R_P.'require/forumpw.php');
	}
	if($forum['allowvisit'] && !allowcheck($forum['allowvisit'],$groupid,$winddb['groups'],$fid,$winddb['visit'])){
		Showmsg('forum_jiami');
	}
	if(!$forum['cms'] && $forum['f_type']=='hidden' && !$forum['allowvisit']){
		Showmsg('forum_hidden');
	}
}
function forum_creditcheck(){
	global $db,$winddb,$userrvrc,$forumset,$groupid;

	$forumset['rvrcneed']   /= 10;
	$forumset['moneyneed']   = (int) $forumset['moneyneed'];
	$forumset['creditneed']  = (int) $forumset['creditneed'];
	$forumset['postnumneed'] = (int) $forumset['postnumneed'];
	$check = 1;
	if($forumset['rvrcneed'] && $userrvrc < $forumset['rvrcneed']){
		$check = 0;
	} elseif($forumset['moneyneed'] && $winddb['money'] < $forumset['moneyneed']){
		$check = 0;
	} elseif($forumset['creditneed'] && $winddb['credit'] < $forumset['creditneed']){
		$check = 0;
	} elseif($forumset['postnumneed'] && $winddb['postnum'] < $forumset['postnumneed']){
		$check = 0;
	}
	if(!$check){
		if($groupid == 'guest'){
			Showmsg('forum_guestlimit');
		} else{
			Showmsg('forum_creditlimit');
		}
	}
}
function forum_sell($fid) {
	global $db,$winduid,$timestamp;
	$rt = $db->get_one("SELECT MAX(overdate) AS u FROM pw_forumsell WHERE uid='$winduid' AND fid='$fid'");
	if ($rt['u'] < $timestamp) {
		Showmsg('forum_sell');
	}
}
function get_creditset($creditset,$db_creditset){
    $creditset    = unserialize($creditset);
	$db_creditset = unserialize(stripslashes($db_creditset));
	if($creditset){
		foreach($creditset as $key => $value){
			$value['Digest']===''   && $creditset[$key]['Digest']   = $db_creditset[$key]['Digest'];
			$value['Post']===''     && $creditset[$key]['Post']     = $db_creditset[$key]['Post'];
			$value['Reply']===''    && $creditset[$key]['Reply']    = $db_creditset[$key]['Reply'];
			$value['Undigest']==='' && $creditset[$key]['Undigest'] = $db_creditset[$key]['Undigest'];
			$value['Delete']===''   && $creditset[$key]['Delete']   = $db_creditset[$key]['Delete'];
			$value['Deleterp']==='' && $creditset[$key]['Deleterp'] = $db_creditset[$key]['Deleterp'];
		}
	} else{
		$creditset = $db_creditset;
	}
	return $creditset;
}
function customcredit($uid,$creditset,$option){
	global $db,$_CREDITDB;
	foreach($_CREDITDB as $key => $value){
		if($creditset[$key][$option]){
			if($option == 'Digest' || $option == 'Post' || $option == 'Reply'){
				$addpoint = $creditset[$key][$option];
			} else{
				$addpoint = -$creditset[$key][$option];
			}
			$db->pw_update(
				"SELECT uid FROM pw_membercredit WHERE uid='$uid' AND cid='$key'",
				"UPDATE pw_membercredit SET value=value+'$addpoint' WHERE uid='$uid' AND cid='$key'",
				"INSERT INTO pw_membercredit SET uid='$uid',cid='$key',value='$addpoint'"
			);
		}
	}
}
function forumindex($fup){
	global $forum,$fid,$cateid,$fpage;
	$secondurl="thread.php?fid=$fid".($fpage>1 ? "&page=$fpage" : '');
	$guidename = array();
	if($forum[$fup]['type']=='category'){
		$cateid=$forum[$fup]['fid'];
		$guidename=array(
			$cateid=>array($forum[$fid]['name'],$secondurl)
		);
	} elseif($forum[$fup]['type']=='forum'){
		$cateid=$forum[$fup]['fup'];
		$guidename=array(
			$cateid=>array($forum[$fup]['name'],"thread.php?fid=".$forum[$fup]['fid']),
			$fup=>array($forum[$fid]['name'],$secondurl)
		);
	} elseif($forum[$fup]['type']=='sub'){
		$fup1=$forum[$fup]['fup'];
		$cateid=$forum[$fup1]['fup'];
		$guidename=array(
			$cateid=>array($forum[$fup1]['name'],"thread.php?fid=".$forum[$fup1]['fid']),
			$fup1=>array($forum[$fup]['name'],"thread.php?fid=".$forum[$fup]['fid']),
			$fup=>array($forum[$fid]['name'],$secondurl)
		);
	}
	return $guidename;
}
function headguide($guidename,$onmouseover=true){
	global $db_menu,$db_bbsname,$db_bfn,$cateid,$fid,$imgpath,$stylepath,$db_menu;
	
	if ($db_menu>1 && $onmouseover) {
		$headguide = "<img src=\"$imgpath/$stylepath/index/home_menu.gif\" align=\"absmiddle\" id=\"td_cate\" onMouseOver=\"read.open('menu_cate','td_cate');\" style=\"cursor:pointer;\" /> ";
	} else{
		$headguide = "<img src=\"$imgpath/$stylepath/index/home.gif\" align=\"absmiddle\" /> ";
	}

	$headguide .= "<a href=\"$db_bfn\">$db_bbsname</a>";
	
	if (!is_array($guidename)) {
		return array($headguide." &raquo; ".$guidename,forumlist($fid));
	}
	foreach($guidename as $key=>$value){
		if($value[1]){
			$headguide .= " &raquo; <a href=\"$value[1]\">$value[0]</a>";
		} else{
			$headguide .= " &raquo; $value[0]";
		}
	}
	return array($headguide,forumlist($fid));
}
function numofpage($count,$page,$numofpage,$url,$max=null){
	global $tablecolor;
	$total = $numofpage;
	if(!empty($max)){
		$max = (int)$max;
		$numofpage > $max && $numofpage = $max;
	}
	if($numofpage <= 1 || !is_numeric($page)){
		return '';
	} else{
		list($url,$mao) = explode('#',$url);
		$mao && $mao = '#'.$mao;
		$pages = "<div class=\"pages\"><a href=\"{$url}page=1$mao\" style=\"font-weight:bold\">&laquo;</a>";
		for($i=$page-3;$i<=$page-1;$i++){
			if($i<1) continue;
			$pages .= "<a href=\"{$url}page=$i$mao\">$i</a>";
		}
		$pages .= "<b> $page </b>";
		if($page < $numofpage){
			$flag = 0;
			for($i=$page+1;$i<=$numofpage;$i++){
				$pages .= "<a href=\"{$url}page=$i$mao\">$i</a>";
				$flag++;
				if($flag==4) break;
			}
		}
		$pages .= "<input type=\"text\" size=\"3\" onkeydown=\"javascript: if(event.keyCode==13){ location='{$url}page='+this.value+'{$mao}';return false;}\"><a href=\"{$url}page=$numofpage$mao\" style=\"font-weight:bold\">&raquo;</a> Pages: ( $page/$total total ) </div>";
		return $pages;
	}
}
function getstyles($skin){
	$styles = '';
	$fp = opendir(D_P.'data/style/');
	while($skinfile = readdir($fp)){
		if(preg_match('/([^\.]+?)\.php$/i',$skinfile,$rt)){
			if($skin && $rt[1]==$skin){
				$styles .= "<option value=\"$rt[1]\" selected>$rt[1]</option>";
			} else{
				$styles .= "<option value=\"$rt[1]\">$rt[1]</option>";
			}
		}
	}
	closedir($fp);
	return $styles;
}
function forumlist($fid){
	global $forum,$db_menu;
	if ($db_menu%4<2) return;
	!is_array($forum) && $forum = array();
	$chtml = "<div id=\"menu_cate\" class=\"menu\" style=\"display:none;\"><div style=\"padding:5px;height:420px;width:200px;overflow-Y:auto;\"><ul class=\"ul1\">";
	foreach ($forum as $key=>$v) {
		if($v['cms'] || $v['f_type']=='hidden')continue;
		$fup = $v['fup'];
		if($v['type']=='category'){
			$chtml .= '<li> <a href="index.php?cateid='.$v['fid'].'">>> '.$v['name'].'</a></li>';
		} elseif($forum[$fup]['type']=='category'){
			$chtml .= '<li> &nbsp;<a href="thread.php?fid='.$v['fid'].'">|- '.$v['name'].'</a></li>';
		} elseif($forum[$fup]['type']=='forum'){
			$chtml .= '<li> &nbsp; &nbsp;<a href="thread.php?fid='.$v['fid'].'">|- '.$v['name'].'</a></li>';
		} else{
			$chtml .= '<li> &nbsp;&nbsp; &nbsp; &nbsp;<a href="thread.php?fid='.$v['fid'].'">|- '.$v['name'].'</a></li>';
		}
	}
	$chtml .= '</ul></div></div>';
	return $chtml;
}
function updatecommend($fid,$forumset){
	global $db,$timestamp;
	$forumset['commendnum']<1 && $forumset['commendnum'] = 10;
	$commend = array();
	
	if($forumset['commendlist']){
		$query = $db->query("SELECT tid,authorid,author,subject FROM pw_threads WHERE tid IN($forumset[commendlist]) AND fid='$fid'");
		while($rt=$db->fetch_array($query)){
			if($forumset['commendlength'] && strlen($rt['subject'])>$forumset['commendlength']){
				$rt['subject'] = substrs($rt['subject'],$forumset['commendlength']);
			}
			$commend[] = $rt;
		}
	}
	$count = count($commend);
	if($forumset['autocommend'] && $count<$forumset['commendnum']){
		$num = $forumset['commendnum'] - $count;
		switch($forumset['autocommend']){
			case '1' : $orderby = 'postdate';break;
			case '2' : $orderby = 'lastpost';break;
			case '3' : $orderby = 'hits';break;
			case '4' : $orderby = 'replies';break;
			default  : $orderby = 'digest';break;
		}
		$sql   = $forumset['commendlist'] ? " AND tid NOT IN($forumset[commendlist])" : '';
		$query = $db->query("SELECT tid,authorid,author,subject FROM pw_threads WHERE fid='$fid' AND topped='0' $sql ORDER BY $orderby DESC LIMIT $num");
		while($rt=$db->fetch_array($query)){
			if($forumset['commendlength'] && strlen($rt['subject'])>$forumset['commendlength']){
				$rt['subject'] = substrs($rt['subject'],$forumset['commendlength']);
			}
			$commend[] = $rt;
		}
	}
	$forumset['ifcommend'] = $timestamp;
	$forumsetdb = addslashes(serialize($forumset));
	$commend = $commend ? addslashes(serialize($commend)) : '';
	$db->update("UPDATE pw_forumsextra SET forumset='$forumsetdb',commend='$commend' WHERE fid='$fid'");
}
function getforumtitle($guidename){
	$headguide = array();
	foreach ($guidename as $value) {
		if ($value[0]) {
			if ($value[1]) {
				$headguide[] = "<a href=\"$value[1]\">$value[0]</a>";
			} else {
				$headguide[] = $value[0];
			}
		}
	}
	$guidename = implode(' &raquo; ',$headguide);
	krsort($headguide);
	return array($guidename,strip_tags(implode('|',$headguide)).' - ');
}
?>