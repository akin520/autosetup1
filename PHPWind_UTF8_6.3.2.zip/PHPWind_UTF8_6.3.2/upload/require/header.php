<?php
!function_exists('readover') && exit('Forbidden');

if (file_exists(D_P."data/style/$skin.php") && strpos($skin,'..')===false) {
	@include Pcv(D_P."data/style/$skin.php");
} elseif (file_exists(D_P."data/style/$db_defaultstyle.php") && strpos($db_defaultstyle,'..')===false) {
	@include Pcv(D_P."data/style/$db_defaultstyle.php");
} else {
	@include(D_P."data/style/wind.php");
}
$db_skindb = array();
$fp = opendir(D_P.'data/style/');
while ($skinfile = readdir($fp)) {
	if (preg_match('/([^\.]+?)\.php$/i',$skinfile,$skindb)) {
		$db_skindb[] = $skindb[1];
	}
}
closedir($fp);

$s_url = "$_SERVER[PHP_SELF]?";
foreach ($_GET as $key => $value) {
	$key!='skinco' && $value && $s_url .= "$key=".rawurlencode($value).'&';
}
$s_url = Char_cv($s_url,true);
$msgsound = $head_pop = $menu_down = '';

if ($groupid=='guest' && $db_regpopup=='1') {
	$head_pop = 'head_pop';
} elseif ($winddb['newpm']>0 && !$_COOKIE['msghide'] && $db_msgsound && $secondurl!='message.php') {
	$msgsound = "<bgsound src=\"$imgpath/$stylepath/msg/msg.wav\" border=\"0\">";
}
$db_menuinit = "'td_hack' : 'menu_hack','td_skin' : 'menu_skin'";

if ($db_menu%2==1) {
	$db_menuinit .= ",'td_sort' : 'menu_sort','td_msg' : 'menu_msg','td_profile' : 'menu_profile'";
	$menu_down = "<img src=\"$imgpath/wind/menu-down.gif\" />";
}
if ($db_union) {
	$db_union=explode("\t",stripslashes($db_union));
	$db_union[0] && $db_hackdb=array_merge((array)$db_hackdb,(array)unserialize($db_union[0]));
}
if (file_exists(D_P."data/style/{$tplpath}_css.htm")) {
	$css_path = D_P."data/style/{$tplpath}_css.htm";
} else {
	$css_path = D_P.'data/style/wind_css.htm';
}

require PrintEot('header');
?>