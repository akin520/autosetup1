<?php
!function_exists('readover') && exit('Forbidden');

@include_once (D_P.'data/bbscache/newinfo_config.php');
foreach ($nf_order as $key=>$val) {
	if ($val['order'] && $val['cachetime']<$timestamp && $val['type'] != 'custom' && ($val['type'] != 'newpic' || !$val['mode'])) {
		require_once (R_P.'require/rebang.php');
		$rebang = new reBang();
		if ($val['type'] == 'newpic' && !$val['mode']) {
			$nf_newinfodb[$key] = $rebang->getReBang('newpic',5);
		} elseif ($val['type'] == 'info' && $val['mode']) {
			$info = $rebang->getReBang('info',$nf_config['shownum']);
			$bbsinfo = explode(',',$val['mode']);
			unset($nf_newinfodb[$key]);
			foreach ($bbsinfo as $val) {
				$nf_newinfodb[$key][$val] = $info[$val];
			}
		} elseif ($val['type']) {
			$nf_newinfodb[$key] = $rebang->getReBang($val['type'],$nf_config['shownum']);
		}
		foreach ($nf_newinfodb[$key] as $k=>$v) {
			$nf_newinfodb[$key][$k]['name'] && $nf_newinfodb[$key][$k]['name'] = substrs($v['name'],$nf_config['titlelen'],'N');
		}
		$updatetime = $nf_order[$key]['updatetime'] ? $nf_order[$key]['updatetime'] : ($nf_config['updatetime'] ? $nf_config['updatetime'] : '600');
		$nf_order[$key]['cachetime'] = $timestamp + $updatetime;
		writeover(D_P.'data/bbscache/newinfo_config.php',"<?php\r\n\$nf_config=".pw_var_export($nf_config).";\r\n\$nf_newinfodb=".pw_var_export($nf_newinfodb).";\r\n\$nf_order=".pw_var_export($nf_order).";\r\n?>");
		break;
	}
}

require_once PrintEot('newinfo');
?>
