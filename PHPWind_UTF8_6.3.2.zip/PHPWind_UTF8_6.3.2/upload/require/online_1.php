<?php
!function_exists('readover') && exit('Forbidden');

require_once GetLang('action');
isset($forum) || include(D_P.'data/bbscache/forum_cache.php');

$userinbbs = $guestinbbs = 0;
$query = $db->query("SELECT uid!=0 as ifuser,COUNT(*) AS count FROM pw_online GROUP BY uid='0'");
while($rt = $db->fetch_array($query)){
	if($rt['ifuser']) $userinbbs=$rt['count']; else	$guestinbbs=$rt['count'];
}
if($userinbbs+$guestinbbs < 2000 || CkInArray($windid,$manager)){
	$onlinedb  = $gusetdb = array();
	if(empty($db_showguest)){
		$query = $db->query("SELECT username,lastvisit,ip,fid,tid,groupid,action,ifhide,uid FROM pw_online WHERE uid!=0");
	} else{
		$query = $db->query("SELECT username,lastvisit,ip,fid,tid,groupid,action,ifhide,uid FROM pw_online");
	}
	while($rt = $db->fetch_array($query)){
		if($rt['uid']){
			$inread = $rt['tid'] ? '(Read)' : '';
			if(strpos($db_showgroup,",".$rt['groupid'].",")!==false){
				$rt['img'] = $rt['groupid'];
			} else{
				$rt['img'] = '6';
			}
			if($rt['ifhide']){
				if($groupid==3){
					$adminonly  = "&#38544;&#36523;:$rt[username]\n";
				}
				$rt['img']		= '6';
				$rt['username'] = '&#38544;&#36523;&#20250;&#21592;';
				$rt['uid']		= 0;
			} else{
				$adminonly = '';
			}
			if($groupid=='3'){
				$adminonly = "{$adminonly}I P : $rt[ip]\n";
			}
			$fname  = $forum[$rt['fid']]['name'];
			$action = $fname ? substrs(strip_tags($fname),13) : $lang[$rt['action']];
			$rt['lastvisit']  = get_date($rt['lastvisit'],'m-d H:i');
			$rt['onlineinfo'] = "$adminonly&#35770;&#22363;: $action{$inread}\n&#26102;&#38388;: $rt[lastvisit]";
			$onlinedb[] = $rt;
		} elseif($db_showguest){
			$inread = $rt['tid'] ? '(Read)' : '';
			$rt['img']='2';
			$rt['username']='guest';

			if($groupid=='3'){
				$ipinfo="I P : {$rt[ip]}\n";
			}
			$fname  = $forum[$rt['fid']]['name'];
			$action = $fname ? substrs(strip_tags($fname),13) : $lang[$rt['action']];
			$rt['lastvisit']  = get_date($rt[lastvisit],'m-d H:i');
			$rt['onlineinfo'] = "$ipinfo&#35770;&#22363;: $action{$inread}\n&#26102;&#38388;: $rt[lastvisit]";
			$gusetdb[] = $rt;
		}
	}
	if($db_showguest){
		$onlinedb = array_merge($onlinedb,$gusetdb);
	}
	$index_whosonline = '<div><table align="center" cellspacing="0" cellpadding="0" width="99%"><tr>';
	$flag = -1;
	foreach($onlinedb as $key=>$val){
		$flag++;
		if($flag%7==0) $index_whosonline.='</tr><tr>';
		$index_whosonline .= "<td style=\"border:0;width:14%\"><img src=\"$imgpath/$stylepath/group/$val[img].gif\" align=\"bottom\"> <a href=\"profile.php?action=show&uid=$val[uid]\" title=\"$val[onlineinfo]\">$val[username]</a></td>";
	}
	$index_whosonline .= '</tr></table></div>';
} else{
	$online = 'no';
}
?>