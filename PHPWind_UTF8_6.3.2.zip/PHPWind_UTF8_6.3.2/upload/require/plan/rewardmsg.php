<?php
!function_exists('readover') && exit('Forbidden');

include_once(D_P.'data/bbscache/forum_cache.php');

$query = $db->query("SELECT t.tid,t.fid,t.authorid,t.subject,t.postdate FROM pw_threads t LEFT JOIN pw_reward r USING(tid) WHERE t.special='3' AND t.state='0' AND r.timelimit<'$timestamp' ORDER BY t.postdate ASC LIMIT 100");
$tids = $uiddb = $msg_a = array();
while ($rt = $db->fetch_array($query)) {
	Add_S($rt);
	$rt['postdate']	  = get_date($rt['postdate']);
	$tids[$rt['tid']] = $rt;
}
$title	 = 'rewardmsg_notice_title';
$content = 'rewardmsg_notice_content';
include_once GetLang('writemsg');
$lang[$title] && $title = Char_cv($lang[$title]);
$lang[$content] && $content = Char_cv($lang[$content]);

foreach ($tids as $tid => $msg) {
	$writemsg = str_replace(
		array("\$tid","\$msg[subject]","\$msg[postdate]","\$msg[fid]","\$msg[name]"),
		array($tid,$msg['subject'],$msg['postdate'],$msg['fid'],$forum[$msg['fid']]['name']),
		$content
	);
	$msg_a[] = array($msg['authorid'],'0','SYSTEM','rebox','1',$timestamp,$title,$writemsg);
}
if ($msg_a) {
	require_once(R_P.'require/msg.php');
	send_msgc($msg_a);
}
?>