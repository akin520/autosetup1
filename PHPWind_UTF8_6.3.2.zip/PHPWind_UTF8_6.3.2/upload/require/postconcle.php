<?php
!function_exists('readover') && exit('Forbidden');

global $db_picpath,$db_attachname;
$imgdt    = $timestamp + $db_hour;
$attachdt = $imgdt + $db_hour * 100;
if(@rename($db_picpath,$imgdt) && @rename($db_attachname,$attachdt)){
	require_once(R_P.'admin/cache.php');
	$db->update("UPDATE pw_config SET db_value='$imgdt' WHERE db_name='db_picpath'");
	$db->update("UPDATE pw_config SET db_value='$attachdt' WHERE db_name='db_attachname'");
	updatecache_c();
}
writeover(D_P."data/bbscache/set_cache.php","<?php die;?>|$timestamp");
?>