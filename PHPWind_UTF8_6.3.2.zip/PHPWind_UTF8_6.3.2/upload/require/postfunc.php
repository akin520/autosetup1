<?php
!function_exists('readover') && exit('Forbidden');

function cvipfrom($ip,$txt=null){
	global $s_ip0;
	$f = $l_d = '';
	$d_ip = explode('.',str_replace('255','*',$ip));
	if ($txt=='0.txt') {
		$s_ip0 = "$d_ip[0].";
	} else {
		$s_ip0 = '';
		$txt = "$d_ip[0].txt";
	}
	$check0 = true;
	if (file_exists(R_P."ipdata/$txt")) {
		$db = fopen(R_P."ipdata/$txt","rb");
		flock($db,LOCK_SH);
		$d = "\n".fread($db,filesize(R_P."ipdata/$txt"));
		$check0 = false;
		$ip = d_ip($d_ip);
		$s_ip = "\n$s_ip0$d_ip[1].";
		if (($s = strpos($d,"$s_ip$d_ip[2].$d_ip[3]"))!==false) {
			fseek($db,$s,SEEK_SET);
			$l_d = substr(fgets($db,100),0,-1); fclose($db);
			$ip_a = explode("\t",$l_d);
			$ip_a[3] && $ip_a[2] .= " $ip_a[3]";
			return $ip_a[2];
		} elseif (($s = strpos($d,"$s_ip$d_ip[2]."))!==false || ($s = strpos($d,$s_ip))!==false || ($s_ip0 && ($s = strpos($d,"\n$s_ip0"))!==false)) {
			list($l_d,$f) = s_ip($db,$s,$ip);
			if ($f) return $f;
		} else {
			if ($s_ip0) {
				$s_ip = "\n$s_ip0";
				$d_ip[1] = $d_ip[0];
			}
			while (strpos($d,$s_ip)===false) {
				$d_ip[1]--;
				if ($d_ip[1]<1) {
					fclose($db);
					return 'Unknown';
				}
				$s_ip = "\n$d_ip[1].";
				if (($s = strpos($d,$s_ip))!==false) {
					list($l_d,$f) = s_ip($db,$s,$ip);
					if ($l_d) break;
					if ($f) return $f;
				}
			}
		}
		while ($l_d && preg_match("/^$s_ip/i","\n".$l_d)!==false) {
			list($l_d,$f) = s_ip($db,$s,$ip,$l_d);
			if ($f) return $f;
		}
		fclose($db);
		unset($d,$s_ip,$l_d);
		($f || $txt=='0.txt') && $check0 = false;
	}
	if ($check0) {
		$f = cvipfrom($ip,'0.txt');
		if (!$f) return 'Unknown';
		return $f;
	} else {
		return 'Unknown';
	}
}
function s_ip($db,$s,$ip,$l_d=null){
	global $s_ip0;
	if (empty($l_d)) {
		fseek($db,$s,SEEK_SET);
		$l_d = fgets($db,100);
	}
	$ip_a = explode("\t",$l_d);
	$ip_a[0] = d_ip(explode('.',$ip_a[0]));
	$ip_a[1] = d_ip(explode('.',$ip_a[1]));
	if (!$s_ip0) $ip = substr($ip,strpos($ip,'.')+1);
	if ($ip<$ip_a[0]) {
		fclose($db);
		$f = 'Unknown'; $l_d = '';
	} elseif ($ip>=$ip_a[0] && $ip<=$ip_a[1]) {
		fclose($db);
		$ip_a[3] && $ip_a[2] .= " $ip_a[3]";
		$f = $ip_a[2]; $l_d = '';
	} else {
		$f = '';
		$l_d = fgets($db,100);
	}
	return array($l_d,$f);
}
function d_ip($d_ip){
	$d_ips = '';
	foreach ($d_ip as $value) {
		$d_ips .= '.'.sprintf("%03d",str_replace('*','255',$value));
	}
	return substr($d_ips,1);
}
function lastinfo($fid,$allowhtm=0,$type='',$sys_type=''){
	global $db,$R_url,$db_htmdir,$foruminfo,$tid,$windid,$timestamp,$atc_title,$t_date,$replytitle;
	if($type == 'new'){
		$rt['tid']      = $tid;
		$rt['postdate'] = $timestamp;
		$rt['lastpost'] = $timestamp;
		$author   = $windid;
		$subject  = substrs($atc_title,26);
		$topicadd = ",tpost=tpost+1,article=article+1,topic=topic+1";
		$fupadd   = "tpost=tpost+1,article=article+1,topic=topic+1";
	} elseif($type == 'reply'){
		$rt['tid']      = $tid;
		$rt['postdate'] = $t_date;
		$rt['lastpost'] = $timestamp;
		$author         = $windid;
		$subject  = $atc_title ? substrs($atc_title,26) : 'Re:'.addslashes(substrs($replytitle,26));
		$topicadd = ",tpost=tpost+1,article=article+1";
		$fupadd   = "tpost=tpost+1,article=article+1";
	} else{
		$rt = $db->get_one("SELECT tid,author,postdate,subject,lastpost,lastposter FROM pw_threads WHERE fid='$fid' ORDER BY lastpost DESC LIMIT 0,1");

		if($rt['postdate'] == $rt['lastpost']){
			$subject = addslashes(substrs($rt['subject'],26));
			$author  = $rt['author'];
		} else{
			$subject = 'Re:'.addslashes(substrs($rt['subject'],26));
			$author  = $rt['lastposter'];
		}
		$topicadd=$fupadd="";
	}
	$GLOBALS['anonymous'] && $author = $GLOBALS['db_anonymousname'];

	$htmurl   = $db_htmdir.'/'.$fid.'/'.date('ym',$rt['postdate']).'/'.$rt['tid'].'.html';
	$new_url  = file_exists(R_P.$htmurl) && $allowhtm && $sys_type!='1B' ? "$R_url/$htmurl" : "read.php?tid=$rt[tid]&page=e#a";
	$lastpost = $subject."\t".addslashes($author)."\t".$rt['lastpost']."\t".$new_url;
	$db->update("UPDATE pw_forumdata SET lastpost='$lastpost' $topicadd WHERE fid='$fid'");

	if($foruminfo['type'] == 'sub'){
		if($foruminfo['password'] != '' || $foruminfo['allowvisit'] != '' || $foruminfo['f_type'] == 'hidden'){
			$lastpost = '';
		} else{
			$lastpost = "lastpost='$lastpost'";
		}
		if($lastpost && $fupadd){
			$lastpost .= ', ';
		}
		if($lastpost || $fupadd){
			$db->update("UPDATE pw_forumdata SET $lastpost $fupadd WHERE fid='$foruminfo[fup]'");
			$rt1 = $db->get_one("SELECT fup,type FROM pw_forums WHERE fid='$foruminfo[fup]'");
			if($rt1['type'] == 'sub'){
				$db->update("UPDATE pw_forumdata SET $lastpost $fupadd WHERE fid='$rt1[fup]'");
			}
		}
	}
}

function bbspostguide(){
	global $db,$creditset,$db_creditset,$db_upgrade,$db_hour,$ifupload,$groupid,$windid,$winduid,$winddb,$timestamp,$top_post,$fatherid,$fid,$tid,$tdtime,$db_autochange,$db_tcheck,$atc_content,$gp_allowupload,$creditname;

	$creditset = get_creditset($creditset,$db_creditset);
	if($db_autochange){
		if(file_exists(D_P."data/bbscache/set_cache.php")){
			list(,$set_control) = explode("|",readover(D_P."data/bbscache/set_cache.php"));
		} else{
			$set_control = 0;
		}
		if(($timestamp - $set_control) > $db_hour * 3600){
			require_once(R_P.'require/postconcle.php');
		}
	}
	if($groupid != 'guest'){
		$winddb['todaypost'] ++;
		$winddb['monthpost'] ++;
		$winddb['lastpost'] = $timestamp;
		$winddb['postnum'] ++;

		if($top_post){
			$addrvrc  = $creditset['rvrc']['Post'];
			$addmoney = $creditset['money']['Post'];
			$winddb['rvrc']  += $creditset['rvrc']['Post'];
			$winddb['money'] += $creditset['money']['Post'];
			customcredit($winduid,$creditset,'Post');
		} else{
			$addrvrc  = $creditset['rvrc']['Reply'];
			$addmoney = $creditset['money']['Reply'];
			$winddb['rvrc']  += $creditset['rvrc']['Reply'];
			$winddb['money'] += $creditset['money']['Reply'];
			customcredit($winduid,$creditset,'Reply');
		}
		if($ifupload && $gp_allowupload==1 && $GLOBALS['uploadmoney']){
			upload_award($GLOBALS['attachs']);
		}
		$usercredit=array(
			'postnum'	=> $winddb['postnum'],
			'digests'	=> $winddb['digests'],
			'rvrc'		=> $winddb['rvrc'],
			'money'		=> $winddb['money'],
			'credit'	=> $winddb['credit'],
			'onlinetime'=> $winddb['onlinetime'],
		);
		$upgradeset = unserialize($db_upgrade);
		foreach($upgradeset as $key=>$val){
			if(is_numeric($key)){
				require_once(R_P.'require/credit.php');
				foreach(GetCredit($winduid) as $key=>$value){
					$usercredit[$key] = $value[1];
				}
				break;
			}
		}
		$memberid = getmemberid(CalculateCredit($usercredit,$upgradeset));
		if($winddb['memberid']!=$memberid){
			$db->update("UPDATE pw_members SET memberid='$memberid' WHERE uid='$winduid'");
		}
		$sqladd = $db_tcheck ? ",postcheck='".tcheck($atc_content)."'" : '';
		$db->update("UPDATE pw_memberdata SET postnum='$winddb[postnum]',rvrc=rvrc+'$addrvrc',money=money+'$addmoney',todaypost='$winddb[todaypost]',monthpost='$winddb[monthpost]',lastpost='$winddb[lastpost]',uploadtime='$winddb[uploadtime]',uploadnum='$winddb[uploadnum]' $sqladd WHERE uid='$winduid'");
	} else{
		Cookie('userlastptime',$timestamp);
	}
}

function getmemberid($nums){
	global $lneed;
	arsort($lneed);
	reset($lneed);
	foreach($lneed as $key=>$lowneed){
		$gid=$key;
		if($nums>=$lowneed){
			break;
		}
	}
	return $gid;
}
function CalculateCredit($creditdb,$upgradeset){
	$credit=0;
	foreach($upgradeset as $key=>$val){
		if($creditdb[$key] && $val){
			if($key == 'rvrc'){
				$creditdb[$key] /= 10;
			} elseif($key == 'onlinetime'){
				$creditdb[$key] /= 3600;
			}
			$credit += $creditdb[$key]*$val;
		}
	}
	return (int)$credit;
}
function check_data($type="new"){
	global $db_titlemax,$db_postmin,$db_postmax,$foruminfo,$db_wordsfb,$atc_usesign,$article,$db_sellset;

	$atc_title   = trim(Char_cv($_POST['atc_title']));
	$atc_content = $_POST['atc_content'];
	if(empty($article) && !$atc_title || strlen($atc_title)>$db_titlemax){
		Showmsg('postfunc_subject_limit');
	}
	if(strlen($atc_content)>=$db_postmax || strlen(trim($atc_content))<$db_postmin){
		Showmsg('postfunc_content_limit');
	}
	$ifwordsfb = $atc_content == addslashes(wordsfb(stripslashes($atc_content))) ? $db_wordsfb : 0;
	$ifconvert = 1;
	unset($_POST['atc_content']);

	if($_POST['atc_convert']=="1"){
		$_POST['atc_autourl'] && $atc_content = autourl($atc_content);
		$atc_content = html_check($atc_content);
		/*
		* Ȩ�޿����Ƿ��ܷ����Զ����ŵĶ�ý��
		*/
		foreach(array('wmv','rm','flash') as $key=>$value){
			if(strpos(",{$GLOBALS[_G][media]},",",$value,") === false){
				$atc_content = preg_replace("/(\[$value=([0-9]{1,3}\,[0-9]{1,3}\,)?)1(\].+?\[\/$value\])/is", "\${1}0\\3",$atc_content);
			}
		}
		/*
		* [post]��[hide��[sell=λ�ò��ܻ�
		*/
		if(!$foruminfo['allowhide'] || !$GLOBALS['gp_allowhidden']){
			$atc_content = str_replace("[post]","[\tpost]",$atc_content);
		} elseif($_POST['atc_hide']=='1'){
			$atc_content = "[post]".str_replace(array('[post]','[/post]'),"",$atc_content)."[/post]";
			$ifconvert = 2;
		}
		if(!$GLOBALS['forumset']['allowencode'] || !$GLOBALS['_G']['allowencode']){
			$atc_content = str_replace("[hide=","[\thide=",$atc_content);
		} elseif($_POST['atc_requirervrc']=='1'){
			$atc_content = preg_replace("/\[hide=(.+?)\]/is","",$atc_content);
			$atc_content = "[hide=".(int)$_POST['atc_rvrc']."]".str_replace("[/hide]","",$atc_content)."[/hide]";
			$ifconvert = 2;
		}
		if(!$foruminfo['allowsell'] || !$GLOBALS['gp_allowsell']){
			$atc_content = str_replace("[sell=","[\tsell=",$atc_content);
		} elseif($_POST['atc_requiresell']=='1'){
			$atc_content = str_replace("[/sell]","",preg_replace("/\[sell=(.+?)\]/is","",$atc_content));
			$atc_content = "[sell=".(int)$_POST['atc_money'].",{$_POST[atc_credittype]}]{$atc_content}[/sell]";
			$ifconvert = 2;
		}
		if($ifconvert==1){
			$atc_content!=convert($atc_content,'') && $ifconvert=2;
		}
	}
	if($atc_usesign<2){
		$atc_content = Char_cv($atc_content);
	} else{
		$atc_content = preg_replace(
			array("/<script.*>.*<\/script>/is","/<(([^\"']|\"[^\"]*\"|'[^']*')*?)>/eis","/javascript/i"),
			array("","jscv('\\1')","java script"),
			str_replace('.','&#46;',$atc_content)
		);
	}
	return array($atc_title,$atc_content,$ifconvert,$ifwordsfb);
}

//�Զ�urlת�亯��
function autourl($message){
	global $db_autoimg;
	if($db_autoimg==1){
		$message=preg_replace(array(
					"/(?<=[^\]a-z0-9-=\"'\\/])((https?|ftp):\/\/|www\.)([a-z0-9\/\-_+=.~!%@?#%&;:$\\��]+\.gif)/i",
					"/(?<=[^\]a-z0-9-=\"'\\/])((https?|ftp):\/\/|www\.)([a-z0-9\/\-_+=.~!%@?#%&;:$\\��]+\.jpg)/i"
				), array(
					"[img]\\1\\3[/img]",
					"[img]\\1\\3[/img]"
				), ' '.$message);
		$message=substr($message,1);
	}
	$message=preg_replace(array(
					"/(?<=[^\]a-z0-9-=\"'\\/])((https?|ftp|gopher|news|telnet|mms|rtsp):\/\/|www\.)([a-z0-9\/\-_+=.~!%@?#%&;:$\\��]+)/i",
					"/(?<=[^\]a-z0-9\/\-_.~?=:.])([_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4}))/i"
				), array(
					"[url]\\1\\3[/url]",
					"[email]\\0[/email]"
				), ' '.$message);
	$message=substr($message,1);
	return $message;
}
function html_check($souce){
	global $db_bbsurl,$db_picpath,$db_attachname;
	if(strpos($souce,$db_bbsurl)!==false){
		$souce=str_replace($db_picpath,'p_w_picpath',$souce);
		$souce=str_replace($db_attachname,'p_w_upload',$souce);
	}
	return $souce;
}
function jscv($code){
	$code = str_replace('\\"','"',$code);
	$code = preg_replace('/[\s]on[\w]+\s*=\s*(\\\"|\\\\\').+?\\1/is',"",$code);
	$code = preg_replace("/[\s]on[\w]+\s*=[^\s]*/is","",$code);
	return '<'.$code.'>';
}
function tcheck($content){
	$content = trim($content);
	$content = strlen($content)>100 ? substr($content,0,100) : $content;
	return substr(md5($content),5,16);
}
function check_tag($tags){
	$tags = array_unique(explode(" ",preg_replace('/\s+/is',' ',trim($tags))));
	count($tags)>5 && Showmsg("tags_num_limit");
	foreach($tags as $key=>$value){
		(strlen($value)>15 || strlen($value)<3) && Showmsg('tag_length_limit');
	}
	$tags = implode(" ",$tags);
	return Char_cv($tags);
}
function insert_tag($tid,$tags){
	global $db;
	$sql  = '';
	$tags = explode(" ",$tags);
	foreach($tags as $key=>$value){
		if(!$value)	continue;
		$rt = $db->get_one("SELECT tagid FROM pw_tags WHERE tagname='$value'");
		if(!$rt){
			$db->update("INSERT INTO pw_tags (tagname,num) VALUES ('$value','1')");
			$tagid = $db->insert_id();
		} else{
			$tagid = $rt['tagid'];
			$db->update("UPDATE pw_tags SET num=num+1 WHERE tagid='$tagid'");
		}
		$sql .= ($sql ? ',' : '')."('$tagid','$tid')";
	}
	$sql && $db->update("INSERT INTO pw_tagdata (tagid,tid) VALUES $sql");
}
function update_tag($tid,$tags){
	global $db;
	$tags	= " $tags ";
	$tagids	= '';
	$query	= $db->query("SELECT * FROM pw_tagdata td LEFT JOIN pw_tags t USING(tagid) WHERE td.tid='$tid'");
	while($rt = $db->fetch_array($query)){
		if(strpos($tags," $rt[tagname] ")===false){
			$tagids .= $tagids ? ','.$rt['tagid'] : $rt['tagid'];
		} else{
			$tags = str_replace(" $rt[tagname] "," ",$tags);
		}
	}
	if($tagids){
		$db->update("DELETE FROM pw_tagdata WHERE tid='$tid' AND tagid IN($tagids)");
		$db->update("UPDATE pw_tags SET num=num-1 WHERE tagid IN($tagids)");
	}
	if($tags = trim($tags)){
		insert_tag($tid,$tags);
	}
}
function relate_tag($subject,$content){
	@include(D_P.'data/bbscache/tagdb.php');
	$i    = 0;
	$tags = '';
	foreach($tagdb as $tag=>$num){
		if(strpos($subject,$tag)!==false || strpos($content,$tag)!==false){
			$tags .= $tags ? ' '.$tag : $tag;
			if(++$i > 9) break;
		}
	}
	return $tags;
}
function alarm($title,$content){
	global $alarm,$admincheck;
	if(empty($alarm) || $admincheck) return 1;
	foreach($alarm as $key=>$value){
		$banword = (string) stripslashes($key);
		if(strpos($title,$banword)!==false || strpos($content,$banword)!==false){
			return 0;
		}
	}
	return 1;
}
function postupload($tmp_name,$filename){
	if(strpos($filename,'..')!==false || strpos($filename,'.php.')!==false || eregi("\.php$",$filename)){
		exit('illegal file type!');
	}
	if(function_exists("move_uploaded_file") && @move_uploaded_file($tmp_name,$filename)){
		@chmod($filename,0777);
		return true;
	} elseif(@copy($tmp_name, $filename)){
		@chmod($filename,0777);
		return true;
	} elseif(is_readable($tmp_name)){
		writeover($filename,readover($tmp_name));
		if(file_exists($filename)){
			@chmod($filename,0777);
			return true;
		}
	}
	return false;
}
function if_uploaded_file($tmp_name){
	if (!$tmp_name || $tmp_name=='none') {
		return false;
	} elseif (function_exists('is_uploaded_file') && !is_uploaded_file($tmp_name) && !is_uploaded_file(str_replace('\\\\', '\\', $tmp_name))) {
		return false;
	} else{
		return true;
	}
}
function UploadFile($uid,$uptype = 'all',$thumbs = null){//fix by noizy
	global $ifupload,$db_attachnum,$db_uploadfiletype,$action,$replacedb,$winddb,$gp_allownum,$tdtime,$timestamp,$fid,$db_attachdir,$attachdir,$db_watermark,$db_waterwidth,$db_waterheight,$db_ifgif,$db_waterimg,$db_waterpos,$db_watertext,$db_waterfont,$db_watercolor,$db_waterpct,$db_jpgquality,$db_ifathumb,$db_iffthumb,$db_athumbsize,$db_fthumbsize,$db_ifftp,$attach_ext,$savedir,$forumset,$ftp,$newpic;
	$uploaddb = array();
	$newpic   = '';
	foreach ($_FILES as $key => $value) {
		if (if_uploaded_file($value['tmp_name'])) {
			list($t,$i) = explode('_',$key);
			$i = (int)$i;
			$atc_attachment = $value['tmp_name'];
			$atc_attachment_name = Char_cv($value['name']);
			$atc_attachment_size = $value['size'];
			$attach_ext = strtolower(substr(strrchr($atc_attachment_name,'.'),1));
			if (empty($attach_ext) || !isset($db_uploadfiletype[$attach_ext])) {
				uploadmsg($uptype,'upload_type_error');
			}
			if ((int)$atc_attachment_size < 1 || ($db_uploadfiletype[$attach_ext] && $atc_attachment_size > $db_uploadfiletype[$attach_ext]*1024)) {
				uploadmsg($uptype,'upload_size_error');
			}
			if ($uptype == 'face') {
				$ifreplace = 0;
				$db_attachdir = 1;
				$db_ifathumb = $db_iffthumb;
				$db_athumbsize = $db_fthumbsize;
				$savedir = $thumbdir = '';
				$tmpname = $uptype."_$uid.$attach_ext";
				$savedir = 'upload/'.str_pad(substr($uid,-2),2,'0',STR_PAD_LEFT);
				if (!$db_ifftp && !is_dir("$attachdir/$savedir")) {
					@mkdir("$attachdir/$savedir");
					@chmod("$attachdir/$savedir",0777);
					@fclose(@fopen("$attachdir/$savedir".'/index.html','w'));
					@chmod("$attachdir/$savedir".'/index.html',0777);
				}
				$fileuplodeurl = $thumbdir = "$savedir/$uid.$attach_ext";
			} elseif ($uptype == 'cnlogo') {
				$ifreplace = $db_ifathumb = 0;
				$db_attachdir = 1;
				$savedir = 'cn_img';
				$tmpname = $uptype."_$uid.$attach_ext";
				$fileuplodeurl = "$savedir/colony_$uid.$attach_ext";
				$thumbdir = '';
			} elseif ($uptype == 'photo') {
				if ($t=='replace') {
					$ifreplace = 1;
					$fileuplodeurl = $replacedb[$i];
					$tmpurl = strrchr($fileuplodeurl,'/');
					$fileuplodename = $tmpurl ? substr($tmpurl,1) : $fileuplodeurl;
					$tmpname = $uptype."_$fileuplodename";
				} else {
					$ifreplace = 0;
					$tmpname = $uptype."_$uid.$attach_ext";
					$fileuplodeurl = $fileuplodename = "$uid.$attach_ext";
					$db_ifathumb = 1;
					if ($db_attachdir) {
						$savedir = 'photo/';
						if ($db_attachdir == 2) {
							$savedir .= 'Day_'.date('ymd');
						} elseif ($db_attachdir == 3) {
							$savedir .= "Cyid_$GLOBALS[cyid]";
						} else {
							$savedir .= 'Mon_'.date('ym');
						}
						if (!$db_ifftp && !is_dir("$attachdir/$savedir")) {
							@mkdir("$attachdir/$savedir");
							@chmod("$attachdir/$savedir",0777);
							@fclose(@fopen("$attachdir/$savedir".'/index.html','w'));
							@chmod("$attachdir/$savedir".'/index.html',0777);
						}
						$fileuplodeurl = $savedir.'/'.$fileuplodeurl;
					}
				}
				$thumbdir = str_replace($fileuplodename,'s_'.$fileuplodename,$fileuplodeurl);
			} else {
				if ($action=='modify' && $t=='replace' && isset($replacedb[$i])) {
					$ifreplace = 1;
					$fileuplodeurl = $replacedb[$i]['attachurl'];
					$tmpurl = strrchr($fileuplodeurl,'/');
					$tmpname = $uptype.'_'.($tmpurl ? substr($tmpurl,1) : $fileuplodeurl);
				} else {
					$ifreplace = 0;
					$attach_ext = preg_replace('/(php|asp|jsp|cgi|fcgi|exe|pl|phtml|dll|asa|com|scr|inf)/i',"scp_\\1",$attach_ext);
					if ($winddb['uploadtime']<$tdtime) {
						$winddb['uploadtime'] = $tdtime;
						$winddb['uploadnum'] = 1;
					} else {
						$winddb['uploadnum']>=$gp_allownum && uploadmsg($uptype,'upload_num_error');
						$winddb['uploadtime']=$timestamp;
						$winddb['uploadnum']++;
					}
					$prename = substr(md5($timestamp.$i.randstr(8)),10,15);
					$tmpname = $uptype."_$prename.$attach_ext";
					$fileuplodeurl = $fid."_{$uid}_$prename.$attach_ext";
					if ($db_attachdir) {
						if ($db_attachdir == 2) {
							$savedir = "Type_$attach_ext";
						} elseif ($db_attachdir == 3) {
							$savedir = 'Mon_'.date('ym');
						} elseif ($db_attachdir == 4) {
							$savedir = 'Day_'.date('ymd');
						} else {
							$savedir = "Fid_$fid";
						}
						if (!$db_ifftp) {
							if (!is_dir("$attachdir/$savedir")) {
								@mkdir("$attachdir/$savedir");
								@chmod("$attachdir/$savedir",0777);
								@fclose(@fopen("$attachdir/$savedir".'/index.html','w'));
								@chmod("$attachdir/$savedir".'/index.html',0777);
							}
							if ($db_ifathumb && !is_dir("$attachdir/thumb/$savedir")) {
								@mkdir("$attachdir/thumb/$savedir");
								@chmod("$attachdir/thumb/$savedir",0777);
								@fclose(@fopen("$attachdir/thumb/$savedir".'/index.html','w'));
								@chmod("$attachdir/thumb/$savedir".'/index.html',0777);
							}
						}
						$fileuplodeurl = $savedir.'/'.$fileuplodeurl;
					}
				}
				$thumbdir = "thumb/$fileuplodeurl";
			}
			$havefile = $ifthumb = 0;
			if ($db_ifftp || file_exists("$attachdir/$fileuplodeurl")) {
				$havefile = 1;
				$source = D_P."data/tmp/$tmpname";
			} else {
				$source = "$attachdir/$fileuplodeurl";
			}
			if (!postupload($atc_attachment,$source)) {
				uploadmsg($uptype,'upload_error');
			}
			$ifupload = 3; $type = 'zip';
			$img_size[0] = $img_size[1] = 0;
			$size = ceil(filesize($source)/1024);
			if (in_array($attach_ext,array('gif','jpg','jpeg','png','bmp','swf'))) {
				require_once(R_P.'require/imgfunc.php');
				if (!$img_size = GetImgSize($source,$attach_ext)) {
					P_unlink($source);
					uploadmsg($uptype,'upload_content_error');
				}
				$ifupload = 1;
				$img_size[0] = $img_size['width'];
				$img_size[1] = $img_size['height'];
				unset($img_size['width'],$img_size['height']);
				if ($uptype == 'all' && $db_watermark && $forumset['watermark'] && $img_size[2]<'4' && $img_size[0]>$db_waterwidth && $img_size[1]>$db_waterheight && function_exists('imagecreatefromgif') && function_exists('imagealphablending') && ($attach_ext!='gif' || function_exists('imagegif') && ($db_ifgif==2 || $db_ifgif==1 && (PHP_VERSION > '4.4.2' && PHP_VERSION < '5' || PHP_VERSION > '5.1.4'))) && ($db_waterimg && function_exists('imagecopymerge') || !$db_waterimg && function_exists('imagettfbbox'))) {
					ImgWaterMark($source,$db_waterpos,$db_waterimg,$db_watertext,$db_waterfont,$db_watercolor,$db_waterpct,$db_jpgquality);
				}
				$type = 'img';
				if ($attach_ext == 'swf') {
					$type = 'zip';
				} elseif ($db_ifathumb) {
					$thumburl = $havefile ? D_P."data/tmp/thumb_$tmpname" : "$attachdir/$thumbdir";
					list($db_thumbw,$db_thumbh) = explode("\t",$db_athumbsize);
					list($cenTer,$sameFile) = explode("\t",$thumbs);
					if ($thumbsize = MakeThumb($source,$thumburl,$db_thumbw,$db_thumbh,$cenTer,$sameFile)) {
						$img_size[0] = $thumbsize[0];
						$img_size[1] = $thumbsize[1];
						$source!=$thumburl && $ifthumb = 1;
					}
				}
				if(!$newpic && $img_size[0] > 50 && $img_size[1] > 50){
					$newpic=geturl($fileuplodeurl,'show');
					$newpic=$newpic[0] == 'imgurl' ? '' : $newpic[0];
				}
			} elseif ($attach_ext == 'txt') {
				if (preg_match('/(onload|submit|post|form)/i',readover($source))) {
					P_unlink($source);
					uploadmsg($uptype,'upload_content_error');
				}
				$ifupload = 2;
				$type = 'txt';
			}
			if ($db_ifftp && $ftpsize=$ftp->upload($source,$fileuplodeurl)) {
				P_unlink($source);
				P_unlink("$attachdir/$fileuplodeurl");
				if ($ifthumb == 1) {
					$ftp->mkd("thumb/$savedir");
					$ftp->upload($thumburl,$thumbdir) && P_unlink($thumburl);
				}
			} elseif ($havefile) {
				P_unlink("$attachdir/$fileuplodeurl");
				@rename($source,"$attachdir/$fileuplodeurl");
				if ($ifthumb == 1) {
					P_unlink("$attachdir/$thumbdir");
					@rename($thumburl,"$attachdir/$thumbdir");
				}
			}
			$uploaddb[] = array('id' => $i,'ifreplace' => $ifreplace,'name' => $atc_attachment_name,'size' => $size,'type' => $type,'attachurl' => $fileuplodeurl,'ifthumb' => $ifthumb,'img_w' => $img_size[0],'img_h' => $img_size[1]);
		}
	}
	return $uploaddb;
}
function uploadmsg($uptype,$msg){
	if ($uptype=='face' && defined('AJAX') && AJAX) {
		@extract($GLOBALS, EXTR_SKIP);
		global $stylepath,$tablewidth,$mtablewidth,$tplpath,$runfc;
		require_once GetLang('msg');
		$lang[$msg] && $msg=$lang[$msg];
		echo "<script language=\"JavaScript1.2\">parent.facepath('','','$msg','','');</script>";exit;
	} else {
		Showmsg($msg);
	}
}
/**
 * upload flies when the board have award
 *
 * @param array() $attachs
 */
function upload_award($attachs){
	global $db,$creditname,$uploadcredit,$uploadmoney,$winduid,$ftp,$db_ifftp,$ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir;
	require_once(R_P.'require/credit.php');
	$credit = UserCredit($winduid,$uploadcredit);
	if($uploadmoney < 0 && $credit < abs($uploadmoney)){
		require_once(R_P.'require/updateforum.php');
		if($db_ifftp && !$ftp){
			require_once(R_P.'require/ftp.php');
			$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
		}
		delete_att(array($attachs));
		if ($ftp) {
			$ftp->close(); unset($ftp);
		}
		$creditname = CreditName($uploadcredit);
		Showmsg('upload_money_limit');
	}
	if(!UserCredit($winduid,$uploadcredit,'set',$uploadmoney)){
		require_once(R_P.'require/updateforum.php');
		if($db_ifftp && !$ftp){
			require_once(R_P.'require/ftp.php');
			$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
		}
		delete_att(array($attachs));
		if ($ftp) {
			$ftp->close(); unset($ftp);
		}
		Showmsg('undefined_action');
	}
}
?>