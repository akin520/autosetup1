<?php
!function_exists('readover') && exit('Forbidden');
require_once(R_P.'require/updateforum.php');

$t_typedb = array();
$t_per    = $t_exits = 0;
$t_db     = $foruminfo['t_type'];

if ($t_db) {
	$t_typedb = explode("\t",$t_db);
	$t_typedb = array_unique ($t_typedb);
	$t_per	  = $t_typedb[0];
	unset($t_typedb[0]);
	foreach ($t_typedb as $value) {
		$value && $t_exits = 1;
	}
}
$db_forcetype = $t_exits && $t_per=='2' && $article==0 && !$admincheck ? 1 : 0; // �Ƿ���Ҫǿ���������

if ($article==0) {
	$pw_tmsgs = GetTtable($tid);
	$tpcdb = $db->get_one("SELECT t.tid,t.fid AS tfid,t.author,t.authorid,t.icon,t.locked,t.postdate,t.lastpost, t.subject,t.type,t.ifcheck,t.special,state,t.anonymous,t.ifmail,t.ptable,t.ifhide,tm.content,tm.aid,tm.ifsign,tm.tags,tm.magic FROM pw_threads t LEFT JOIN $pw_tmsgs tm USING(tid) WHERE t.tid='$tid'");
	!$tpcdb['tid'] && Showmsg('illegal_tid');
	@extract($tpcdb);
	$pw_posts = GetPtable($ptable);
	$ifmailck = $ifmail>1 ? 'checked' : '';
	list($magicid,$magicname) = explode("\t",$magic);
} else {
	!is_numeric($pid) && Showmsg('illegal_tid');
	$pw_posts = GetPtable('N',$tid);
	$atcdb = $db->get_one("SELECT aid,ifsign,tid,fid AS tfid,author,authorid,icon,postdate,subject,content,anonymous,ifhide FROM $pw_posts WHERE pid='$pid'");
	!$atcdb['tid'] && Showmsg('illegal_tid');
	@extract($atcdb);
	$ifcheck = 1;
	$special = 0;
}
$tfid != $fid && Showmsg('illegal_tid');
$page = floor($article/$db_readperpage)+1;

if (!$admincheck && (!$SYSTEM['deltpcs'] || $groupid == 5)) {
	if ($groupid == 'guest' || $authorid != $winduid) {
		Showmsg('modify_noper');
	} elseif ($locked%3 > 0) {
		Showmsg('modify_locked');
	}
}
if ($winduid != $authorid && $groupid != 3 && $groupid != 4) {
	$authordb = $db->get_one("SELECT groupid FROM pw_members WHERE uid='$authorid'");
	if (($authordb['groupid'] == 3 || $authordb['groupid'] == 4)) {
		Showmsg('modify_admin');
	}
}
if ($gp_edittime && ($timestamp - $postdate) > $gp_edittime * 60) {
	Showmsg('modify_timelimit');
}
$hideemail = 'disabled';
$icon = (int)$icon;
if (!$_POST['step']) {

	$attach = array();
	if ($aid) {
		$attachs = unserialize(stripslashes($aid));
		if (is_array($attachs)) {
			$attach = $attachs;
			foreach ($attach as $key=>$val) {
				list($attach[$key]['attachurl'],) = geturl($val['attachurl'],'lf');
				strlen($val['name'])>25 && $attach[$key]['name'] = substrs($val['name'],30);
			}
		}
	}
	if ($article == 0) {
		if ($foruminfo['cms']) {
			include_once(R_P.'require/c_search.php');
			list($tids,$kname) = search_tid($tid);
		}
		$ptype	 = $t_typedb[$type];
		$ptypeid = $type;

		switch ($special) {
			case 1:
				@extract($db->get_one("SELECT voteopts,modifiable,previewable,timelimit FROM pw_polls WHERE tid='$tid'"));
				$votearray = unserialize($voteopts);
				$votearray['multiple'][0] && $multi = 'checked';
				$modifiable && $ifmodify = 'checked';
				$previewable && $ifpreview = 'checked';
				$vote_close = ($state || ($timelimit && $timestamp-$postdate>$timelimit*86400)) ? 1 : 0;
				$voteable = ($_G['modifyvote'] && $vote_close==0) ? "" : "disabled";
				$mostnum = $votearray['multiple'][1];
				break;
			case 2:
				$act = $db->get_one("SELECT * FROM pw_activity WHERE tid='$tid'");
				$act['starttime'] = get_date($act['starttime']);
				$act['endtime']   = get_date($act['endtime']);
				$act['deadline']  = get_date($act['deadline']);
				${'sel_'.$act['sexneed']} = 'checked';
			case 3:
				@extract($db->get_one("SELECT cbtype,catype FROM pw_reward WHERE tid='$tid'"));
				$cbselect = "<option value=\"$cbtype\">".(is_numeric($cbtype) ? $_CREDITDB[$cbtype][0] : ${'db_'.$cbtype.'name'}).'</option>';
				$caselect = "<option value=\"$catype\">".(is_numeric($catype) ? $_CREDITDB[$catype][0] : ${'db_'.$catype.'name'}).'</option>';
				list(,$rw_b_val,$rw_a_val) = explode("\t",$forumset['rewarddb']);
				break;
			default:
				$special = 0;
		}
		list($tags) = explode("\t",$tags);
	}
	empty($subject) && $subject=' ';

	$htmcheck    = $ifsign < 2 ? '' : 'checked';
	!$ifanonymous && $anonymous && $ifanonymous = 'checked';
	!$htmlatt && $ifhide && $htmlatt = 'checked';
	$atc_title   = $subject;
	$atc_content = str_replace(array('<','>'),array('&lt;','&gt;'),$content);

	if (strpos($atc_content,$db_bbsurl) !== false) {
		$atc_content = str_replace('p_w_picpath',$db_picpath,$atc_content);
		$atc_content = str_replace('p_w_upload',$db_attachname,$atc_content);
	}

	list($guidename,$forumtitle) = getforumtitle(forumindex($foruminfo['fup']));
	if (trim($subject)) {
		$guidename .= " &raquo; <a href=\"read.php?tid=$tid\">$subject</a>";
	}
	$db_metakeyword = str_replace(array('|',' - '),',',$forumtitle).'phpwind';
	$db_metadescrip = substrs(strip_tags(str_replace('"','&quot;',$atc_content)),50);

	require_once(R_P.'require/header.php');
	list($msg_guide,$forumlist) = headguide($guidename);
	require_once PrintEot('post');footer();

} elseif ($_POST['step'] == 1) {
	if ($winduid != $authorid && $groupid != 3 && $groupid != 4) {
		Showmsg('modify_del_right');
	}

	if (!$admincheck && $gp_allowdelatc == 0) {
		Showmsg('modify_group_right');
	}
	$rt = $db->get_one("SELECT COUNT(*) AS count FROM $pw_posts WHERE tid='$tid' AND ifcheck='1'");
	$count = $rt['count'] + 1;
	if ($article == 0 && !$admincheck && $count > 1) {
		Showmsg('modify_replied');
	}
	$rs = $db->get_one("SELECT replies,topped FROM pw_threads WHERE tid='$tid'");
	if ($rs['replies'] != $rt['count']) {
		$db->update("UPDATE pw_threads SET replies='$rt[count]' WHERE tid='$tid'");
	}
	$creditset = get_creditset($creditset,$db_creditset);
	if($aid){
		$ftp = null;
		if ($db_ifftp) {
			require_once(R_P.'require/ftp.php');
			$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
		}
		delete_att(array($aid));
		if ($ftp) {
			$ftp->close(); unset($ftp);
		}
	}
	if ($article == 0) {
		$deltype  = 'deltpc';
		$deltitle = substrs($subject,28);
		if ($count == 1) {
			$db->update("DELETE FROM $pw_tmsgs WHERE tid='$tid'");
			$db->update("DELETE FROM pw_threads WHERE tid='$tid'");
			P_unlink(R_P."$db_htmdir/$fid/".date('ym',$postdate)."/$tid.html");
		} else {
			$rt = $db->get_one("SELECT * FROM $pw_posts WHERE tid='$tid' ORDER BY postdate LIMIT 1");
			Add_S($rt);
			@extract($rt);
			if ($count == 2) {
				$lastpost	= $postdate;
				$lastposter	= $author;
			} else {
				$lt = $db->get_one("SELECT postdate,author FROM $pw_posts WHERE tid='$tid' ORDER BY postdate DESC LIMIT 1");
				$lastpost	= $lt['postdate'];
				$lastposter	= $lt['author'];
			}
			$count -= 2;
			$db->update("DELETE FROM $pw_posts WHERE pid='$pid'");
			$subject && $subject="subject='$subject',";
			$db->update("UPDATE pw_threads SET icon='$icon',$subject author='$author',authorid='$authorid',postdate='$postdate',lastpost='$lastpost',lastposter='$lastposter',replies='$count' WHERE tid='$tid'");
			$db->update("UPDATE $pw_tmsgs SET aid='$aid',userip='$userip',ifsign='$ifsign',ipfrom='$ipfrom' ,alterinfo='$alterinfo',ifconvert='$ifconvert',content='$content' WHERE tid='$tid'");
		}
		$msg_delrvrc  = $creditset['rvrc']['Delete'];
		$msg_delmoney = $creditset['money']['Delete'];
		dtchange($authorid,-$creditset['rvrc']['Delete'],-1,-$creditset['money']['Delete']);
		customcredit($authorid,$creditset,'Delete');
	} else {
		$deltype  = 'delrp';
		$deltitle = $subject ? substrs($subject,28) : substrs($content,28);
		$db->update("DELETE FROM $pw_posts WHERE pid='$pid'");
		$db->update("UPDATE pw_threads SET replies=replies-1 WHERE tid='$tid'");
		$msg_delrvrc  = $creditset['rvrc']['Deleterp'];
		$msg_delmoney = $creditset['money']['Deleterp'];
		dtchange($authorid,-$creditset['rvrc']['Deleterp'],-1,-$creditset['money']['Deleterp']);
		customcredit($authorid,$creditset,'Deleterp');
	}
	if ($db_guestread) {
		require_once(R_P.'require/guestfunc.php');
		clearguestcache($tid,$rs['replies']);
	}
	P_unlink(D_P.'data/bbscache/c_cache.php');
	updateforum($fid);
	if ($rs['topped']) {
		updatetop();
	}
	$msg_delrvrc = floor($msg_delrvrc/10);
	require_once(R_P.'require/writelog.php');
	$log = array(
		'type'      => 'delete',
		'username1' => $author,
		'username2' => $windid,
		'field1'    => $fid,
		'field2'    => '',
		'field3'    => '',
		'descrip'   => $deltype.'_descrip',
		'timestamp' => $timestamp,
		'ip'        => $onlineip,
		'tid'		=> $tid,
		'forum'		=> $foruminfo['name'],
		'subject'	=> $deltitle,
		'affect'	=> "{$db_rvrcname}��-{$msg_delrvrc}��{$db_moneyname}��-{$msg_delmoney}",
		'reason'	=> 'edit delete article!'
	);
	writelog($log);
	if ($foruminfo['allowhtm'] && $article<=$db_readperpage ) {
		include_once(R_P.'require/template.php');
	}
	if($tid && $db_ifsort&30){
		require_once(R_P.'require/sort.php');
		sort_delete($tid);
	}
	if ($deltype == 'delrp') {
		refreshto("read.php?tid=$tid",'enter_thread');
	} else {
		refreshto("thread.php?fid=$fid",'enter_thread');
	}
} elseif ($_POST['step'] == 2) {
	InitGP(array('atc_anonymous','atc_iconid','atc_newrp','keep','downrvrc','attdesc','atc_tags','atc_hideatt','magicid','magicname'),'P');
	$atc_tags = ($db_iftag && $atc_tags) ? check_tag($atc_tags) : '';
	list($atc_title,$atc_content,$ifconvert,$ifwordsfb) = check_data($action);
	$sqladd = '';
	switch ($special) {
		case 1:
			@extract($db->get_one("SELECT voteopts FROM pw_polls WHERE tid='$tid'"));
			$votearray = unserialize($voteopts);
			InitGP(array('vt_selarray','timelimit','multiplevote','modifiable','mostvotes', 'previewable','vote_close'), 'P');
			if ($_G['modifyvote'] && is_array($votearray) && is_array($vt_selarray)) {
				foreach ($vt_selarray as $key => $value) {
					$value = trim(Char_cv($value));
					if ($value) {
						$newvotearray['options'][$key] = array($value,$votearray['options'][$key][1],$votearray['options'][$key][2]);
					}
				}
				if ($mostvotes && is_numeric($mostvotes)) {
					$mostvotes > count($vt_selarray) ? $mostvotes = count($vt_selarray) : '';
				} else {
					$mostvotes = count($vt_selarray);
				}
				$newvotearray['multiple'] = array($multiplevote,$mostvotes);
				$voteopts = addslashes(serialize($newvotearray));
				!$modifiable && $modifiable = 0;
				!$previewable && $previewable = 0;
				$timelimit < 0 && $timelimit = 0;
				$db->update("UPDATE pw_polls SET voteopts='$voteopts',modifiable='$modifiable',previewable='$previewable',timelimit='$timelimit' WHERE tid='$tid'");
			}
			$vote_close && $sqladd .= ",state='1'";
			break;
		case 2:
			InitGP(array('act_subject','act_location'),'P',1);
			InitGP(array('act_starttime','act_deadline','act_endtime','act_num','act_costs','act_sex'),'P');
			!($act_subject && $act_starttime && $act_deadline) && Showmsg('active_data_empty');
			$act_starttime= PwStrtoTime($act_starttime);
			$act_endtime  = PwStrtoTime($act_endtime);
			$act_deadline = PwStrtoTime($act_deadline);
			$act_deadline < $timestamp && Showmsg('deadline_limit');
			$act_deadline > $act_starttime && Showmsg('starttime_limit');
			$act_endtime && $act_starttime>$act_endtime && Showmsg('endtime_limit');
			(!is_numeric($act_num) || $act_num<0) && $act_num=0;
			(!is_numeric($act_costs) || $act_costs<0) && $act_costs=0;
			$db->update("UPDATE pw_activity SET subject='$act_subject',starttime='$act_starttime',endtime='$act_endtime',location='$act_location',num='$act_num',sexneed='$act_sex',costs='$act_costs',deadline='$act_deadline' WHERE tid='$tid'");
			break;
		case 3:
			if (empty($_POST['addreward'])) break;
			InitGP(array('bonus','ctype'),'P');
			$rewdb = $db->get_one("SELECT cbtype,catype,timelimit FROM pw_reward WHERE tid='$tid'");
			if ($ctype['best'] <> $rewdb['cbtype'] || $ctype['active'] <> $rewdb['catype']) {
				Showmsg('reward_credit_error');
			}
			list($rw_valid,$rw_b_val,$rw_a_val) = explode("\t",$forumset['rewarddb']);
			$bonus['best']   = (int) $bonus['best'];
			$bonus['active'] = (int) $bonus['active'];
			$bonus['best']   < $rw_b_val && Showmsg('credit_limit');
			$bonus['active'] < $rw_a_val && Showmsg('credit_limit');
			$timelimit = ($rewdb['timelimit']>$timestamp ? $rewdb['timelimit'] : $timestamp) + $rw_valid*86400;
			require_once(R_P.'require/credit.php');

			if ($rewdb['cbtype'] == $rewdb['catype']) {
				$total = $bonus['best'] * 2 + $bonus['active'];
				UserCredit($winduid,$rewdb['cbtype']) < $total && Showmsg('reward_credit_limit');
				UserCredit($winduid,$rewdb['cbtype'],'set',-$total);
			} else {
				if (UserCredit($winduid,$rewdb['cbtype']) < $bonus['best']*2) {
					Showmsg('reward_credit_limit');
				}
				UserCredit($winduid,$rewdb['catype']) < $bonus['active'] && Showmsg('reward_credit_limit');
				UserCredit($winduid,$rewdb['cbtype'],'set',-$bonus['best']*2);
				UserCredit($winduid,$rewdb['catype'],'set',-$bonus['active']);
			}
			$db->update("UPDATE pw_reward SET cbval=cbval+'$bonus[best]',caval=caval+'$bonus[active]',timelimit='$timelimit' WHERE tid='$tid'");
			break;
	}
	/**
	* �����޸�
	*/
	$oldattach = $replacedb = array();
	$ftp = null;
	if ($aid) {
		if ($db_ifftp) {
			require_once(R_P.'require/ftp.php');
			$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
		}
		$oldattach = unserialize(stripslashes($aid));
		$unsetattach = $updateattach = array();
		foreach ($oldattach as $key=>$value) {
			if (!@in_array($key,$keep)) {
				$unsetattach[$key] = $value;
				unset($oldattach[$key]);
			} else {
				if (!is_array($downrvrc) || !is_array($attdesc)) {
					Showmsg('undefined_action');
				}
				$attdesc[$key]				 = Char_cv($attdesc[$key]);
				$oldattach[$key]['desc']     = str_replace('\\','',$attdesc[$key]);
				$oldattach[$key]['needrvrc'] = (int)$downrvrc[$key];
				if (array_key_exists('replace_'.$key,$_FILES)) {
					$db_attachnum++;
					$replacedb[$key]=$oldattach[$key];
				} else {
					$updateattach[] = "UPDATE pw_attachs SET needrvrc='{$downrvrc[$key]}',descrip='{$attdesc[$key]}' WHERE aid='$key'";
				}
			}
		}
	}
	require_once(R_P.'require/postupload.php');
	if ($attachs) {
		if ($db_ifftp && !$ftp) {
			require_once(R_P.'require/ftp.php');
			$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
		}
		if($gp_allowupload==1 && $uploadmoney && empty($oldattach)){
			upload_award($attachs);
		}
		$attachs = unserialize(stripslashes($attachs));
		foreach ($attachs as $key=>$value) {
			$oldattach[$key] = $value;
		}
		$db->update("UPDATE pw_memberdata SET uploadtime='$winddb[uploadtime]',uploadnum='$winddb[uploadnum]' WHERE uid='$winduid'");
	}
	if ($oldattach) {
		$oldattach = addslashes(serialize($oldattach));
	} else {
		$oldattach = '';
	}
	$atc_iconid = is_numeric($atc_iconid) ? $atc_iconid : $icon;
	$timeofedit = get_date($timestamp);
	$anonymous  = ($forumset['anonymous'] && $_G['anonymous'] && $atc_anonymous) ? 1 : 0;
	$ifhide		= ($foruminfo['allowhide'] && $gp_allowhidden && $atc_hideatt) ? 1 : 0;

	if ($groupid != 3 && $postdate + 300 < $timestamp) {
		$altername = $anonymous && $windid==$author ? $db_anonymousname : $windid;
		require_once GetLang('post');
		$alterinfo = $lang['edit_post'];
	} else {
		$alterinfo = '';
	}
	if ($winduid != $authorid) {
		/**
		* ����Ա�༭���ӵİ�ȫ�ռ�
		*/
		require_once(R_P.'require/writelog.php');
		$log = array(
			'type'      => 'edit',
			'username1' => $author,
			'username2' => $windid,
			'field1'    => $fid,
			'field2'    => '',
			'field3'    => '',
			'descrip'   => 'edit_descrip',
			'timestamp' => $timestamp,
			'ip'        => $onlineip,
			'tid'		=> $tid,
			'forum'		=> $foruminfo['name'],
			'subject'	=> substrs($subject,28),
			'reason'	=> 'edit article'
		);
		writelog($log);
	}

	$atc_content = trim($atc_content);
	if ($authorid == $winduid) {
		$ipdata = "userip='$onlineip',ipfrom='$ipfrom',";
	} else {
		$ipdata = '';
	}
	if ($article == 0) {
		if ($db_iftag) {
			if ($atc_tags != $tags) {
				update_tag($tid,$atc_tags);
			}
			$atc_tags .= "\t".relate_tag($atc_title,$atc_content);
		}
		$ifmagic   = 0;
		$magic     = '';
		if ($db_windmagic && $magicid) {
			$magicid	= Char_cv($magicid);
			$magicname	= Char_cv($magicname);
			$ifmagic	= 1;
			$magic		= $magicid."\t".$magicname;
		}
		$db->update("UPDATE $pw_tmsgs SET aid='$oldattach',$ipdata ifsign='$atc_usesign',alterinfo='$alterinfo',tags='$atc_tags',ifconvert='$ifconvert',ifwordsfb='$ifwordsfb',content='$atc_content',magic='$magic' WHERE tid='$tid'");
		if ($aids) {
			$db->update("UPDATE pw_attachs SET tid='$tid' WHERE aid IN($aids)");
		}
		if ($anonymous != $tpcdb['anonymous'] && $postdate==$lastpost) {
			$lastposter = $anonymous ? $db_anonymousname : $author;
			$sqladd .= ",lastposter='$lastposter'";
		}
	} else {
		$db->update("UPDATE $pw_posts SET aid='$oldattach',$ipdata icon='$atc_iconid',subject='$atc_title',ifsign='$atc_usesign',alterinfo='$alterinfo',ifconvert='$ifconvert',ifwordsfb='$ifwordsfb',content='$atc_content',anonymous='$anonymous',ifhide='$ifhide' WHERE pid='$pid'");
		if ($aids) {
			$db->update("UPDATE pw_attachs SET tid='$tid',pid='$pid' WHERE aid IN($aids)");
		}
		if ($anonymous != $atcdb['anonymous']) {
			$lt = $db->get_one("SELECT pid FROM $pw_posts WHERE tid='$tid' ORDER BY postdate DESC LIMIT 1");
			if ($pid==$lt['pid']) {
				$lastposter = $anonymous ? $db_anonymousname : $author;
				$sqladd .= ",lastposter='$lastposter'";
			}
		}
	}

	$ifupload = getattachtype($tid);
	if ($article == 0) {
		##�������
		//ǿ�Ʒ���
		if (!$p_type || empty($t_typedb[$p_type]) || ($t_per == 0 && !$admincheck)) {
			$w_type=0;
		} else {
			$w_type=$p_type;
		}
		$db_forcetype && $w_type=='0' && Showmsg('force_tid_select');
		$ifmail = $db_replysitemail && $atc_newrp ? 2 : 0;
		$db->update("UPDATE pw_threads SET icon='$atc_iconid',subject='$atc_title',type='$w_type',ifupload='$ifupload',ifmail='$ifmail',anonymous='$anonymous',ifmagic='$ifmagic',ifhide='$ifhide' $sqladd WHERE tid='$tid'");
	} else {
		$db->update("UPDATE pw_threads SET ifupload='$ifupload' $sqladd WHERE tid='$tid'");
	}
	if(count($unsetattach)){
		if ($db_ifftp) {
			require_once(R_P.'require/ftp.php');
			$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
		}
		delete_att(array(serialize($unsetattach)));
		if ($ftp) {
			$ftp->close(); unset($ftp);
		}
	}
	if(count($updateattach)){
		foreach ($updateattach as $value){
			if(!$value) continue;
			$db->update($value);
		}
	}
	if ($foruminfo['allowhtm'] && !$foruminfo['cms'] && $article < $db_readperpage) {
		include_once (R_P.'require/template.php');
	}
	$rt = $db->get_one("SELECT lastpost FROM pw_forumdata WHERE fid='$fid'");
	$lastpost = explode("\t",$rt['lastpost']);
	if ($lastpost[2] == $postdate) {
		lastinfo($fid,$foruminfo['allowhtm'],'',$foruminfo['cms'].'B');
	}
	refreshto("read.php?tid=$tid&page=$page&toread=1",'enter_thread');
}
?>