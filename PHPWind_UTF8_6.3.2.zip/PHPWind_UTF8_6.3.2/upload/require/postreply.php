<?php
!function_exists('readover') && exit('Forbidden');
/**
* ���Ȩ���ж�
*/
if ($foruminfo['allowrp'] && !$admincheck && !allowcheck($foruminfo['allowrp'],$groupid,$winddb['groups'],$fid,$winddb['reply'])) {
	Showmsg('reply_forum_right');
}
/**
* �û���Ȩ���ж�
*/
if (!$foruminfo['allowrp'] && !$admincheck && $gp_allowrp==0) {
	Showmsg('reply_group_right');
}
if ($article=='0') {
	$pw_tmsgs = GetTtable($tid);
	$S_sql = ',m.groupid,tm.ifsign,tm.content';
	$J_sql = "LEFT JOIN pw_members m ON m.uid=t.authorid LEFT JOIN $pw_tmsgs tm ON tm.tid=t.tid";
} else {
	$S_sql = $J_sql = '';
}
$tpcarray = $db->get_one("SELECT t.fid,t.locked,t.ifcheck,t.author,t.authorid,t.postdate,t.lastpost,t.ifmail,t.special,t.subject,t.type,t.ifshield,t.anonymous,t.ptable $S_sql FROM pw_threads t $J_sql WHERE t.tid='$tid'");
$pw_posts = GetPtable($tpcarray['ptable']);

$t_date = $tpcarray['postdate'];//���ⷢ��ʱ�� bbspostguide ���õ�
if ($tpcarray['fid']!=$fid) {
	Showmsg('illegal_tid');
}
$replytitle=$tpcarray['subject'];
/**
* convert()��Ҫ$tpc_author����
*/
$tpc_author=$tpcarray['author'];

if ($forumset['lock']&& !$admincheck && $timestamp - $tpcarray['postdate'] > $forumset['lock'] * 86400) {
	Showmsg('forum_locked');
}
if (!$admincheck  && !$tpcarray['ifcheck']) {
	Showmsg('reply_ifcheck');
}
if (!$admincheck && !$SYSTEM['replylock'] && $tpcarray['locked']%3<>0) {
	Showmsg('reply_lockatc');
}
$special = 0;
$icon = (int)$icon;
if (!$_POST['step']) {
	##�������
	$db_forcetype = 0;
	require_once(R_P.'require/bbscode.php');
	$hideemail = "disabled";
	if ($action=="quote") {
		if ($article=='0') {
			$atcarray = $tpcarray;
		} else{
			!is_numeric($pid) && Showmsg('illegal_tid');
			$atcarray = $db->get_one("SELECT p.author,p.subject,p.ifsign,p.postdate,p.content,p.ifshield,p.anonymous,m.groupid FROM $pw_posts p LEFT JOIN pw_members m ON m.uid=p.authorid WHERE p.pid='$pid'");
		}
		if ($atcarray['ifshield']) { //��������
			$atcarray['content'] = shield($atcarray['ifshield']=='1' ? 'shield_article' : 'shield_del_article');
		} elseif ($atcarray['groupid'] == '6') {
			$atcarray['content'] = shield('ban_article');
		}
		$ifsign = $atcarray['ifsign'];
		$old_author = $atcarray['anonymous'] ? $db_anonymousname : $atcarray['author'];
		$replytitle = $atcarray['subject'];
		$wtof_oldfile = get_date($atcarray['postdate']);
		require_once GetLang('post');
		$old_content = stripslashes($atcarray['content']);
		$old_content = preg_replace("/\[hide=(.+?)\](.+?)\[\/hide\]/is",$lang['hide_post'],$old_content);
		$old_content = preg_replace("/\[post\](.+?)\[\/post\]/is",$lang['post_post'],$old_content);
		$old_content = preg_replace("/\[sell=(.+?)\](.+?)\[\/sell\]/is",$lang['sell_post'],$old_content);
		$old_content = preg_replace("/\[quote\](.*)\[\/quote\]/is","",$old_content);
		$bit_content = explode("\n",$old_content);

		if (count($bit_content) > 5) {
			$old_content = "$bit_content[0]\n$bit_content[1]\n$bit_content[2]\n$bit_content[3]\n$bit_content[4]\n.......";
		}
		if (strpos($old_content,$db_bbsurl)!==false) {
			$old_content = str_replace('p_w_picpath',$db_picpath,$old_content);
			$old_content = str_replace('p_w_upload',$db_attachname,$old_content);
		}
		$old_content = preg_replace("/\<(.+?)\>/is","",$old_content);
		$atc_content = "[quote]".($article==0 ? $lang['info_post_1'] : $lang['info_post_2'])."\n{$old_content}[/quote]\n";
	}
	list($guidename,$forumtitle) = getforumtitle(forumindex($foruminfo['fup']));
	$guidename .= " &raquo; <a href=\"read.php?tid=$tid\">$tpcarray[subject]</a>";
	if (!$replytitle) {
		$atc_title = "Re:$tpcarray[subject]";
		$forumtitle = "$atc_title|$forumtitle";
	} else {
		$atc_title = "Re:$replytitle";
		$forumtitle = "$atc_title|$tpcarray[subject]|$forumtitle";
	}
	$db_metakeyword = str_replace(array('|',' - '),',',$forumtitle).'phpwind';

	require_once(R_P.'require/header.php');
	$post_reply = "";
	if ($db_showreplynum > 0) {
		$query = $db->query("SELECT p.author,p.subject,p.postdate,p.content,p.anonymous,p.ifconvert,p.ifwordsfb,p.ifshield,m.groupid FROM $pw_posts p LEFT JOIN pw_members m ON p.authorid=m.uid WHERE tid='$tid' AND ifcheck='1' ORDER BY postdate DESC LIMIT 0,$db_showreplynum");
		while ($oldsubject = $db->fetch_array($query)) {
			$oldsubject['subject'] = stripslashes($oldsubject['subject']);
			$oldsubject['content'] = stripslashes($oldsubject['content']);
			$tpc_author = ($oldsubject['anonymous'] && !$admincheck && $windid!=$oldsubject['author']) ? $db_anonymousname : $oldsubject['author'];
			if ($oldsubject['ifshield']) { //��������
				$groupid!='3' && $oldsubject['content'] = shield($oldsubject['ifshield']=='1' ? 'shield_article' : 'shield_del_article');
			} elseif ($oldsubject['groupid'] == 6 && $groupid != 3 && $db_shield) {
				$oldsubject['content'] = shield('ban_article');
			} else {
				$oldsubject['ifwordsfb']!=$db_wordsfb && $oldsubject['content'] = wordsfb($oldsubject['content']);
				$oldsubject['ifconvert']==2 && $oldsubject['content'] = convert($oldsubject['content'],$db_windpost);
				if (strpos($oldsubject['content'],'[p:')!==false || strpos($oldsubject['content'],'[s:')!==false) {
					$oldsubject['content'] = showface($oldsubject['content']);
				}
			}
			$post_reply.="<table align=center width=70% cellspacing=1 cellpadding=2 style='TABLE-LAYOUT: fixed;WORD-WRAP: break-word'><tr><td width=100%>$tpc_author:$oldsubject[subject]<br /><br />$oldsubject[content]</td></tr></table><hr size=1 color=$tablecolor width=80%>";
		}
	}
	/**
	* �������ʱΪ�˼��ٿռ�,�ظ����������Ϊ��,����Ĭ��Ϊ�ظ�����!
	*/
	list($msg_guide,$forumlist) = headguide($guidename);
	require_once PrintEot('post');footer();

} elseif ($_POST['step']==2) {

	InitGP(array('atc_anonymous','atc_iconid','atc_hideatt'),'P');
	list($atc_title,$atc_content,$ifconvert,$ifwordsfb)=check_data('reply');
	$atc_iconid = (int)$atc_iconid;
	/*
	*�¾���Ҫ��Ϊ�˽�ʡ���ݵ��ظ�,�����������ж�
	*/
	stripslashes($atc_title)=='Re:'.$replytitle && $atc_title='';

	$db_tcheck && $winddb['postcheck'] == tcheck($atc_content) && Showmsg('content_same'); //������֤

	//!$atc_usesign && $atc_usesign=0;
	require_once(R_P.'require/postupload.php');
	$sqladd = $attachs ? ",ifupload='$ifupload'" : '';

	if ($foruminfo['f_check']>1 && $_G['atccheck'] && !$admincheck) {
		$ifcheck = 0;
	} else{
		$ifcheck = alarm($atc_title,$atc_content);
	}
	$atc_content=trim($atc_content);
	$anonymous	= ($forumset['anonymous'] && $_G['anonymous'] && $atc_anonymous) ? 1 : 0;
	$ifhide		= ($foruminfo['allowhide'] && $gp_allowhidden && $atc_hideatt) ? 1 : 0;

	bbspostguide();
	
	if ($db_plist) {
		$db->update("INSERT INTO pw_pidtmp(pid) values('')");
		$pid = $db->insert_id();
	} else {
		$pid = '';
	}
	$db->update("INSERT INTO $pw_posts (pid,fid,tid,aid,author,authorid,icon,postdate,subject,userip,ifsign,ipfrom,ifconvert,ifwordsfb,ifcheck,content,anonymous,ifhide) VALUES ('$pid','$fid','$tid','$attachs','".addslashes($windid)."','$winddb[uid]', '$atc_iconid','$timestamp','$atc_title','$onlineip','$atc_usesign','$ipfrom','$ifconvert','$ifwordsfb','$ifcheck','$atc_content','$anonymous','$ifhide')");
	!$pid && $pid = $db->insert_id();
	if ($ifcheck==1) {
		if ($windid!=$tpcarray['author']) {
			if ($db_replysendmail==1 && ($tpcarray['ifmail']==1 || $tpcarray['ifmail']==3)) {
				$receiver = $tpcarray['author'];
				$old_title=$read['subject'];
				$detail = $db->get_one("SELECT email,receivemail FROM pw_members WHERE uid='$tpcarray[authorid]'");
				$send_address = $detail['email'];
				if ($detail['receivemail']=="1") {
					require_once(R_P.'require/sendemail.php');
					if (sendemail($send_address,'email_reply_subject','email_reply_content','email_additional') === true) {
						$sqladd .= ",ifmail=ifmail-1";
					}
				}
			}
			if ($db_replysitemail && ($tpcarray['ifmail']==2 || $tpcarray['ifmail']==3)) {
				$rt = $db->get_one("SELECT mb.replyinfo,m.newrp FROM pw_memberinfo mb LEFT JOIN pw_members m USING(uid) WHERE mb.uid='$tpcarray[authorid]'");
				if (!$rt) {
					$db->update("INSERT INTO pw_memberinfo(uid,replyinfo) VALUES('$tpcarray[authorid]',',$tid,')");
				} elseif (strpos($rt['replyinfo'],",$tid,")===false) {
					$replyinfo=$rt['replyinfo'] ? $rt['replyinfo'].$tid.',' : ",$tid,";
					$db->update("UPDATE pw_memberinfo SET replyinfo='$replyinfo' WHERE uid='$tpcarray[authorid]'");
				}
				if (!$rt['newrp']) {
					$db->update("UPDATE pw_members SET newrp=1 WHERE uid='$tpcarray[authorid]'");
				}
				$sqladd .= ",ifmail=4";
			}
		}
		$atc_author = $anonymous ? $db_anonymousname : $windid;
		$tpcarray['locked']<3 && $tpcarray['lastpost']<$timestamp && $sqladd .= ",lastpost='$timestamp'";
		$db->update("UPDATE pw_threads SET lastposter ='".addslashes($atc_author)."',replies=replies+1 $sqladd ,hits=hits+1 WHERE tid='$tid'");
	}
	if ($aids) {
		$db->update("UPDATE pw_attachs SET tid='$tid',pid='$pid' WHERE aid IN($aids)");
	}

	unset($j_p);
	if ($ifcheck==1) {
		if ($foruminfo['allowhtm'] && !$foruminfo['cms']) {
			include_once(R_P.'require/template.php');
		}
		if ($tpcarray['locked']<3) {
			lastinfo($fid,$foruminfo['allowhtm'],'reply',$foruminfo['cms'].'B');
		}
		//Start Here�»ظ����а�
		if($db_ifsort&16 && !$foruminfo['allowvisit'] && $foruminfo['f_type']!='hidden' && !$foruminfo['password'] && !$forumset['forumsell']){
			require_once(R_P.'require/sort.php');
			sort_newreply($tid,($atc_title ? $atc_title : 'Re:'.$replytitle));
		}
		//End Here
		if (empty($j_p)) $j_p="read.php?tid=$tid&page=e&#a";
		refreshto($j_p,'enter_thread');
	} else{
		refreshto("thread.php?fid=$fid",'post_check');
	}
}
?>