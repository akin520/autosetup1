<?php
!function_exists('readover') && exit('Forbidden');

/*
*
* ����
*
*/
list($rw_valid,$rw_b_val,$rw_a_val,$rw_credit) = explode("\t",$forumset['rewarddb']);

empty($rw_valid) && $rw_valid = 10;
$rw_credit = explode(',',$rw_credit);

InitGP(array('bonus','ctype'),'P');
$bonus['best']   = (int)$bonus['best'];
$bonus['active'] = (int)$bonus['active'];
$bonus['best']   < $rw_b_val && Showmsg('credit_limit');
$bonus['active'] < $rw_a_val && Showmsg('credit_limit');

if (!in_array($ctype['best'],$rw_credit) || !in_array($ctype['active'],$rw_credit)) {
	Showmsg('reward_credit_error');
}
if ($ctype['best'] == $ctype['active']) {
	$total_c = $bonus['best']*2 + $bonus['active'];
	if (!is_numeric($ctype['best'])) {
		if ($ctype['best'] == 'rvrc') {
			$userrvrc < $total_c && Showmsg('reward_credit_limit');
			$reduce = $total_c*10;
		} else {
			$winddb[$ctype['best']] < $total_c && Showmsg('reward_credit_limit');
			$reduce = $total_c;
		}
		$db->update("UPDATE pw_memberdata SET $ctype[best]=$ctype[best]-'$reduce' WHERE uid='$winduid'");
	} else {
		require_once(R_P.'require/credit.php');
		UserCredit($winduid,$ctype['best']) < $total_c && Showmsg('reward_credit_limit');
		UserCredit($winduid,$ctype['best'],'set',-$total_c);
	}
} else {
	$sql_0 = '';
	$sql_1 = array();
	foreach ($ctype as $key=>$val) {
		if ($bonus[$key] < 1) {
			continue;
		}
		$i = $key == 'best' ? 2 : 1;
		$reduce = $bonus[$key]*$i;

		if (!is_numeric($val)) {
			$val == 'rvrc' && $reduce *= 10;
			$winddb[$val] < $reduce && Showmsg('reward_credit_limit');
			$sql_0 .= ($sql_0 ? ',' : '').$val."=".$val."-'".$reduce."'";
		} else {
			require_once(R_P.'require/credit.php');
			UserCredit($winduid,$val) < $reduce && Showmsg('reward_credit_limit');
			$sql_1[$val] = $reduce;
		}
	}
	$sql_0 && $db->update("UPDATE pw_memberdata SET $sql_0 WHERE uid='$winduid'");
	if ($sql_1) {
		foreach ($sql_1 as $cid=>$value) {
			UserCredit($winduid,$cid,'set',-$value);
		}
	}
}
$special	= array_sum($bonus) > 0 ? 3 : 0;
$timelimit	= $timestamp + $rw_valid * 86400;

?>