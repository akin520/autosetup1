<?php
!function_exists('readover') && exit('Forbidden');

$ifupload = $aids = 0;
$attachs = array();
foreach($_FILES as $key=>$val){
	if(!$val['tmp_name'] || $val['tmp_name'] == 'none'){
		unset($_FILES[$key]);
	}
}
$filenum = count($_FILES);
if($filenum > 0 && $filenum <= $db_attachnum){
	if(!$db_allowupload){
		Showmsg('upload_close');
	} elseif($foruminfo['allowupload'] && !allowcheck($foruminfo['allowupload'],$groupid,$winddb['groups'])){
		Showmsg('upload_forum_right');//���Ȩ���ж�
	} elseif(!$foruminfo['allowupload'] && $gp_allowupload==0){
		Showmsg('upload_group_right');//�û���Ȩ���ж�
	}
	$ftp = null;
	if ($db_ifftp) {
		require_once(R_P.'require/ftp.php');
		$ftp = new FTP($ftp_server,$ftp_port,$ftp_user,$ftp_pass,$ftp_dir);
	}
	$uploaddb = UploadFile($winduid);
	foreach($uploaddb as $value){
		InitGP(array('atc_downrvrc'.$value['id'],'atc_desc'.$value['id']),'P',1);
		$value['name'] = addslashes($value['name']);
		if(!$value['ifreplace']){
			$value['needrvrc'] = (int)${'atc_downrvrc'.$value['id']};
			$value['descrip'] = ${'atc_desc'.$value['id']};
			$db->update("INSERT INTO pw_attachs SET fid='$fid',uid='$winduid',hits=0,name='$value[name]',type='$value[type]',size='$value[size]',attachurl='$value[attachurl]',needrvrc='$value[needrvrc]',uploadtime='$timestamp',descrip='$value[descrip]',ifthumb='$value[ifthumb]'");
			$aid = $db->insert_id();
			$attachs[$aid] = array(
				'aid'       => $aid,
				'name'      => stripslashes($value['name']),
				'type'      => $value['type'],
				'attachurl' => $value['attachurl'],
				'needrvrc'  => $value['needrvrc'],
				'size'      => $value['size'],
				'hits'      => 0,
				'desc'		=> str_replace('\\','',$value['descrip']),
				'ifthumb'	=> $value['ifthumb']
			);
			$atc_content = str_replace("[upload=$value[id]]","[attachment=$aid]",$atc_content);
		} else{
			$value['needrvrc'] = $replacedb[$value['id']]['needrvrc'];
			$value['descrip'] = $replacedb[$value['id']]['desc'];
			$aid = $replacedb[$value['id']]['aid'];
			$db->update("UPDATE pw_attachs SET name='$value[name]',type='$value[type]',size='$value[size]',attachurl='$value[attachurl]',needrvrc='$value[needrvrc]',uploadtime='$timestamp',descrip='$value[descrip]',ifthumb='$value[ifthumb]' WHERE aid='$aid'");
			$oldattach[$aid]['name'] = $value['name'];
			$oldattach[$aid]['type'] = $value['type'];
			$oldattach[$aid]['size'] = $value['size'];
			$oldattach[$aid]['ifthumb'] = $value['ifthumb'];
		}
	}
}
unset($_FILES);
foreach ($attachs as $key => $value) {
	$aids .= ','.$key;
}
$attachs = !empty($attachs) ? addslashes(serialize($attachs)) : '';
if ($ftp) {
	$ftp->close(); unset($ftp);
}
?>