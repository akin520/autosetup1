<?php
!function_exists('readover') && exit('Forbidden');

/**
 * ��̳��Ҫ���а�������
 *
 */
class reBang{
	var $db;
	var $sortnum;

	function reBang(){
		global $db_sortnum,$db;
		$this->sortnum = $db_sortnum ? $db_sortnum : 20;
		$this->db = $db ? $db : PwNewDB();
	}

	/**
	 * ȡ�ð�����
	 *
	 * @param array $order array in ('newpost','newreply','newpic','replies','digest','topic','article','tpost','postnum','todaypost','monthpost','onlinetime','rvrc','money','credit','currency')
	 * @param integer $num
	 * @param integer $hour
	 * @param string $fids
	 * @return array
	 */
	function getReBang($order=array(),$num=null,$hour=null,$fids=null){
		global $db_ifsort;
		static $_MEMBER = null,$_ARTICLE = null;
		$num = intval($num) ? intval($num) : $this->sortnum;
		settype($order,'array');
		$rebang = array();
		foreach ($order as $type) {
			if (isset($rebang[$type])) {
				continue;
			}
			if (in_array($type,array('topic','article','tpost'))) {
				$rebang[$type] = $this->getForum($num,$type);
			} elseif ($type == 'new') {
				$rebang['new'] = $this->getMember($num,'new');
			} elseif ($type == 'info') {
				$rebang['info'] = $this->getInfo();
			} elseif (in_array($type,array('postnum','todaypost','monthpost','onlinetime','rvrc','money','credit','currency')) || is_numeric($type)) {
				if ($db_ifsort&1) {
					if (!isset($_MEMBER)) {
						$this->update('member');
						@include(D_P.'data/bbscache/sort_memberdata.php');
					}
					$_MEMBER[$type] && $rebang[$type] = array_slice($_MEMBER[$type],0,$num);
				} else {
					$rebang[$type] = $this->getMember($num,$type);
				}
			} elseif (in_array($type,array('digest','replies','hits'))) {
				if ($db_ifsort&2) {
					if (!isset($_ARTICLE)) {
						$this->update('article');
						@include(D_P.'data/bbscache/sort_articledata.php');
					}
					$_ARTICLE[$type] && $rebang[$type] = array_slice($_ARTICLE[$type],0,$num);
				} else {
					$rebang[$type] = $this->getPost($num,$type,$hour,$fids);
				}
			} elseif ($type == 'newpic') {
				if ($db_ifsort&4) {
					@include(D_P.'data/bbscache/sort_newpic.php');
					$_NEWPIC && $rebang[$type] = array_slice($_NEWPIC,0,$num);
				} else {
					$rebang[$type] = $this->getNewPic($num,$fids);
				}
			} elseif ($type == 'newpost') {
				if ($db_ifsort&8) {
					@include(D_P.'data/bbscache/sort_newpost.php');
					$_NEWPOST && $rebang[$type] = array_slice($_NEWPOST,0,$num);
				} else {
					$rebang[$type] = $this->getNewPost($num,$hour,$fids);
				}
			} elseif ($type == 'newreply') {
				if ($db_ifsort&16) {
					@include(D_P.'data/bbscache/sort_newreply.php');
					$_NEWREPLY && $rebang[$type] = array_slice($_NEWREPLY,0,$num);
				} else {
					$rebang[$type] = $this->getNewReply($num,$hour,$fids);
				}
			} else {
				$rebang[$type] = array();
			}
		}
		if (count($order)>1) {
			return $rebang;
		} else {
			return $rebang[$order[0]];
		}
	}

	/**
	 * �������:������,������,���շ�����
	 *
	 * @param integer $num
	 * @param string $order in array('topic','article','tpost')
	 * @return array
	 */
	function getForum($num=null,$order='topic'){
		if (!in_array($order,array('topic','article','tpost'))) {
			return false;
		}
		$num = intval($num) ? intval($num) : $this->sortnum;
		$forum = array();
		$query = $this->db->query("SELECT fd.fid as id,f.name,fd.$order as value FROM pw_forumdata fd LEFT JOIN pw_forums f USING(fid) WHERE f.password='' AND f.allowvisit='' AND f.f_type<>'hidden' ORDER BY fd.$order DESC LIMIT $num");
		while($rt = $this->db->fetch_array($query)){
			$rt['value'] && $forum[$rt['id']] = $rt;
		}
		return $forum;
	}

	/**
	 * ���¸���ͼƬ
	 *
	 * @param integer $num
	 * @param string $fids
	 * @return array
	 */
	function getNewPic($num=null,$fids=null){
		$num    = intval($num) ? intval($num) : $this->sortnum;
		!$fids && $fids = $this->getFid();
		$sqladd = $fids ? "AND a.fid IN ($fids)" : '';
		$newpic = array();
		$query  = $this->db->query("SELECT a.tid,a.attachurl,t.subject FROM pw_attachs a LEFT JOIN pw_threads t ON a.tid=t.tid WHERE a.type='img' AND a.pid=0 $sqladd ORDER BY a.aid DESC LIMIT 0,$num");
		while($rt = $this->db->fetch_array($query)){
			$pic = geturl($rt['attachurl'],'show');
			if(is_array($pic) && !$newpic[$rt['tid']]){
				$newpic[$rt['tid']] = array(
					'id'   => $rt['tid'],
					'name' => $rt['subject'],
					'value'=> $pic[0]
				);
			}
		}
		return $newpic;
	}

	/**
	 * ����������
	 *
	 * @param integer $num
	 * @param integer $hour ʱ����ڵ�������(Сʱ)
	 * @param string $fids
	 * @return array
	 */
	function getNewPost($num=null,$hour=null,$fids=null){
		global $timestamp;
		$num = intval($num) ? intval($num) : $this->sortnum;
		$time = $hour ? $timestamp-intval($hour)*3600 : '';
		!$fids && $fids = $this->getFid();
		$sqladd  = $fids ? "AND fid IN ($fids)" : '';
		if ($time) {
			$sql = "SELECT tid as id,subject as name,postdate as value FROM pw_threads WHERE postdate>'$time' AND ifcheck ='1' $sqladd ORDER BY postdate DESC LIMIT $num";
		} else {
			$sql = "SELECT tid as id,subject as name,postdate as value FROM pw_threads WHERE ifcheck LIKE '%1' $sqladd ORDER BY tid DESC LIMIT $num";
		}
		$newpost = array();
		$query   = $this->db->query($sql);
		while($post = $this->db->fetch_array($query)){
			$newpost[$post['id']] = $post;
		}
		return $newpost;
	}

	/**
	 * ���»ظ�����
	 *
	 * @param integer $num
	 * @param integer $hour
	 * @param string $fids
	 * @return array
	 */
	function getNewReply($num=null,$hour=null,$fids=null){
		global $db_ptable;
		$num = intval($num) ? intval($num) : $this->sortnum;
		$time = $hour ? $timestamp-intval($hour)*3600 : '';
		!$fids && $fids = $this->getFid();
		$sqladd  = $fids ? "AND fid IN ($fids)" : '';
		$pw_posts = GetPtable($db_ptable);
		if ($time) {
			$sql = "SELECT DISTINCT tid FROM $pw_posts WHERE postdate>'$time' and ifcheck='1' AND $sqladd ORDER BY postdate DESC LIMIT $num";
		} else {
			$sql = "SELECT DISTINCT tid FROM $pw_posts WHERE ifcheck LIKE '%1' $sqladd ORDER BY pid DESC LIMIT $num";
		}
		$newreply = array();
		$tids = '';
		$query = $this->db->query($sql);
		while($reply = $this->db->fetch_array($query)){
			$tids .= ','.$reply['tid'];
		}
		if($tids){
			$tids = substr($tids,1);
			$query = $this->db->query("SELECT tid as id,subject as name,lastpost as value FROM pw_threads WHERE tid IN($tids) ORDER BY value DESC");
			while($reply = $this->db->fetch_array($query)){
				$reply['name'] = 'Re:'.$reply['name'];
				$newreply[$reply['id']] = $reply;
			}
		}
		return $newreply;
	}

	/**
	 * ��������:������,������,������
	 *
	 * @param integer $num
	 * @param string $order in array ('digest','replys','hits')
	 * @param integer $hour
	 * @param string $fids
	 * @return array
	 */
	function getPost($num=null,$order=null,$hour=null,$fids=null){
		$num = intval($num) ? intval($num) : $this->sortnum;
		$time = $hour ? $timestamp-intval($hour)*3600 : '';
		!$fids && $fids = $this->getFid();
		$sqladd = '';
		$fids && $sqladd .= " AND fid IN ($fids) ";
		$time && $sqladd .= " AND postdate>'$time'";
		if ($order == 'digest') {
			$sql = "SELECT tid as id,subject as name,lastpost as value FROM pw_threads WHERE digest IN(1,2) AND ifcheck='1' $sqladd ORDER BY lastpost DESC LIMIT $num";
		} elseif ($order == 'replies') {
			$sql = "SELECT tid as id,subject as name,replies as value FROM pw_threads WHERE ifcheck='1' $sqladd ORDER BY replies DESC LIMIT $num";
		} elseif ($order == 'hits') {
			$sql = "SELECT tid as id,subject as name,hits as value FROM pw_threads WHERE ifcheck='1' $sqladd ORDER BY hits DESC LIMIT $num";
		} else {
			return false;
		}
		$posts = array();
		$query = $this->db->query($sql);
		while ($rt = $this->db->fetch_array($query)) {
			$posts[$rt['id']] = $rt;
		}
		return $posts;
	}

	/**
	 * ��Ա����:����ע��,������,����ʱ��(Ч�ʵ�),�·�����(Ч�ʵ�),���췢����(Ч�ʵ�),��������(Ч�ʵ�)
	 *
	 * @param integer $num
	 * @param string $type in array('new','postnum','onlinetime','monthpost','todaypost','rvrc','money','credit','currency')
	 * @return array
	 */
	function getMember($num=null,$order=null){
		$num = intval($num) ? intval($num) : $this->sortnum;
		if (is_numeric($order) && $GLOBALS['_CREDITDB'][$order]) {
			$sql = "SELECT mc.uid as id,mc.value,m.username as name FROM pw_membercredit mc LEFT JOIN pw_members m USING(uid) WHERE mc.cid='$order' ORDER BY mc.value DESC LIMIT $num";
		} elseif ($order == 'monthpost') {
			$sql = "SELECT md.uid as id,md.monthpost as value,m.username as name FROM pw_memberdata md LEFT JOIN pw_members m USING(uid) WHERE md.lastpost>'$GLOBALS[montime]' ORDER BY md.monthpost DESC LIMIT $num";
		} elseif ($order == 'todaypost') {
			$sql = "SELECT md.uid as id,md.todaypost as value,m.username as name FROM pw_memberdata md LEFT JOIN pw_members m USING(uid) WHERE md.lastpost>'$GLOBALS[tdtime]' ORDER BY md.todaypost DESC LIMIT $num";
		} elseif ($order == 'new') {
			$sql = "SELECT uid as id,username as name,regdate as value FROM pw_members ORDER BY uid DESC LIMIT $num";
		} elseif (in_array($order,array('postnum','onlinetime','rvrc','money','credit','currency'))) {
			$sql = "SELECT md.uid as id,md.$order as value,m.username as name FROM pw_memberdata md LEFT JOIN pw_members m USING(uid) ORDER BY md.$order DESC LIMIT $num";
		} else {
			return false;
		}
		$member = array();
		$query = $this->db->query($sql);
		while ($rt = $this->db->fetch_array($query)) {
			if($order == 'rvrc'){
				$rt['value'] = floor($rt['value']/10);
			}elseif($order == 'onlinetime'){
				$rt['value'] = floor($rt['value']/3600);
			}
			$rt['value'] && $member[$rt['id']] = $rt;
		}
		return $member;
	}

	/**
	 * ��̳��Ϣ
	 *
	 * @return array
	 */
	function getInfo(){
		global $tdtime,$db_online,$db_hostweb;
		$bbsinfo = $this->db->get_one("SELECT newmember,totalmember,higholnum,higholtime,tdtcontrol,yposts,hposts FROM pw_bbsinfo WHERE id=1");
		$rs = $this->db->get_one("SELECT SUM(fd.topic) as topic,SUM(fd.subtopic) as subtopic,SUM(fd.article) as article,SUM(fd.tpost) as tposts FROM pw_forums f LEFT JOIN pw_forumdata fd USING(fid) WHERE f.ifsub='0' AND f.cms!='1'");
		$bbsinfo['topic']   = $rs['topic'] + $rs['subtopic'];
		$bbsinfo['article'] = $rs['article'];
		$bbsinfo['tposts']  = $rs['tposts'];
		if($bbsinfo['tdtcontrol']!=$tdtime && $db_hostweb == 1){
			$this->db->update("UPDATE pw_bbsinfo SET yposts='$bbsinfo[tposts]',tdtcontrol='$tdtime' WHERE id=1");
			$this->db->update("UPDATE pw_forumdata SET tpost=0 WHERE tpost<>'0'");
			$bbsinfo['yposts'] = $bbsinfo['tposts'];
			$bbsinfo['tposts'] = '';
		}
		unset($bbsinfo['tdtcontrol']);
		$bbsinfo['guest'] = $bbsinfo['users'] = 0;
		if (!$db_online && file_exists(D_P.'data/bbscache/olcache.php')) {
			include(D_P.'data/bbscache/olcache.php');
			$bbsinfo['guest'] = $guestinbbs;
			$bbsinfo['users'] = $userinbbs;
		} elseif ($db_online) {
			$userinbbs = $guestinbbs = 0;
			$query = $this->db->query("SELECT uid!=0 as ifuser,COUNT(*) AS count FROM pw_online GROUP BY uid!='0'");
			while($rt = $this->db->fetch_array($query)){
				if($rt['ifuser']){
					$bbsinfo['users'] = $rt['count'];
				} else {
					$bbsinfo['guest'] = $rt['count'];
				}
			}
		}
		$bbsinfo['usertotal'] = $bbsinfo['guest']+$bbsinfo['users'];
		return $bbsinfo;
	}

	function update($type=null,$updatetime=null){
		global $timestamp,$db_sorttime;
		$updatetime = $updatetime ? intval($updatetime) : ($db_sorttime ? $db_sorttime : 300);
		$updatetime = $timestamp - $updatetime;
		if ($type == 'member' && @filemtime(D_P.'data/bbscache/sort_memberdata.php')<$updatetime) {
			$__MEMBERDB = $_MEMBER = array();
			$flag = false;
			@include(D_P.'data/bbscache/sort_member.php');
			foreach($__MEMBERDB as $value){
				foreach($value as $key=>$val){
					$uiddb[$key] || $uiddb[$key] = $key;
				}
			}
			if($uiddb){
				$memberdb = array();
				$uiddb = implode(',',$uiddb);
				$query = $this->db->query("SELECT uid,username FROM pw_members WHERE uid IN($uiddb)");
				while($rt=$this->db->fetch_array($query)){
					$memberdb[$rt['uid']] = $rt;
				}
				foreach($__MEMBERDB as $key=>$value){
					if (is_numeric($key) && !isset($GLOBALS['_CREDITDB'][$key])){
						$flag || $flag = true;
						unset($__MEMBERDB[$key]);
						unset($__THRESHOLD[$key]);
					} else {
						foreach($value as $k=>$v){
							if($key == 'rvrc'){
								$v = floor($v/10);
							}elseif($key == 'onlinetime'){
								$v = floor($v/3600);
							}
							$_MEMBER[$key][] = array('id'=>$k,'name'=>$memberdb[$k]['username'],'value'=>$v);
						}
					}
				}
			}
			$flag && writeover(D_P.'data/bbscache/sort_member.php',"<?php\r\n\$__THRESHOLD = ".pw_var_export($__THRESHOLD).";\r\n\$__MEMBERDB = ".pw_var_export($__MEMBERDB).";\r\n?>");
			writeover(D_P.'data/bbscache/sort_memberdata.php',"<?php\r\n\$_MEMBER = ".pw_var_export($_MEMBER).";\r\n?>");
		} elseif ($type == 'article' && @filemtime(D_P.'data/bbscache/sort_articledata.php')<$updatetime) {
			$__ARTICLEDB = $_ARTICLE = array();
			@include(D_P.'data/bbscache/sort_article.php');
			foreach($__ARTICLEDB as $value){
				foreach($value as $key=>$val){
					$tiddb[$key] || $tiddb[$key] = $key;
				}
			}
			if($tiddb){
				$articledb = array();
				$tiddb = implode(',',$tiddb);
				$rs = $this->db->query("SELECT tid,subject,lastpost as digest,hits,replies,fid FROM pw_threads WHERE tid IN($tiddb)");
				while($rt=$this->db->fetch_array($rs)){
					$articledb[$rt['tid']] = $rt;
				}
				foreach($__ARTICLEDB as $key=>$value){
					foreach($value as $k=>$v){
						$articledb[$k]['subject'] = str_replace('$','\$',$articledb[$k]['subject']);
						$_ARTICLE[$key][] = array('id'=>$articledb[$k]['tid'],'name'=>$articledb[$k]['subject'],'value'=>$articledb[$k][$key],'fid'=>$articledb[$k]['fid']);
					}
				}
			}
			writeover(D_P.'data/bbscache/sort_articledata.php',"<?php\r\n\$_ARTICLE = ".pw_var_export($_ARTICLE).";\r\n?>");
		}
		return false;
	}

	/**
	 * ��ȡ��Ч���FID
	 *
	 * @return string
	 */
	function getFid(){
		static $fids = null;
		if (@filemtime(D_P.'data/bbscache/commonforum.php')<@filemtime(D_P.'data/bbscache/forum_cache.php')) {
			$query = $this->db->query("SELECT f.fid,f.allowvisit,f.password,f.f_type,fe.forumset FROM pw_forums f LEFT JOIN pw_forumsextra fe ON fe.fid=f.fid WHERE f.type<>'category'");
			while ($rt = $this->db->fetch_array($query)) {
				$forumset = $rt['forumset'] ? unserialize($rt['forumset']) : '';
				if ($rt['f_type']!='hidden' && !$rt['allowvisit'] && !$rt['password'] && !$forumset['forumsell']) {
					$fids .= ",'$rt[fid]'";
				}
			}
			$fids && $fids = substr($fids,1);
			writeover(D_P.'data/bbscache/commonforum.php',"<?php\r\n\$fids = \"$fids\";\r\n?>");
		}

		if (!isset($fids)) {
			include (D_P.'data/bbscache/commonforum.php');
		}
		return $fids;
	}
}
?>