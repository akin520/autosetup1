<?php
!function_exists('readover') && exit('Forbidden');

list($db_ifupload,$db_imgheight,$db_imgwidth,$db_imgsize)=explode("\t",$db_upload);
!$db_imgwidth && !$db_imgheight && $db_imgwidth = 100;

function showfacedesign($usericon,$show_a = null) {
	global $imgpath;
	$user_a = explode('|',$usericon);
	$faceurl = '';
	$user_a[1] = (int)$user_a[1];
	if ($user_a[4]) {
		$faceurl = "$imgpath/pig.gif";
		$user_a[1] = 4;
	} elseif ($user_a[1] == 3) {
		list($tempuid) = explode('.',$user_a[0]);
		list($tempdir,$tempuid) = explode('/',$tempuid);
		!$tempuid && $tempuid = $tempdir;
		if ((int)$tempuid > 0) {
			global $db_ftpweb,$attachpath,$attachdir;
			if ($db_ftpweb && !file_exists("$attachdir/upload/$user_a[0]")) {
				$faceurl = "$db_ftpweb/upload/$user_a[0]";
			} else {
				$faceurl = "$attachpath/upload/$user_a[0]";
			}
		}
	} elseif ($user_a[1] == 2 && substr($user_a[0],0,4) == 'http') {
		$faceurl = $user_a[0];
	}
	if (!$faceurl || !$user_a[0] || strpos($faceurl,'<')!==false || $user_a[1]<1) {
		$user_a[1] = 1;
	}
	if ($user_a[1] == 1) {
		global $imgdir;
		if (!$user_a[0] || !file_exists("$imgdir/face/$user_a[0]")) {
			$user_a[0] = 'none.gif';
		}
		$faceurl = "$imgpath/face/$user_a[0]";
	}
	$imglen = '';
	if ($user_a[1] == 2 || $user_a[1] == 3) {
		list($user_a[2],$user_a[3]) = getfacelen($user_a[2],$user_a[3]);
		if (empty($show_a)) {
			if ($user_a[2]) $imglen .= " width=\"$user_a[2]\"";
			if ($user_a[3]) $imglen .= " height=\"$user_a[3]\"";
		}
	}
	if (empty($show_a)) {
		return "<img class=\"pic\" src=\"$faceurl\"$imglen border=\"0\" />";
	} else {
		return array($faceurl,$user_a[1],$user_a[2],$user_a[3],$user_a[0],$user_a[4]);
	}
}
function getfacelen($img_w,$img_h){
	global $db_imgheight,$db_imgwidth;
	$have_w = false;
	if ($db_imgwidth && (!$img_w || $img_w>$db_imgwidth)) {
		$have_w = true;
		$img_w = $db_imgwidth;
	}
	if ($db_imgheight) {
		if (!$img_h && $have_w) {
			$img_h = $db_imgwidth;
		} elseif ($img_h>$db_imgheight) {
			$img_h = $db_imgheight;
		}
	}
	return array($img_w,$img_h);
}
function DelIcon($filename){
	global $attachdir,$db_ftpweb,$ftp;
	if (strpos($filename,'..')!==false) {
		return false;
	}
	if (file_exists("$attachdir/upload/$filename")) {
		P_unlink("$attachdir/upload/$filename");
	} elseif ($db_ftpweb && $ftp) {
		$ftp->delete("upload/$filename");
	}
}
?>