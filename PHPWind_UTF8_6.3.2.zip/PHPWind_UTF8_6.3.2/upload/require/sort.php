<?php
!function_exists('readover') && exit('Forbidden');

/**
 * ��Ա����
 *
 * @param array $winddb ��Ա��Ϣ
 */
function sort_member($winddb=array(),$num=null){//$db_ifsort&1
	global $tdtime,$montime,$db,$db_sortnum;
	$num = $num ? intval($num) : ($db_sortnum ? $db_sortnum : 20);
	$flag = false;
	$__MEMBERDB = $__THRESHOLD = array();
	$__CREDITDB = array('postnum','todaypost','monthpost','onlinetime','rvrc','money','credit','currency');
	$winddb['lastpost']<$tdtime && $winddb['todaypost'] = 0;
	$winddb['lastpost']<$montime && $winddb['monthpost'] = 0;
	@include(D_P.'data/bbscache/sort_member.php');
	$cachetime = @filemtime(D_P.'data/bbscache/sort_member.php');
	if ($cachetime && $cachetime < $tdtime) {
		$__THRESHOLD['todaypost'] = 0;
		$__MEMBERDB['todaypost'] = array();
		if ($cachetime < $montime) {
			$__THRESHOLD['monthpost'] = 0;
			$__MEMBERDB['monthpost'] = array();
		}
		$flag = true;
	}
	foreach ($__CREDITDB as $k) {
		if($winddb[$k] && (($__MEMBERDB[$k][$winddb['uid']] && $__MEMBERDB[$k][$winddb['uid']] != $winddb[$k]) || (!$__MEMBERDB[$k][$winddb['uid']] && $winddb[$k] > $__THRESHOLD[$k]))){
			$__THRESHOLD[$k] = sort_array($winddb['uid'],$winddb[$k],$__MEMBERDB[$k],$num);
			$flag || $flag = true;
		}
	}
	$query = $db->query("SELECT cid,value FROM pw_membercredit WHERE uid='$winddb[uid]'");
	while ($rt = $db->fetch_array($query)) {
		if(($__MEMBERDB[$rt['cid']][$winddb['uid']] && $__MEMBERDB[$rt['cid']][$winddb['uid']] != $rt['value']) || (!$__MEMBERDB[$rt['cid']][$winddb['uid']] && $rt['value'] > $__THRESHOLD[$rt['cid']])){
			$__THRESHOLD[$rt['cid']] = sort_array($winddb['uid'],$rt['value'],$__MEMBERDB[$rt['cid']],$num);
			$flag || $flag = true;
		}
	}
	$flag && writeover(D_P.'data/bbscache/sort_member.php',"<?php\r\n\$__THRESHOLD = ".pw_var_export($__THRESHOLD).";\r\n\$__MEMBERDB = ".pw_var_export($__MEMBERDB).";\r\n?>");
}

/**
 * ��������
 *
 * @param array $postdb ������Ϣ
 */
function sort_post($postdb=array(),$num=null){//$db_ifsort&2
	global $db_sortnum;
	$num = $num ? intval($num) : ($db_sortnum ? $db_sortnum : 20);
	$flag = false;
	$__ARTICLEDB = $__THRESHOLD = array();
	@include(D_P.'data/bbscache/sort_article.php');
	foreach($postdb as $key=>$post){
		if($post['ifcheck']!=1 || $post['locked']>=2){
			continue;
		}
		if($post['replies'] && $__ARTICLEDB['replies'][$post['tid']] != $post['replies'] && $post['replies'] > $__THRESHOLD['replies']){
			$__THRESHOLD['replies'] = sort_array($post['tid'],$post['replies'],$__ARTICLEDB['replies'],$num);
			$flag || $flag = true;
		}
		if($post['hits'] && $__ARTICLEDB['hits'][$post['tid']] != $post['hits'] && $post['hits'] > $__THRESHOLD['hits']){
			$__THRESHOLD['hits'] = sort_array($post['tid'],$post['hits'],$__ARTICLEDB['hits'],$num);
			$flag || $flag = true;
		}
		if($post['digest'] && $__ARTICLEDB['digest'][$post['tid']] != $post['lastpost'] && $post['lastpost'] > $__THRESHOLD['digest']){
			$__THRESHOLD['digest'] = sort_array($post['tid'],$post['lastpost'],$__ARTICLEDB['digest'],$num);
			$flag || $flag = true;
		}
	}
	$flag && writeover(D_P.'data/bbscache/sort_article.php',"<?php\r\n\$__THRESHOLD = ".pw_var_export($__THRESHOLD).";\r\n\$__ARTICLEDB = ".pw_var_export($__ARTICLEDB).";\r\n?>");
}

/**
 * �����Ӹ���ͼƬ
 *
 * @param integer $tid
 * @param string $subject
 * @param string $pic
 * @param integer $num
 */
function sort_newpic($tid,$subject,$pic,$num=null){//$db_ifsort&4
	global $db_sortnum;
	$num = $num ? intval($num) : ($db_sortnum ? $db_sortnum : 20);
	@include(D_P.'data/bbscache/sort_newpic.php');
	if(!$_NEWPIC){
		$_NEWPIC[$tid]=array(
			'id' => $tid,
			'name' => $subject,
			'value' => $pic
		);
	}else{
		if(count($_NEWPIC)>=$num){
			array_pop($_NEWPIC);
		}
		$_NEWPIC = array_merge(array($tid=>array('value'=>$pic,'id'=>$tid,'name'=>$subject)),$_NEWPIC);
	}
	writeover(D_P.'data/bbscache/sort_newpic.php',"<?php\r\n\$_NEWPIC = ".pw_var_export($_NEWPIC).";\r\n?>");
}

/**
 * ������������
 *
 * @param integer $tid
 * @param string $subject
 * @param integer $num
 */
function sort_newpost($tid,$subject,$num=null){//$db_ifsort&8
	global $timestamp,$db_sortnum;
	$num = $num ? intval($num) : ($db_sortnum ? $db_sortnum : 20);
	@include(D_P.'data/bbscache/sort_newpost.php');
	if(!$_NEWPOST){
		$_NEWPOST[$tid]=array(
			'id' => $tid,
			'name' => $subject,
			'value' => $timestamp
		);
	}else{
		if(count($_NEWPOST)>=$num){
			array_pop($_NEWPOST);
		}
		$_NEWPOST = array_merge(array($tid=>array('id' => $tid,'name' => $subject,'value' => $timestamp)),$_NEWPOST);
	}
	writeover(D_P.'data/bbscache/sort_newpost.php',"<?php\r\n\$_NEWPOST = ".pw_var_export($_NEWPOST).";\r\n?>");
}

/**
 * ���»ظ�����
 *
 * @param integer $tid
 * @param string $subject
 * @param integer $num
 */
function sort_newreply($tid,$subject,$num=null){//$db_ifsort&16
	global $timestamp,$db_sortnum;
	$num = $num ? intval($num) : ($db_sortnum ? $db_sortnum : 20);
	@include(D_P.'data/bbscache/sort_newreply.php');
	if(!$_NEWREPLY){
		$_NEWREPLY[$tid]=array(
			'id' => $tid,
			'name' => $subject,
			'value' => $timestamp
		);
	}else{
		if($_NEWREPLY[$tid]){
			unset($_NEWREPLY[$tid]);
		}elseif(count($_NEWREPLY)>=$num){
			array_pop($_NEWREPLY);
		}
		$_NEWREPLY = array_merge(array($tid=>array('id' => $tid,'name' => $subject,'value' => $timestamp)),$_NEWREPLY);
	}
	writeover(D_P.'data/bbscache/sort_newreply.php',"<?php\r\n\$_NEWREPLY = ".pw_var_export($_NEWREPLY).";\r\n?>");
}

function sort_delete($ids){
	global $db_ifsort;
	if ($db_ifsort&2) {
		include (D_P.'data/bbscache/sort_article.php');
		$update = false;
		foreach($__ARTICLEDB as $key=>$value){
			foreach($value as $k=>$v){
				if(strpos(",$ids,",",$k,")!==false){
					unset($__ARTICLEDB[$key][$k]);
					$update || $update=true;
				}
			}
			$__THRESHOLD[$key] = end($__ARTICLEDB[$key]);
		}
		$update && writeover(D_P.'data/bbscache/sort_article.php',"<?php\r\n\$__THRESHOLD = ".pw_var_export($__THRESHOLD).";\r\n\$__ARTICLEDB = ".pw_var_export($__ARTICLEDB).";\r\n?>");
	}
	if ($db_ifsort&4) {
		include (D_P.'data/bbscache/sort_newpic.php');
		$update = false;
		foreach($_NEWPIC as $key=>$value){
			if(strpos(",$ids,",",$key,")!==false){
				unset($_NEWPIC[$key]);
				$update || $update=true;
			}
		}
		$update && writeover(D_P.'data/bbscache/sort_newpic.php',"<?php\r\n\$_NEWPIC = ".pw_var_export($_NEWPIC).";\r\n?>");
	}
	if ($db_ifsort&8) {
		include (D_P.'data/bbscache/sort_newpost.php');
		$update = false;
		foreach($_NEWPOST as $key=>$value){
			if(strpos(",$ids,",",$key,")!==false){
				unset($_NEWPOST[$key]);
				$update || $update=true;
			}
		}
		$update && writeover(D_P.'data/bbscache/sort_newpost.php',"<?php\r\n\$_NEWPOST = ".pw_var_export($_NEWPOST).";\r\n?>");
	}
	if ($db_ifsort&16) {
		include (D_P.'data/bbscache/sort_newpost.php');
		$update = false;
		foreach($_NEWPOST as $key=>$value){
			if(strpos(",$ids,",",$key,")!==false){
				unset($_NEWPOST[$key]);
				$update || $update=true;
			}
		}
		$update && writeover(D_P.'data/bbscache/sort_newpost.php',"<?php\r\n\$_NEWPOST = ".pw_var_export($_NEWPOST).";\r\n?>");
	}
}

/**
 * �����㷨
 *
 * @param mixed $key
 * @param mixed $val
 * @param array $array
 * @param integer $num
 * @param string $order
 * @return mixed
 */
function sort_array($key,$val,&$array,$num,$order=''){//$order='DESC'
	$array[$key] = $val;
	$order=='ASC' ? asort($array) : arsort($array);
	$count = count($array);
	if($count > $num){
		array_pop($array);
	}
	if($count >= $num){
		return end($array);
	}else{
		return 0;
	}
}
?>