<?php
!function_exists('readover') && exit('Forbidden');

function updateforum($fid,$lastinfo='') {
	global $db,$db_fcachenum;
	$fm = $db->get_one("SELECT fup,type,password,allowvisit,f_type FROM pw_forums WHERE fid='$fid'");
	if ($fm['type'] != 'category') {
		$subtopics = $subrepliess = 0;
		$query = $db->query("SELECT fid FROM pw_forums WHERE fup='$fid'");
		while ($subinfo = $db->fetch_array($query)) {
			@extract($db->get_one("SELECT COUNT(*) AS subtopic,SUM( replies ) AS subreplies FROM pw_threads WHERE fid='$subinfo[fid]' AND ifcheck='1'"));
			$subtopics   += $subtopic;
			$subrepliess += $subreplies;
			$query2 = $db->query("SELECT fid FROM pw_forums WHERE fup='$subinfo[fid]'");
			while ($subinfo2 = $db->fetch_array($query2)) {
				@extract($db->get_one("SELECT COUNT(*) AS subtopic,SUM( replies ) AS subreplies FROM pw_threads WHERE fid='$subinfo2[fid]' AND ifcheck='1'"));
				$subtopics   += $subtopic;
				$subrepliess += $subreplies;
			}
		}
		$rs       = $db->get_one("SELECT COUNT(*) AS topic,SUM( replies ) AS replies FROM pw_threads WHERE fid='$fid' AND ifcheck='1' AND topped<=3");
		$topic    = $rs['topic'];
		$replies  = $rs['replies'];
		$article  = $topic + $replies + $subtopics + $subrepliess;
		if (!$lastinfo) {
			$lt = $db->get_one("SELECT tid,author,postdate,lastpost,lastposter,subject FROM pw_threads WHERE fid='$fid' AND topped=0 AND ifcheck=1 ORDER BY lastpost DESC LIMIT 0,1");
			if ($lt['postdate'] == $lt['lastpost']) {
				$subject = addslashes(substrs($lt['subject'],26));
			} else {
				$subject = 'Re:'.addslashes(substrs($lt['subject'],26));
			}
			$author  = addslashes($lt['lastposter']);
			$lastinfo = $lt['tid'] ? $subject."\t".$author."\t".$lt['lastpost']."\t"."read.php?tid=$lt[tid]&page=e#a" : '' ;
		}
		$db->update("UPDATE pw_forumdata SET topic='$topic',article='$article',subtopic='$subtopics',lastpost='$lastinfo' WHERE fid='$fid'");
		if ($fm['password'] != '' || $fm['allowvisit'] != '' || $fm['f_type'] == 'hidden') {
			$lastinfo = '';
		}
		delfcache($fid,$db_fcachenum);
		if ($fm['type'] == 'sub') {
			updateforum($fm['fup'],$lastinfo);
		}
	}
}
function delfcache($fid,$num) {
	if ($num < 1) return;
	for ($i=1;$i<=$num;$i++) {
		P_unlink(D_P."data/bbscache/fcache_{$fid}_{$i}.php");
	}
}
function updatetop() {
	global $db;
	include(D_P.'data/bbscache/forum_cache.php');

	$toppeddb = $fupdb = $topfid = $fups = array();
	$fids = 0;
	foreach ($forum as $f=>$v) {
		if ($v['type']=='category') continue;
		$fids .= ','.$f;
		$fup = $v['fup'];
		if ($forum[$fup]['type']=='category') {
			$cateid=$fup;
		} elseif ($forum[$fup]['type']=='forum') {
			$cateid=$forum[$fup]['fup'];
		} elseif ($forum[$fup]['type']=='sub') {
			$fup=$forum[$fup]['fup'];
			$cateid=$forum[$fup]['fup'];
		}
		$fupdb[$f] = $cateid;
		$fups[$cateid][] = $f;
	}
	$query=$db->query("SELECT tid,fid,topped FROM pw_threads WHERE fid IN($fids) AND ifcheck='1' AND topped>'1'");
	while ($rt=$db->fetch_array($query)) {
		$topfid[$rt['fid']]['0']++;
		if ($rt['topped']=='3') {
			$toppeddb['3'][0]++;
			$toppeddb['3'][1] .= $toppeddb['3'][1] ? ','.$rt['tid'] : $rt['tid'];
		} elseif ($rt['topped']=='2') {
			$cateid = $fupdb[$rt['fid']];
			$toppeddb['2'][$cateid][0]++;
			$toppeddb['2'][$cateid][1] .= $toppeddb['2'][$cateid][1] ? ','.$rt['tid'] : $rt['tid'];
			foreach ($fups[$cateid] as $k=>$f) {
				$topfid[$f]['1']++;
			}
		}
	}
	writeover(D_P.'data/bbscache/toppeddb.php',"<?php\r\n\$toppeddb=".pw_var_export($toppeddb).";\r\n?>");

	$db->update("UPDATE pw_forumdata SET top1='".$toppeddb['3'][0]."',top2=0");
	foreach ($topfid as $key => $v) {
		$top2 = $v['0'];
		$top1 = $toppeddb['3'][0] + $v['1'] - $v['0'];
		$db->update("UPDATE pw_forumdata SET top1='".(int)$top1."',top2='".(int)$top2."' WHERE fid='$key'");
	}
}
function getattachtype($tid) {
	global $db,$pw_posts,$pw_tmsgs;
	$attach=$db->get_one("SELECT aid FROM $pw_posts WHERE tid='$tid' AND aid<>'' ORDER BY postdate DESC LIMIT 1");
	if (!$attach) {
		$attach=$db->get_one("SELECT aid FROM $pw_tmsgs WHERE tid='$tid'");
	}
	if ($attach) {
		$attachs= unserialize(stripslashes($attach['aid']));
		$last=@array_pop($attachs);
		$type=$last['type'];
		switch($type) {
			case 'img': return 1;
			case 'txt': return 2;
			case 'zip': return 3;
		}
	}
	return 0;
}
function dtchange($user,$wwz,$postn,$money) {
	global $db;
	$user=='guest' || $db->update("UPDATE pw_memberdata SET postnum=postnum+'$postn',rvrc=rvrc+'$wwz',money=money+'$money' WHERE uid='$user'");
}
function delete_tag($tids) {
	global $db;
	if ($tids) {
		$tagdb = array();
		$query = $db->query("SELECT tagid FROM pw_tagdata WHERE tid IN($tids)");
		while (@extract($db->fetch_array($query))) {
			$tagdb[$tagid]++;
		}
		foreach ($tagdb as $tagid=>$num) {
			$db->update("UPDATE pw_tags SET num=num-'$num' WHERE tagid='$tagid'");
		}
		$db->update("DELETE FROM pw_tagdata WHERE tid IN($tids)");
	}
}
function delete_att($attachdb,$ifdel=true) {
	global $db_ftpweb,$attachdir,$db,$ftp;
	$delaids = '';
	foreach ($attachdb as $attachs) {
		$attachs = unserialize(stripslashes($attachs));
		foreach ($attachs as $key => $value) {
			is_numeric($key) && $delaids .= $key.',';
			if ($ifdel) {
				if ($ftp && !file_exists($attachdir."/".$value['attachurl'])) {
					$ftp->delete($value['attachurl']);
					$value['ifthumb'] && $ftp->delete("thumb/$value[attachurl]");
				} else {
					P_unlink("$attachdir/$value[attachurl]");
					$value['ifthumb'] && P_unlink("$attachdir/thumb/$value[attachurl]");
				}
			}
		}
	}
	$delaids = substr($delaids,0,-1);
	
	if($delaids){
		if($ifdel){
			$db->update("DELETE FROM pw_attachs WHERE aid IN($delaids)");
		} elseif($db_recycle){
			$db->update("UPDATE pw_attachs SET fid='0' WHERE aid IN($delaids)");
		}
	}
	return $delaids;
}
?>