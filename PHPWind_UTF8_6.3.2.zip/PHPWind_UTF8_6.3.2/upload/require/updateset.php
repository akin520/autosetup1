<?php
!function_exists('readover') && exit('Forbidden');

function write_config($newconfig=array()){
	global $tplpath;
	if (!empty($newconfig) && is_array($newconfig)) {
		foreach ($newconfig as $key => $value) {
			${$key} = $value;
		}
	} else {
		include D_P.'data/sql_config.php';
	}
	$db_hostweb!=0 && $db_hostweb = 1;
	!$pconnect && $pconnect = 0;
	$att_url = $mg_a = $mg_p = '';
	foreach ($manager as $value) {
		$mg_a .= ",'$value'";
	}
	foreach ($manager_pwd as $value) {
		$mg_p .= ",'$value'";
	}
	foreach ($attach_url as $value) {
		$att_url .= ",'$value'";
	}
	$mg_a = substr($mg_a,1); $mg_p = substr($mg_p,1); $att_url = substr($att_url,1);
	if (file_exists(R_P."template/admin_$tplpath")) {
		include R_P."template/admin_$tplpath/cp_lang_all.php";
	} else {
		include R_P."template/admin/cp_lang_all.php";
	}
	$writetofile =
"<?php
/**
$lang[sqlinfo]
*/
	$lang[dbhost]
\$dbhost = '$dbhost';

	$lang[dbuser]
\$dbuser = '$dbuser';
\$dbpw = '$dbpw';

	$lang[dbname]
\$dbname = '$dbname';

	$lang[database]
\$database = '$database';

	$lang[PW]
\$PW = '$PW';

	$lang[pconnect]
\$pconnect = '$pconnect';

/**
$lang[charset]
*/
\$charset = '$charset';

/**
$lang[managerinfo]
*/
	$lang[managername]
\$manager = array($mg_a);

	$lang[managerpwd]
\$manager_pwd = array($mg_p);

/**
$lang[hostweb]
*/
\$db_hostweb = '$db_hostweb';

/**
$lang[attach_url]
*/
\$attach_url = array($att_url);
".'?>';
	writeover(D_P.'data/sql_config.php',$writetofile);
}
?>