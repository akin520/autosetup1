<?php
!function_exists('readover') && exit('Forbidden');

PwNewDB();
$a_sql	= $u ? "uid='$u'" : "username='$a'";
$u_db	= $db->get_one("SELECT uid AS u FROM pw_members WHERE $a_sql");// UB

if ($u_db) {
	$u		= $u_db['u'];
	$u_db	= $db->get_one("SELECT adsips FROM pw_memberinfo WHERE uid='$u'");
	if ($u_db) {
		$u_db['adsips'] = strlen($u_db['adsips']) > 15000 ? '' : $u_db['adsips']."\t";
		if (strpos("\t".$u_db['adsips']."\t","\t".$onlineip."\t")===false) {
			$db->update("UPDATE pw_memberinfo SET adsips='$u_db[adsips]$onlineip' WHERE uid='$u'");
			$db->update("UPDATE pw_memberdata SET credit=credit+1 WHERE uid='$u'");
		}
	} else {
		$db->update("INSERT INTO pw_memberinfo(uid,adsips) VALUES('$u','$onlineip')");
		$db->update("UPDATE pw_memberdata SET credit=credit+1 WHERE uid='$u'");
	}
}
Cookie('userads','',0);
?>