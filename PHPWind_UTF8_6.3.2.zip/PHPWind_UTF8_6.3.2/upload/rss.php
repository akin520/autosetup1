<?php
define('RSS',1);
require_once('global.php');

$Rss_newnum=20;
$Rss_listnum=20;
$Rss_updatetime=10;

if($tid){
	$rs = $db->get_one("SELECT t.subject,t.fid,t.ptable,f.name,f.allowvisit,f.f_type FROM pw_threads t LEFT JOIN pw_forums f USING(fid) WHERE tid='$tid'");
	if($rs['allowvisit'] != '' || $rs['f_type'] == 'hidden'){
		echo"<META HTTP-EQUIV='Refresh' CONTENT='0; URL=rss.php'>";exit;
	}
	require_once(R_P.'require/rss.php');
	$title = substrs($rs['subject'],40);
	$channel = array(
		'title'			=>  $title,
		'link'			=>  "$db_bbsurl/read.php?tid=$tid",
		'description'	=>  "Latest $Rss_newnum replies of $title",
		'copyright'		=>  "Copyright(C) $db_bbsname",
		'generator'		=>  "PHPWind BLOG by PHPWind Studio",
		'lastBuildDate' =>  date('r'),
	);
	$image = array(
		'url'		  =>  "$imgpath/rss.gif",
		'title'		  =>  'PHPWind Board',
		'link'		  =>  $db_bbsurl,
		'description' =>  $db_bbsname,
	);
	$Rss = new Rss(array('xml'=>"1.0",'rss'=>"2.0",'encoding'=>$db_charset));
	$Rss->channel($channel);
	$Rss->image($image);
	
	$pw_posts = GetPtable($rs['ptable']);
	$query = $db->query("SELECT pid,subject,author,postdate,anonymous,content FROM $pw_posts WHERE tid='$tid' ORDER BY postdate DESC LIMIT $Rss_listnum");
	while($rt=$db->fetch_array($query)){
		$rt['content'] = preg_replace("/\[post\](.+?)\[\/post\]/is","",$rt['content']);
		$rt['content'] = preg_replace("/\[hide=(.+?)\](.+?)\[\/hide\]/is","",$rt['content']);
		$rt['content'] = preg_replace("/\[sell=(.+?)\](.+?)\[\/sell\]/is","",$rt['content']);
		$rt['content'] = substrs($rt['content'],300);
		$rt['anonymous'] && $rt['author'] = $db_anonymousname;
		$item = array(
			'title'       =>  $rt['subject'],
			'description' =>  $rt['content'],
			'link'        =>  "$db_bbsurl/read.php?tid=$tid#$rt[pid]",
			'author'      =>  $rt['author'],
			'category'    =>  strip_tags($rs['name']),
			'pubdate'     =>  date('r',$rt['postdate']),
		);
		$Rss->item($item);
	}
	$all = $Rss->rssHeader;
	$all .= $Rss->rssChannel;
	$all .= $Rss->rssImage;
	$all .= $Rss->rssItem;
	$all .= "</channel></rss>";
	header("Content-type: application/xml");
	echo $all;exit;
} else{
	$cache_path=D_P.'data/bbscache/rss_'.$fid.'_cache.xml';
	if($timestamp-@filemtime($cache_path) > $Rss_updatetime*60){
		require_once(R_P.'require/rss.php');
		require_once(D_P.'data/bbscache/forum_cache.php');		
		if($db_tlist){
			@extract($db->get_one("SELECT MAX(tid) AS tid FROM pw_threads"));
			$pw_tmsgs = GetTtable($tid);
		}
		if($fid){
			$rt=$db->get_one("SELECT allowvisit,f_type FROM pw_forums WHERE fid='$fid'");
			if($rt['allowvisit'] != '' || $rt['f_type'] == 'hidden'){
				echo"<META HTTP-EQUIV='Refresh' CONTENT='0; URL=rss.php'>";exit;
			}
		}
		$sql = '';
		if($fid){
			$description="Latest $Rss_newnum article of ".$forum[$fid]['name'];
			$sql="WHERE t.fid='$fid' AND ifcheck=1 AND topped='0' AND lastpost>'".($timestamp-604800)."' ORDER BY lastpost DESC LIMIT $Rss_listnum";
		} else{
			$fids=$extra='';
			$query=$db->query("SELECT fid FROM pw_forums WHERE allowvisit='' AND f_type!='hidden'");
			while($rt=$db->fetch_array($query)){
				$fids.=$extra."'".$rt['fid']."'";
				$extra=',';
			}

			$description="Latest $Rss_newnum article of all forums";
			$fids && $sql="WHERE fid IN($fids) AND ifcheck=1 AND topped='0' AND postdate>'".($timestamp-604800)."' ORDER BY postdate DESC LIMIT $Rss_newnum";
		}
		$channel=array(
			'title'			=>  $db_bbsname,
			'link'			=>  $db_bbsurl,
			'description'	=>  $description,
			'copyright'		=>  "Copyright(C) $db_bbsname",
			'generator'		=>  "PHPWind BLOG by PHPWind Studio",
			'lastBuildDate' =>  date('r'),
		);
		$image = array(
			'url'		  =>  "$imgpath/rss.gif",
			'title'		  =>  'PHPWind Board',
			'link'		  =>  $db_bbsurl,
			'description' =>  $db_bbsname,
		);
		$Rss = new Rss(array('xml'=>"1.0",'rss'=>"2.0",'encoding'=>$db_charset));
		$Rss->channel($channel);
		$Rss->image($image);
		if ($sql) {
			$query=$db->query("SELECT t.tid,t.fid,t.subject,t.author,t.postdate,t.anonymous,tm.content FROM pw_threads t RIGHT JOIN $pw_tmsgs tm ON tm.tid=t.tid $sql");
			while($rt=$db->fetch_array($query)){
				$rt['content'] = preg_replace("/\[post\](.+?)\[\/post\]/is","",$rt['content']);
				$rt['content'] = preg_replace("/\[hide=(.+?)\](.+?)\[\/hide\]/is","",$rt['content']);
				$rt['content'] = preg_replace("/\[sell=(.+?)\](.+?)\[\/sell\]/is","",$rt['content']);
				$rt['content'] = substrs($rt['content'],300);
				$rt['anonymous'] && $rt['author'] = $db_anonymousname;
				$item = array(
					'title'       =>  $rt['subject'],
					'description' =>  $rt['content'],
					'link'        =>  "$db_bbsurl/read.php?tid=$rt[tid]",
					'author'      =>  $rt['author'],
					'category'    =>  $forum[$rt['fid']]['name'],
					'pubdate'     =>  date('r',$rt['postdate']),
				);
				$Rss->item($item);
			}
		}
		$Rss->generate($cache_path);
	}
	header("Content-type: application/xml");
	@readfile($cache_path);
	exit;
}
?>