<?php
require_once('global.php');
require_once(R_P.'require/header.php');
InitGP(array('action'));
!$action && $action='sendpwd';

if ($action == 'sendpwd') {

	if (!$_POST['step']) {

		require_once(PrintEot('sendpwd'));footer();

	} elseif ($_POST['step']==2) {

		($db_gdcheck & 16) && GdConfirm($_POST['gdcode']);
		InitGP(array('pwuser','email','question','customquest','answer'));
		$userarray = $db->get_one("SELECT password,safecv,email,regdate FROM pw_members WHERE username='$pwuser'");
		if($userarray['email'] != $email){
			Showmsg('email_error',1);
		}
		$safecv='';
		if($db_ifsafecv){
			require_once(R_P.'require/checkpass.php');
			$safecv=questcode($question,$customquest,$answer);
			if($userarray['safecv'] != $safecv){
				Showmsg('safecv_error',1);
			}
		}
		if($userarray){
			if($timestamp-GetCookie('lastwrite')<=60){
				$gp_postpertime = 60;
				Showmsg('sendpwd_limit',1);
			}
			Cookie('lastwrite',$timestamp);
			$send_email = $userarray['email'];
			$submit     = $userarray['regdate'];
			$submit    .= md5(substr($userarray['password'],10));
			$sendtoname = $pwuser;
			$pwuser   = rawurlencode($pwuser);
			require_once(R_P.'require/sendemail.php');
			$sendinfo = sendemail($send_email,'email_sendpwd_subject','email_sendpwd_content','email_additional');
			if($sendinfo === true){
				Showmsg('mail_success',1);
			} else{
				Showmsg(is_string($sendinfo) ? $sendinfo : 'mail_failed',1);
			}
		} else{
			$errorname = Char_cv($pwuser);
			Showmsg('user_not_exists',1);
		}
	}
} elseif($action=='getback'){
	InitGP(array('pwuser','submit'));
	if(CkInArray($pwuser,$manager)){
		Showmsg('undefined_action',1);
	}
	$detail = $db->get_one("SELECT password,regdate FROM pw_members WHERE username='$pwuser'");
	if($detail){
		$is_right  = $detail['regdate'];
		$is_right .= md5(substr($detail['password'],10));
		if($submit==$is_right){
			if(!$_POST['jop']){
				require_once PrintEot('getpwd');footer();
			} elseif($_POST['jop']==2){
				InitGP(array('new_pwd','pwdreapt'));
				if($new_pwd!=$pwdreapt || !$new_pwd){
					Showmsg('password_confirm',1);
				} else{
					$new_pwd = stripslashes($new_pwd);
					$new_pwd = str_replace("\t","",$new_pwd);
					$new_pwd = str_replace("\r","",$new_pwd);
					$new_pwd = str_replace("\n","",$new_pwd);
					$new_pwd = md5($new_pwd);
					$db->update("UPDATE pw_members SET password='$new_pwd' WHERE username='$pwuser'");
					Showmsg('password_change_success',1);
				}
			}
		} else{
			Showmsg('password_confirm_fail',1);
		}
	} else{
		$errorname = Char_cv($pwuser);
		Showmsg('user_not_exists',1);
	}
}
?>