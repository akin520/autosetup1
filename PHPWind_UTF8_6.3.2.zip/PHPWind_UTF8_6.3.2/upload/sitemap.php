<?php
require_once('global.php');

@include_once(D_P.'data/bbscache/sm_config.php');
$cachefile = D_P."data/bbscache/sitemap.xml";
!$sm_updatePeri && $sm_updatePeri = 12;

if($timestamp-@filemtime($cachefile)>=$sm_updatePeri*3600){
	$sm_num < 1 && $sm_num = 1000;
	$mapinfo = "<?xml version =\"1.0\" encoding=\"GB2312\"?>\r\n<document xmlns:bbs=\"http://ps-spider01.baidu.com:8090/sitemap/sitemap.xsd\">\r\n\t<webSite>$db_bbsurl</webSite>\r\n\t<webMaster>$db_ceoemail</webMaster>\r\n\t<updatePeri>$sm_updatePeri</updatePeri>\r\n\t<updatetime>".get_date($timestamp)."</updatetime>\r\n\t<version>PHPWind $wind_version Certificate</version>\r\n";
	if($db_tlist){
		$rt = $db->get_one("SELECT MAX(tid) AS mtid FROM pw_threads");
		$pw_tmsgs = GetTtable($rt['mtid']);
	} else{
		$pw_tmsgs = 'pw_tmsgs';
	}
	$query = $db->query("SELECT t.tid,t.fid,t.subject,t.postdate,t.lastpost,t.hits,t.replies,t.digest,tm.content FROM pw_threads t LEFT JOIN $pw_tmsgs tm ON t.tid=tm.tid LEFT JOIN pw_forums f ON t.fid=f.fid WHERE f.password='' AND f.allowvisit='' AND f.f_type<>'hidden' ORDER BY t.postdate DESC LIMIT $sm_num");
	while($rt = $db->fetch_array($query)){
		$mapinfo .= "\t<item>\r\n\t\t<link>$db_bbsurl/read.php?tid=$rt[tid]</link>\r\n\t\t<title>".str_replace('&','&amp;',$rt['subject'])."</title>\r\n\t\t<pubDate>".get_date($rt['postdate'])."</pubDate>\r\n\t\t<bbs:lastDate>".get_date($rt['lastpost'])."</bbs:lastDate>\r\n\t\t<bbs:reply>$rt[replies]</bbs:reply>\r\n\t\t<bbs:hit>$rt[hits]</bbs:hit>\r\n\t\t<bbs:mainLen>".strlen($rt['content'])."</bbs:mainLen>\r\n\t\t<bbs:boardid>$rt[fid]</bbs:boardid>\r\n\t\t<bbs:pick>$rt[digest]</bbs:pick>\r\n\t</item>\r\n";
	}
	$mapinfo .= "</document>";
	echo $mapinfo;
	writeover($cachefile,$mapinfo);
} else{
	readfile($cachefile);
}
?>