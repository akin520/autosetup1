<?php
$wind_in='st';
require_once('global.php');
$groupid=='guest'&&	Showmsg('not_login');
!$gp_allowsort && Showmsg('sort_group_right');

require_once(R_P.'require/header.php');
$per = 24;//����ʱ�䣬Сʱ��λ
$cachenum = 20;//��ѯ��
$cachetime = '';
$action = Char_cv($_GET['action']);
if (empty($action)) {
	@include_once(D_P.'data/bbscache/olcache.php');
	$usertotal = $guestinbbs+$userinbbs;
	$bbsinfo=$db->get_one("SELECT id,newmember,totalmember,higholnum,higholtime,tdtcontrol,yposts,hposts FROM pw_bbsinfo WHERE id=1");
	$bbsinfo['higholtime'] = get_date($bbsinfo['higholtime']);
	$rs=$db->get_one("SELECT SUM(fd.topic) as topic,SUM(fd.subtopic) as subtopic,SUM(fd.article) as article,SUM(fd.tpost) as tposts FROM pw_forums f LEFT JOIN pw_forumdata fd USING(fid) WHERE f.ifsub='0' AND f.cms!='1'");
	$topic=$rs['topic']+$rs['subtopic'];
	$article=$rs['article'];
	$tposts=$rs['tposts'];
	if($bbsinfo['tdtcontrol']!=$tdtime){
		if($db_hostweb == 1){
			$db->update("UPDATE pw_bbsinfo SET yposts='$tposts',tdtcontrol='$tdtime' WHERE id=1");
			$db->update("UPDATE pw_forumdata SET tpost=0 WHERE tpost<>'0'");
		}
		if(file_exists(D_P.'data/bbscache/ip_cache.php')){
			P_unlink(D_P.'data/bbscache/ip_cache.php');
		}
	}
	require PrintEot('sort');footer();
} elseif($action=='ipstate'){
	InitGP(array('type','year','month'));
	!$type && $type='month';
	if($type=='month'){
		$c_month=get_date($timestamp,'Y-n');
		$c_year=is_numeric($year) ? $year : get_date($timestamp,'Y');
		$p_year=$c_year-1;
		$n_year=$c_year+1;
		$summip=0;
		$m_ipdb=array();
		$query=$db->query("SELECT month,sum(nums) as nums FROM pw_ipstates WHERE month like '$c_year%' group by month");
		while($rt=$db->fetch_array($query)){
			$summip+=$rt['nums'];
			$key=substr($rt['month'],strrpos($rt['month'],'-')+1);
			$rt['_month'] = str_replace('-','_',$rt['month']);
			$m_ipdb[$key]=$rt;
		}
		for($i=1;$i<=12;$i++){
			!$m_ipdb[$i] && $m_ipdb[$i]=array('month'=>$c_year.'-'.$i,'_month'=>$c_year.'_'.$i,'nums'=>'0');
		}
		ksort($m_ipdb);
	} elseif($type=='day'){
		$c_month=$month ? str_replace('_','-',$month) : get_date($timestamp,'Y-n');
		list($Y,$M)=explode('-',$c_month);
		if(!is_numeric($Y) || !is_numeric($M)){
			Showmsg('undefined_action');
		}
		if($M==1){
			$p_month=($Y-1).'_12';
			$n_month=$Y.'_2';
		}elseif($M==12){
			$p_month=$Y.'_11';
			$n_month=($Y+1).'_1';
		}else{
			$p_month=$Y.'_'.($M-1);
			$n_month=$Y.'_'.($M+1);
		}
		$sumip=0;
		$d_ipdb=array();
		$query=$db->query("SELECT day,nums FROM pw_ipstates WHERE month='$c_month' ORDER BY day");
		while($rt=$db->fetch_array($query)){
			$sumip+=$rt['nums'];
			$key=substr($rt['day'],strrpos($rt['day'],'-')+1);
			$d_ipdb[$key]=$rt;
		}
		for($i=1;$i<=get_date(PwStrtoTime($c_month.'-1'),'t');$i++){
			!$d_ipdb[$i] && $d_ipdb[$i]=array('day'=>"$c_month-$i",'nums'=>'0');
		}
		ksort($d_ipdb);
	}
	require PrintEot('sort');footer();
} elseif($action=='online'){
	require_once(R_P.'require/forum.php');
	require_once(D_P.'data/bbscache/forum_cache.php');
	require_once(D_P.'data/bbscache/level.php');
	InitGP(array('page'));
	(!is_numeric($page) || $page<1) && $page=1;

	$ltitle['-1']='Member';
	$threaddb = array();
	if($db_online){
		require_once GetLang('action');
		$limit = "LIMIT ".($page-1)*$db_perpage.",$db_perpage";
		$rt    = $db->get_one("SELECT COUNT(*) AS sum FROM pw_online");
		$pages = numofpage($rt['sum'],$page,ceil($rt['sum']/$db_perpage),"sort.php?action=online&");
		$count = $rt['sum'];
		$query = $db->query("SELECT * FROM pw_online $limit");
		while($rt = $db->fetch_array($query)){
			$groupid!=3 && $rt['ip'] = '-';
			$rt['forum']	= $forum[$rt['fid']]['name'];
			$rt['action']	= $rt['forum'] ? substrs(strip_tags($rt['forum']),13) : $lang[$rt['action']];
			$rt['lasttime']	= get_date($rt['lastvisit']);
			$rt['group']	= $ltitle[$rt['groupid']];
			if($rt['tid']){
				$rt['atc']	= $rt['tid'];
			}
			if(!$rt['uid']){
				$rt['username'] = $rt['group'] = 'Guest';
			}
			$threaddb[] = $rt;
		}
	} else{
		$onlinedb=openfile(D_P.'data/bbscache/online.php');
		if(count($onlinedb)==1){
			$onlinedb=array();
		} else{
			unset($onlinedb[0]);
		}
		$online_A=$guest_A=array();
		foreach($onlinedb as $online){
			if(trim($online)){
				$detail=explode("\t",$online);
				$online_A[$online]=$detail[1];
			}
		}
		unset($onlinedb);
		@asort($online_A);
		$online_A=@array_keys($online_A);

		$guestdb=openfile(D_P.'data/bbscache/guest.php');
		if(count($guestdb)==1){
			$guestdb=array();
		} else{
			unset($guestdb[0]);
		}
		foreach($guestdb as $online){
			if(trim($online)){
				$detail=explode("\t",$online);
				$guest_A[$online]=$detail[1];
			}
		}
		unset($guestdb);
		@asort($guest_A);
		$guest_A=@array_keys($guest_A);
		$online_A = array_merge ($online_A, $guest_A);
		unset($guest_A);
		$count=count($online_A);

		$numofpage=$count%$db_perpage==0 ? floor($count/$db_perpage) : floor($count/$db_perpage)+1;
		$numofpage && $page>$numofpage && $page=$numofpage;
		$pages=numofpage($count,$page,$numofpage,"sort.php?action=online&");
		$start=($page-1)*$db_perpage;
		$end=min($start+$db_perpage,$count);

		for($i=$start;$i<$end;$i++){
			if(!$online_A[$i]) continue;
			$thread=explode("\t",$online_A[$i]);
			if(count($thread)<10){
				$thread['username']='Guest';
				$thread['ip']=CkInArray($windid,$manager) ? $thread[0] : "-";
				$thread['group']='Guest';
				$thread['action']=$thread[4];
				$thread['lasttime']=$thread[5];
				$thread[2]=str_replace('<FiD>','',$thread[2]);
				$forum[$thread[2]]['name'] && $thread['forum']="<a href='thread.php?fid=$thread[2]'>".$forum[$thread[2]]['name']."</a>";
				$thread['atc']=$thread[3];
			} else{
				$thread['username']=$thread[0];
				$thread['ip']=CkInArray($windid,$manager) ? $thread[2] : "-";
				$thread['group']=$ltitle[$thread[5]];
				$thread['action']=$thread[6];
				$thread['lasttime']=$thread[7];
				$forum[$thread[3]]['name'] && $thread['forum']="<a href='thread.php?fid=$thread[3]'>".$forum[$thread[3]]['name']."</a>";
				$thread['atc']=$thread[4];
			}
			$threaddb[]=$thread;
		}
	}
	require_once PrintEot('sort');footer();
} elseif($action=='member'){
	$_SORTDB = $member = array();
	list($db_moneyname,$db_moneyunit,$db_rvrcname,$db_rvrcunit,$db_creditname,$db_creditunit)=explode("\t",$db_credits);
	$array = array('postnum','todaypost','monthpost','onlinetime','rvrc','money','credit','currency');
	foreach ($_CREDITDB as $key => $value) {
		array_push($array,$key);
	}
	if ($db_ifsort&1) {
		require_once (R_P.'require/rebang.php');
		$rebang = new reBang();
		$member = $rebang->getReBang($array,20);
		foreach ($member as $key=>$value) {
			foreach ($value as $v ) {
				$_SORTDB[$key][] = array($v['id'],$v['name'],$v['value']);
			}
		}
	} else {
		$cachetime = @filemtime(D_P."data/bbscache/member_sort.php");
		if(!$per || !file_exists(D_P."data/bbscache/member_sort.php") || ($timestamp-$cachetime>$per*3600)){
			$step = $_GET['step'] ? intval($_GET['step']) : 0;
			if ($array[$step]) {
				@include(D_P."data/bbscache/member_tmp.php");
				require_once (R_P.'require/rebang.php');
				$rebang = new reBang();
				$member = $rebang->getMember(20,$array[$step]);
				unset($_SORTDB[$array[$step]]);
				foreach ($member as $v ) {
					$_SORTDB[$array[$step]][] = array($v['id'],$v['name'],$v['value']);
				}
				$step++;
				writeover(D_P.'data/bbscache/member_tmp.php',"<?php\r\n\$_SORTDB=".pw_var_export($_SORTDB).";\r\n?>");
				refreshto("sort.php?action=member&step=$step",'update_cache');
			} else {
				@include(D_P."data/bbscache/member_tmp.php");
				writeover(D_P.'data/bbscache/member_sort.php',"<?php\r\n\$_SORTDB=".pw_var_export($_SORTDB).";\r\n?>");
				P_unlink(D_P."data/bbscache/member_tmp.php");
				refreshto("sort.php?action=member",'update_cache');
			}
		}
		@include(D_P."data/bbscache/member_sort.php");
		$cachetime=get_date($cachetime+$per*3600);
	}
	require_once GetLang('sort');
	$show_url="profile.php?action=show&uid";
	require PrintEot('sort');footer();
} elseif($action=='forum'){
	require_once(R_P.'require/rebang.php');
	$rebang = new reBang();
	$_FORUMDB = $rebang->getReBang(array('topic','article','tpost'));
	foreach ($_FORUMDB as $key=>$value) {
		foreach ($value as $k=>$v) {
			$_SORTDB[$key][] = array($v['id'],$v['name'],$v['value']);
		}
	}

	require_once GetLang('sort');
	$show_url="thread.php?fid";
	include(D_P."data/bbscache/forum_sort.php");
	require PrintEot('sort');footer();
} elseif($action=='article'){
	$_SORTDB = $article = array();
	$array = array('digest','replies','hits');
	if ($db_ifsort&2) {
		require_once (R_P.'require/rebang.php');
		$rebang = new reBang();
		$article = $rebang->getReBang($array,20);
		foreach ($article as $key=>$value) {
			foreach ($value as $v ) {
				$v['name'] = substrs($v['name'],30);
				$_SORTDB[$key][] = array($v['id'],$v['name'],$v['value']);
			}
		}
	} else {
		$cachetime = @filemtime(D_P."data/bbscache/article_sort.php");
		if(!$per || !file_exists(D_P."data/bbscache/article_sort.php") || ($timestamp-$cachetime>$per*3600)){
			$step = $_GET['step'] ? intval($_GET['step']) : 0;
			if ($array[$step]) {
				@include(D_P."data/bbscache/article_tmp.php");
				require_once (R_P.'require/rebang.php');
				$rebang = new reBang();
				$article = $rebang->getPost(20,$array[$step]);
				unset($_SORTDB[$array[$step]]);
				foreach ($article as $v ) {
					$v['name'] = substrs($v['name'],30);
					$_SORTDB[$array[$step]][] = array($v['id'],$v['name'],$v['value']);
				}
				$step++;
				writeover(D_P.'data/bbscache/article_tmp.php',"<?php\r\n\$_SORTDB=".pw_var_export($_SORTDB).";\r\n?>");
				refreshto("sort.php?action=article&step=$step",'update_cache');
			} else {
				@include(D_P."data/bbscache/article_tmp.php");
				writeover(D_P.'data/bbscache/article_sort.php',"<?php\r\n\$_SORTDB=".pw_var_export($_SORTDB).";\r\n?>");
				P_unlink(D_P."data/bbscache/article_tmp.php");
				refreshto("sort.php?action=article",'update_cache');
			}
		}
		@include(D_P."data/bbscache/article_sort.php");
		$cachetime = get_date($cachetime+$per*3600);
	}

	require_once GetLang('sort');
	include(D_P.'data/bbscache/forum_cache.php');
	$show_url="read.php?tid";
	require PrintEot('sort');footer();
} elseif($action=='team'){
	list($db_moneyname,,$db_rvrcname,,$db_creditname,)=explode("\t",$db_credits);
	$lockfile = D_P.'data/bbscache/lock_team.txt';
	$fp = fopen($lockfile,'wb+');
	flock($fp,LOCK_EX);
	$cachetime=@filemtime(D_P."data/bbscache/team_sort.php");
	if(!$per || $timestamp-$cachetime>$per*3600){
		include_once(D_P.'data/bbscache/level.php');
		$gids=0;
		$query=$db->query("SELECT gid FROM pw_usergroups WHERE gptype='system' AND gid NOT IN(5,6,7)");
		while($rt=$db->fetch_array($query)){
			$gids.=','.$rt['gid'];
		}
		$teamdb=$tfdb=$fadmindb=$forumdb=$admin_a=$men=array();
		$query=$db->query("SELECT fid,forumadmin FROM pw_forums WHERE cms!='1' AND forumadmin!=''");
		while($rt=$db->fetch_array($query)){
			$fuids = explode(',',substr($rt['forumadmin'],1,-1));
			foreach($fuids as $key=>$val){
				if($val){
					$tfdb[$rt['fid']][]=$val;
					$admin_a[]=addslashes($val);
				}
			}
		}

		$uids  = '';
		$query = $db->query("SELECT m.uid,m.username,m.groupid,m.groups,m.memberid,md.lastvisit,md.lastpost,md.postnum,md.rvrc,md.money,md.onlinetime,md.monoltime,md.monthpost FROM pw_members m LEFT JOIN pw_memberdata md USING(uid) WHERE m.groupid IN($gids)");
		while($rt = $db->fetch_array($query)){
			$men[$rt['uid']] = $rt;
		}
		if(!empty($admin_a)){
			$admin_a = array_unique($admin_a);
			$fname = "'".implode("','",$admin_a)."'";
			$query = $db->query("SELECT m.uid,m.username,m.groupid,m.groups,m.memberid,md.lastvisit,md.lastpost,md.postnum,md.rvrc,md.money,md.onlinetime,md.monoltime,md.monthpost FROM pw_members m LEFT JOIN pw_memberdata md USING(uid) WHERE m.username IN($fname)");
			while($rt = $db->fetch_array($query)){
				$men[$rt['uid']] = $rt;
			}
		}
		foreach($men as $key=>$rt){
			$rt['leavedays'] = floor(($timestamp-$rt['lastvisit'])/86400);
			$rt['lastpost'] < $montime && $rt['monthpost'] = 0;
			$rt['lastpost']  = get_date($rt['lastpost']);
			$rt['onlinetime']= round($rt['onlinetime']/3600,2);
			$rt['monoltime'] = $rt['lastvisit'] > $montime ? round($rt['monoltime']/3600,2) : 0;
			$rt['systitle'] = $ltitle[$rt['groupid']];
			$rt['memtitle'] = $ltitle[$rt['memberid']];
			$rt['rvrc'] = floor($rt['rvrc']/10);
			if($rt['groupid']!=5 && $rt['groupid']!='-1'){
				$teamdb[] = $rt;
			}
			if($rt['groupid']==5 || strpos($rt['groups'],',5,')!==false){
				$rt['hits'] = $rt['post'] = 0;
				$fadmindb[$rt['uid']] = $rt;
				$uids .= $uids ? ','.$rt['uid'] : $rt['uid'];
			}
		}

		if ($uids) {
			$query = $db->query("SELECT COUNT(*) AS post,SUM(hits) AS count,authorid FROM pw_threads WHERE postdate>'$montime' AND authorid IN($uids) GROUP BY authorid");
			while ($rt = $db->fetch_array($query)) {
				$fadmindb[$rt['authorid']]['hits'] = $rt['count'];
				$fadmindb[$rt['authorid']]['post'] = $rt['post'];
			}
		}
		foreach ($tfdb as $fid=>$value) {
			foreach ($fadmindb as $key=>$val){
				if (in_array($val['username'],$value)) {
					$forumdb[$fid][$val['uid']]=$val;
				}
			}
		}
		writeover(D_P.'data/bbscache/team_sort.php',"<?php\r\n\$teamdb=".pw_var_export($teamdb).";\r\n\$forumdb=".pw_var_export($forumdb).";\n?>");
	} else{
		include(D_P.'data/bbscache/team_sort.php');
	}
	fclose($fp);
	$cachetime=get_date($cachetime+$per*3600);
	include_once(D_P.'data/bbscache/forum_cache.php');

	require PrintEot('sort');footer();
} elseif($action=='admin'){
	$thismonth = get_date($timestamp,'n');
	InitGP(array('month','type'));

	$baseurl = 'sort.php?action=admin';
	if (!$month || !file_exists(D_P.'data/bbscache/admin_sort_'.$month.".php")) {
		$month = $thismonth;
	} else {
		$baseurl .= "&month=$month";
	}
	$cachetime = @filemtime(D_P."data/bbscache/admin_sort_".$month.".php");
	include_once(D_P.'data/bbscache/level.php');

	if ((!$per || $timestamp-$cachetime>$per*3600) && $month==$thismonth) {
		$gids  = 0;
		$query = $db->query("SELECT gid FROM pw_usergroups WHERE gptype='system' AND gid NOT IN(6,7)");
		while ($rt = $db->fetch_array($query)) {
			$gids .= ','.$rt['gid'];
		}
		$admindb = array();
		$query = $db->query("SELECT uid,username,groupid,groups FROM pw_members WHERE groupid IN($gids) ORDER BY groupid");
		while ($rt = $db->fetch_array($query)) {
			$admindb[$rt['username']] = array('uid'=>$rt['uid'],'gid'=>$rt['groupid'],'total'=>0);
		}
		$query = $db->query("SELECT COUNT(*) AS count,username2 AS manager,type FROM pw_adminlog WHERE timestamp>'$montime' GROUP BY username2,type");
		while ($rt = $db->fetch_array($query)) {
			if (isset($admindb[$rt['manager']])) {
				$admindb[$rt['manager']][$rt['type']] = $rt['count'];
				$admindb[$rt['manager']]['total'] += $rt['count'];
			}
		}
		writeover(D_P."data/bbscache/admin_sort_".$month.".php","<?php\n\$admindb=".pw_var_export($admindb).";\n?>");
	} else {
		include Pcv(D_P."data/bbscache/admin_sort_".$month.".php");
	}
	$cachetime = get_date($cachetime+$per*3600);
	$sort_a = $month_a = array();
	$fg = opendir(D_P.'data/bbscache/');
	while ($othermonth=readdir($fg)) {
		if (eregi("^admin_sort_[1-9][0-2]?\.php$",$othermonth)) {
			$year = get_date(filemtime(D_P.'data/bbscache/'.$othermonth),'Y');
			$othermonth = str_replace(array(".php","admin_sort_"),array("",""),$othermonth);
			$a_key = $year.($othermonth>9 ? $othermonth : '0'.$othermonth);
			$month_a[$a_key] = $othermonth==$month ? "<b>&nbsp;{$year}-{$othermonth}</b>" : "&nbsp;<a href=\"sort.php?action=admin&month=$othermonth\">{$year}-{$othermonth}</a>";
		}
	}closedir($fg);
	ksort($month_a);

	if (!empty($type)) {
		function cmp($a,$b) {
			global $type;
			return $a[$type] == $b[$type] ? 0 : ($a[$type] > $b[$type] ? -1 : 1);
		}
		uasort($admindb,"cmp");
		$sort_a[$type] = "<img src=\"$imgpath/wind/menu-down.gif\" />";
	}
	require PrintEot('sort');footer();
} elseif($action=='delsort'){
	InitGP(array('month','verify'));
	(!$month || !is_numeric($month) || $groupid!='3') && Showmsg('undefined_action');
	$verify != substr(md5($windid.$winduid.$groupid.$db_hash),0,8) && Showmsg('illegal_request');
	if(file_exists(D_P.'data/bbscache/admin_sort_'.$month.'.php')){
		P_unlink(D_P.'data/bbscache/admin_sort_'.$month.'.php');
	}
	refreshto("sort.php?action=admin",'operate_success');
}

function savearray($name,$array){
	$arraydb="\$$name=array(\n\t\t";
	foreach($array as $key=>$value){
		$arraydb.="'".$key."'=>\narray(\n\t\t\t";
		foreach($value as $value1){
			$arraydb.='array(';
			foreach($value1 as $value2){
				$arraydb.="'".str_replace(array("\\","'"),array("\\\\","\'"),$value2)."',";
			}
			$arraydb.="),\n\t\t\t";
		}
		$arraydb.="),\n\t\t";
	}
	$arraydb.=");\n";
	return $arraydb;
}
?>