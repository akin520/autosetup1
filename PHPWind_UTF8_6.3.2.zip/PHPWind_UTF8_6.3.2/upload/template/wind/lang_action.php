<?php
!function_exists('readover') && exit('Forbidden');

$lang = array (

'hm'				=>'论坛首页',
'mb'				=>'会员列表',
'sc'				=>'搜索程序',
'rg'				=>'注册中',
'vt'				=>'今日到访会员',
'hp'				=>'查看帮助',
'nt'				=>'公告中心',
'st'				=>'统计信息',
);
?>