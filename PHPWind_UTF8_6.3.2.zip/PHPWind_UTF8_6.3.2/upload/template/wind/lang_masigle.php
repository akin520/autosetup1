<?php
!function_exists('readover') && exit('Forbidden');

$lang = array (

'banuser_1'				=>"你已经被管理员$windid 禁言,禁言时间为_limit 天",
'banuser_2'				=>"你已经被管理员$windid 禁言",
'rvrc'					=>"威望",
'money'					=>"财富",
'credit'				=>"支持度",
'unit'					=>"点",
'topped'				=>"置顶",
'topped_2'				=>'解除置顶',
'topped_msg_1'			=>'您的文章被置顶.',
'topped_msg_2'			=>'您的文章被解除置顶.',
'digest'				=>"精华",
'digest_2'				=>"取消精华",
'digest_3'				=>"精华帖子",
'digest_msg_1'			=>"您的文章被设为精华帖.",
'digest_msg_3'			=>"您的文章被取消精华.",
'lock'					=>"锁定",
'lock_1'				=>"关闭",
'lock_2'				=>"解除锁定",
'lock_3'				=>"锁定帖子",
'lock_msg_1'			=>"您的文章被锁定.",
'lock_msg_2'			=>"您的文章被取消锁定.",
'del_msg'				=>"无意义的回复帖",
'push_msg'				=>"您的文章被提前。",


);
?>