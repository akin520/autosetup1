<?php
!function_exists('readover') && exit('Forbidden');

$lang = array (

'hide_post'	=> "[color=red]浏览此帖需要威望[/color]",
'post_post'	=> "[color=red]此处是被引用的隐藏帖[/color]",
'sell_post'	=> "[color=red]此处是被引用的出售帖[/color]",
'info_post_1'	=> "引用楼主{$old_author}于{$wtof_oldfile}发表的 {$atcarray[subject]} :",
'info_post_2'	=> "引用第{$article}楼{$old_author}于{$wtof_oldfile}发表的 {$atcarray[subject]} :",
'edit_post'	=> "此帖被{$altername}在{$timeofedit}重新编辑",

);
?>