<?php
!function_exists('readover') && exit('Forbidden');

$lang = array (

'post'			=>"发帖",
'digests'		=>"精华",
'rvrc'			=>$db_rvrcname,
'money'			=>$db_moneyname,
'tpost'			=>"今日发帖",
'mpost'         =>'本月发帖',
'credit'		=>$db_creditname,
'topic'			=>"主题",
'article'		=>"文章",
'reply'			=>"回复",
'hit'			=>"人气",
'digest'		=>"精华帖",
'onlinetime'	=>"在线时间",
'postnum'		=>"发帖",
'todaypost'		=>"今日发帖",
'monthpost'		=>'本月发帖',
'replies'		=>"回复",
'hits'			=>"人气",
'digests'		=>"精华帖",
'currency'		=>$db_currencyname,
);
?>