<?php
	if($start <= 1) {
		truncatetable_uc('pms');
		validid('id', 'sms');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}sms WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}sms' ����<br>�뽫����Ϣ�� '{$source_tablepre}sms' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while($m = $db['source']->fetch_array($query)) {
		$m = array_change_key_case(daddslashes($m));

		if($msgtoid = getuid($m['myname'])) {
			$msgfrom	= $m['name'];
			$msgfromid	= getuid($msgfrom);
			$folder		= 'inbox';
			$new		= 0;
			$subject	= $m['name'];
			$dateline	= timetounix($m['addtime']);
			$dateline	= $dateline > $timestamp ? $timestamp : $dateline;
			$message	= @strip_tags(trim($m['content']));
			$delstatus	= 0;
			$related	= 0;
			$fromappid	= 1;

			$fields = array('msgfrom','msgfromid','msgtoid','folder','new','subject','dateline','message','delstatus','related','fromappid');
			$sql = getinsertsql("{$uc_tablepre}pms", $fields);

			if($db['uc']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������Ϣ $subject");
			}
			$totalrows ++;
		}
		$converted = 1;
	}
?>