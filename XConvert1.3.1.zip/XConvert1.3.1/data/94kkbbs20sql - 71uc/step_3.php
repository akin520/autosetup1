<?php
	if($start <= 1) {
		truncatetable('threads');
		truncatetable('polls');
		truncatetable('polloptions');
		validid('topicid', 'topic');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Topic WHERE TopicID BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}Topic' ����<br>�뽫����� '{$source_tablepre}Topic' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');

	while($t = $db['source']->fetch_array($query)) {

		$t				=	array_change_key_case(daddslashes($t));
		$lp				=	explode('|', $t['lastreply']);
		$tid			=	$t['topicid'];
		$fid			=	$t['boardid'];
		$iconid			=	0;
		$typeid			=	0;
		$readperm		=	0;
		$price			=	0;
		$author			=	cutstr(htmlspecialchars(trim($t['name'])), 15);
		$authorid		=	getuid($author);
		$subject		=	cutstr(htmlspecialchars(trim(@strip_tags($t['caption']))), 78);
		$dateline		=	timetounix($t['addtime']);
		$lastpost		=	timetounix($t['lasttime']);
		if ($lp[0]=="����"){
			$lastposter =	cutstr(htmlspecialchars(trim($t['name'])), 15);
                }else{
			$lastposter =	cutstr(htmlspecialchars(trim($lp[0])), 15);
                }
		$views			=	$t['hits'];
		$replies		=	$t['replynum'];
		$displayorder	=	$t['toptype'];
		$highlight		=	0;
		$digest			=	$t['goodnum'];
		$rate			=	0;
		$blog			=	0;
		$poll			=	$t['isvote'] ? 1 : 0;
		$special		=	$poll;
		$attachment		=	0;
		$moderated		=	0;
		$closed			=	0;
		$recommends     =  '';
		$recommend_add  =  '';
		$recommend_sub  =  '';
		$heats          =   0;

		$sql1fields = array('tid', 'fid', 'iconid', 'typeid', 'readperm', 'price', 'author', 'authorid', 'subject', 'dateline', 'lastpost', 'lastposter', 'views', 'replies', 'displayorder', 'highlight', 'digest', 'rate', 'special', 'attachment', 'moderated', 'closed', 'recommends', 'recommend_add', 'recommend_sub', 'heats');
		$sql1 = getinsertsql("{$discuz_tablepre}threads", $sql1fields);

		if($db['discuz']->query($sql1)){
			if($poll) {
				$query2 = $db['source']->query("SELECT topicid, vote, votenum, votetype, outtime FROM {$source_tablepre}topicvote WHERE topicid='$tid'");
				$v = daddslashes(array_change_key_case($db['source']->fetch_array($query2)));
				if(!$v['topicid']) {
					$db['discuz']->query("UPDATE {$discuz_tablepre}threads SET special=0 WHERE tid='$tid'");
				} else {
					$multiple = $v['votetype'];
					$maxchoices = 0;
					$expiration = timetounix($v['outtime']);
					$db['discuz']->query(getinsertsql("{$discuz_tablepre}polls", array('tid', 'multiple', 'maxchoices', 'expiration')));
					$polloptions = explode('|', $v['vote']);
					$votenums = explode('|', $v['votenum']);

					foreach($polloptions as $key => $polloption) {
						if($key == 0 ) {
							continue;
						}
						$query3 = $db['source']->query("SELECT * FROM {$source_tablepre}topicvoteuser WHERE topicid='$tid'");
						$voterids = $comma = '';
						while($u = $db['source']->fetch_array($query3)) {
							$u = array_change_key_case(daddslashes($u));
							if(!in_array($key, explode(',', $u['votenum']))) {
								continue;
							}
							$voterids .= $comma.getuid($u['user']) ;
							$comma = "\t";
						}
						$votes = $votenums[$key];
						$db['discuz']->query(getinsertsql("{$discuz_tablepre}polloptions", array('tid', 'votes', 'displayorder', 'polloption', 'voterids')));
					}
				}
			}
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ tid = $tid subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql1."</textarea>");
		}
		$converted = 1;
		$totalrows ++;
	}

	if($converted || $end < $maxid) {
		altertable('threads', 'tid');
		altertable('polls', 'tid');
		altertable('polloptions', 'tid');
	}

?>