<?php
	if($start <= 1) {
		truncatetable('attachments');
		truncatetable('attachmentfields');
		validid('fileid', 'upfile');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}upfile WHERE (fileid BETWEEN $start AND $end)");
	while ($att = $db['source']->fetch_array($query)) {
		$att = array_change_key_case(daddslashes($att));

		if($att['fileid']) {
			$aid = $att['fileid'];
			$tid = 0;
			$pid = 0;

			$dateline = timetounix($att['uptime']);
			$filename = random(8).".".$att['filetype'];
			$filetype = getfiletype($filename);
			$filesize = $att['filesize'];
			$attachment = '94kk/'.$att['filename'];
			$downloads = $att['hits'];
			$description = '';
			$isimage = in_array($filetype, array('image/pjpeg', 'image/gif', 'image/bmp', 'image/png')) ? 1 : 0;
			$uid = getuid($att['username']);
			$price = 0;
			$thumb = 0;
			$remote = 0;

			$sql1fields =  array('aid', 'tid', 'pid', 'dateline', 'readperm', 'price', 'filename', 'filetype', 'filesize', 'attachment', 'downloads', 'isimage', 'uid', 'thumb', 'remote');
			$sql1 = getinsertsql("{$discuz_tablepre}attachments", $sql1fields);
			
			$sql1fields_2 =  array('aid', 'tid', 'pid', 'uid', 'description');
			$sql1_2 = getinsertsql("{$discuz_tablepre}attachmentfields", $sql1fields_2);
			
			if($db['discuz']->query($sql1)) {
				$db['discuz']->query($sql1_2);
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������ $filename ");
			}
			$totalrows ++;

		}
		$converted = 1;
	}

	if($converted || $end < $maxid) {
		altertable('attachments', 'aid');
		altertable('attachmentfields', 'aid');
	}

?>