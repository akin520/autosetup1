<?php

/*
	[DISCUZ!] convertinc/exts_gbk.php - basically configuration for DvBBS 7.x SQL => Discuz!5.5.0
	This is NOT a freeware, use is subject to license terms
*/

$extcreditsarray = array(
	1 => array(
		'title' => '����',
		'unit' => '��',
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1
		),
	2 => array(
		'title' => '����',
		'showinthread' => '1',
		'unit' => '��',
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1
		),
	3 => array(
		'title' => '��Ǯ',
		'unit' => '��',
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1
		),
	4 => array(
		'title' => '����',
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1
		),
	5 => array(
		'title' => '��ȯ',
		'unit' => '��',
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1
		)
	);
?>