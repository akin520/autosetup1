<?php

/*
	[DISCUZ!] convertinc/exts_gbk.php - basically configuration for DvBBS 7.x SQL => Discuz!5.5.0
	This is NOT a freeware, use is subject to license terms
*/

$extcreditsarray = array(
	1 => array(
		'title' => '经验',
		'unit' => '点',
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1
		),
	2 => array(
		'title' => '威望',
		'showinthread' => '1',
		'unit' => '点',
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1
		),
	3 => array(
		'title' => '金钱',
		'unit' => '￥',
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1
		),
	4 => array(
		'title' => '魅力',
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1
		),
	5 => array(
		'title' => '点券',
		'unit' => '￥',
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1
		)
	);
?>