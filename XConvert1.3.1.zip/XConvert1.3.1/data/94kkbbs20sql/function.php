<?php
function convertbbcode($message) {
	global $p;
	$searcharray1 = array(
		'<i>',
		'</i>',
		'[REPLY]',
		'[/REPLY]',
		'[SIZE=',
		'[/SIZE]',
		'[COLOR=',
		'[/COLOR]',
		'[img]\"',
		'"[/img]',
		'</align>'
	);

	$replacearray1 = array(
		'[i]',
		'[/i]',
		'[hide]',
		'[/hide]',
		'[size=',
		'[/size]',
		'[color=',
		'[/color]',
		'[img]',
		'[/img]',
		'[align]'

	);

	$searcharray2 = array(
		"/\[upload=([a-z]+)\].*viewFile.asp?.*FileName=(\d+).*\[\/upload\]/eis",
		"/\[upload=(jpg|gif|bmp|png)\,*(#*[0-9\.]*)\,([0-9]{1,3})\,*(#*[0-9\.]*)\,*(#*[0-9\.]*)\]\s*([a-zA-Z0-9_\-\/\.]+)\s*\[\/upload\]/eis",
		"/\[upload=(\w{1,3})\,*(#*[0-9\.]*)\,([0-9]{1,3})\,*(#*[0-9\.]*)\,*(#*[0-9\.]*)\]\s*([a-zA-Z0-9_\-\/\.]+)\s*\[\/upload\]/eis",
		"/\[MP=(\d{1,4}),(\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\/MP\]/is",
		"/\[rm=(\d{1,4}),(\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\/rm\]/is",
		"/\<P align=([^\[\<]+?)\>/is"
	);

	$replacearray2 = array(
		"parseattach('\\2', $p[bbsid])",
		"parseattach('\\6', $p[bbsid], 1)",
		"parseattach('\\6', $p[bbsid], 1)",
		"[media=wma,\\1,\\2,0]\\3[/media]",
		"[media=rm,\\1,\\2,0]\\3[/media]",
		"[align=\\1]"
	);
	return daddslashes(str_replace($searcharray1, $replacearray1, preg_replace($searcharray2, $replacearray2, stripslashes($message))));
}

function parseattach($filename, $pid, $isimage = 0) {
	global $discuz_tablepre,$db;
	$attachment = '94kk/'.$filename;
	$aid = @$db['discuz']->result($db['discuz']->query("SELECT aid FROM {$discuz_tablepre}attachments WHERE attachment='$attachment'"), 0);
	$db['discuz']->query("UPDATE {$discuz_tablepre}attachments SET pid='$pid' WHERE aid='$aid'");
	return '[attach]'.$aid.'[/attach]';
}

function random($length, $numeric = 0) {
	mt_srand((double)microtime() * 1000000);
	if($numeric) {
		$hash = sprintf('%0'.$length.'d', mt_rand(0, pow(10, $length) - 1));
	} else {
		$hash = '';
		$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
		$max = strlen($chars) - 1;
		for($i = 0; $i < $length; $i++) {
			$hash .= $chars[mt_rand(0, $max)];
		}
	}
	return $hash;
}


?>