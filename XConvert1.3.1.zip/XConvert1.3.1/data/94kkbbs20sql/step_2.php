<?php
	truncatetable('forums');
	truncatetable('forumfields');
	truncatetable('moderators');

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}board ORDER BY boardid") or dexit("�������ݱ� '{$source_tablepre}board' ����<br>�뽫���� '{$source_tablepre}board' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while($forum =$db['source']->fetch_array($query)) {

		$forum = array_change_key_case(daddslashes($forum));

		$fid = $forum['boardid'];
		$fup = $forum['parentid'];
		if(isset($forum['depth']) && $forum['depth'] == 0) {
			$type = 'group';
		} elseif ($forum['depth'] == 1) {
			$type = 'forum';
		} else {
			$type = 'sub';
		}
		$name =	cutstr(htmlspecialchars(trim(@strip_tags($forum['boardname']))), 50);
		$displayorder = $forum['orders'];
		$styleid = 0;
		$threads = $forum['topicnum'];
		$posts = $forum['essaynum'];
		$todayposts = $forum['todaynum'];
		$lastpost = '';
		$status = 1;
		$allowsmilies = 1;
		$allowhtml = 0;
		$allowbbcode = $allowsmilies;
		$allowimgcode = $allowsmilies;
		$modnewposts = 0;
		$allowshare = $allowsmilies;
		$allowpostspecial = 3;
		$alloweditrules = 0;
		$recyclebin = 0;
		$jammer = 0;
		$disablewatermark =	0;
		$inheritedmod = 0;
		$autoclose = 0;
		$description = $forum['introduce'];
		$password = '';
		$icon = $forum['boardimg'];
		$postcredits = '';
		$replycredits = '';
		$redirect = '';
		$attachextensions = '';
		$moderators = addmoderators(explode('|', $forum['boardadmin']), $fid);
		$rules = '';
		$threadtypes = '';
		$viewperm = '';
		$postperm = '';
		$replyperm = '';
		$getattachperm = '';
		$postattachperm = '';

		$query1fields = array('fid' , 'fup' , 'type' , 'name' , 'status' , 'displayorder' , 'styleid' , 'threads' , 'posts' , 'todayposts' , 'lastpost' , 'allowsmilies' , 'allowhtml' , 'allowbbcode' , 'allowimgcode' , 'allowshare' , 'allowpostspecial' , 'allowspecialonly' , 'alloweditrules' , 'recyclebin' , 'modnewposts' , 'jammer' , 'disablewatermark' , 'inheritedmod' , 'autoclose' , 'alloweditpost' , 'simple');
		$query1 = getinsertsql("{$discuz_tablepre}forums", $query1fields);

		$query2fields = array('fid', 'description', 'password', 'icon', 'postcredits', 'replycredits', 'redirect', 'attachextensions', 'moderators', 'rules', 'threadtypes', 'viewperm', 'postperm', 'replyperm', 'getattachperm', 'postattachperm');
		$query2 = getinsertsql("{$discuz_tablepre}forumfields", $query2fields);

		$query3 =	"DELETE FROM {$discuz_tablepre}moderators WHERE fid='$fid';";

		if($db['discuz']->query($query1)) {
			if($db['discuz']->query($query2)) {
				$convertedrows ++;
			} else {
				$db['discuz']->query($query3);
				$db['discuz']->query("DELETE FROM {$discuz_tablepre}forums WHERE `fid`='$fid' LIMIT 1;");
				reportlog("���������չ��Ϣ���ݳ��� fid = $fid name = $name");
			}
		} else {
			$db['discuz']->query($query3);
			reportlog("��������������ݳ��� fid = $fid name = $name");
		}
		$totalrows ++;
	}

	altertable('forums', 'fid');
	altertable('forumfields', 'fid');
	altertable('moderators', 'fid');
?>