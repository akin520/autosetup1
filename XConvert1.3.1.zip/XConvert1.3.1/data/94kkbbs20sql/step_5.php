<?php

	$kk_posttbl = isset($_GET['kk_posttbl']) ? $_GET['kk_posttbl'] : '';
	$tableid = isset($_GET['tableid']) ? $_GET['tableid'] : 1;
	
	if($start <= 1 && $kk_posttbl == '') {
		$kk_posttbl = $comma = '';
		$tablequery = $db['source']->query("SELECT bbstable FROM {$source_tablepre}config");
		while ($tb = $db['source']->fetch_array($tablequery)){
			$tb= array_change_key_case($tb);
			$tablename = explode('|', $tb['bbstable']);			
		}
		$comma = $kk_posttbl ='';
		$tablename = explode(',' , $tablename[0]);
		foreach($tablename as $tbid) {
			$kk_posttbl .= $comma.$source_tablepre.'bbs'.$tbid;
			$comma = ',';
		}
	}

	$tablearray = explode(',', $kk_posttbl);
	$tablecount = count($tablearray);
	$posttable = $tablearray[$tableid - 1];

	if($start <= 1 && $tableid == 1) {
		truncatetable('posts');
		validid('bbsid', $tablearray[0], '');
	}

	$query = $db['source']->query("SELECT * FROM $posttable WHERE bbsid BETWEEN $start AND $end") or dexit("�������ݱ� '$posttable' ����<br>�뽫���ӱ� '$posttable' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while ($p = $db['source']->fetch_array($query)) {
		$p = array_change_key_case(daddslashes($p));

		$pid = $p['bbsid'];
		if ($p['topicid']=="0"){
                	$tid = $p['replytopicid'];
                  }else{
                	$tid = $p['topicid'];
                }
		$fid = $p['boardid'];
		$first = $p['replytopicid'] == 0 ? 1 : 0;
		$subject= cutstr(@strip_tags(trim($p['caption'])), 78);
		$author = $p['name'];
		$authorid= getuid($author);
		$dateline= timetounix($p['addtime']);
		$message= convertbbcode($p['content']);
		$useip = $p['ip'];
    		$attachment= 0;
		$usesig = 1;
		$bbcodeoff= 0;
		$smileyoff= 0;
		$parseurloff= 0;
		$htmlon = @strip_tags($message) == $message ? 0 : 1;
		$rate = 0;
		$ratetimes= 0;
		$status = $p['isdel'] == 1 ? 1 : 0;

		$sqlfields = array('pid', 'fid', 'tid', 'first', 'author', 'authorid', 'subject', 'dateline', 'message', 'useip', 'attachment', 'usesig', 'bbcodeoff', 'smileyoff', 'parseurloff', 'htmlon', 'rate', 'ratetimes', 'status');
		$sql = getinsertsql("{$discuz_tablepre}posts", $sqlfields);

		if($db['discuz']->query($sql)){
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
		}

		$converted = 1;
		$totalrows ++;
	}

	if($converted || $end < $maxid) {
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid."&tableid=$tableid&kk_posttbl=$kk_posttbl");
	} elseif($tableid < $tablecount) {
		validid('bbsid', $tablearray[$tableid], '');
		$end = $start - 1;
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.($tableid + 1)."&kk_posttbl=$kk_posttbl");
	}

?>