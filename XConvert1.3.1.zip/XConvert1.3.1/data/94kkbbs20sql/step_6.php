<?php

	truncatetable('forumlinks');

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}link ORDER BY id");
	while($fl = $db['source']->fetch_array($query)) {
		$fl = array_change_key_case(daddslashes($fl));
		$fl = daddslashes($fl);
		$name = cutstr(@strip_tags(trim($fl['bbsname'])), 100);
		$url = cutstr(@strip_tags(trim($fl['url'])),100);
		$description = '';// cutstr(@strip_tags(trim($fl['readme'])), 200);
		$logo = cutstr(@strip_tags(trim($fl['pic'])), 100);
		$displayorder = $fl['orders'];

		$sql = getinsertsql("{$discuz_tablepre}forumlinks", array('name', 'url', 'description', 'logo', 'displayorder'));
		if($db['discuz']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת��������̳ $name");
		}
		$totalrows ++;
	}

?>