<?php
	if($start <= 1) {
		truncatetable('pms');
		validid('id', 'sms');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}sms WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}sms' ����<br>�뽫����Ϣ�� '{$source_tablepre}sms' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while($m = $db['source']->fetch_array($query)) {
		$m = array_change_key_case(daddslashes($m));

		if($msgtoid = getuid($m['myname'])) {
			$msgfrom = $m['name'];
			$msgfromid = getuid($msgfrom);
			$folder = 'inbox';
			$new = 0;
			$subject = $m['name'];
			$dateline = timetounix($m['addtime']);
			$message = @strip_tags(trim($m['content']));
			$delstatus = 0;

			$sql = getinsertsql("{$discuz_tablepre}pms", array('msgfrom', 'msgfromid', 'msgtoid', 'folder', 'new', 'subject', 'dateline', 'message', 'delstatus'));

			if($db['discuz']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������Ϣ $subject");
			}
			$totalrows ++;
		}
		$converted = 1;
	}
?>