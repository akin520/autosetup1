<?php
	$query = $db['discuz']->query("SELECT pid FROM {$discuz_tablepre}attachments LIMIT $limit_start, $rpp");
	while($att = $db['discuz']->fetch_array($query)) {
		$att = array_change_key_case(daddslashes($att));

		$query1 = $db['discuz']->query("SELECT tid FROM {$discuz_tablepre}posts WHERE pid='$att[pid]'");
		$p = $db['discuz']->fetch_array($query1);
		$tid = $p['tid'];

		$sql1 = "UPDATE {$discuz_tablepre}attachments SET tid='$tid' WHERE pid='$att[pid]'";
		$sql2 = "UPDATE {$discuz_tablepre}posts SET attachment=1 WHERE pid='$att[pid]'";
		$sql3 = "UPDATE {$discuz_tablepre}threads SET attachment=1 WHERE tid='$tid'";

		if (@$db['discuz']->query($sql1)) {
			$db['discuz']->query($sql2);
			$db['discuz']->query($sql3);
			$convertedrows ++;
		} else {
			reportlog('��������');
		}
		$converted = 1;
		$totalrows ++;
	}

	if(!$converted) {
		$db['discuz']->query("DELETE FROM {$discuz_tablepre}attachments WHERE pid=0 or tid=0");
	}
?>