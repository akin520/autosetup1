<?php
	$str = '';
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}admin") or dexit("�������ݱ� '{$source_tablepre}admin' ����<br>�뽫���ݱ� '{$source_tablepre}admin' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');

	while($admin = $db['source']->fetch_array($query)) {
		$admin = array_change_key_case(daddslashes($admin));
		if($admin['strings'] == ',01,02,03,04,05,06,07,08,09,11,12,13,21,22,23,24,25,26,27,31,32,33,34,35,36,41,42,43,44,45,51,52,53,54,55,56,57,58,') {
			if($db['discuz']->result($db['discuz']->query("SELECT COUNT(*) FROM {$discuz_tablepre}members WHERE username='$admin[name]' AND adminid='1' AND groupid='1'"), 0)) {
				$convertedrows ++;
			} else {
				$db['discuz']->query("UPDATE {$discuz_tablepre}members SET adminid='1', groupid='1' WHERE username='$admin[name]' LIMIT 1;");
				if($db['discuz']->affected_rows()) {
					$convertedrows ++;
				}
			}
			$totalrows ++;
		}
	}
?>