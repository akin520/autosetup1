﻿<?php

/*
	[DISCUZ!] convertinc/exts_utf8.php - basically configuration for DvBBS 7.x SQL => Discuz!5.5.0
	This is NOT a freeware, use is subject to license terms
*/

$extcreditsarray = array(
	1 => array(
		'title' => '经验',
		'unit' => '点',
		'available' => 1
		),
	2 => array(
		'title' => '威望',
		'showinthread' => '1',
		'unit' => '点',
		'available' => 1
		),
	3 => array(
		'title' => '金钱',
		'unit' => '￥',
		'available' => 1
		),
	4 => array(
		'title' => '魅力',
		'available' => 1
		),
	5 => array(
		'title' => '点券',
		'unit' => '￥',
		'available' => 1
		),
	6 => array(
		'title' => '金币',
		'available' => 1
		)
	);
$bbcodearray = array(
	'rmprompt'		=>	"请输入RM视频的宽度:\t请输入RM视频的高度:\t请输入RM视频的地址(URL): ",
	'mpexplanation'		=>	'嵌入 Windows media 音频或视频',
	'mpprompt'		=>	"请输入windows视频的宽度:\t请输入windows视频的高度:\t请输入windows视频的地址(URL): ",
	'flashexplanation'	=>	'嵌入 flash动画',
	'flashprompt'		=>	"请输入flash动画的宽度:\t请输入flash动画的高度:\t请输入flash动画的地址(URL): ",
	);
?>