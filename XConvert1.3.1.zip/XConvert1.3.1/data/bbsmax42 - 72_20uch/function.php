<?php

function addbbcode(){
	global $db,$discuz_tablepre, $bbcodearray;

	$flashplayer ='<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="{1}" height="{2}"><param name="allowScriptAccess" value="sameDomain"><param name="movie" value="{3}"><param name="quality" value="high"><param name="bgcolor" value="#ffffff"><embed src="{3}" quality="high" bgcolor="#ffffff" width="{1}" height="{2}" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object>';
	$flashexplanation = "$bbcodearray[flashexplanation]";
	$flashprompt = "$bbcodearray[flashprompt]";
	$flashexample = '[flash=500,350]http://your.com/example.swf[/flash]';

	$db['discuz']->query("UPDATE {$discuz_tablepre}bbcodes SET replacement = '$flashplayer', example = '$flashexample', prompt ='$flashprompt', params =3, available =1 WHERE tag ='flash'");

}

function ctspecialgroup(){
	global $db,$source_tablepre, $discuz_tablepre;
	$query = $db['discuz']->query("select max(groupid) from {$discuz_tablepre}usergroups");
	$db['discuz']->query("DELETE FROM {$discuz_tablepre}usergroups WHERE groupid > 15");
	$gquery = $db['source']->query("SELECT usergroupid, usertitle FROM {$source_tablepre}usergroups WHERE parentgid =2");
	while($g		=	$db['source']->fetch_array($gquery)) {
		$g		=	daddslashes($g);
		$groupid	=	$g['usergroupid'] + 15;
		$grouptitle	=	$g['usertitle'];
		$gsql		=	"REPLACE INTO {$discuz_tablepre}usergroups (groupid, radminid, type, system, grouptitle, creditshigher, creditslower, stars, color, groupavatar, readaccess, allowvisit, allowpost, allowreply, allowpostpoll, allowpostreward, allowposttrade, allowpostactivity, allowdirectpost, allowgetattach, allowpostattach, allowvote, allowmultigroups, allowsearch, allowcstatus, allowuseblog, allowinvisible, allowtransfer, allowsetreadperm, allowsetattachperm, allowhidecode, allowhtml, allowcusbbcode, allowanonymous, allownickname, allowsigbbcode, allowsigimgcode, allowviewpro, allowviewstats, disableperiodctrl, reasonpm, maxprice, maxsigsize, maxattachsize, maxsizeperday, maxpostsperhour, attachextensions, raterange, mintradeprice, maxtradeprice, minrewardprice, maxrewardprice, magicsdiscount, allowmagics, maxmagicsweight, allowbiobbcode, allowbioimgcode, maxbiosize, tradestick, exempt, maxattachnum, allowposturl, allowrecommend, edittimelimit, allowpostrushreply) VALUES ('$groupid', 0, 'special', 'private', '$grouptitle', 50, 200, 2, '', '', 20, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 100, 0, 0, 0, 'chm, pdf, zip, rar, tar, gz, bzip2, gif, jpg, jpeg, png', '', 1, 0, 1, 0, 0, 1, 60, 0, 0, 0, 5, 0, 0, 3, 1, 0, 0)";
		$db['discuz']->query($gsql);
	}
}

function convertbbcode($message) {
	global $p, $source_bbsurl;
	$pregfind = array(
		"/\[attachimg\](\d+).*\[\/attachimg\]/is",
		"/\[attachimg=\d+,\d+\](\d+)\[\/attachimg\]/is",
		"/\[uploadimage\](\d+),.*\[\/uploadimage\]/is",
		"/\[uploadfile\](\d+),.*\[\/uploadfile\]/is",
		"/\[upload=([a-z]+)\].*viewFile.asp?.*ID=(\d+).*\[\/upload\]/is",
		"/\[upload=([a-z]+),.*?\]viewFile\.asp\?ID=(\d+)\[\/upload\]/is",
		"/\[upload=(jpg|gif|bmp|png),.*?\]\s*UploadFile\/([a-zA-Z0-9_\-\/\.]+)\s*\[\/upload\]/ies",
		"/\[upload=(jpg|gif|bmp|png)\]\s*UploadFile\/([a-zA-Z0-9_\-\/\.]+)\s*\[\/upload\]/eis",
		"/\[upload=([a-z]+)\]\s*UploadFile\/([a-zA-Z0-9_\-\/\.]+)\s*\[\/upload\]/eis",
		"/\[(\w{2})=(\d{1,4}),(\d{1,4}),(true|false|0|1)\]\s*([^\[\<\r\n]+?)\s*\[\/\\1\]/ies",
		"/\[sound\]\s*([^\[\<\r\n]+?)\s*\[\/sound\]/is",
		"/\[qt=(\d{1,4}),(\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\qt\]/is",
		"/\[(center|left|right)\]/i",
		"/\[\/(center|left|right)\]/i",
		"/\[face/i",
		"/\[\/face\]/i",
		"/<div class=\"quote\">/i",

	);
	$pregreplace = array(
		"[attach]\\1[/attach]",
		"[attach]\\1[/attach]",
		"[attach]\\1[/attach]",
		"[attach]\\1[/attach]",
		"[attach]\\2[/attach]",
		"[attach]\\2[/attach]",
		"parseattach('\\2', $p[postid], $p[isupload], 1)",
		"parseattach('\\2', $p[postid], $p[isupload], 1)",
		"parseattach('\\2', $p[postid], $p[isupload])",
		"parsemedia('\\2', '\\3', '\\4', '\\5')",
		"[media=wma,200,64,0]\\1[/media]",
		"[media=rm,\\1,\\2,0]\\3[/media]",
		"[align=\\1]",
		"[/align]",
		"[font",
		"[/font]",
		"<div class=\"msgheader\">QUOTE:</div><div class=\"msgborder\">",
	);
	
	$bbsurl = str_replace(' ', '', $source_bbsurl);//ȥ���ո�
	if($bbsurl){
		$bbsurl = substr($bbsurl, 0, 1) == '|' ? substr($bbsurl, 1) : $bbsurl;//ȥ����ͷ��|
		$bbsurl = substr($bbsurl, -1) == '|' ? substr($bbsurl, 0, -1) : $bbsurl;//ȥ��β����|
		$bbsurltemp = str_replace(array('/', '.'), array('\/', '\.'), $bbsurl);//ת��
		$urlfind = array(
			"/($bbsurltemp)\/index.asp\?boardid=(\d+)/is",
			"/($bbsurltemp)\/list.asp\?boardid=(\d+)/is",
			"/($bbsurltemp)\/dispbbs.asp\?(boardid=\d+)&amp;id=(\d+)(&amp;star=(\d+))(&amp;page=\d{0,}){0,1}/is",
			"/($bbsurltemp)\/dispbbs.asp\?(boardid=\d+)&amp;id=(\d+)(&amp;page=\d{0,}){0,1}/is",
			"/($bbsurltemp)\/dispbbs.asp\?(boardid=\d+)(&amp;page=\d{0,}){0,1}&amp;id=(\d+)(&amp;star=(\d+))/is",
			"/($bbsurltemp)\/dispbbs.asp\?(boardid=\d+)(&amp;page=\d{0,}){0,1}&amp;id=(\d+)/is",
		);
		$urlreplace = array(
			"\\1/forumdisplay.php?fid=\\2",
			"\\1/forumdisplay.php?fid=\\2",
			"\\1/viewthread.php?tid=\\3&extra=&page=\\5",
			"\\1/viewthread.php?tid=\\3",
			"\\1/viewthread.php?tid=\\4&extra=&page=\\6",
			"\\1/viewthread.php?tid=\\4",
		);
		$pregfind = array_merge($pregfind, $urlfind);
		$pregreplace = array_merge($pregreplace, $urlreplace);
	}
	return daddslashes(str_replace(array('[replyview]', '[/replyview]', '[B]', '[/B]'), array('[hide]', '[/hide]', '[b]', '[/b]'), preg_replace($pregfind, $pregreplace, stripslashes($message))));
}

function parsemedia($width, $height, $autostart, $url) {
	if($autostart == 'true' || $autostart == '1') {
		$autostart = '1';
	} else {
		$autostart = '0';
	}
	return '[media=wmv,'.$width.','.$height.','.$autostart.']'.$url.'[/media]';
}


function parseattach($filename, $pid, $haveattach, $isimage = 0) {
	global $discuz_tablepre,$db;
	$filename = 'dvbbs/'.$filename;
	if($haveattach && ($aid = $db['discuz']->result($db['discuz']->query("SELECT aid FROM {$discuz_tablepre}attachments WHERE pid='$pid' AND attachment='$filename'"), 0))) {
		return '[attach]'.$aid.'[/attach]';
	} else {
		if($isimage) {
			return "<img src=\"attachments/$filename\" border=\"0\" onclick=\"zoom(this)\" onload=\"if(this.width>document.body.clientWidth*0.5) {this.resized=true;this.width=document.body.clientWidth*0.5;this.style.cursor='pointer';} else {this.onclick=null}\" alt=\"\" />";
		} else {
			return "<a href=\"attachments/$filename\" target=\"_blank\">�򿪸���</a>";
		}
	}
}

function random($length, $numeric = 0) {
	mt_srand((double)microtime() * 1000000);
	if($numeric) {
		$hash = sprintf('%0'.$length.'d', mt_rand(0, pow(10, $length) - 1));
	} else {
		$hash = '';
		$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
		$max = strlen($chars) - 1;
		for($i = 0; $i < $length; $i++) {
			$hash .= $chars[mt_rand(0, $max)];
		}
	}
	return $hash;
}

function getdependence($fid) {
	global $discuz_tablepre,$db;

	if($fid < 1) {
		return 0;
	}
	$query = $db['discuz']->query("SELECT a.fid, a.fup, a.type, b.fup AS parentfup, b.type AS parenttype FROM {$discuz_tablepre}forums a LEFT JOIN {$discuz_tablepre}forums b ON a.fup = b.fid WHERE a.fid = $fid");
	$forum = $db['discuz']->fetch_array($query);
	if($forum['parenttype'] == 'group') {
		return $forum['fid'];
	} else {
		getdependence($forum['fid']);
	}
	return 0;

}

function formatstr($str) {
	while(substr($str, -1) == '\\'){
		$str = substr($str, 0, -1);
	}
	return $str;
}

function getmoderatortype($uid) {
	global $db, $discuz_tablepre;
	return $uid ? $db['discuz']->result($db['discuz']->query("SELECT adminid FROM {$discuz_tablepre}members WHERE uid='$uid' LIMIT 1"), 0) : 0;
}

function set_dir($dir) {
	$dirarr	=	explode("/", $dir);
	$dirlevel	=	count($dirarr);
	$flag	=	1;
	for($i=0;$i<$dirlevel;$i++) {
		$temdir	=	'';
		$extra	=	'';
		for($j=0;$j<=$i;$j++) {
			$temdir	.=	$extra.$dirarr[$j];
			$extra	=	'/';
		}
		!is_dir($temdir) && mkdir($temdir, 0777);
		!is_dir($temdir) && $flag = 0;
	}
	return $flag;
}

function getavatar($uid, $postfix) {
	$avatardir		=	'';
	$idlength		=	strlen($uid);
	if($idlength > 3) {
		$iddir		=	getdirbyid(substr($uid, 0, 3), 1);
	} elseif($idlength == 3) {
		$iddir		=	getdirbyid(substr($uid, 0, 2), 1);
	} elseif($idlength == 2) {
		$iddir		=	getdirbyid(substr($uid, 0, 1), 1);
	} elseif($idlength == 1) {
		$iddir		=	'';
	} else {
		return '';
	}
	$avatardir	=	$iddir.$uid.'.'.$postfix;
	return $avatardir;
}

function getdirbyid($id, $len) {
	$adddir	=	'';
	while(strlen($id) > $len){
		$adddir	=	substr($id, -$len)."/".$adddir;
		$id		=	substr($id, 0, -$len);
	}
	$adddir = $id != '' ? $id.'/'.$adddir : $adddir;
	return $adddir;
}

function set_home($uid, $dir = '.') {
	$uid = abs(intval($uid));
	$uid = sprintf("%09d", $uid);
	$dir1 = substr($uid, 0, 3);
	$dir2 = substr($uid, 3, 2);
	$dir3 = substr($uid, 5, 2);
	!is_dir($dir.'/'.$dir1) && mkdir($dir.'/'.$dir1, 0777);
	!is_dir($dir.'/'.$dir1.'/'.$dir2) && mkdir($dir.'/'.$dir1.'/'.$dir2, 0777);
	!is_dir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3) && mkdir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3, 0777);
	return $dir1.'/'.$dir2.'/'.$dir3;
}

function getnewavatar($uid, $size = 'big', $postfix) {
	$size = in_array($size, array('big', 'middle', 'small')) ? $size : 'big';
	$uid = abs(intval($uid));
	$uid = sprintf("%09d", $uid);
	$dir1 = substr($uid, 0, 3);
	$dir2 = substr($uid, 3, 2);
	$dir3 = substr($uid, 5, 2);
	return $dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2)."_avatar_$size.".$postfix;
}
?>