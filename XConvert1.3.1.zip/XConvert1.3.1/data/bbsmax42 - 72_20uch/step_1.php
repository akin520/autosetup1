<?php
	if($start <= 1) {
		truncatetable('members');
		truncatetable('memberfields');
		truncatetable_uc('members');
		truncatetable_uc('memberfields');
		truncatetable_uch('space');
		truncatetable_uch('spacefield');
		validid('UserID', 'Users');

		if($discuz_charset == 'utf8'){
			include './data/'.$child.'/exts_utf8.php';
		}else {
			include './data/'.$child.'/exts_gbk.php';
		}
	}
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Users WHERE (UserID BETWEEN $start AND $end)") or dexit("�������ݱ� '{$source_tablepre}Users' ����<br>�뽫�û��� '{$source_tablepre}Users' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');

	while ($user = $db['source']->fetch_array($query)) {
		$user		=	array_change_key_case($user);
		$uid		=	$user['userid'];
		$username	=	trim($user['username']);
		if(!$username || $username != htmlspecialchars(daddslashes($username))) {
			reportlog("�Ƿ��û��� <b><font color='red'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
		} elseif(strlen($username) > 15) {
			reportlog("�û��� <b><font color='orange'>$username</font></b> ���ȴ��� 15�����ܱ�ת����uid = $uid ��<br>\r\n");
		} elseif(getuid($username)) {
        		reportlog("�ظ��û��� <b><font color='blue'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
		} else {
			$user = daddslashes($user);

			//uc members
			$ucpw			=	convertucpw(strtolower($user['password']));
			$password		=	$ucpw['password'];
			$email			=	cutstr($user['email'], 32);
			$myid			=	'';
			$myidkey		=	'';
			$regip			=	$user['createip'];
			$regdate		=	timetounix($user['createdate']);
			$lastloginip	=	$user['lastvisitip'];
			$lastlogintime	=	timetounix($user['lastvisitdate']);
			$salt			=	$ucpw['salt'];

			//uc memberfields
			$blacklist		=	'';

			//dz members
			$secques		=	'';
			$gender			=	$user['gender'];
        	$adminid		=	0;
        	$groupid		=	10;
			$groupexpiry	=	0;
			$extgroupids	=	'';
			$lastip			=	$lastloginip;
			$lastvisit		=	$lastlogintime;
			$lastactivity	=	$lastvisit;
			$lastpost		=	$user['lastpostdate'];
			$posts			=	$user['totalcomments'];
			$threads        =   $user['totaltopics'];
			$digestposts	=	0;
			$oltime			=	$user['totalonlinetime'];
			$pageviews		=	0;
			$credits		=	$user['points'];
			$extcredits1	=	$user['point_1'];
			$extcredits2	=	$user['point_2'];
			$extcredits3	=	$user['point_3'];
			$extcredits4	=	$user['point_4'];
			$extcredits5	=	$user['point_5'];
			$extcredits6	=	$user['point_6'];
			$extcredits7	=	$user['point_7'];
			$extcredits8	=	$user['point_8'];
			$birtharr		=	explode("|", $user['userinfo']);
			$birthyear		=	$birtharr[17] ? $birtharr[17] : '0000';
			$birthday		=	$birtharr[16] ? substr($birtharr[16], -2) : '00';
			$birthmon		=	$birtharr[16] ? substr($birtharr[16], 0, -2) : '00';
			$bday			=	$birthyear.'-'.$birthmon.'-'.$birthday;
			$signature		=	@strip_tags($user['signature']);
			$sigstatus		=	$signature ? 1 : 0;
			$tpp			=	'0';
			$ppp			=	'0';
			$styleid		=	'0';
			$dateformat		=	'0';
			$timeformat		=	'0';
			$pmsound		=	'0';
			$showemail		=	'0';
			$newsletter		=	'1';
			$invisible		=	'0';
			$timeoffset		=	'9999';
			$newpm			=	0;
			$accessmasks	=	0;
			$editormode		=	2;
			$customshow		=	26;
			$xspacestatus	=	0;

			//dz memberfields			
			$nickname		=	$user['realname'];
			$site			=	'';
			$alipay			=	'';
			$icq			=	'';
			$qq				=	'';
			$yahoo			=	'';
			$msn			=	'';
			$taobao			=	'';
			$location		=	'';
			$customstatus	=	'';
			$newbietaskid   =   0;
			$medals			=	'';
			$avatar			=	$user['avatarsrc'];
			$avatarwidth	=	0;
			$avatarheight	=	0;
			$bio			=	'';
			$sightml		=	parsesign($user['signature']);
			$ignorepm		=	'';
			$groupterms		=	'';
			$authstr		=	'';
			$spacename		=	'';
			$buyercredit	=	'';
			$sellercredit	=	'';
			$prompt			=	'';

			//uchome space
			$credit			=	$credits;
			$experience		=	0;
			$name			=	'';
			$namestatus		=	0;
			$videostatus	=	0;
			$domain			=	'';
			$friendnum		=	0;
			$viewnum		=	$user['spaceviews'];
			$notenum		=	0;
			$addfriendnum	=	0;
			$mtaginvitenum	=	0;
			$eventinvitenum	=	0;
			$myinvitenum	=	0;
			$pokenum		=	0;
			$doingnum		=	$user['totaldoings'];
			$blognum		=	$user['totalblogarticles'];
			$albumnum		=	$user['totalalbums'];
			$threadnum		=	0;
			$pollnum		=	0;
			$eventnum		=	0;
			$sharenum		=	$user['totalshares'];	
			$updatetime		=	timetounix($user['updatedate']);
			$lastsearch		=	$lastlogintime;
			$lastlogin		=	$lastlogintime;
			$lastsend		=	$lastlogintime;
			$attachsize		=	0;
			$addsize		=	0;
			$addfriend		=	0;
			$flag			=	0;
			$newpm			=	0;
			$ip				=	0;
			$mood			=	0;

			//uchome spacefield
			$sex			=	$gender;
			$newemail		=	'';
			$emailcheck		=	0;
			$mobile			=	'';
			$qq				=	'';
			$msn			=	'';
			$msnrobot		=	'';
			$msncstatus		=	0;
			$videopic		=	'';
			$birthyear		=	0;
			$birthmonth		=	0;
			$birthday		=	0;
			$blood			=	'';
			$marry			=	0;
			$birthprovince	=	'';
			$birthcity		=	'';
			$resideprovince	=	'';
			$residecity		=	'';
			$note			=	'';
			$spacenote		=	'';
			$authstr		=	'';
			$theme			=	'';
			$nocss			=	0;
			$menunum		=	0;
			$css			=	'';
			$privacy		=	'';
			$friend			=	'';
			$feedfriend		=	'';
			$sendmail		=	'';
			$magicstar		=	0;
			$magicexpire	=	0;
			$timeoffset		=	'';
			
			$fields1 = array('uid', 'username', 'password', 'email', 'myid', 'myidkey', 'regip', 'regdate', 'lastloginip', 'lastlogintime', 'salt', 'secques');
			$query1 = getinsertsql("{$uc_tablepre}members", $fields1);

			$fields2 = array('uid', 'blacklist');
			$query2 = getinsertsql("{$uc_tablepre}memberfields", $fields2);

			$fields3 = array('uid', 'username', 'password', 'secques', 'gender', 'adminid', 'groupid', 'groupexpiry', 'extgroupids', 'regip', 'regdate', 'lastip', 'lastvisit', 'lastactivity', 'lastpost', 'posts','threads', 'digestposts', 'oltime', 'pageviews', 'credits', 'extcredits1', 'extcredits2', 'extcredits3', 'extcredits4', 'extcredits5', 'extcredits6', 'extcredits7', 'extcredits8', 'email', 'bday', 'sigstatus', 'tpp', 'ppp', 'styleid', 'dateformat', 'timeformat', 'pmsound', 'showemail', 'newsletter', 'invisible', 'timeoffset', 'prompt', 'accessmasks', 'editormode', 'customshow', 'xspacestatus','newbietaskid');
			$query3 = getinsertsql("{$discuz_tablepre}members", $fields3);

			$fields4 = array('uid','nickname','site','alipay','icq','qq','yahoo','msn','taobao','location','customstatus','medals','avatar','avatarwidth','avatarheight','bio','sightml','ignorepm','groupterms','authstr','spacename','buyercredit','sellercredit');
			$query4 = getinsertsql("{$discuz_tablepre}memberfields", $fields4);
			
			$groupid =	5;
			$avatar  =	0;
			$fields5 = array('uid', 'groupid', 'credit', 'experience', 'username', 'name', 'namestatus', 'videostatus', 'domain', 'friendnum', 'viewnum', 'notenum', 'addfriendnum', 'mtaginvitenum', 'eventinvitenum', 'myinvitenum', 'pokenum', 'doingnum', 'blognum', 'albumnum', 'threadnum', 'pollnum', 'eventnum', 'sharenum', 'dateline', 'updatetime', 'lastsearch', 'lastpost', 'lastlogin', 'lastsend', 'attachsize', 'addsize', 'addfriend', 'flag', 'newpm', 'avatar', 'regip', 'ip', 'mood');
			$query5 = getinsertsql("{$uch_tablepre}space", $fields5);

			$fields6 = array('uid', 'sex', 'email', 'newemail', 'emailcheck', 'mobile', 'qq', 'msn', 'msnrobot', 'msncstatus', 'videopic', 'birthyear', 'birthmonth', 'birthday', 'blood', 'marry', 'birthprovince', 'birthcity', 'resideprovince', 'residecity', 'note', 'spacenote', 'authstr', 'theme', 'nocss', 'menunum', 'css', 'privacy', 'friend', 'feedfriend', 'sendmail', 'magicstar', 'magicexpire', 'timeoffset');
			$query6 = getinsertsql("{$uch_tablepre}spacefield", $fields6);

			if ($db['uc']->query($query1)) {
				if ($db['uc']->query($query2)) {
					$password = strtolower($user['userpassword']);
					if ($db['discuz']->query($query3)) {
						if ($db['discuz']->query($query4)) {
							$db['uchome']->query($query5);
							$db['uchome']->query($query6);
							$convertedrows ++;
						} else {
							$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
							$db['uc']->query("DELETE FROM {$uc_tablepre}memberfields WHERE uid='$uid' LIMIT 1;");
							$db['discuz']->query("DELETE FROM {$discuz_tablepre}members WHERE uid='$uid' LIMIT 1;");
							reportlog("���� DZ ��Ա��չ��Ϣ���ݳ��� uid = $uid username = $username");
						}
					} else {
						$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
						$db['uc']->query("DELETE FROM {$uc_tablepre}memberfields WHERE uid='$uid' LIMIT 1;");
						reportlog("���� DZ ��Ա�������ݳ��� uid = $uid username = $username");
					}
				} else {
					$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
					reportlog("���� UC ��Ա��չ��Ϣ���ݳ��� uid = $uid username = $username");
				}
			} else {
				reportlog("�� UC �����Ա�������ݳ��� uid = $uid username = $username");
			}
		}
		$converted = 1;
		$totalrows ++;
	}
?>