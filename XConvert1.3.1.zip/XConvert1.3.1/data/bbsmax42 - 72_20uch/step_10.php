<?php

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Moderators");
	while($moderator = $db['source']->fetch_assoc($query)) {
		$moderator	=	array_change_key_case(daddslashes($moderator));
		
		$fid			=	$moderator['forumid'];
		$uid			=	$moderator['userid'];
		$username		=	getusername($uid);
		$moderatortype	=	getmoderatortype($uid);
		$adminid		=	in_array($moderatortype, array("1", "2", "3")) ? $moderatortype : 3;
		
		$sql1 = "UPDATE {$discuz_tablepre}members SET adminid='$adminid' WHERE uid='$uid'";
		$sql2 = "UPDATE {$discuz_tablepre}forumfields SET moderators=concat(moderators, '\t', '$username') WHERE fid='$fid'";
		
		if($db['discuz']->query($sql1)) {
			$db['discuz']->query($sql2);
			$convertedrows ++;
		} else {
			reportlog("�޷�ת�������� forumid = $fid, userid=$uid");
		}
		$totalrows ++;
	}
?>