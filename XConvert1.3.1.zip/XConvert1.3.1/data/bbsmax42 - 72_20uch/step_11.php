<?php
	if($start <= 1){
		truncatetable_uch('class');
	}
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}BlogCategories WHERE CategoryID BETWEEN $start AND $end");
	while($category = $db['source']->fetch_assoc($query)) {
		$category	=	array_change_key_case(daddslashes($category));
		
		$classid		=	$category['categoryid'];
		$classname		=	$category['name'];
		$uid			=	$category['userid'];
		$dateline		=	timetounix($category['createdate']);
		
		$fields = array('classid', 'classname', 'uid', 'dateline');
		$sql = getinsertsql("{$uch_tablepre}class", $fields);
		
		if($db['uchome']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת����־���� categoryid = $classid");
		}
		$totalrows ++;
		$converted = 1;
	}
?>