<?php
	if($start <= 1){
		truncatetable_uch('blog');
		truncatetable_uch('blogfield');
	}
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}BlogArticles WHERE ArticleID BETWEEN $start AND $end");
	while($blog = $db['source']->fetch_assoc($query)) {
		$blog	=	array_change_key_case(daddslashes($blog));
		
		//blog
		$blogid			=	$blog['articleid'];
		$topicid		=	0;
		$uid			=	$blog['userid'];
		$username		=	getusername($blog['userid']);
		$subject		=	$blog['subject'];
		$classid		=	$blog['categoryid'];
		$viewnum		=	$blog['totalviews'];
		$replynum		=	$blog['totalcomments'];
		$hot			=	0;
		$dateline		=	timetounix($blog['createdate']);
		$pic			=	$blog['thumb'];
		$picflag		=	0;
		$noreply		=	0;
		$friend			=	0;
		$password		=	'';
		$click_1		=	0;
		$click_2		=	0;
		$click_3		=	0;
		$click_4		=	0;
		$click_5		=	0;

		$tag			=	"a:0:{}";
		$message		=	$blog['content'];
		$postip			=	$blog['createip'];;
		$related		=	"a:0:{}";
		$relatedtime	=	timetounix($blog['lastcommentdate']);
		$target_ids		=	'';
		$hotuser		=	'';
		$magiccolor		=	0;
		$magicpaper		=	0;
		$magiccall		=	0;
		
		$fields1 = array('blogid', 'topicid', 'uid', 'username', 'subject', 'classid', 'viewnum', 'replynum', 'hot', 'dateline', 'pic', 'picflag', 'noreply', 'friend', 'password', 'click_1', 'click_2', 'click_3', 'click_4', 'click_5');
		$sql1 = getinsertsql("{$uch_tablepre}blog", $fields1);

		$fields2 = array('blogid', 'uid', 'tag', 'message', 'postip', 'related', 'relatedtime', 'target_ids', 'hotuser', 'magiccolor', 'magicpaper', 'magiccall') ;
		$sql2 = getinsertsql("{$uch_tablepre}blogfield", $fields2);
		
		if($db['uchome']->query($sql1)) {
			if($db['uchome']->query($sql2)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת����־��չ articleid = $blogid");
			}
		} else {
			reportlog("�޷�ת����־ articleid = $blogid");
		}
		$totalrows ++;
		$converted = 1;
	}
?>