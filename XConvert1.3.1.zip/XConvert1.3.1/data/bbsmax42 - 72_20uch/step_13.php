<?php
	if($start <= 1){
		truncatetable_uch('album');
	}
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Albums WHERE AlbumID BETWEEN $start AND $end");
	while($album = $db['source']->fetch_assoc($query)) {
		$album	=	array_change_key_case(daddslashes($album));
		
		//album
		$albumid		=	$album['albumid'];
		$albumname		=	$album['name'];
		$uid			=	$album['userid'];
		$username		=	getusername($album['userid']);
		$dateline		=	timetounix($album['createdate']);
		$updatetime		=	timetounix($album['updatedate']);
		$picnum			=	$album['totalphotos'];
		$pic			=	"bbsmax/thumb/".$album['cover'];
		$picflag		=	1;
		$friend			=	0;
		$password		=	'';
		$target_ids		=	'';
		
		$fields = array('albumid', 'albumname', 'uid', 'username', 'dateline', 'updatetime', 'picnum', 'pic', 'picflag', 'friend', 'password', 'target_ids');
		$sql = getinsertsql("{$uch_tablepre}album", $fields);

		if($db['uchome']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת����� albumid = $albumid");
		}
		$totalrows ++;
		$converted = 1;
	}
?>