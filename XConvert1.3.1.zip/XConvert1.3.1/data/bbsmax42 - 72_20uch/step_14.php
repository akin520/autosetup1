<?php
	if($start <= 1){
		truncatetable_uch('pic');
	}
	$query = $db['source']->query("SELECT p.*, f.FileID, f.ServerFilePath, f.MD5, f.FileSize as ffilesize FROM {$source_tablepre}Photos p LEFT JOIN {$source_tablepre}Files f ON p.FileID=f.FileID WHERE p.PhotoID BETWEEN $start AND $end");
	while($pic = $db['source']->fetch_assoc($query)) {
		$pic	=	array_change_key_case(daddslashes($pic));
		
		//pic
		$picid			=	$pic['photoid'];
		$albumid		=	$pic['albumid'];
		$topicid		=	0;
		$uid			=	$pic['userid'];
		$username		=	getusername($uid);
		$dateline		=	timetounix($pic['createdate']);
		$postip			=	$pic['createip'];
		$filename		=	$pic['name'];
		$title			=	$pic['description'];
		$type			=	getfiletype($pic['name']);
		$size			=	$pic['ffilesize'];
		$filepatharr	=	explode(".", $pic['serverfilepath']);
		$filepath		=	"bbsmax/".$filepatharr[0].$pic['filetype'];
		$thumb			=	0;
		$remote			=	0;
		$hot			=	0;
		$click_6		=	0;
		$click_7		=	0;
		$click_8		=	0;
		$click_9		=	0;
		$click_10		=	0;
		$magicframe		=	0;
		
		$fields = array('picid', 'albumid', 'topicid', 'uid', 'username', 'dateline', 'postip', 'filename', 'title', 'type', 'size', 'filepath', 'thumb', 'remote', 'hot', 'click_6', 'click_7', 'click_8', 'click_9', 'click_10', 'magicframe');
		$sql = getinsertsql("{$uch_tablepre}pic", $fields);

		if($db['uchome']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת�����ͼƬ photoid = $picid");
		}
		$totalrows ++;
		$converted = 1;
	}
?>