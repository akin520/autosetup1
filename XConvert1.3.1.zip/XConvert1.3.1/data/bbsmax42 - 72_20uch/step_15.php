<?php
	if($start <= 1){
		truncatetable_uch('doing');
	}
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Doings WHERE DoingID BETWEEN $start AND $end");
	while($doing = $db['source']->fetch_assoc($query)) {
		$doing	=	array_change_key_case(daddslashes($doing));
		
		//doing
		$doid			=	$doing['doingid'];
		$uid			=	$doing['userid'];
		$username		=	getusername($uid);
		$from			=	'';
		$dateline		=	timetounix($doing['createdate']);
		$message		=	$doing['content'];
		$ip				=	$doing['createip'];
		$replynum		=	$doing['totalcomments'];
		$mood			=	0;
				
		$fields = array('doid', 'uid', 'username', '`from`', 'dateline', 'message', 'ip', 'replynum', 'mood');
		$sql = getinsertsql("{$uch_tablepre}doing", $fields);

		if($db['uchome']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת����¼ doingid = $doid");
		}
		$totalrows ++;
		$converted = 1;
	}
?>