<?php
	if($start <= 1){
		truncatetable_uch('comment');
		truncatetable_uch('docomment');
	}
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Comments WHERE CommentID BETWEEN $start AND $end");
	while($com = $db['source']->fetch_assoc($query)) {
		$com	=	array_change_key_case(daddslashes($com));
		
		//comment
		$uid				=	$com['targetuserid'];
		$dateline			=	timetounix($com['createdate']);
		$message			=	$com['content'];
		$ip					=	$com['createip'];

		if($com['type'] == '3') {
			$id				=	$com['commentid'];
			$upid			=	0;
			$doid			=	$com['targetid'];
			$username		=	getusername($uid);
			$grade			=	1;

			$fields = array('id', 'upid', 'doid', 'uid', 'username', 'dateline', 'message', 'ip', 'grade');
			$sql = getinsertsql("{$uch_tablepre}docomment", $fields);
		} else {
			$cid			=	$com['commentid'];
			$id				=	$com['targetid'];
			if($com['type'] == '1') {
				$idtype		=	'uid';
			} elseif($com['type'] == '2') {
				$idtype		=	'blogid';
			} elseif($com['type'] == '4') {
				$idtype		=	'picid';
			} else {
				$idtype		=	'sid';
			}
			$authorid		=	$com['userid'];
			$author			=	getusername($authorid);
			$magicflicker	=	0;

			$fields = array('cid', 'uid', 'id', 'idtype', 'authorid', 'author', 'ip', 'dateline', 'message', 'magicflicker');
			$sql = getinsertsql("{$uch_tablepre}comment", $fields);
		}
		
		if($db['uchome']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ commentid = ".$com['commentid']);
		}
		$totalrows ++;
		$converted = 1;
	}
?>