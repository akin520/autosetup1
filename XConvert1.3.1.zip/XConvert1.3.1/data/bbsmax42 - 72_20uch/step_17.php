<?php
	if($start <= 1){
		truncatetable_uc('pms');
	}
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}ChatMessages WHERE MessageID BETWEEN $start AND $end");
	while($pm = $db['source']->fetch_assoc($query)) {
		$pm	=	array_change_key_case(daddslashes($pm));
		
		//pm
		$msgfrom		=	getusername($pm['userid']);
		$msgfromid		=	$pm['userid'];
		$msgtoid		=	$pm['targetuserid'];
		$folder			=	'inbox';
		$new			=	$pm['isread'] == 'true' ? 1 : 0;
		$subject		=	formatstr(substr($pm['content'], 0, 70));
		$dateline		=	timetounix($pm['createdate']);
		$message		=	$pm['content'];
		$delstatus		=	0;
		$related		=	0;
		$fromappid		=	2;
		
		if($msgfromid && $msgtoid){
			$checkfirstsql_1 = "SELECT count(*) FROM {$uc_tablepre}pms WHERE msgfromid='$msgfromid' AND msgtoid='$msgtoid' AND related='0'";
			$is_first_1 = $db['uc']->result($db['uc']->query($checkfirstsql_1), 0);

			$checkfirstsql_2 = "SELECT count(*) FROM {$uc_tablepre}pms WHERE msgfromid='$msgtoid' AND msgtoid='$msgfromid' AND related='0'";
			$is_first_2 = $db['uc']->result($db['uc']->query($checkfirstsql_2), 0);

			if(!$is_first_1 || !$is_first_2){
				if(!$is_first_1){
					$db['uc']->query("INSERT INTO {$uc_tablepre}pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus, related, fromappid) VALUES ('$msgfrom', '$msgfromid', '$msgtoid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus', '$related', '$fromappid')");
				}
				if(!$is_first_2){
					$db['uc']->query("INSERT INTO {$uc_tablepre}pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus, related, fromappid) VALUES ('$msgfrom', '$msgtoid', '$msgfromid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus', '$related', '$fromappid')");
				}
			}else{
				$db['uc']->query("UPDATE {$uc_tablepre}pms SET subject='$subject', dateline='$dateline' AND message='$message' WHERE msgfrom='$msgfromid' AND msgtoid='$msgtoid' AND related='0'");
			}
			$related	=	1;
		}elseif($msgfromid && !$msgtoid){
			$converted = 1;
			$totalrows ++;
			continue;
		}
		
		$fields = array('msgfrom','msgfromid','msgtoid','folder','new','subject','dateline','message','delstatus','related','fromappid');
		$sql = getinsertsql("{$uc_tablepre}pms", $fields);

		if($db['uc']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������Ϣ messageid = ".$pm['messageid']);
		}
		$totalrows ++;
		$converted = 1;
	}
?>