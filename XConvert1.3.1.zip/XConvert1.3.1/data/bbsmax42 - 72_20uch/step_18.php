<?php
	if($start <= 1){
		truncatetable_uch('friend');
	}
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Friends WHERE UserID BETWEEN $start AND $end");
	while($friend = $db['source']->fetch_assoc($query)) {
		$friend	=	array_change_key_case(daddslashes($friend));
		
		$uid			=	$friend['userid'];
		$fuid			=	$friend['frienduserid'];
		$fusername		=	getusername($fuid);
		$status			=	1;
		$gid			=	$friend['groupid'];
		$note			=	'';
		$num			=	0;
		$dateline		=	timetounix($friend['createdate']);

		$fields = array('uid', 'fuid', 'fusername', 'status', 'gid', 'note', 'num', 'dateline');
		$sql = getinsertsql("{$uch_tablepre}friend", $fields);

		if($db['uchome']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת��uch���� userid = $uid, frienduserid = $friendid");
		}
		$totalrows ++;
		$converted = 1;
	}
?>