<?php
	$query = $db['source']->query("SELECT a.AttachmentID, a.FileID, a.FileName, f.ServerFilePath FROM {$source_tablepre}Attachments a LEFT JOIN {$source_tablepre}Files f ON a.FileID=f.FileID WHERE a.AttachmentID BETWEEN $start AND $end");
	while($att = $db['source']->fetch_assoc($query)) {
		$att	=	array_change_key_case(daddslashes($att));

		$att['serverfilepath']	=	str_replace('\\\\', '/', $att['serverfilepath']);
		$attachmentid	=	$att['attachmentid'];
		$serverfilepath	=	"DiskFiles/".$att['serverfilepath'];
		$name			=	$att['filename'];
		$postfix		=	strchr($name, '.');
		$pos			=	strrpos($att['serverfilepath'], '.');
		if($pos > 0) {
			$newfilepath	=	"bbsmax_bbs/".substr($att['serverfilepath'], 0, $pos).$postfix;
		} else {
			$newfilepath	=	"bbsmax_bbs/".$att['serverfilepath'].$postfix;
		}
		$pos_dir		=	strrpos($newfilepath, '/');
		$newfiledir		=	substr($newfilepath, 0, $pos_dir);
		
		if(set_dir($newfiledir)){
			if(file_exists($serverfilepath) && !file_exists($newfilepath) && copy($serverfilepath, $newfilepath)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת���޸���̳ͼƬ attachmentid = $attachmentid, serverfilepath = $serverfilepath");
			}
		} else {
			echo "Failed to make dir";
			exit;
		}
		$totalrows ++;
		$converted = 1;	
	}
?>