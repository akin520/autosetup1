<?php
	truncatetable('forums');
	truncatetable('forumfields');
	truncatetable('moderators');

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Forums ORDER BY ForumID") or dexit("�������ݱ� '{$source_tablepre}Forums' ����<br>�뽫���� '{$source_tablepre}Forums' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while($forum = mssql_fetch_array($query)) {

		$forum			=	array_change_key_case(daddslashes($forum));
		$fid			=	$forum['forumid'];
		$fup			=	$forum['parentid'];
		if($fid <= 0) {
			continue;
		}
		$forumnum	=	$db['source']->result($db['source']->query("SELECT COUNT(*) AS num FROM {$source_tablepre}Forums WHERE Parentid = $fid"), 0, 'num');
		if($fup == 0) {
			$type		=	$forumnum ? 'group' : 'forum';
		} else {
			if($forumnum > 0) {
				$type	=	'forum';
			} else {
				$parentfid	=	$db['source']->result($db['source']->query("SELECT ParentID FROM {$source_tablepre}Forums WHERE ForumID = $fup"), 0, 'ParentID');
				$type	=	$parentfid ? 'sub' : 'forum';
			}
		}
		$name			=	cutstr(htmlspecialchars(trim(@strip_tags($forum['forumname']))), 50);
		$displayorder	=	$forum['sortorder'];
		$styleid		=	0;
		$threads		=	$forum['totalthreads'];
		$posts			=	$forum['totalposts'];
		$todayposts		=	$forum['todaythreads'];
		$lastpost		=	'';
		$status			=	1;
		$allowsmilies	=	1;
		$allowhtml		=	0;
		$allowbbcode	=	$allowsmilies;
		$allowimgcode	=	$allowsmilies;
		$modnewposts	=	0;
		$allowshare		=	$allowsmilies;
		$allowpostspecial	=	3;
		$allowspecialonly	=	0;
		$alloweditrules		=	0;
		$recyclebin			=	0;
		$jammer				=	0;
		$disablewatermark	=	0;
		$inheritedmod		=	0;
		$autoclose			=	0;
		$description		=	$forum['description'];
		$password			=	'';
		$icon				=	'';
		$postcredits		=	'';
		$replycredits		=	'';
		$redirect			=	$forum['forumtype'] == 2 ? $forum['password'] : '';
		$attachextensions	=	'';
		$moderators			=	'';
		$rules				=	'';
		$threadtypes		=	'';
		$viewperm			=	'';
		$postperm			=	'';
		$replyperm			=	'';
		$getattachperm		=	'';
		$postattachperm		=	'';
		$alloweditpost		=	1;
		$simple				=	0;
		$modworks			=	0;
		$threadplugin		=   '';
		$extra				=	'';

		$fields1 = array('fid', 'fup', 'type', 'name', 'status', 'displayorder', 'styleid', 'threads', 'posts', 'todayposts', 'lastpost', 'allowsmilies', 'allowhtml', 'allowbbcode', 'allowimgcode', 'allowshare', 'allowpostspecial', 'allowspecialonly', 'alloweditrules', 'recyclebin', 'modnewposts', 'jammer', 'disablewatermark', 'inheritedmod', 'autoclose', 'alloweditpost', 'simple', 'modworks');
		$query1 = getinsertsql("{$discuz_tablepre}forums", $fields1);

		$fields2 = array('fid', 'description', 'password', 'icon', 'postcredits', 'replycredits', 'redirect', 'attachextensions', 'moderators', 'rules', 'threadtypes', 'viewperm', 'postperm', 'replyperm', 'getattachperm', 'postattachperm', 'threadplugin', 'extra');
		$query2 = getinsertsql("{$discuz_tablepre}forumfields", $fields2);

		$query3	=	"DELETE FROM {$discuz_tablepre}moderators WHERE fid='$fid';";

		if($db['discuz']->query($query1)) {
			if($db['discuz']->query($query2)) {
				$convertedrows ++;
			} else {
				$db['discuz']->query($query3);
				$db['discuz']->query("DELETE FROM {$discuz_tablepre}forums WHERE fid='$fid' LIMIT 1;");
				reportlog("���������չ��Ϣ���ݳ��� fid = $fid name = $name");
			}
		} else {
			$db['discuz']->query($query3);
			reportlog("��������������ݳ��� fid = $fid name = $name");
		}
		$totalrows ++;
	}

	$forumarr	=	array();
	$query_repair = $db['discuz']->query("SELECT * FROM {$discuz_tablepre}forums");
	while($repairforum = $db['discuz']->fetch_array($query_repair)) {
		
		$fid	=	$repairforum['fid'];
		$fup	=	$repairforum['fup'];
		$type	=	$repairforum['type'];
		$forumarr[$fid]	=	array("type" => $type, "fup" => $fup);

	}
	foreach($forumarr as $fid => $forumitem) {
		$fup = $forumarr[$fid]['fup'];
		if(in_array($forumarr[$fup]['type'], array('forum', 'sub'))) {
			$forumarr[$fid]['type'] = 'sub';
		}
		$flag = 0;
		$fup_1 = $forumarr[$fid]['fup'];
		while(in_array($forumarr[$fup_1]['type'], array('forum', 'sub'))){
			$flag	=	$fup_1;
			$fup_1	=	$forumarr[$fup_1]['fup'];
		}
		$forumarr[$fid]['fup']	=	$flag ? $flag : $forumarr[$fid]['fup'];
	}
	foreach($forumarr as $fid => $forumitem) {
		$query_sql = "UPDATE {$discuz_tablepre}forums SET fup = ".$forumarr[$fid]['fup'].", type = '".$forumarr[$fid]['type']."' WHERE fid = ".$fid;
		$db['discuz']->query($query_sql);
	}
?>