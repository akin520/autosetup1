<?php
	$query = $db['source']->query("SELECT p.PhotoID, p.UserID, p.Name, p.FileID, f.ServerFilePath FROM {$source_tablepre}Photos p LEFT JOIN {$source_tablepre}Files f ON p.FileID=f.FileID WHERE p.PhotoID BETWEEN $start AND $end");
	while($pic = $db['source']->fetch_assoc($query)) {
		$pic	=	array_change_key_case(daddslashes($pic));

		//pic
		$pic['serverfilepath']	=	str_replace('\\\\', '/', $pic['serverfilepath']);
		$picid			=	$pic['photoid'];
		$serverfilepath	=	"DiskFiles/".$pic['serverfilepath'];
		$name			=	$pic['name'];
		$postfix		=	strchr($name, '.');
		$pos			=	strrpos($pic['serverfilepath'], '.');
		if($pos > 0) {
			$newfilepath	=	"bbsmax_home/".substr($pic['serverfilepath'], 0, $pos).$postfix;
		} else {
			$newfilepath	=	"bbsmax_home/".$pic['serverfilepath'].$postfix;
		}
		$pos_dir		=	strrpos($newfilepath, '/');
		$newfiledir		=	substr($newfilepath, 0, $pos_dir);

		if(set_dir($newfiledir)){
			if(file_exists($serverfilepath) && !file_exists($newfilepath) && copy($serverfilepath, $newfilepath)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת���޸�ͼƬ picid = $picid, serverfilepath = $serverfilepath");
			}
		} else {
			echo "Failed to make dir";
			exit;
		}
		$totalrows ++;
		$converted = 1;	
	}
?>