<?php
	if($start <= 1) {
		set_dir("ucenter/data/avatar");
	}
	$maxuid	=	$db['discuz']->result($db['discuz']->query("SELECT max(uid) FROM {$discuz_tablepre}memberfields"), 0);
	if($start <= $maxuid) {
		$converted = 1;	
	}
	$queryt = $db['discuz']->query("SELECT uid, avatar FROM {$discuz_tablepre}memberfields WHERE uid >= $start AND uid < $end");
	while($mem = $db['discuz']->fetch_array($queryt)) {
		$uid			=	$mem['uid'];
		$avatarfix		=	$mem['avatar'];

		if($avatarfix != '') {
			$avatardir	=	getavatar($uid, $avatarfix);
			$bigavatar	=	'Avatar/Big/'.$avatardir;
			$midavatar	=	'Avatar/Default/'.$avatardir;
			$smallavatar=	'Avatar/Small/'.$avatardir;
			
			set_home($uid, "ucenter/data/avatar");
			$newbigava	=	'ucenter/data/avatar/'.getnewavatar($uid, $size = 'big', $avatarfix);
			$newmidava	=	'ucenter/data/avatar/'.getnewavatar($uid, $size = 'middle', $avatarfix);
			$newsmallava=	'ucenter/data/avatar/'.getnewavatar($uid, $size = 'small', $avatarfix);

			$flag		=	0;
			if(file_exists($bigavatar)) {
				if(rename($bigavatar, $newbigava)) {
					$flag ++;
				}
			}
			if(file_exists($midavatar)) {
				if(rename($midavatar, $newmidava)) {
					$flag ++;
				}
			}
			if(file_exists($smallavatar)) {
				if(rename($smallavatar, $newsmallava)) {
					$flag ++;
				}
			}
			if($flag == 3) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת���޸�ͷ�� uid = $uid");
			}
		}
		$totalrows ++;
		$converted = 1;	
	}
?>