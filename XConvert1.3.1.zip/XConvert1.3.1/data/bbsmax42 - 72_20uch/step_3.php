<?php
if($start <= 1) {
		truncatetable('threads');
		truncatetable('polls');
		truncatetable('polloptions');
		validid('ThreadID', 'Threads');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Threads WHERE ThreadID BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}Threads' ����<br>�뽫����� '{$source_tablepre}Threads' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');

	while($t = mssql_fetch_assoc($query)) {
		$t = array_change_key_case(daddslashes($t));

		//$lp			=	explode('$', $t['lastpost']);

		$tid			=	$t['threadid'];
		$fid			=	$t['forumid'];
		$iconid			=	0;
		$typeid			=	$t['threadcatalogid'];
		$readperm		=	0;
		$price			=	$t['price'];
		$authorid		= 	$t['postuserid'];
		$author			=	getusername($authorid);
		$subject		=	formatstr(cutstr(htmlspecialchars(trim(@strip_tags($t['subject']))), 78));
		$subject		=	$subject ? $subject : 'no subject';
		$dateline		=	timetounix($t['createdate']);
		$dateline		=	$dateline > $timestamp ? $timestamp : $dateline;
		$lastpost		=	timetounix($t['updatedate']);
		$lastpost		=	$lastpost > $timestamp ? $timestamp : $lastpost;
		$lastposter		=	$t['postnickname'];
		$views			=	$t['totalviews'];
		$replies		=	$t['totalreplies'];
		$displayorder	=	0;
		$highlight		=	0;
		$digest			=	0;
		$rate			=	0;
		$blog			=	0;
		$poll			=	$t['threadtype'] == 1 ? 1 : 0;
		$attachment		=	0;
		$moderated		=	0;
		$closed			=	0;
		$recommends     =  '';
		$recommend_add  =  '';
		$recommend_sub  =  '';
		$heats          =   0;
		$status			=	0;
		$special		=	0;
		
		$fields1 = array('tid', 'fid', 'iconid', 'typeid', 'readperm', 'price', 'author', 'authorid', 'subject', 'dateline', 'lastpost', 'lastposter', 'views', 'replies', 'displayorder', 'highlight', 'digest', 'rate', 'special', 'attachment', 'moderated', 'closed', 'recommends', 'recommend_add', 'recommend_sub', 'heats', 'status');
		$sql1 = getinsertsql("{$discuz_tablepre}threads", $fields1);

		if($db['discuz']->query($sql1)){
			if($poll) {
				$query2 = $db['source']->query("SELECT * FROM {$source_tablepre}Polls WHERE ThreadID=".$t['threadid']);
				$v = $db['source']->fetch_assoc($query2);
				$v = array_change_key_case(daddslashes($v));

				if(!$v['multiple']) {
					$db['discuz']->query("UPDATE {$discuz_tablepre}threads SET special=0 WHERE tid='$tid'");
				} else {
					$multiple	= $v['multiple'];
					$maxchoices = $multiple ? 0 : $multiple;
					$expiration = timetounix($v['expiresdate']);
					$db['discuz']->query("INSERT INTO {$discuz_tablepre}polls (tid, multiple, maxchoices, expiration) VALUES('$tid', '$multiple', '$maxchoices', '$expiration');");
					$db['discuz']->query("UPDATE {$discuz_tablepre}threads SET special=1 WHERE tid='$tid'");
					$query3 = $db['source']->query("SELECT * FROM {$source_tablepre}PollItems WHERE ThreadID=".$t['threadid']);
					while($items = $db['source']->fetch_assoc($query3)) {
						$items		=	array_change_key_case(daddslashes($items));
						$polloption	=	$items['itemname'];
						$votes		=	0;
						$voterids	=	'';
						$extra		=	'';

						$query4 = $db['source']->query("SELECT * FROM {$source_tablepre}PollItemDetails WHERE ItemID=".$items['itemid']);
						while($details = $db['source']->fetch_assoc($query4)) {
							$details	=	array_change_key_case(daddslashes($details));
							$voterids	.=	$extra.$details['itemid'];
							$extra		=	'\t';
							$votes ++;
						}

						$db['discuz']->query("INSERT INTO {$discuz_tablepre}polloptions (tid, votes, polloption, voterids) VALUES('$tid', '$votes', '$polloption', '$voterids');");
					}
				}
			}
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ tid = $tid subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql1."</textarea>");
		}
		$converted = 1;
		$totalrows ++;
	}
?>