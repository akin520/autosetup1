<?php
	if($start <= 1) {
		truncatetable('attachments');
		truncatetable('attachmentfields');
		validid('AttachmentID', 'Attachments');
	}

	$query = $db['source']->query("SELECT a.*, p.ThreadID, f.ServerFilePath FROM {$source_tablepre}Attachments a LEFT JOIN {$source_tablepre}Posts p ON a.PostID = p.PostID LEFT JOIN {$source_tablepre}Files f ON a.FileID = f.FileID WHERE (a.AttachmentID BETWEEN $start AND $end)") or dexit("�������ݱ� {$source_tablepre}Attachments ����<br>�뽫���ӱ� {$source_tablepre}Attachments �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while ($att =  $db['source']->fetch_assoc($query)) {
		$att = array_change_key_case(daddslashes($att));

		$aid	=	$att['attachmentid'];
		$tid	=	$att['threadid'];
		$pid	=	$att['postid'];
		if($tid && $pid) {
			$dateline		=	timetounix($att['createdate']);
			$price			=	$att['price'];
			$filename		=	$att['filename'];
			$filetype		=	getfiletype($filename);
			$filesize		=	$att['filesize'];
			$downloads		=	$att['totaldownloads'];
			$filepath		=	$att['serverfilepath'];
			if(strstr($filepath, ".") == '') {
				$attachment	=	'bbsmax/'.$filepath.strrchr($filename, '.');
			} else {
				$pos		=	strrpos($filepath, '.');
				$attachment	=	'bbsmax/'.substr($filepath, 0, $pos).strrchr($filename, '.');
			}	
			$description	=	cutstr(htmlspecialchars(strip_tags($att['filename'])), 90);
			$isimage		=	in_array($filetype, array('image/pjpeg', 'image/gif', 'image/bmp', 'image/png')) ? 1 : 0;
			$uid			=	$att['userid'];
			$thumb			=	0;
			$remote			=	0;
			
			$fields1 = array('aid', 'tid', 'pid', 'dateline', 'readperm', 'price', 'filename', 'filetype', 'filesize', 'attachment', 'downloads', 'isimage', 'uid', 'thumb', 'remote');
			$sql1 = getinsertsql("{$discuz_tablepre}attachments", $fields1);

			$fields2 = array('aid', 'tid', 'pid', 'uid', 'description');
			$sql2 = getinsertsql("{$discuz_tablepre}attachmentfields", $fields2);

			$sql3 = "UPDATE {$discuz_tablepre}threads SET attachment=1 WHERE tid='$tid'";

			if($db['discuz']->query($sql1)) {
				$db['discuz']->query($sql2);
				$db['discuz']->query($sql3);
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������ $filename ");
			}
			$totalrows ++;
		}
		$converted = 1;
	}

?>