<?php
	if($start <= 1) {
		truncatetable('posts');
		truncatetable('trades');
		validid('PostID', 'Posts');
	}
	
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Posts WHERE PostID BETWEEN $start AND $end;") or dexit("�������ݱ� {$source_tablepre}Posts ����<br>�뽫���ӱ� {$source_tablepre}Posts �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while ($p = $db['source']->fetch_assoc($query)) {
		$p = array_change_key_case(daddslashes($p));

		$oldpid			=	$p['postid'];
		$tid			=	$p['threadid'];
		$fid			=	$p['forumid'];
		$is_first		=	$db['discuz']->result($db['discuz']->query("SELECT count(*) FROM {$discuz_tablepre}posts WHERE tid = $tid"), 0);
		$first			=	$is_first > 0 ? 0 : 1;
		$subject		=	formatstr(cutstr(@strip_tags(trim($p['subject'])), 78));
		$author			=	$p['nickname'];
		$authorid		=	$p['userid'];
		$dateline		=	timetounix($p['createdate']);
		$useip			=	$p['ipaddress'];
		$is_att			=	$db['discuz']->result($db['discuz']->query("SELECT COUNT(*) FROM {$discuz_tablepre}attachments WHERE tid = $tid AND pid = $oldpid"), 0);
		$attachment		=	$is_att ? 1 : 0;
		$p['isupload']	=	$attachment;
		$message		=	convertbbcode($p['content']);
		$usesig			=	1;
		$bbcodeoff		=	0;
		$smileyoff		=	0;
		$parseurloff	=	0;
		$htmlon			=	@strip_tags($message) == $message ? 0 : 1;
		$rate			=	0;
		$ratetimes		=	0;
		$status			=	0;
		
		$fields = array('fid', 'tid', 'first', 'author', 'authorid', 'subject', 'dateline', 'message', 'useip', 'attachment', 'usesig', 'bbcodeoff', 'smileyoff', 'parseurloff', 'htmlon', 'rate', 'ratetimes', 'status');
		$sql = getinsertsql("{$discuz_tablepre}posts", $fields);

		if($db['discuz']->query($sql)){
			$pid = $db['discuz']->insert_id();
			$db['discuz']->query("UPDATE {$discuz_tablepre}attachments SET pid = $pid WHERE tid = $tid AND pid = $oldpid");
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
		}

		$converted = 1;
		$totalrows ++;
	}

?>