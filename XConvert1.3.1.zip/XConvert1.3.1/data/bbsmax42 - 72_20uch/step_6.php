<?php
	if($start <= 1) {
		truncatetable('threadtypes');
		validid('ThreadCatalogID', 'ThreadCatalogs');
	}
	
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}ThreadCatalogs ORDER BY ThreadCatalogID") or dexit("�������ݱ� {$source_tablepre}ThreadCatalogs ����<br>�뽫���ӱ� {$source_tablepre}ThreadCatalogs �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');

	while($tt = $db['source']->fetch_assoc($query)) {
		$tt				=	array_change_key_case(daddslashes($tt));
		$typeid			=	$tt['threadcatalogid'];
		$displayorder	=	0;
		$name			=	$tt['threadcatalogname'];
		$description	=	'';
		$special		=	0;
		$modelid		=	0;
		$expiration		=	0;
		$template		=	'';
		$stemplate		=	'';
		
		if($typeid) {
			$fields = array('typeid', 'displayorder', 'name', 'description', 'special', 'modelid', 'expiration', 'template', 'stemplate');
			$sql = getinsertsql("{$discuz_tablepre}threadtypes", $fields);

			if($db['discuz']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת��������� typeid = $typeid, $name");
			}
			$totalrows ++;
		}
	}

	$query_forum = $db['source']->query("SELECT * FROM {$source_tablepre}Forums ORDER BY ForumID") or dexit("�������ݱ� '{$source_tablepre}Forums' ����<br>�뽫���� '{$source_tablepre}Forums' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while($forum = $db['source']->fetch_assoc($query_forum)) {
		$forum		=	array_change_key_case(daddslashes($forum));
		$fid		=	$forum['forumid'];
		$typearray	=	array();
		
		$queryf = $db['source']->query("SELECT f.*, t.ThreadCatalogName FROM {$source_tablepre}ThreadCatalogsInForums f LEFT JOIN {$source_tablepre}ThreadCatalogs t ON f.ThreadCatalogID = t.ThreadcatalogID WHERE ForumID=$fid");
		while($ttf = $db['source']->fetch_assoc($queryf)) {
			$ttf		=	array_change_key_case(daddslashes($ttf));

			$typearray['types'][]	=	$ttf['ThreadCatalogName'];
			$typearray['required']	=	0;
			$typearray['listable']	=	1;
			$typearray['prefix']	=	0;
			$typearray['selectbox'] =	'';
			$typearray['flat']		=	$typearray['types'];
		}

		$threadtypes = daddslashes(serialize($typearray));
		$db['discuz']->query("UPDATE {$discuz_tablepre}forumfields SET threadtypes='$threadtypes' WHERE fid='$fid'");
	}
?>