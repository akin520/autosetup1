<?php
	if($start <= 1) {
		truncatetable('ratelog');
		validid('PostMarkID', 'PostMarks');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}PostMarks WHERE PostMarkID BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}PostMarks' ����<br>�뽫����Ϣ�� '{$source_tablepre}PostMarks' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while($rate = $db['source']->fetch_assoc($query)) {
		$rate = array_change_key_case(daddslashes($rate));
		
		$pid		=	$rate['postid'];
		$uid		=	$rate['userid'];
		$username	=	getusername($rate['userid']);
		$dateline	=	$rate['createdate'];
		$reason		=	$rate['reason'];
		$credits	=	array();
		if($rate['extendedpoints_1'] > 0) {
			$extcredits				=	1;
			$credits[$extcredits]	=	$rate['extendedpoints_1'];
			
		}
		if($rate['extendedpoints_2'] > 0) {
			$extcredits				=	2;
			$credits[$extcredits]	=	$rate['extendedpoints_2'];
		}
		
		foreach($credits as $extcredits => $score){
			$fields = array('pid', 'uid', 'username', 'extcredits', 'dateline', 'score', 'reason');
			$sql = getinsertsql("{$discuz_tablepre}ratelog", $fields);

			if($db['discuz']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������ postmarkid = ".$rate['postmarkid']);
			}
			$totalrows ++;
		}
		$converted = 1;
	}
?>