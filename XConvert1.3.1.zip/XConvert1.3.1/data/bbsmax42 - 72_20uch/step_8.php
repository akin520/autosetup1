<?php
	if($start <= 1) {
		truncatetable_uc('friends');
		validid('UserID', 'Friends');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Friends WHERE UserID BETWEEN $start AND $end");
	while($friend = $db['source']->fetch_assoc($query)) {
		$friend = array_change_key_case(daddslashes($friend));

		$uid		=	$friend['userid'];
		$friendid	=	$friend['frienduserid'];
		$direction	=	0;
		$related	=	0;
		$delstatus	=	0;
		$comment	=	'';

		$fields = array('uid', 'friendid', 'direction', 'version', 'delstatus', 'comment');
		$sql = getinsertsql("{$uc_tablepre}friends", $fields);

		if($db['uc']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת����̳�������� uid = $uid friendid = $friendid");
		}
		$totalrows ++;
		$converted = 1;
	}
?>