<?php
	if($start <= 1) {
		truncatetable('announcements');
		validid('AnnouncementID', 'Announcements');
	}
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Announcements WHERE AnnouncementID BETWEEN $start AND $end");
	while($announce = $db['source']->fetch_assoc($query)) {
		$announce	=	array_change_key_case(daddslashes($announce));
		
		$id				=	$announce['announcementid'];
		$author			=	getusername($announce['postuserid']);
		$subject		=	$announce['subject'];
		$type			=	$announce['announcementtype'];
		$displayorder	=	$announce['sortorder'];
		$starttime		=	timetounix($announce['begindate']);
		$endtime		=	timetounix($announce['enddate']);
		$message		=	$announce['content'];
		$groups			=	'';

		$fields = array('id', 'author', 'subject', 'type', 'displayorder', 'starttime', 'endtime', 'message', 'groups');
		$sql = getinsertsql("{$discuz_tablepre}announcements ", $fields);
		
		if($db['discuz']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ announcementid = $id");
		}
		$totalrows ++;
		$converted = 1;
	}
?>