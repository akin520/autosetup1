<?php
	if($start <= 1) {
		truncatetable_uc('pms');
		validid('messageid', 'privatemessages');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}privatemessages WHERE messageid BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}privatemessages' ����<br>�뽫����Ϣ�� {$source_tablepre}privatemessages �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	
	while($m = $db['source']->fetch_assoc($query)) {
		$m = array_change_key_case(daddslashes($m));
		//pms		
		$msgtoid = getuid($m['recipientusername']);
		if($msgtoid > 0) {
			$msgfrom 	= 	$m['senderusername'];
			$msgfromid 	= 	getuid($m['senderusername']);
			$folder 	= 	'inbox'; //����Ϣ�����ļ��У�inbox=�ռ��� outbox=�ݸ��䣩
			$new 		= 	$m['isread']; //�¶���Ϣ��0=�Ѷ� 1=δ�� 2=������ʾ��
			$subject	= 	$m['subject'];
			$dateline 	= 	sqltimetounix($m['createtime']);
			$dateline 	= 	$dateline > $timestamp ? $timestamp : $dateline;
			$message 	= 	@strip_tags(trim($m['body']));
			$delstatus 	= 	$m['issenderdelete'] ? 1 : ($m['isrecipientdelete'] ? 2 : 0); //ɾ��״̬��0=�� 1=������ 2=�����ߣ�
			$related	=	0;
			$fromappid	=	1;

			if($msgfromid){
				$checkfirstsql_1 = "SELECT count(*) FROM {$uc_tablepre}pms WHERE msgfromid='$msgfromid' AND msgtoid='$msgtoid' AND related='0'";
				$is_first_1 = $db['uc']->result($db['uc']->query($checkfirstsql_1), 0);
				$checkfirstsql_2 = "SELECT count(*) FROM {$uc_tablepre}pms WHERE msgfromid='$msgtoid' AND msgtoid='$msgfromid' AND related='0'";
				$is_first_2 = $db['uc']->result($db['uc']->query($checkfirstsql_2), 0);
				
				if(!$is_first_1 || !$is_first_2){
					if(!$is_first_1){
						$db['uc']->query("INSERT INTO {$uc_tablepre}pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus, related, fromappid) VALUES ('$msgfrom', '$msgfromid', '$msgtoid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus', '$related', '$fromappid')");
					}
					if(!$is_first_2){
						$db['uc']->query("INSERT INTO {$uc_tablepre}pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus, related, fromappid) VALUES ('$msgfrom', '$msgtoid', '$msgfromid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus', '$related', '$fromappid')");
					}
				}else{
					$db['uc']->query("UPDATE {$uc_tablepre}pms SET subject='$subject', dateline='$dateline' AND message='$message' WHERE msgfrom='$msgfromid' AND msgtoid='$msgtoid' AND related='0'");
				}
				$related	=	1;	
			}

			$fields = array('msgfrom','msgfromid','msgtoid','folder','new','subject','dateline','message','delstatus','related','fromappid');
			$sql = getinsertsql("{$uc_tablepre}pms", $fields);

			if($db['uc']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������Ϣ <br>".$sql."<br>".mysqlerror());
			}
			$totalrows ++;
		}
		$converted = 1;
	}

?>