<?php
	$query	=	$db['source']->query("SELECT * FROM {$source_tablepre}sitesettings");

	while($setting = $db['source']->fetch_assoc($query)) {
		$setting = array_change_key_case($setting);
		
		preg_match_all('|<([^>]+)>(.*)</([^>]+)>|U', trim($setting['sitesettingsxml']), $s_array);
		$s = array();
		foreach ($s_array[0] as $value) {
			preg_match('|<([^>]+)>(.*)</([^>]+)>|U', trim($value), $a);
			if (!empty($a[1]) && strtolower($a[1]) == strtolower($a[3])) {
				$s[strtolower($a[1])] = $a[2];
			}			
		}
		$fieldarray = array(
				'sitename' => 'sitename',
				'siteurl' => 'siteurl',
				'bbclosed' => 'sitedisabled',
				'seodescription' => 'metadescription',
				'seokeywords' => 'metakeywords',
				'oltimespan' => 'useronlinetime',
				'whosonlinestatus' => 'displaywhoisonline',
				'floodctrl' => 'postinterval',
				'newbiespan' => 'regusertimepost',
				'hottopic' => 'popularpostthresholdposts',
				'censoruser' => 'bannedregusername',
				'regverify' => 'allownewuserregistration',
				);
		foreach($fieldarray AS $key => $val) {
			$a = $s[$val];
			$sql = "REPLACE INTO {$discuz_tablepre}settings (variable, value) VALUES ('$key', '$a')";
			if ($db['discuz']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("������̳�����������ݳ�����$key => $setting[$key]����䣺<br>$sql".mysqlerror());
			}
			$totalrows++;
		}
	}
?>