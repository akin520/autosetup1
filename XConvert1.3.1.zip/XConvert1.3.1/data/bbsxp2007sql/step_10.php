<?php
	//�������ڰ�� fid ��Ӧ��ϵ
	$query = $db['discuz']->query("SELECT pid FROM {$discuz_tablepre}posts LIMIT $limit_start, $rpp");
	while($p = $db['discuz']->fetch_array($query)) {
		$sql = "UPDATE {$discuz_tablepre}posts p, {$discuz_tablepre}threads t SET p.fid=t.fid WHERE p.pid='$p[pid]' AND p.tid=t.tid";

		if ($db['discuz']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog(mysqlerror());
		}
		$converted = 1;
		$totalrows ++;
	}
?>