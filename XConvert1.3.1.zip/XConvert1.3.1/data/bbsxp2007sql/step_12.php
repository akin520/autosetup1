<?php
	//������̳
	truncatetable('forumlinks');
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Links ORDER BY linkid");

	while($fl = $db['source']->fetch_assoc($query)) {		
		//forumlinks		
		$fl	= array_change_key_case(daddslashes($fl));
		$displayorder 	= 	$f1['sortorder'];
		$name	= 	cutstr(@strip_tags(trim($fl['name'])),100);
		$url	= 	cutstr(@strip_tags(trim($fl['url'])),100);
		$description 	= 	cutstr(@strip_tags(trim($fl['intro'])),200);
		$logo	= 	cutstr(@strip_tags(trim($fl['logo'])),100);
		
		$sql	= "INSERT INTO {$discuz_tablepre}forumlinks (displayorder, name, url, description, logo) VALUES ('$displayorder', '$name', '$url', '$description', '$logo');";
		if( $db['discuz']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת��������̳ $name");
		}
		$totalrows ++;
	}
?>