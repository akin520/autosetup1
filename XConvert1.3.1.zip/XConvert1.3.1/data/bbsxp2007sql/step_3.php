<?php

	truncatetable('forums');
	truncatetable('forumfields');
	truncatetable('moderators');
	
	//��������Ӱ��
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Forums ORDER BY forumid");
	$forumids = array();
	while($forum = $db['source']->fetch_array($query)) {

		$forum = array_change_key_case(daddslashes($forum));		
		//forums
		$fid			=	$forum['forumid'];
		$fup			=	$forum['parentid'];
		$type			=	$fup == 0 ? 'forum' : 'sub'; //������ͣ�group=���� forum=��� sub=�Ӱ�飩
		$name			=	cutstr(htmlspecialchars(trim(@strip_tags($forum['forumname']))), 50);
		$status			=	$forum['isactive'] ? 1 : 0;
		$displayorder	=	$forum['sortorder'];
		$styleid		=	0;
		$threads		=	$forum['totalthreads'];
		$posts			=	$forum['totalposts'];
		$todayposts		=	$forum['todayposts'];
		$lastpost		=	'';
		$allowsmilies	=	1;
		$allowhtml		=	0;
		$allowbbcode	=	$allowsmilies;
		$allowimgcode	=	$allowsmilies;
		$allowmediacode = 	0;
		$allowanonymous = 	0;
		$allowshare		=	$allowsmilies;
		$allowpostspecial	=	3;
		$allowspecialonly 	= 	'';
		$alloweditrules	=	0;
		$recyclebin		=	0;
		$modnewposts	=	0;
		$jammer			=	0;
		$disablewatermark	=	0;
		$inheritedmod	=	0;
		$autoclose		=	0;
		$forumcolumns 	= 	0;
		$threadcaches 	= 	0;
		$allowpaytoauthor 	= 	1;
		$alloweditpost 	= 	1;
		$simple 		= 	'';
		//forumfields		
		$description	=	@strip_tags($forum['forumdescription']);
		$password		=	'';
		$icon			=	trim($forum['forumicon']);
		$postcredits	=	'';
		$replycredits	=	'';
		$getattachcredits 	= 	'';
		$postattachcredits 	= 	'';
		$digestcredits 	= 	'';
		$redirect		=	'';
		$attachextensions	=	'';
		$formulaperm 	= 	'';
		$moderators		=	addmoderators(explode('|', $forum['moderated']), $fid);
		$rules			=	$forum['forumrules'];
		$threadtypes	=	'';
		$viewperm		=	'';
		$postperm		=	'';
		$replyperm		=	'';
		$getattachperm	=	'';
		$postattachperm	=	'';
		$keywords 		= 	'';
		$supe_pushsetting 	= 	'';
		$modrecommend 	= 	'';
		$tradetypes 	= 	'';
		$typemodels 	= 	'';
		
		$sql1	=	"INSERT INTO {$discuz_tablepre}forums (fid, fup, type, name, status, displayorder, styleid, threads, posts, todayposts, lastpost, allowsmilies, allowhtml, allowbbcode, allowimgcode, allowmediacode, allowanonymous, allowshare, allowpostspecial, allowspecialonly, alloweditrules, recyclebin, modnewposts, jammer, disablewatermark, inheritedmod, autoclose, forumcolumns, threadcaches, allowpaytoauthor, alloweditpost, simple) VALUES ('$fid', '$fup', '$type', '$name', '$status', '$displayorder', '$styleid', '$threads', '$posts', '$todayposts', '$lastpost', '$allowsmilies', '$allowhtml', '$allowbbcode', '$allowimgcode', '$allowmediacode', '$allowanonymous', '$allowshare', '$allowpostspecial', '$allowspecialonly', '$alloweditrules', '$recyclebin', '$modnewposts', '$jammer', '$disablewatermark', '$inheritedmod', '$autoclose', '$forumcolumns', '$threadcaches', '$allowpaytoauthor', '$alloweditpost', '$simple');";

		$sql2	=	"INSERT INTO {$discuz_tablepre}forumfields (fid, description, password, icon, postcredits, replycredits, getattachcredits, postattachcredits, digestcredits, redirect, attachextensions, formulaperm, moderators, rules, threadtypes, viewperm, postperm, replyperm, getattachperm, postattachperm, keywords, supe_pushsetting, modrecommend, tradetypes, typemodels) VALUES ('$fid', '$description', '$password', '$icon', '$postcredits', '$replycredits', '$getattachcredits', '$postattachcredits', '$digestcredits', '$redirect', '$attachextensions', '$formulaperm', '$moderators', '$rules', '$threadtypes', '$viewperm', '$postperm', '$replyperm', '$getattachperm', '$postattachperm', '$keywords', '$supe_pushsetting', '$modrecommend', '$tradetypes', '$typemodels');";
	
		$sql3	=	"DELETE FROM {$discuz_tablepre}moderators WHERE `fid`='$fid';";

		if($db['discuz']->query($sql1)) {
			if($db['discuz']->query($sql2)) {
				if($fup == 0)
					$forumids[$forum['forumid']] = $forum['groupid'];
				$convertedrows ++;
			} else {
				$db['discuz']->query($sql3);
				$db['discuz']->query("DELETE FROM `{$discuz_tablepre}forums` WHERE `fid`='$fid' LIMIT 1;");
				reportlog("���������չ��Ϣ���ݳ��� fid = $fid name = $name");
			}
		} else {
			$db['discuz']->query($sql3);
			reportlog("��������������ݳ��� fid = $fid name = $name");
		}
		$totalrows ++;
	}

	//�������

	$query1 = $db['source']->query("SELECT * FROM {$source_tablepre}Groups ORDER BY groupid");
	$groupids = array();
	$i = 0;
	while($group = $db['source']->fetch_array($query1)) {

		$group = array_change_key_case(daddslashes($group));		
		//forums
		//$fid			=	$group['groupd'];
		$fup			=	0;
		$type			=	'group'; //������ͣ�group=���� forum=��� sub=�Ӱ�飩
		$name		=	cutstr(htmlspecialchars(trim(@strip_tags($group['groupname']))), 50);
		$status		=	1;
		$displayorder	=	$group['sortorder'];
		//forumfields		
		$description	 	=	@strip_tags($group['groupdescription']);
		
		$sql4 = "INSERT INTO {$discuz_tablepre}forums (fup, type, name, status, displayorder) VALUES ('$fup', '$type', '$name', '$status', '$displayorder');";

		
		$i++;
		//echo ($i);
		if($db['discuz']->query($sql4)) {
			$fid = mysql_insert_id();
			$sql5 = "INSERT INTO {$discuz_tablepre}forumfields (fid, description) VALUES ('$fid', '$description');";
			//echo ($i);
			if($db['discuz']->query($sql5)) {
				//echo ($i).'<br>';
				$groupids[$group['groupid']] = $fid;
				$convertedrows ++;
			} else {
				reportlog("���������չ��Ϣ���ݳ��� fid = $fid name = $name");
			}
		} else {
			reportlog("��������������ݳ��� fid = $fid name = $name");
		}
		$totalrows ++;
	}
	
	//���°����������

	foreach ($forumids as $f_id => $g_old_id) {
		$sql = "UPDATE {$discuz_tablepre}forums SET fup=".$groupids[$g_old_id]." WHERE fid=$f_id";
		if(!$db['discuz']->query($sql)) {
			reportlog("���°�������������� fid = $f_id ԭʼgid = $g_old_id ��gid = ".$groupids[$g_old_id]);
		}
	}

	altertable('forums', 'fid');
	altertable('forumfields', 'fid');
	altertable('moderators', 'fid');
?>