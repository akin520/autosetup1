<?php
	if($start <= 1) {
		truncatetable('threads');
		truncatetable('polls');
		truncatetable('polloptions');
		validid('threadid', 'threads');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Threads WHERE forumid BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}Threads' ����<br>�뽫����� '{$source_tablepre}Threads' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');

	while($t = $db['source']->fetch_array($query)) {
		$t = array_change_key_case(daddslashes($t));
		//threads		
		$tid			=	$t['threadid'];
		$fid			=	$t['forumid'];
		$iconid			=	0;
		$typeid			=	0;
		$readperm		=	0;
		$price			=	0;
		$author			=	cutstr(htmlspecialchars(trim($t['postauthor'])), 15);
		$authorid		= 	getuid(trim($t['postauthor']));
		$subject		=	cutstr(htmlspecialchars(trim(@strip_tags($t['topic']))), 78);
		$dateline		=	sqltimetounix($t['posttime']);
		$lastpost		=	sqltimetounix($t['lasttime']);
		$lastposter		=	cutstr(htmlspecialchars(trim($t['lastname'])), 15);
		$views			=	$t['totalviews'];
		$replies		=	$t['totalreplies'];
		$displayorder	=	$t['isdel'] ? '-1' : ($t['istop'] > 3 ? 3 : $t['istop']);
		$highlight		=	0;
		$digest			=	$t['isgood'];
		$rate			=	0;
		$blog			=	0;
		$special 		= 	$t['isvote'] ? 1 : 0;
		$attachment		=	0;
		$subscribed		=	0;		
		$moderated		=	0;
		$closed			=	$t['islocked'];
		$itemid 		= 	'';
		$supe_pushstatus 	= 	'';
		$sgid 			= 	'';
		
		if ($t['isvote']) {
			//echo 1;
			$vote_query = $db['source']->query("SELECT ThreadID, IsMultiplePoll, Expiry, Items, Result FROM {$source_tablepre}Votes WHERE ThreadID='$tid';") or dexit("�������ݱ� '{$source_tablepre}Votes' ����<br>�뽫ͶƱ�� '{$source_tablepre}Votes' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
			//echo 2;
			$vote = $db['source']->fetch_array($vote_query);
			$vote = array_change_key_case(daddslashes($vote));
			//exit($vote['ThreadID']);
			//polls
			$multiple = $vote['ismultiplepoll'];
			$visible = 1;
			$maxchoices = 1;
			$expiration = sqltimetounix($vote['expiry']);
			
			$polloptions = explode('|', $vote['items']);
			$polloption_nums = explode('|', $vote['result']);

			$sql2 = "INSERT INTO {$discuz_tablepre}polls (tid, multiple, visible, maxchoices, expiration) VALUES ('$tid', '$multiple', '$visible', '$maxchoices', '$expiration');";
			
		}
		

		$sql1 = "INSERT INTO {$discuz_tablepre}threads (tid, fid, iconid, typeid, readperm, price, author, authorid, subject, dateline, lastpost, lastposter, views, replies, displayorder, highlight, digest, rate, blog, special, attachment, subscribed, moderated, closed, itemid, supe_pushstatus, sgid) VALUES ('$tid', '$fid', '$iconid', '$typeid', '$readperm', '$price', '$author', '$authorid', '$subject', '$dateline', '$lastpost', '$lastposter', '$views', '$replies', '$displayorder', '$highlight', '$digest', '$rate', '$blog', '$special', '$attachment', '$subscribed', '$moderated', '$closed', '$itemid', '$supe_pushstatus', '$sgid');";
				
		if($db['discuz']->query($sql1)){
			$convertedrows ++;
			if($t['isvote'] && $db['discuz']->query($sql2)){
				$flag = 1;				
				for ($i = 0; $i < count($polloptions); $i++) {
					//polloptions
					$votes = trim($polloption_nums[$i]); //Ʊ��
					$displayorder = 0;
					$polloption = trim($polloptions[$i]); //����
					$voterids = '';
					
					if ($votes == '' || $votes < 0 || empty($polloption)) {
						break;
					}
					
					$sql3 = "INSERT INTO {$discuz_tablepre}polloptions (tid, votes, displayorder, polloption, voterids) VALUES ('$tid', '$votes', '$displayorder', '$polloption', '$voterids');";
					
					if (!$db['discuz']->query($sql3)) {
						break;
						$flag = 0;
						reportlog("�޷�ת��ͶƱ��ѡ�� tid = $tid polloption = '$polloption'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql3."</textarea>");
					}
				}
				if ($flag) {
					$convertedrows ++;
				} else {
					$db['discuz']->query("DELETE FROM `{$discuz_tablepre}threads` WHERE `tid`='$tid';");
					$db['discuz']->query("DELETE FROM `{$discuz_tablepre}polls` WHERE `tid`='$tid';");
					$db['discuz']->query("DELETE FROM `{$discuz_tablepre}polloptions` WHERE `tid`='$tid';");
					reportlog("�޷�ת��ͶƱѡ�� tid = $tid subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql3."</textarea>");
				}
			}
		} else {
			reportlog("�޷�ת������ tid = $tid subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql1."</textarea>");
		}
		$converted = 1;
		$totalrows ++;
	}

?>