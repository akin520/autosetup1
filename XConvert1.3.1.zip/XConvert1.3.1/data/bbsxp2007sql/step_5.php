<?php
	if($start <= 1) {
		truncatetable('attachments');
		validid('upfileid', 'postattachments');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}postattachments WHERE threadid <> 0 AND upfileid BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}postattachments' ����<br>�뽫������ '{$source_tablepre}postattachments' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while ($a = $db['source']->fetch_assoc($query)) {
		$a = array_change_key_case(daddslashes($a));
		//attachments
		$aid 		= 	$a['upfileid'];
		$tid 		= 	$a['threadid'];
		$pid 		= 	$a['threadid'];
		$dateline 	= 	sqltimetounix($a['created']);
		$readperm 	= 	0;
		$price 		= 	0;
		$filename 	= 	$a['filename'];
		$description 	= 	$a['description'];
		$filetype 	= 	$a['contenttype'];
		$filesize 	= 	$a['contentsize'];
		$attachment = 	str_replace('UpFile/UpAttachment', 'bbsxp', $a['filepath']);
		$downloads 	= 	0;
		$isimage 	= 	substr($filetype, 0, 5) == 'image' ? 1 : 0;
		$uid 		= 	getuid($a['username']);
		$thumb 		= 	0;
		$remote 	= 	0;
		
		$sql = "INSERT INTO {$discuz_tablepre}attachments (aid, tid, pid, dateline, readperm, price, filename, description, filetype, filesize, attachment, downloads, isimage, uid, thumb, remote) VALUES ('$aid', '$tid', '$pid', '$dateline', '$readperm', '$price', '$filename', '$description', '$filetype', '$filesize', '$attachment', '$downloads', '$isimage', '$uid', '$thumb', '$remote');";

		if($db['discuz']->query($sql)){
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ upfileid = '".$a['upfileid']."'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
		}

		$converted = 1;
		$totalrows ++;
	}

	if($converted || $end < $maxid) {
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid."&tableid=$tableid");
	} elseif($tableid < $tablecount - 1) {
		validid('upfileid', 'postattachments');
		$end = $start - 1;
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.($tableid+1));
	}

?>