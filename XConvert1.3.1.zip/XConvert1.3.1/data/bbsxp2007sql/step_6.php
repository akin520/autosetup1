<?php
	$tableid = isset($_GET['tableid']) ? $_GET['tableid'] : 0;
	$tablearray = explode(',', str_replace('  ', '', $posttbl));
	$tablecount = count($tablearray);
	$tableid = intval($tableid);
	$posttable = $source_tablepre.$tablearray[$tableid];

	if($start <= 1 && $tableid == 0) {
		truncatetable('posts');
		validid('threadid', $tablearray[0], '');
	}
$i = 0;
	$query = $db['source']->query("SELECT * FROM $posttable WHERE threadid BETWEEN $start AND $end") or dexit("�������ݱ� '$posttable' ����<br>�뽫���ӱ� '$posttable' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while ($p = $db['source']->fetch_assoc($query)) {
		$p = array_change_key_case(daddslashes($p));
		//posts
		$pid			=	$p['id'];
		$fid			=	0;
		$tid			=	$p['threadid'];
		$first			=	$p['parentid'] == 0 ? 1 : 0;
		$author			=	$p['postauthor'];
		$authorid		=	getuid($author);
		$subject		=	cutstr(@strip_tags(trim($p['subject'])), 78);
		$dateline		=	sqltimetounix($p['postdate']);
		$message		=	 preg_replace('|http://bbs.wxqcw.com/|', '', str_replace('UpFile/UpAttachment', 'attachments/bbsxp', $p['body']));
		/*
		$temp = array();
		if(preg_match_all('|http:\/\/bbs.wxqcw.com/|', $message, $temp) > 0){
			$i++;
			echo $message.'<hr>\n\r';
			echo preg_replace('|http:\/\/bbs.wxqcw.com/|', '', $message);
			
		}
		if($i == 5) exit;*/
		$useip			=	$p['ipaddress'];
		$invisible 		= 	0;
		$anonymous 		= 	0;
		$usesig			=	0;
		$htmlon			=	@strip_tags($message) == $message ? 0 : 1;
		$bbcodeoff		=	-1;
		$smileyoff		=	-1;
		$parseurloff	=	0;
		
		$att = $db['source']->query("SELECT count(*) sum FROM {$source_tablepre}postattachments WHERE threadid = '$tid'");
		$p1 = $db['source']->fetch_assoc($att);
		
        $attachment		=	$p1['sum'] > 0  && $p['parentid'] == 0 ? 1 : 0;
		$rate			=	0;
		$ratetimes		=	0;
		$status 		= 	0;

		$sql = "INSERT INTO {$discuz_tablepre}posts (pid, fid, tid, first, author, authorid, subject, dateline, message, useip, invisible, anonymous, usesig, htmlon, bbcodeoff, smileyoff, parseurloff, attachment, rate, ratetimes, status) VALUES ('$pid', '$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$invisible', '$anonymous', '$usesig', '$htmlon', '$bbcodeoff', '$smileyoff', '$parseurloff', '$attachment', '$rate', '$ratetimes', '$status');";

		if($db['discuz']->query($sql)){
			//$pid = mysql_insert_id();
			if($p['parentid'] == 0) {
				$db['discuz']->query("UPDATE {$discuz_tablepre}attachments set pid='$pid' WHERE tid='$tid'");
			} 
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
		}

		$converted = 1;
		$totalrows ++;
	}

	if($converted || $end < $maxid) {
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid."&tableid=$tableid");
	} elseif($tableid < $tablecount - 1) {
		validid('id', $tablearray[$tableid+1], '');
		$end = $start - 1;
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.($tableid+1));
	}

?>