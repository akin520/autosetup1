<?php
	//���Ӹ��� pid ��Ӧ��ϵ
	$query = $db['discuz']->query("SELECT tid FROM {$discuz_tablepre}attachments LIMIT $limit_start, $rpp");

	while($t = $db['discuz']->fetch_array($query)) {

		$sql = "UPDATE {$discuz_tablepre}attachments a, {$discuz_tablepre}posts p SET a.pid=p.pid WHERE a.tid=p.tid AND p.first=1;";
		
		if ($db['discuz']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog(mysqlerror());
		}
		$converted = 1;
		$totalrows ++;
	}
?>