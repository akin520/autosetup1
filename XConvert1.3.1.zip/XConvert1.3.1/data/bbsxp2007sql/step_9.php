<?php
	//�������� uid ��Ӧ��ϵ
	$query	=	$db['discuz']->query("SELECT pid FROM {$discuz_tablepre}posts LIMIT $limit_start, $rpp");
	while($p =	$db['discuz']->fetch_array($query)) {

		$sql	=	"UPDATE {$discuz_tablepre}posts p, {$discuz_tablepre}members m SET p.authorid=m.uid WHERE p.pid='$p[pid]' AND p.author=m.username";

		if ($db['discuz']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog(mysqlerror());
		}
		$converted = 1;
		$totalrows ++;
	}
?>