<?php
	if($start <= 1) {
		truncatetable('members');
		truncatetable('memberfields');
		truncatetable_uc('members');
		truncatetable_uc('memberfields');
		validid('id', 'users');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}users WHERE (id BETWEEN $start AND $end)");

	while ($user = $db['source']->fetch_assoc($query)) {

		$user =	array_change_key_case($user);
		$uid = $user['id'];
		$username = trim($user['username']);

		if(!$username || $username != htmlspecialchars(daddslashes($username))) {
			reportlog("�Ƿ��û��� <b><font color='red'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
		} elseif(strlen($username) > 15) {
			reportlog("�û��� <b><font color='orange'>$username</font></b> ���ȴ��� 15�����ܱ�ת����uid = $uid ��<br>\r\n");
		} elseif(getuid($username)) {
			reportlog("�ظ��û��� <b><font color='blue'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
		} else {
			$user = daddslashes($user);

			//uc members
				$ucpw		=	convertucpw($user['userpass']);
			$password		=	$ucpw['password'];
			$email			=	cutstr($user['useremail'], 32);
			$myid			=	'';
			$myidkey		=	'';
			$regip			=	'bbsxp';
			$regdate		=	sqltimetounix($user['userregtime']);
			$lastloginip	=	$user['userlastip'] ? $user['userlastip'] : 'bbsxp';
			$lastlogintime	=	sqltimetounix($user['userlandtime']);
			$salt			=	$ucpw['salt'];

			//uc memberfields
			$blacklist		=	'';

			//members
			//$password		=	strtolower($user['userpass']);
			$gender			=	($user['sex'] == 'male') ? 1 : (($user['sex'] == 'female') ? 2 : 0);
			$adminid		=	0;
			$groupid		=	$user['useraccountstatus'] == 1 ? 10 : 8;
			if(in_array($user['userroleid'], array(1,2))) {
				$groupid	= $adminid = $user['userroleid'];
			}
			$groupexpiry	=	0;
			$regip			=	'bbsxp';
			$regdate		=	sqltimetounix($user['userregtime']);
			$lastip			=	$user['userlastip'] ? $user['userlastip'] : 'bbsxp';
			$lastvisit		=	sqltimetounix($user['userlandtime']);
			$lastactivity	=	$lastvisit;
			$lastpost		=	$lastvisit;
			$posts			=	$user['posttopic'] + $user['postrevert'];
			$digestposts	=	$user['goodtopic'];
			$oltime			=	0;
			$pageviews		=	0;
			$credits		=	$user['experience'];		//����
			$extcredits1	=	$user['experience'];		//����ֵ
			$extcredits2	=	$user['usermoney'] + $user['savemoney'];//��Ǯ
			$extcredits3	=	0;		
			$extcredits4	=	0;
			$extcredits5	=	0;
			$extcredits6	=	0;
			$extcredits7	=	0;
			$extcredits8	=	0;
			$email			=	cutstr($user['usermail'], 40);
			$bday			=	$user['birthday'] ? @date('Y-m-d', $user['birthday']) : '0000-00-00';
				$signature	=	@strip_tags(trim($user['usersign']));
        	$sigstatus		=	$signature ? 1 : 0;
			$tpp			=	'0';
			$ppp			=	'0';
			$styleid		=	'0';
			$dateformat		=	'0';
			$timeformat		=	'0';
			$pmsound		=	'0';
			$showemail		=	'0';
			$newsletter		=	'1';
			$invisible		=	'0';
			$timeoffset		=	'9999';
			$accessmasks 	= 	0;
			$editormode		= 	2;
			$customshow		= 	26;
			$xspacestatus 	= 	0;
			
			$userimArray	=	explode("\\",$user['userim']);
        	$userinfoArray	=	explode("\\",$user['userinfo']);

        	$user['icq']	=	trim($userimArray[1]);
        	$user['qq']		=	trim($userimArray[0]);
        	$user['yahoo']	=	trim($userimArray[4]);
        	$user['msn']	=	trim($userimArray[3]);

			if ($user['userhome'] && strtolower($user['userhome']) != 'http://') {
        		$user_site	=	trim(preg_match("/^https?:\/\/.+/i", $user['userhome']) ? $user['userhome'] : ($user['userhome'] ? 'http://'.$user['userhome'] : ''));
        		$user_site	=	$user_site ? htmlspecialchars($user_site) : '';
        		$user_site	=	$user_site ? cutstr($user_site,75) : '';
        	}

			$nickname 		= 	'';
			$site 			= 	parsesite($u['homepage']);
			$icq			=	parseqqicq($user['icq']);
			$qq				=	parseqqicq($user['qq']);
			$yahoo			=	$user['yahoo'] ? htmlspecialchars(cutstr($user['yahoo'], 40)) : '';
			$msn			=	$user['msn'] ? htmlspecialchars($user['msn']) : '';	$taobao		=	'';
			$location		=	$userinfoArray[2] ? cutstr(htmlspecialchars(trim(strip_tags($userinfoArray[2]))), 30) : '';
			$customstatus	=	$user['userhonor'] ? cutstr(htmlspecialchars(trim(strip_tags($user['userhonor']))), 30) : '';
			$medals 		= 	'';

			if($user['userface'] && $user['userface'] != 'http://') {
				$user['userface'] = trim($user['userface']);
				if(substr($user['userface'], 0, 7) == 'http://') {
					$avatar = $user['userface'];
					$avatarwidth = 83;
					$avatarheight = 94;
				} else {
					if(strtolower(substr($user['userface'], 0, 12)) == 'images/face/') {
						$avatar = 'images/avatars/bbsxp/'.substr($user['userface'], 12);
						$avatarwidth = 83;
						$avatarheight = 94;
					} elseif(strtolower(substr($user['userface'], 0, 114)) == 'upfile/upface/') {
						$avatar = 'customavatars/bbsxp/'.substr($user['userface'], 14);
						$avatarwidth = 83;
						$avatarheight = 94;
					} else {
						$avatar = $user['userfaceurl'];
						$avatarwidth = 83;
						$avatarheight = 94;
					}
				}
			} else {
				$avatar = '';
				$avatarwidth = 0;
				$avatarheight = 0;
			}

			$bio			=	$userinfoArray[14] ? cutstr(htmlspecialchars($userinfoArray[14]), 100) : '';
			$sightml		=	parsesign($user['usersign']);
			$ignorepm 		= 	'';
			$groupterms		= 	'';
			$authstr 		= 	'';
			$spacename 		= 	'';
			$buyercredit 	= 	'';
			$sellercredit 	= 	'';
			$secques		=	'';
			$prompt			=	'';

			$fields1 = array('uid', 'username', 'password', 'email', 'myid', 'myidkey', 'regip', 'regdate', 'lastloginip', 'lastlogintime', 'salt', 'secques');
			$query1 = getinsertsql("{$uc_tablepre}members", $fields1);

			$fields2 = array('uid', 'blacklist');
			$query2 = getinsertsql("{$uc_tablepre}memberfields", $fields2);

			$fields3 = array('uid', 'username', 'password', 'secques', 'gender', 'adminid', 'groupid', 'groupexpiry', 'extgroupids', 'regip', 'regdate', 'lastip', 'lastvisit', 'lastactivity', 'lastpost', 'posts', 'digestposts', 'oltime', 'pageviews', 'credits', 'extcredits1', 'extcredits2', 'extcredits3', 'extcredits4', 'extcredits5', 'extcredits6', 'extcredits7', 'extcredits8', 'email', 'bday', 'sigstatus', 'tpp', 'ppp', 'styleid', 'dateformat', 'timeformat', 'pmsound', 'showemail', 'newsletter', 'invisible', 'timeoffset', 'prompt', 'accessmasks', 'editormode', 'customshow', 'xspacestatus');
			$query3 = getinsertsql("{$discuz_tablepre}members", $fields3);

			$fields4 = array('uid','nickname','site','alipay','icq','qq','yahoo','msn','taobao','location','customstatus','medals','avatar','avatarwidth','avatarheight','bio','sightml','ignorepm','groupterms','authstr','spacename','buyercredit','sellercredit');
			$query4 = getinsertsql("{$discuz_tablepre}memberfields", $fields4);

			$fields5 = array('uid', 'qq', 'avatar', 'avatarwidth', 'avatarheight', 'bio', 'sightml');
			$query5 = getinsertsql("{$discuz_tablepre}memberfields", $fields5);

			if ($db['uc']->query($query1)) {
				if ($db['uc']->query($query2)) {
					$password = strtolower($user['userpass']);
					if ($db['discuz']->query($query3)) {
						if ($db['discuz']->query($query4)) {
							$convertedrows ++;
						} else {
							if ($db['discuz']->query($query5)) {
								$convertedrows ++;
							} else {
								$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
								$db['uc']->query("DELETE FROM {$uc_tablepre}memberfields WHERE uid='$uid' LIMIT 1;");
								$db['discuz']->query("DELETE FROM {$discuz_tablepre}members WHERE uid='$uid' LIMIT 1;");
								reportlog("���� DZ ��Ա��չ��Ϣ���ݳ��� uid = $uid username = $username");
							}
						}
					} else {
						$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
						$db['uc']->query("DELETE FROM {$uc_tablepre}memberfields WHERE uid='$uid' LIMIT 1;");
						reportlog("���� DZ ��Ա�������ݳ��� uid = $uid username = $username");
					}
				} else {
					$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
					reportlog("���� UC ��Ա��չ��Ϣ���ݳ��� uid = $uid username = $username");
				}
			} else {
				reportlog("�� UC �����Ա�������ݳ��� uid = $uid username = $username");
			}
		}
		$converted = 1;
		$totalrows ++;
	}

?>