<?php

	truncatetable('forums');
	truncatetable('forumfields');
	truncatetable('moderators');

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Forums ORDER BY id");
	while($forum = $db['source']->fetch_array($query)) {

		$forum = array_change_key_case(daddslashes($forum));

		$fid				=	$forum['id'];
		$fup				=	$forum['followid'];
		$type				=	$fup == 0 ? 'group' : 'forum';
		$name				=	cutstr(htmlspecialchars(trim(@strip_tags($forum['forumname']))), 50);
		$displayorder		=	$forum['sortnum'];
		$styleid			=	0;
		$threads			=	$forum['forumthreads'];
		$posts				=	$forum['forumposts'];
		$todayposts			=	$forum['forumtoday'];
		$lastpost			=	'';
		$status				=	$forum['forumhide'] ? 0 : 1;
		$allowsmilies		=	1;
		$allowhtml			=	0;
		$allowbbcode		=	$allowsmilies;
		$allowimgcode		=	$allowsmilies;
		$modnewposts		=	0;
		$allowshare			=	$allowsmilies;
		$allowpostspecial	=	3;
		$alloweditrules		=	0;
		$recyclebin			=	0;
		$jammer				=	0;
		$disablewatermark	=	0;
		$inheritedmod		=	0;
		$autoclose			=	0;
		$description		=	@strip_tags($forum['forumintro']);
		$password			=	'';
		$icon				=	trim($forum['forumicon']);
		$postcredits		=	'';
		$replycredits		=	'';
		$redirect			=	'';
		$attachextensions	=	'';
		$moderators			=	addmoderators(explode('|', $forum['moderated']), $fid);
		$rules				=	$forum['forumrules'];
		$threadtypes		=	'';
		$viewperm			=	'';
		$postperm			=	'';
		$replyperm			=	'';
		$getattachperm		=	'';
		$postattachperm		=	'';
		$modworks			=	0;
		$threadplugin		=	'';
		$extra				=	'';

		$query1	=	"INSERT INTO {$discuz_tablepre}forums ( `fid` , `fup` , `type` , `name` , `status` , `displayorder` , `styleid` , `threads` , `posts` , `todayposts` , `lastpost` , `allowsmilies` , `allowhtml` , `allowbbcode` , `allowimgcode` , `allowshare` , `allowpostspecial` , `alloweditrules` , `recyclebin` , `modnewposts` , `jammer` , `disablewatermark` , `inheritedmod` , `autoclose`, `alloweditpost`, `modworks`) VALUES ('$fid','$fup','$type','$name','$status','$displayorder','$styleid','$threads','$posts','$todayposts','$lastpost','$allowsmilies','$allowhtml','$allowbbcode','$allowimgcode','$allowshare','$allowpostspecial','$alloweditrules','$recyclebin','$modnewposts','$jammer','$disablewatermark','$inheritedmod','$autoclose','1','$modworks');";

		$query2	=	"INSERT INTO {$discuz_tablepre}forumfields ( `fid` , `description` , `password` , `icon` , `postcredits` , `replycredits` , `redirect` , `attachextensions` , `moderators` , `rules` , `threadtypes` , `viewperm` , `postperm` , `replyperm` , `getattachperm` , `postattachperm`, `threadplugin`, `extra`) VALUES ('$fid','$description','$password','$icon','$postcredits','$replycredits','$redirect','$attachextensions','$moderators','$rules','$threadtypes','$viewperm','$postperm','$replyperm','$getattachperm','$postattachperm','$threadplugin','$extra');";
	
		$query3	=	"DELETE FROM {$discuz_tablepre}moderators WHERE `fid`='$fid';";

		if($db['discuz']->query($query1)) {
			if($db['discuz']->query($query2)) {
				$convertedrows ++;
			} else {
				$db['discuz']->query($query3);
				$db['discuz']->query("DELETE FROM `{$discuz_tablepre}forums` WHERE `fid`='$fid' LIMIT 1;");
				reportlog("���������չ��Ϣ���ݳ��� fid = $fid name = $name");
			}
		} else {
			$db['discuz']->query($query3);
			reportlog("��������������ݳ��� fid = $fid name = $name");
		}
		$totalrows ++;
	}

	altertable('forums', 'fid');
	altertable('forumfields', 'fid');
	altertable('moderators', 'fid');
?>