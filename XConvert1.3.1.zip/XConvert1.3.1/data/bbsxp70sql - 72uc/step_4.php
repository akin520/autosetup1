<?php
	if($start <= 1) {
		truncatetable('threads');
		truncatetable('polls');
		truncatetable('polloptions');
		validid('id', 'threads');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Threads WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}Threads' ����<br>�뽫����� '{$source_tablepre}Threads' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');

	while($t = $db['source']->fetch_assoc($query)) {
		$t = array_change_key_case(daddslashes($t));

		$tid			=	$t['id'];
		$fid			=	$t['forumid'];
		$iconid			=	0;
		$typeid			=	0;
		$readperm		=	0;
		$price			=	0;
		$author			=	cutstr(htmlspecialchars(trim($t['username'])), 15);
		$authorid		= 	0;
		$subject		=	cutstr(htmlspecialchars(trim(@strip_tags($t['topic']))), 78);
		$dateline		=	sqltimetounix($t['posttime']);
		$lastpost		=	sqltimetounix($t['lasttime']);
		$lastposter		=	cutstr(htmlspecialchars(trim($t['lastname'])), 15);
		$views			=	$t['views'];
		$replies		=	$t['replies'];
		$displayorder	=	$t['isdel'] ? '-1' : ($t['istop'] > 3 ? 3 : $t['istop']);
		$highlight		=	0;
		$digest			=	$t['isgood'];
		$rate			=	0;
		$poll			=	0;
		$attachment		=	0;
		$moderated		=	0;
		$closed			=	$t['islocked'];
		$recommends     =  '';
		$recommend_add  =  '';
		$recommend_sub  =  '';
		$heats          =   0;
		$status			=	0;

		$sql1 = "INSERT INTO {$discuz_tablepre}threads (`tid` , `fid` , `iconid` , `typeid`, `readperm`, `price`,`author` , `authorid` , `subject` , `dateline` , `lastpost` , `lastposter` , `views` , `replies` , `displayorder` , `highlight` , `digest` , `rate` , `special` , `attachment` , `moderated` , `closed` , `recommends` , `recommend_add` , `recommend_sub` , `heats` , `status`) VALUES('$tid', '$fid', '$iconid', '$typeid', '$readperm', '$price', '$author', '$authorid', '$subject', '$dateline', '$lastpost', '$lastposter', '$views', '$replies', '$displayorder', '$highlight', '$digest', '$rate', '$poll', '$attachment', '$moderated', '$closed', '$recommends', '$recommend_add', '$recommend_sub', '$heats', '$status');";

		if($db['discuz']->query($sql1)){
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ tid = $tid subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql1."</textarea>");
		}
		$converted = 1;
		$totalrows ++;
	}
?>