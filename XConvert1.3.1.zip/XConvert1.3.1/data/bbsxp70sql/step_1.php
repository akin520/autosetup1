<?php
	$query	=	$db['source']->query("SELECT * FROM {$source_tablepre}sitesettings");

	while($setting = $db['source']->fetch_assoc($query)) {
		$setting = array_change_key_case($setting);
		$fieldarray = array(
				'sitename' => 'SiteName',
				'siteurl' => 'SiteURL',
				'bbclosed' => 'SiteDisabled',
				'seodescription' => 'metaDescription',
				'seokeywords' => 'metaKeywords',
				'oltimespan' => 'UserOnlineTime',
				'whosonlinestatus' => 'DisplayWhoIsOnline',
				'floodctrl' => 'DuplicatePostIntervalInMinutes',
				'newbiespan' => 'RegUserTimePost',
				'hottopic' => 'PopularPostThresholdPosts',
				'censoruser' => 'BannedRegUserName',
				'doublee' => 'OnlyMailReg',
				'regverify' => 'EnableUser',
				'bbrulestxt' => 'RegUserAgreement',
				);
		foreach($fieldarray AS $key => $val) {
			$a = $setting[$val];
			$sql = "REPLACE INTO {$discuz_tablepre}settings (variable, value) VALUES ('$key', '$a')";
			if ($db['discuz']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("������̳�����������ݳ�����$key => $setting[$key]����䣺<br>$sql".mysqlerror());
			}
			$totalrows++;
		}
	}
?>