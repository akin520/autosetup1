<?php
//����
	if($start <= 1) {
		truncatetable('announcements');
	}
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Affiche");
	while($a = $db['source']->fetch_assoc($query)) {
		$a		=	array_change_key_case(daddslashes($a));
		$id		=	$a['id'];
		$author		=	$a['username'];
		$subject	=	$a['title'];
		$starttime	=	$a['posttime'];
		$message	=	$a['message'];
		$sql = "INSERT INTO {$discuz_tablepre}announcements (id, author, subject, starttime, message) VALUES ('$id', '$author', '$subject', '$starttime', '$message');";

		if($db['discuz']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog(mysqlerror());
		}
		$totalrows ++;
	}
?>