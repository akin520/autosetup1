<?php
	if($start <= 1) {
		truncatetable('members');
		truncatetable('memberfields');
		validid('id', 'users');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}users WHERE (id BETWEEN $start AND $end)");

	while ($user = $db['source']->fetch_assoc($query)) {

		$user =	array_change_key_case($user);
		$uid = $user['id'];
		$username = trim($user['username']);

		if(!$username || $username != htmlspecialchars(daddslashes($username))) {
			reportlog("�Ƿ��û��� <b><font color='red'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
		} elseif(strlen($username) > 15) {
			reportlog("�û��� <b><font color='orange'>$username</font></b> ���ȴ��� 15�����ܱ�ת����uid = $uid ��<br>\r\n");
		} elseif(getuid($username)) {
			reportlog("�ظ��û��� <b><font color='blue'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
		} else {
			$user = daddslashes($user);

			$password	=	strtolower($user['userpass']);
			$gender		=	($user['sex'] == 'male') ? 1 : (($user['sex'] == 'female') ? 2 : 0);
			$adminid	=	0;
			$groupid	=	$user['useraccountstatus'] == 1 ? 10 : 8;
			if(in_array($user['userroleid'], array(1,2))) {
				$groupid = $adminid = $user['userroleid'];
			}
			$groupexpiry	=	0;
			$regip		=	'bbsxp';
			$regdate	=	sqltimetounix($user['userregtime']);
			$lastip		=	$user['userlastip'] ? $user['userlastip'] : 'bbsxp';
			$lastvisit	=	sqltimetounix($user['userlandtime']);
			$lastactivity	=	$lastvisit;
			$lastpost	=	$lastvisit;
			$posts		=	$user['posttopic'] + $user['postrevert'];
			$digestposts	=	$user['goodtopic'];
			$oltime		=	0;
			$pageviews	=	0;
			$credits	=	$user['experience'];		//����
			$extcredits1	=	$user['experience'];		//����ֵ
			$extcredits2	=	$user['usermoney'] + $user['savemoney'];	//��Ǯ
			$extcredits3	=	0;		
			$extcredits4	=	0;
			$extcredits5	=	0;
			$extcredits6	=	0;
			$extcredits7	=	0;
			$extcredits8	=	0;
			$email		=	cutstr($user['usermail'], 40);
			$bday		=	$user['birthday'] ? @date('Y-m-d', $user['birthday']) : '0000-00-00';
			
			$tpp		=	'0';
			$ppp		=	'0';
			$styleid	=	'0';
			$dateformat	=	'0';
			$timeformat	=	'0';
			$pmsound	=	'0';
			$showemail	=	'0';
			$newsletter	=	'1';
			$invisible	=	'0';
			$timeoffset	=	'9999';
			
			$userimArray	=	explode("\\",$user['userim']);
        		$userinfoArray	=	explode("\\",$user['userinfo']);

        		$user['icq']	=	trim($userimArray[1]);
        		$user['qq']	=	trim($userimArray[0]);
        		$user['yahoo']	=	trim($userimArray[4]);
        		$user['msn']	=	trim($userimArray[3]);

			if ($user['userhome'] && strtolower($user['userhome']) != 'http://') {
        			$user_site	=	trim(preg_match("/^https?:\/\/.+/i", $user['userhome']) ? $user['userhome'] : ($user['userhome'] ? 'http://'.$user['userhome'] : ''));
        			$user_site	=	$user_site ? htmlspecialchars($user_site) : '';
        			$user_site	=	$user_site ? cutstr($user_site,75) : '';
        		}
			$icq		=	parseqqicq($user['icq']);
			$qq		=	parseqqicq($user['qq']);
			$yahoo		=	$user['yahoo'] ? htmlspecialchars(cutstr($user['yahoo'], 40)) : '';
			$msn		=	$user['msn'] ? htmlspecialchars($user['msn']) : '';			
        		$taobao		=	'';
			$location	=	$userinfoArray[2] ? cutstr(htmlspecialchars(trim(strip_tags($userinfoArray[2]))), 30) : '';
			$customstatus	=	$user['userhonor'] ? cutstr(htmlspecialchars(trim(strip_tags($user['userhonor']))), 30) : '';

        		if($user['userface'] && $user['userface'] != 'http://') {
        			$user['userface'] = trim($user['userface']);
        			if(substr($user['userface'], 0, 7) == 'http://') {
        				$avatar = $user['userface'];
        				$avatarwidth = 83;
        				$avatarheight = 94;
        			} else {
                			if(strtolower(substr($user['userface'], 0, 12)) == 'images/face/') {
                				$avatar = 'images/avatars/bbsxp/'.substr($user['userface'], 12);
						$avatarwidth = 83;
						$avatarheight = 94;
					} elseif(strtolower(substr($user['userface'], 0, 114)) == 'upfile/upface/') {
                				$avatar = 'customavatars/bbsxp/'.substr($user['userface'], 14);
						$avatarwidth = 83;
						$avatarheight = 94;
					}
        			}
        		} else {
        			$avatar = '';
        			$avatarwidth = 0;
        			$avatarheight = 0;
        		}

			$bio		=	$userinfoArray[14] ? cutstr(htmlspecialchars($userinfoArray[14]), 100) : '';

        		$signature	=	@strip_tags(trim($user['usersign']));
        		$sigstatus	=	$signature ? 1 : 0;
        		$sightml	=	parsesign($user['usersign']);

			$nickname	=	'';
			$authstr	=	'';
			$secques	=	'';

			$query1		=	"INSERT INTO {$discuz_tablepre}members
						(uid,username, password, secques, gender, adminid, groupid, regip, regdate, lastvisit, lastactivity, posts, credits, extcredits1, extcredits2, extcredits3, extcredits4, extcredits5, extcredits6, extcredits7, extcredits8, email, bday, sigstatus, tpp, ppp, styleid, dateformat, timeformat, pmsound, showemail, newsletter, invisible, timeoffset, lastpost, lastip) VALUES
						('$uid','$username', '$password', '$secques', '$gender', '$adminid', '$groupid', '$regip', '$regdate', '$lastvisit', '$lastactivity', '$posts', '$credits','$extcredits1', '$extcredits2', '$extcredits3', '$extcredits4', '$extcredits5', '$extcredits6', '$extcredits7', '$extcredits8', '$email', '$bday', '$sigstatus', '$tpp', '$ppp', '$styleid', '$dateformat', '$timeformat', '$pmsound', '$showemail', '$newsletter', '$invisible', '$timeoffset','$lastpost','$lastip');
						";

			$query2		=	"INSERT INTO {$discuz_tablepre}memberfields
						(uid, nickname, site, icq, qq, yahoo, msn, taobao, location, customstatus, medals, avatar, avatarwidth, avatarheight, bio, sightml, authstr) VALUES
						('$uid', '$nickname', '$site', '$icq', '$qq', '$yahoo', '$msn', '' ,'$location', '$customstatus', '', '$avatar', '$avatarwidth', '$avatarheight','$bio', '$sightml', '$authstr');
						";

			$query3		=	"INSERT INTO {$discuz_tablepre}memberfields
						(uid, qq, avatar, avatarwidth, avatarheight, bio, sightml) VALUES
						('$uid', '$qq', '$avatar', '$avatarwidth', '$avatarheight', '$bio', '$signature');
						";
			if ($db['discuz']->query($query1)) {
				$convertedrows ++;
				if ($db['discuz']->query($query2)) {
					reportlog();
				} else {
					$db['discuz']->query($query3) or $db['discuz']->query("INSERT INTO `{$discuz_tablepre}memberfields` (uid) VALUES ('$uid');");
				}
			} else {
				reportlog("�����Ա�������ݳ��� uid = $uid username = $username");
			}
		}
		$converted = 1;
		$totalrows ++;
	}

?>