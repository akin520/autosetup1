<?php
	$tableid = isset($_GET['tableid']) ? $_GET['tableid'] : 0;
	$tablearray = explode(',', str_replace('  ', '', $posttbl));
	$tablecount = count($tablearray);
	$tableid = intval($tableid);
	$posttable = $source_tablepre.$tablearray[$tableid];

	if($start <= 1 && $tableid == 0) {
		truncatetable('posts');
		validid('id', $tablearray[0], '');
	}

	$query = $db['source']->query("SELECT * FROM $posttable WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� '$posttable' ����<br>�뽫���ӱ� '$posttable' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while ($p = $db['source']->fetch_assoc($query)) {
		$p = array_change_key_case(daddslashes($p));

		//$pid			=	$p['id'];
		$tid			=	$p['threadid'];
		$fid			=	0;
		$first			=	$p['istopic'];
		$subject		=	cutstr(@strip_tags(trim($p['subject'])), 78);
		$author			=	$p['username'];
		$authorid		=	0;
		$dateline		=	sqltimetounix($p['posttime']);
		$message		=	str_replace('UpFile/UpAttachment', 'attachments/bbsxp', $p['content']);
		$useip			=	$p['postip'];
                $attachment		=	0;
		$usesig			=	1;
		$bbcodeoff		=	0;
		$smileyoff		=	0;
		$parseurloff		=	0;
		$htmlon			=	@strip_tags($message) == $message ? 0 : 1;
		$rate			=	0;
		$ratetimes		=	0;

		$sql = "INSERT INTO {$discuz_tablepre}posts (fid, tid, first, author, authorid, subject, dateline, message, useip, attachment, usesig, bbcodeoff, smileyoff, parseurloff, htmlon, rate, ratetimes) ".
			"VALUES ('$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$attachment','$usesig', '$bbcodeoff', '$smileyoff', '$parseurloff', '$htmlon', '$rate', '$ratetimes')";

		if($db['discuz']->query($sql)){
			$pid = mysql_insert_id();
			$db['discuz']->query("UPDATE {$discuz_tablepre}attachments set pid='$pid' WHERE tid='$tid' AND pid='$p[announceid]'");
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
		}

		$converted = 1;
		$totalrows ++;
	}

	if($converted || $end < $maxid) {
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid."&tableid=$tableid");
	} elseif($tableid < $tablecount - 1) {
		validid('id', $tablearray[$tableid+1], '');
		$end = $start - 1;
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.($tableid+1));
	}

?>