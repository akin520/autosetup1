<?php
//�������� uid ��Ӧ��ϵ
	$query	=	$db['discuz']->query("SELECT tid FROM {$discuz_tablepre}threads LIMIT $limit_start, $rpp");
	while($t =	$db['discuz']->fetch_array($query)) {

		$sql	=	"UPDATE {$discuz_tablepre}threads t, {$discuz_tablepre}members m SET t.authorid=m.uid WHERE t.tid='$t[tid]' AND t.author=m.username";

		if ($db['discuz']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog(mysqlerror());
		}
		$converted = 1;
		$totalrows ++;
	}
?>