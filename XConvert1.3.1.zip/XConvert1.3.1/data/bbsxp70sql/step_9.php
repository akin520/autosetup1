<?php
	if($start <= 1) {
		truncatetable('pms');
		validid('id', 'messages');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}messages WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}messages' ����<br>�뽫����Ϣ�� {$source_tablepre}messages �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while($m = $db['source']->fetch_assoc($query)) {
		$m = array_change_key_case(daddslashes($m));		
		$msgtoid = getuid($m['incept']);
		if($msgtoid > 0) {
			$msgfrom = $m['username'];
			$msgfromid = getuid($m['username']);

			$subject = 'No subject';
			$dateline = sqltimetounix($m['datecreated']);
			$dateline = $dateline > $timestamp ? $timestamp : $dateline;
			$message = @strip_tags(trim($m['content']));
			$sql = "INSERT INTO {$discuz_tablepre}pms (`msgfrom` , `msgfromid` , `msgtoid` , `folder` , `new` , `subject` , `dateline` , `message` ) VALUES ('$msgfrom', '$msgfromid', '$msgtoid', 'inbox', '0', '$subject', '$dateline', '$message');";

			if($db['discuz']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������Ϣ <br>".$sql."<br>".mysqlerror());
			}
			$totalrows ++;
		}
		$converted = 1;
	}

?>