<?php
	if($start <= 1) {
		truncatetable_uc('pms');
		validid('id', 'message');
	}

	$query	=	$db['source']->query("SELECT * FROM {$source_tablepre}message WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� {$source_tablepre}message ����<br>�뽫 MSSQL ���ݱ� {$source_tablepre}message �� content �ֶ������� nText ��Ϊ Text ���͡�", 'mssql');
	while($m	=	$db['source']->fetch_assoc($query)) {
		$m = array_change_key_case(daddslashes($m));

		if($msgtoid = getuid('$m[recipient]')) {

			$msgfrom	=	$m['sender'];
			$msgfromid	=	getuid($msgfrom);
			$folder		=	'inbox';
			$new		=	$m['isread'] ? 0 : 1;
			$subject	=	cutstr(@strip_tags(trim($m['title'])),70);
			$dateline	=	timetounix($m['sendtime']);
			$dateline	=	$dateline > $timestamp ? $timestamp : $dateline;
			$message	=	@strip_tags(trim($m['content']));
			$delstatus	=	0;
			$related	=	0;

			$fields = array('msgfrom','msgfromid','msgtoid','folder','new','subject','dateline','message','delstatus','related');
			$sql = getinsertsql("{$uc_tablepre}pms", $fields);

			if($db['uc']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������Ϣ $subject");
			}
			$totalrows ++;
		}
		$converted = 1;
	}
?>