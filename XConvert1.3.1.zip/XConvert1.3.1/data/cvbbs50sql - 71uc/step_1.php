<?php
	if($start <= 1) {
		truncatetable('members');
		truncatetable('memberfields');
		truncatetable_uc('members');
		truncatetable_uc('memberfields');
		$db['source']->query("ALTER TABLE {$source_tablepre}user DROP column id");
		$db['source']->query("ALTER TABLE {$source_tablepre}user ADD id int identity(1,1) not null");
		validid('id', 'user');
	}

	$query	=	$db['source']->query("SELECT * FROM {$source_tablepre}user WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}user' ����", 'mssql');

	while($user	=	$db['source']->fetch_assoc($query)) {

		$_username = trim($user['name']);
		$_uid = $user['id'];

		if(!$_username || $_username != htmlspecialchars(daddslashes($user['name']))) {
			reportlog("�Ƿ��û��� <b><font color='red'>$_username</font></b> ���ܱ�ת����uid = $_uid��<br>\r\n");
		} elseif(strlen($_username) > 15) {
			reportlog("�û��� <b><font color='orange'>$_username</font></b> ���ȴ��� 15�����ܱ�ת����uid = $_uid��<br>\r\n");
		} elseif(getuid($_username)) {
        		reportlog("�ظ��û��� <b><font color='blue'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
		} else {
			$user = daddslashes($user);
			//uc members
				$ucpw		=	convertucpw($user['password']);
			$password		=	$ucpw['password'];
			$email			=	cutstr($user['email'], 32);
			$myid			=	'';
			$myidkey		=	'';
			$regip			=	$user['firstip'] ? $user['firstip'] : 'cvbbs';
			$regdate		=	timetounix($user['jointime']);
			$lastloginip	=	$user['lastip'] ? $user['lastip'] : $regip;
			$lastlogintime	=	timetounix($user['lasttime']);
			$salt			=	$ucpw['salt'];

			//uc memberfields
			$blacklist		=	'';

			//dz members
			$userinfo		=	$user['info'];
			$user['site']	=	$userinfo[0];
			$user['qq']		=	$userinfo[1];
			$user['msn']	=	$userinfo[2];

			$uid			=	$_uid;
			$username		=	$_username;
			//$password		=	strtolower($user['password']);
			$secques		=	'';
			$gender			=	$user['sex'] ? 2 : 1;
			$adminid		=	0;
			$groupid		=	10;
			$groupexpiry	=	0;
			$extgroupids	=	'';
			$regip			=	$user['firstip'] ? $user['firstip'] : 'cvbbs';
			$regdate		=	sqltimetounix($user['jointime']);
			$lastip			=	$user['lastip'];
			$lastvisit		=	sqltimetounix($user['lasttime']);
			$lastactivity	=	$lastvisit;
			$lastpost		=	$lastvisit;
			$posts			=	$user['topics'] + $user['replies'];
			$threads		=	$user['topics'];
			$digestposts	=	0;
			$oltime			=	0;
			$pageviews		=	0;
			$credits		=	$user['experience'];
			$extcredits1	=	$user['experience'];
			$extcredits2	=	$user['power'];
			$extcredits3	=	0;
			$extcredits4	=	0;
			$extcredits5	=	0;
			$extcredits6	=	0;
			$extcredits7	=	0;
			$extcredits8	=	0;
			$email			=	cutstr($user['email'], 40);
			$bday			=	$user['birthday'] ? @date('Y-m-d', $user['birthday']) : '';
			$sigstatus		=	0
			$tpp			=	0;
			$ppp			=	0;
			$styleid		=	0;
			$dateformat		=	0;
			$timeformat		=	0;
			$pmsound		=	0;
			$showemail		=	0;
			$newsletter		=	1;
			$invisible		=	0;
			$timeoffset		=	$user['timezone'];
			$accessmasks	=	0;
			$editormode		=	2;
			$customshow		=	26;
			$xspacestatus	=	0;

			//dz memberfields
			$nickname		=	$user['truename'];
			$site			=	parsesite($user['site']);
			$alipay			=	'';
			$icq			=	parseqqicq($user['icq'], 5, 12);
			$qq				=	parseqqicq($user['qq'], 5, 12);
			$yahoo			=	'';
			$msn			=	$user['msn'] ? htmlspecialchars(cutstr($user['msn'], 40)) : '';
			$taobao			=	'';
			$location		=	'';
			$customstatus	=	$user['rank'] ? cutstr(htmlspecialchars(trim(strip_tags($user['rank']))), 30) : '';
			$medals			=	'';
			$avatar			=	'';
			$avatarwidth	=	0;
			$avatarheight	=	0;
			parseavatar($user['face']);
			$bio			=	'';
			$sightml		=	'';
			parsesignature($user['signature']);
			$ignorepm		=	'';
			$groupterms		=	'';
			$authstr		=	'';
			$spacename		=	'';
			$buyercredit	=	'';
			$sellercredit	=	'';
			$prompt			=	'';
			$newbietaskid   =   0;

			$fields1 = array('uid', 'username', 'password', 'email', 'myid', 'myidkey', 'regip', 'regdate', 'lastloginip', 'lastlogintime', 'salt', 'secques');
			$query1 = getinsertsql("{$uc_tablepre}members", $fields1);

			$fields2 = array('uid', 'blacklist');
			$query2 = getinsertsql("{$uc_tablepre}memberfields", $fields2);

			$fields3 = array('uid', 'username', 'password', 'secques', 'gender', 'adminid', 'groupid', 'groupexpiry', 'extgroupids', 'regip', 'regdate', 'lastip', 'lastvisit', 'lastactivity', 'lastpost', 'posts', 'threads', 'digestposts', 'oltime', 'pageviews', 'credits', 'extcredits1', 'extcredits2', 'extcredits3', 'extcredits4', 'extcredits5', 'extcredits6', 'extcredits7', 'extcredits8', 'email', 'bday', 'sigstatus', 'tpp', 'ppp', 'styleid', 'dateformat', 'timeformat', 'pmsound', 'showemail', 'newsletter', 'invisible', 'timeoffset', 'prompt', 'accessmasks', 'editormode', 'customshow', 'xspacestatus', 'newbietaskid');
			$query3 = getinsertsql("{$discuz_tablepre}members", $fields3);

			$fields4 = array('uid','nickname','site','alipay','icq','qq','yahoo','msn','taobao','location','customstatus','medals','avatar','avatarwidth','avatarheight','bio','sightml','ignorepm','groupterms','authstr','spacename','buyercredit','sellercredit');
			$query4 = getinsertsql("{$discuz_tablepre}memberfields", $fields4);

			if ($db['uc']->query($query1)) {
				if ($db['uc']->query($query2)) {
					$password = strtolower($user['password']);
					if ($db['discuz']->query($query3)) {
						if ($db['discuz']->query($query4)) {
							$convertedrows ++;
						} else {
							$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
							$db['uc']->query("DELETE FROM {$uc_tablepre}memberfields WHERE uid='$uid' LIMIT 1;");
							$db['discuz']->query("DELETE FROM {$discuz_tablepre}members WHERE uid='$uid' LIMIT 1;");
							reportlog("���� DZ ��Ա��չ��Ϣ���ݳ��� uid = $uid username = $username");
						}
					} else {
						$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
						$db['uc']->query("DELETE FROM {$uc_tablepre}memberfields WHERE uid='$uid' LIMIT 1;");
						reportlog("���� DZ ��Ա�������ݳ��� uid = $uid username = $username");
					}
				} else {
					$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
					reportlog("���� UC ��Ա��չ��Ϣ���ݳ��� uid = $uid username = $username");
				}
			} else {
				reportlog("�� UC �����Ա�������ݳ��� uid = $uid username = $username");
			}
		}
		$converted = 1;
		$totalrows ++;
	}

	if($converted || $end < $maxid) {
		altertable('members', 'uid');
		altertable('memberfields', 'uid');
		altertable_uc('members', 'uid');
		altertable_uc('memberfields', 'uid');
	}
?>