<?php
//����
	if($start <= 1) {
		truncatetable('attachments');
		truncatetable('attachmentfields');
		validid('id', 'attach');
	}

	$query	=	$db['source']->query("SELECT * FROM {$source_tablepre}attach WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}attach' ����", 'mssql');
	while($att	=	$db['source']->fetch_assoc($query)) {
		$att = daddslashes($att);

		$aid			=	$att['id'];
		$tid			=	$att['topicid'];
		$pid			=	$att['replyid'];
		$dateline		=	sqltimetounix($att['uploadtime']);
		$readperm		=	$att['downloadrequire'];
		$filename		=	$att['attachname'];
		$filetype		=	getfiletype($filename);
		$filesize		=	$att['attachsize'];
		$attachment		=	'cvbbs/'.$att['attachpath'];
		$downloads		=	$att['downs'];
		$description		=	'';
		$isimage		=	in_array($filetype, array('image/pjpeg', 'image/gif', 'image/bmp', 'image/png')) ? 1 : 0;

		$sql1 = "INSERT INTO {$discuz_tablepre}attachments (`aid`, `tid`, `pid`, `dateline`,`readperm`,`filename`, `filetype`, `filesize`, `attachment`, `downloads`, `isimage`) VALUES ('$aid', '$tid', '$pid', '$dateline', '$readperm', '$filename', '$filetype', '$filesize', '$attachment', '$downloads', '$isimage');";

		$sql2 = "UPDATE {$discuz_tablepre}threads SET attachment=1 WHERE tid='$tid'";
		$sql3 = "UPDATE {$discuz_tablepre}posts SET attachment=1 WHERE pid='$pid'";

		$sql4 = "INSERT INTO {$discuz_tablepre}attachmentfields(`aid`,`tid`,`pid`,`uid`,`description`) VALUES ('$aid','$tid','$pid','$uid','$description')";

		if($db['discuz']->query($sql1)) {
			$db['discuz']->query($sql2);
			$db['discuz']->query($sql3);
			$db['discuz']->query($sql4);
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ $att[attachname] ");
		}
		$totalrows ++;
		$converted = 1;
	}

?>