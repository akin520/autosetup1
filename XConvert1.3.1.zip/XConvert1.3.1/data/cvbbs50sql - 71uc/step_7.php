<?php
	if($start <= 1) {
		truncatetable_uc('pms');
		validid('id', 'message');
	}

	$query	=	$db['source']->query("SELECT * FROM {$source_tablepre}message WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� {$source_tablepre}message ����<br>�뽫 MSSQL ���ݱ� {$source_tablepre}message �� content �ֶ������� nText ��Ϊ Text ���͡�", 'mssql');
	while($m	=	$db['source']->fetch_assoc($query)) {
		$m = array_change_key_case(daddslashes($m));

		if($msgtoid = getuid('$m[recipient]')) {

			$msgfrom	=	$m['sender'];
			$msgfromid	=	getuid($msgfrom);
			$folder		=	'inbox';
			$new		=	$m['isread'] ? 0 : 1;
			$subject	=	cutstr(@strip_tags(trim($m['title'])),70);
			$dateline	=	timetounix($m['sendtime']);
			$dateline	=	$dateline > $timestamp ? $timestamp : $dateline;
			$message	=	@strip_tags(trim($m['content']));
			$delstatus	=	0;
			$related	=	0;
			$fromappid	=	1;

			if($msgfromid){
				$checkfirstsql_1 = "SELECT count(*) FROM {$uc_tablepre}pms WHERE msgfromid='$msgfromid' AND msgtoid='$msgtoid' AND related='0'";
				$is_first_1 = $db['uc']->result($db['uc']->query($checkfirstsql_1), 0);
				$checkfirstsql_2 = "SELECT count(*) FROM {$uc_tablepre}pms WHERE msgfromid='$msgtoid' AND msgtoid='$msgfromid' AND related='0'";
				$is_first_2 = $db['uc']->result($db['uc']->query($checkfirstsql_2), 0);
				
				if(!$is_first_1 || !$is_first_2){
					if(!$is_first_1){
						$db['uc']->query("INSERT INTO {$uc_tablepre}pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus, related, fromappid) VALUES ('$msgfrom', '$msgfromid', '$msgtoid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus', '$related', '$fromappid')");
					}
					if(!$is_first_2){
						$db['uc']->query("INSERT INTO {$uc_tablepre}pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus, related, fromappid) VALUES ('$msgfrom', '$msgtoid', '$msgfromid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus', '$related', '$fromappid')");
					}
				}else{
					$db['uc']->query("UPDATE {$uc_tablepre}pms SET subject='$subject', dateline='$dateline' AND message='$message' WHERE msgfrom='$msgfromid' AND msgtoid='$msgtoid' AND related='0'");
				}
				$related	=	1;	
			}

			$fields = array('msgfrom','msgfromid','msgtoid','folder','new','subject','dateline','message','delstatus','related','fromappid');
			$sql = getinsertsql("{$uc_tablepre}pms", $fields);

			if($db['uc']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������Ϣ $subject");
			}
			$totalrows ++;
		}
		$converted = 1;
	}
?>