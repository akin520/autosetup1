<?php
function parsesignature($signature) {
	global $sigstatus, $signature, $sightml;

	$user_sigstatus		=	0;
	$user_signature_code	=	'';
	$user_signature_html	=	'';
	$user_signature		=	trim($signature);
	if($user_signature) {
		$user_sigstatus		=	1;
		$user_signature_code	=	@strip_tags($user_signature);
		$user_signature_html	=	parsesign($user_signature);

	}
	$sigstatus		=	$user_sigstatus;
	$signature		=	$user_signature_code;
	$sightml		=	$user_signature_html;
}

function parseavatar($face) {
	global $avatar, $avatarwidth, $avatarheight;

	$avatar = '';
	$avatarwidth = $avatarheight = 0;
	if(!empty($face)) {
		$face = explode("\t", $face);
		$face[0] = trim($face[0]);
		if(!empty($face[0]) && $face[0] != 'http://') {
			if(substr($face[0], 0, 7) == 'http://') {
				$avatar = $face[0];
				$avatarwidth = $face[1] > 0 && $face[1] < 120 ? $face[1] : 120;
				$avatarheight = $face[2] > 0 && $face[2] < 120 ? $face[2] : 120;
			} else {
				if(substr($face[0], 0, 9) == 'userface/') {
					$avatar = 'images/avatars/cvbbs/'.substr($face[0], 9);
					$avatarwidth = 83;
					$avatarheight = 94;
				} elseif(substr($face[0], 0, 18) == 'files/uploadfaces/') {
					$avatar = 'customavatars/cvbbs/'.substr($face[0], 18);
					$avatarwidth = $face[1] > 0 && $face[1] < 120 ? $face[1] : 120;
					$avatarheight = $face[2] > 0 && $face[2] < 120 ? $face[2] : 120;
				}
			}
		}
	}
}

function parsehighlight($highlight) {
	$hlarray = array(1 => 1, 2 => 4, 3 => 6, 4 => 2, 5 => 11, 6 => 41, 7 => 61, 8 => 21, 9 => 9);
	return $hlarray[$highlight];
}

function sqltimetounix($time) {
	if(strtotime($time) !== false && strtotime($time) != -1) {
		$time = strtotime($time);
	} else {
		$time = str_replace(array(' һ�� ',' ���� ',' ���� ',' ���� ',' ���� ',' ���� ',' ���� ',' ���� ',' ���� ',' ʮ�� ',' ʮһ�� ',' ʮ���� ', ' ���� '), array('-1-','-2-','-3-','-4-','-5-','-6-','-7-','-8-','-9-','-10-','-11-','-12-', ' '), $time);
		if(strrchr($time, '����') !== false) {
			$time = strtotime(str_replace(' ���� ', ' ', $time)) + 43200;
		} else {
			$time = strtotime($time);
		}
	}
	return $time;
}

function convertbbcode($message) {

	$pregfind = array(
		"/\[uploadimage\](\d+),.*\[\/uploadimage\]/is",
		"/\[uploadfile\](\d+),.*\[\/uploadfile\]/is"


	);
	$pregreplace = array(
		"[attach]\\1[/attach]",
		"[attach]\\1[/attach]"
	);

	return addslashes(preg_replace($pregfind, $pregreplace, stripslashes($message)));
}

?>