<?php
	truncatetable('forums');
	truncatetable('forumfields');


	$query	=	$db['source']->query("SELECT id,parentid,categoryid,boardname,subject,sortid FROM {$source_tablepre}board") or dexit("�������ݱ� '{$source_tablepre}board' ����", 'mssql');
	while($forum	=	$db['source']->fetch_assoc($query)) {
		$forum = daddslashes($forum);

		$fid = $forum['id'];
		$fup = $forum['parentid'] ? $forum['parentid'] : $forum['categoryid'];
		$type = $forum['parentid'] ? 'sub' : 'forum';
		$name = @strip_tags($forum['boardname']);
		$description = @strip_tags($forum['subject']);
		$status = 1;
		$displayorder = $forum['sortid'];
		$styleid = 0;
		$threads = 0;
		$posts = 0;
		$lastpost = '';
		$todayposts = 0;
		$allowsmilies = 1;
		$allowhtml = 0;
		$allowbbcode = 1;
		$allowimgcode = 1;
		$allowshare = 1;
		$recyclebin = 1;
		$modnewposts = 0;
		$inheritedmod = 0;
		$postcredits = '-1';
		$replycredits = '-1';
		$jammer = 0;
		$autoclose = 0;
		$postcredits = '';
		$replycredits = '';
		$password = '';
		$icon = '';
		$redirect = '';
		$attachextensions = '';
		$moderators = '';
		$rules = '';
		$viewperm = '';
		$postperm = '';
		$replyperm = '';
		$getattachperm = '';
		$postattachperm = '';
		$threadtypes = '';

		$sql = "INSERT INTO {$discuz_tablepre}forums ( `fid` , `fup` , `type` , `name` , `status` , `displayorder` , `styleid` , `threads` , `posts` ,`todayposts`, `lastpost` , `allowsmilies` , `allowhtml` , `allowbbcode` , `allowimgcode` , `allowshare` ,`allowpostspecial`, `recyclebin` , `modnewposts` , `jammer`,`inheritedmod` , `autoclose`, `alloweditpost`)
			VALUES ('$fid', '$fup', '$type', '$name', '$status', '$displayorder', '$styleid', '$threads', '$posts', '$todayposts','$lastpost', '$allowsmilies', '$allowhtml', '$allowbbcode', '$allowimgcode', '$allowshare','0', '$recyclebin', '$modnewposts', '$jammer','$inheritedmod', '$autoclose', '1');";

		$sql2 = "INSERT INTO {$discuz_tablepre}forumfields ( `fid` ,`description`, `password` , `icon` , `postcredits`,`replycredits`,`redirect` , `attachextensions` , `moderators` , `rules` ,`threadtypes`, `viewperm` , `postperm` , `replyperm` , `getattachperm` , `postattachperm` )
			VALUES ('$fid', '$description', '$password', '$icon', '$postcredits','$replycredits','$redirect', '$attachextensions', '$moderators', '$rules', '$threadtypes','$viewperm', '$postperm', '$replyperm', '$getattachperm', '$postattachperm');";

		if ($db['discuz']->query($sql)) {
			if ($db['discuz']->query($sql2)) {
				$convertedrows ++;
			} else {
				$db['discuz']->query("DELETE FROM {$discuz_tablepre}forums WHERE `fid`='$fid' LIMIT 1;");
				reportlog("���������չ��Ϣ���ݳ��� fid = $fid name = $name");
			}
		} else {
			reportlog("��������������ݳ��� fid = $fid name = $name");
		}
		$totalrows ++;
	}

	$query	=	$db['source']->query("SELECT * FROM {$source_tablepre}category") or dexit("�������ݱ� '{$source_tablepre}category' ����", 'mssql');
	while($forum	=	mssql_fetch_assoc($query)) {
		$forum = daddslashes($forum);

		$fid = '';
		$fup = 0;
		$type = 'group';
		$name = @strip_tags($forum['categoryname']);
		$description = '';
		$status = 1;
		$displayorder = $forum['sortid'];
		$styleid = 0;
		$threads = 0;
		$posts = 0;
		$lastpost = '';
		$todayposts = 0;
		$allowsmilies = 1;
		$allowhtml = 0;
		$allowbbcode = 1;
		$allowimgcode = 1;
		$allowshare = 1;
		$recyclebin = 1;
		$modnewposts = 0;
		$inheritedmod = 0;
		$postcredits = '-1';
		$replycredits = '-1';
		$jammer = 0;
		$autoclose = 0;
		$postcredits = '';
		$replycredits = '';
		$password = '';
		$icon = '';
		$redirect = '';
		$attachextensions = '';
		$moderators = '';
		$rules = '';
		$viewperm = '';
		$postperm = '';
		$replyperm = '';
		$getattachperm = '';
		$postattachperm = '';
		$threadtypes = '';

		$sql = "INSERT INTO {$discuz_tablepre}forums ( `fid` , `fup` , `type` , `name` , `status` , `displayorder` , `styleid` , `threads` , `posts` ,`todayposts`, `lastpost` , `allowsmilies` , `allowhtml` , `allowbbcode` , `allowimgcode` , `allowshare` ,`allowpostspecial`, `recyclebin` , `modnewposts` , `jammer`,`inheritedmod` , `autoclose` )
			VALUES ('$fid', '$fup', '$type', '$name', '$status', '$displayorder', '$styleid', '$threads', '$posts', '$todayposts','$lastpost', '$allowsmilies', '$allowhtml', '$allowbbcode', '$allowimgcode', '$allowshare','0', '$recyclebin', '$modnewposts', '$jammer','$inheritedmod', '$autoclose');";

		if ($db['discuz']->query($sql)) {

			$fid = mysql_insert_id();

			$sql2 = "INSERT INTO {$discuz_tablepre}forumfields ( `fid` ,`description`, `password` , `icon` , `postcredits`,`replycredits`,`redirect` , `attachextensions` , `moderators` , `rules` ,`threadtypes`, `viewperm` , `postperm` , `replyperm` , `getattachperm` , `postattachperm` )
		                 VALUES ('$fid', '$description', '$password', '$icon', '$postcredits','$replycredits','$redirect', '$attachextensions', '$moderators', '$rules', '$threadtypes','$viewperm', '$postperm', '$replyperm', '$getattachperm', '$postattachperm');";

			$sql3 = "UPDATE {$discuz_tablepre}forums SET fup='$fid' WHERE fup='$forum[id]'";

			if ($db['discuz']->query($sql2)) {
				$db['discuz']->query($sql3);
				$convertedrows ++;
			} else {
				$db['discuz']->query("DELETE FROM {$discuz_tablepre}forums WHERE `fid`='$fid' LIMIT 1;");
				reportlog("���������չ��Ϣ���ݳ��� fid = $fid name = $name");
			}
		} else {
			reportlog("��������������ݳ��� fid = $fid name = $name");
		}
		$totalrows ++;
	}

	altertable('forums', 'fid');
	altertable('forumfields', 'fid');
?>