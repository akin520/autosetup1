<?php
	if($start <= 1) {
		truncatetable('threads');
		truncatetable('polls');
		validid('id', 'topic');
	}

	$query	=	$db['source']->query("SELECT * FROM {$source_tablepre}topic WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� {$source_tablepre}topic ����<br>�뽫 MSSQL ���ݱ� {$source_tablepre}topic �� content �ֶ������� nText ��Ϊ Text ���͡�", 'mssql');
	while($t	=	$db['source']->fetch_assoc($query)) {
		$t = daddslashes($t);

		$tid			=	$t['id'];
		$fid			=	$t['boardid'];
		$iconid			=	$t['icon'];
		$typeid			=	0;
		$readperm		=	0;
		$price			=	0;
		$author			=	cutstr(htmlspecialchars(trim($t['name'])),15);
		$authorid		= 	@mysql_result($db['discuz']->query("SELECT uid FROM {$discuz_tablepre}members WHERE username='$t[name]'"), 0);
		$subject		=	cutstr(htmlspecialchars(trim(@strip_tags($t['title']))),78);
		$dateline		=	sqltimetounix($t['addtime']);
		$lastpost		=	sqltimetounix($t['lastreplytime']);
		$lastposter		=	cutstr(htmlspecialchars(trim($t['lastreplyuser'])), 15);
		$views			=	$t['clicks'];
		$replies		=	$t['replies'];
		$displayorder		=	$t['istopall'] ? 3 : ($t['isclassical'] ? 2 : ($t['istop'] ? 1 : ($t['isdelete'] ? '-1' : 0)));
		$highlight		=	parsehighlight($t['titlecolor']);
		$digest			=	0;
		$rate			=	0;
		$blog			=	0;
		$special			=	$t['voteid'] ? 1 : 0;
		$attachment		=	0;
		$subscribed		=	0;
		$moderated		=	0;
		$closed			=	$t['islock'];

		$sql = "INSERT INTO {$discuz_tablepre}threads (
			`tid` , `fid` , `iconid` , `typeid`, `readperm`, `price`,`author` , `authorid` , `subject` , `dateline` , `lastpost` , `lastposter` , `views` , `replies` , `displayorder` , `highlight` , `digest` , `rate` , `blog` , `special` , `attachment` , `subscribed`, `moderated` , `closed`
			) VALUES(
			'$tid', '$fid', '$iconid', '0', '0', '0',  '$author',  '$authorid','$subject','$dateline','$lastpost','$lastposter','$views','$replies','$displayorder','$highlight','$digest','$rate','$blog','$special','$attachment','$subscribed','$moderated','$closed');";

		if($db['discuz']->query($sql)){
			if($special) {
				$query2	=	$db['source']->query("SELECT * FROM {$source_tablepre}vote WHERE id=$t[voteid]") or dexit("�������ݱ� {$source_tablepre}vote ����<br>�뽫 MSSQL ���ݱ� {$source_tablepre}vote �� items �ֶκ� users �ֶ������� nText ��Ϊ Text ���͡�", 'mssql');
				while($p	=	$db['source']->fetch_assoc($query2)) {
					$p = daddslashes($p);

					$pollarray = array();
					$items = explode("\t", $p['items']);
					$tickets = explode("\t", $p['tickets']);

					foreach($items AS $id => $item) {
						$pollarray['options'][] = array($item, $tickets[$id]);
						$db['discuz']->query("INSERT INTO {$discuz_tablepre}polloptions (`tid`, `votes`, `polloption`) VALUES('$tid', '$tickets[$id]', '$item');");
					}
					$multiple = $p['ismultiable'];
					$voters = explode(',', $p['users']);
					$total = array_sum($pollarray['options'][1]);
					$pollopts = addslashes(serialize($pollarray));
					$db['discuz']->query("INSERT INTO {$discuz_tablepre}polls (`tid`, `multiple`, `visible`, `maxchoices`, `expiration`) VALUES('$tid', '$multiple', '1', '$total', '$dateline');");
				}
			}
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ tid = $tid subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
		}
		$converted = 1;
		$totalrows ++;

	}

?>