<?php
	if($start <= 1) {
		truncatetable('posts');
		validid('id', 'reply');
	}

	$query	=	$db['source']->query("SELECT * FROM {$source_tablepre}reply WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}reply' ����<br>�뽫 MSSQL ���ݱ� '{$source_tablepre}reply' �� content �ֶ������� nText ��Ϊ Text ���͡�", 'mssql');
	while($p	=	$db['source']->fetch_assoc($query)) {
		$p = daddslashes($p);

		$pid			=	$p[id];
		$tid			=	$p[topicid];
		$fid			=	0;
		$first			=	0;
		$subject		=	'';
		$author			=	$p['name'];
		$authorid		=	0;
		$dateline		=	sqltimetounix($p['addtime']);
		$message		=	convertbbcode($p['content']);
		$useip			=	$p[ip];
                $attachment		=	0;
		$usesig			=	0;
		$bbcodeoff		=	0;
		$smileyoff		=	0;
		$parseurloff		=	0;
		$htmlon			=	strip_tags($message) == $message ? 0 : 1;

		$sql1 = "INSERT INTO {$discuz_tablepre}posts (pid, fid, tid, first, author, authorid, subject, dateline, message, useip, attachment, usesig, bbcodeoff, smileyoff, parseurloff, htmlon, rate, ratetimes) ".
			"VALUES ('$pid', '$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$attachment','$usesig', '$bbcodeoff', '$smileyoff', '$parseurloff', '$htmlon', '0', '0')";

		$sql2 = "UPDATE {$discuz_tablepre}posts p, {$discuz_tablepre}threads t SET p.fid=t.fid WHERE p.pid='$pid' AND p.tid=t.tid";

		$sql3 = "UPDATE {$discuz_tablepre}posts p, {$discuz_tablepre}members m SET p.authorid=m.uid WHERE p.pid='$pid' AND p.author=m.username";

		if($db['discuz']->query($sql1)){
			$db['discuz']->query($sql2);
			$db['discuz']->query($sql3);
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ pid = $pid subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql1."</textarea>");
		}
		$converted =1;
		$totalrows ++;
	}

?>