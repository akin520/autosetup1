<?php
	$query = $db['discuz']->query("SELECT tid, subject FROM {$discuz_tablepre}threads ORDER BY tid LIMIT $limit_start, $rpp");
	while($t = $db['discuz']->fetch_array($query)) {
		$sql = "UPDATE {$discuz_tablepre}posts SET first='1', subject='".daddslashes($t['subject'])."' WHERE tid='$t[tid]' ORDER BY dateline LIMIT 1";
		if($db['discuz']->query($sql)) {
			$converted = 1;
			$convertedrows ++;
		} else {
			reportlog("��� first & ���ӱ��� ����");
		}
		$totalrows ++;
	}
?>