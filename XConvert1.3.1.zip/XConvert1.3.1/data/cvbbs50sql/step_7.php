<?php
// ����Ϣ����
	if($start <= 1) {
		truncatetable('pms');
		validid('id', 'message');
	}

	$query	=	$db['source']->query("SELECT * FROM {$source_tablepre}message WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� {$source_tablepre}message ����<br>�뽫 MSSQL ���ݱ� {$source_tablepre}message �� content �ֶ������� nText ��Ϊ Text ���͡�", 'mssql');
	while($m	=	$db['source']->fetch_assoc($query)) {
		$m = daddslashes($m);

		$msgtoid = $db['discuz']->result($db['discuz']->query("SELECT uid FROM {$discuz_tablepre}members WHERE username='$m[recipient]'"), 0);
		if($msgtoid > 0) {

			$msgfrom = $m['sender'];
			$msgfromid = $db['discuz']->result($db['discuz']->query("SELECT uid FROM {$discuz_tablepre}members WHERE username='$msgfrom'"), 0);
			$folder = 'inbox';
			$new = $m['isread'] ? 0 : 1;
			$subject = $m['title'];
			$dateline = sqltimetounix($m['sendtime']);
			$message = @strip_tags(trim($m['content']));

			$sql = "INSERT INTO {$discuz_tablepre}pms (`msgfrom` , `msgfromid` , `msgtoid` , `folder` , `new` , `subject` , `dateline` , `message` ) VALUES ('$msgfrom', '$msgfromid', '$msgtoid', '$folder', '$new', '$subject', '$dateline', '$message');";

			if($db['discuz']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������Ϣ $subject");
			}
			$totalrows ++;
		}
		$converted = 1;
	}
?>