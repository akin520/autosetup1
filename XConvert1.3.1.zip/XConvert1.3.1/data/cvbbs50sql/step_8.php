<?php
	// ���ӹ���Ա
	$string = '';
	$query	=	$db['source']->query("SELECT * FROM {$source_tablepre}admin") or dexit("�������ݱ� {$source_tablepre}admin ����", 'mssql');
	while($admin	=	$db['source']->fetch_assoc($query)) {
		$admin = daddslashes($admin);

		$username = $admin['username'];

		$sql = "UPDATE {$discuz_tablepre}members SET groupid=1, adminid=1 WHERE username='$username'";

		if ($db['discuz']->query($sql)) {
			$string .= "���� $username Ϊ����Ա<br>";
			$convertedrows ++;
		} else {
			reportlog('');
		}
		$totalrows ++;
	}

?>