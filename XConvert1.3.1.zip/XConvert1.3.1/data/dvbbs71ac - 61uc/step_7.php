<?php
	if($start <= 1) {
		truncatetable_uc('pms');
		validid('id', 'message');
	}

	$query = "SELECT * FROM {$source_tablepre}message WHERE id BETWEEN $start AND $end";
	$rs = $db['source']->execute($query);

	$fieldarray = array('sender', 'incept', 'title', 'content', 'flag', 'sendtime', 'delr', 'dels', 'issend');
	while (!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$pms[$field] = daddslashes($rs->fields[$field]->value);
		}

		if($msgtoid = getuid($pms['incept'])) {
			//pms
			$msgfrom	=	$pms['sender'];
			$msgfromid	=	getuid($msgfrom);
			$folder		=	$pms['issend'] ? 'inbox' : 'outbox';
			$new		=	$pms['flag'] ? 0 : 1;
			$subject	=	cutstr(@strip_tags(trim($pms['title'])),70);
			$subject	=	str_replace('\'','',$subject);
			$subject	=	str_replace('\\','',$subject);
			$dateline	=	timetounix($pms['sendtime']);
			$dateline	=	$dateline > $timestamp ? $timestamp : $dateline;
			$message	=	@strip_tags(trim($pms['content']));
			$delstatus	=	$pms['dels'] ? 2 : 0;
			$related	=	0;

			$fields = array('msgfrom','msgfromid','msgtoid','folder','new','subject','dateline','message','delstatus','related');
			$sql = getinsertsql("{$uc_tablepre}pms", $fields);

			if($db['uc']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������Ϣ $subject");
			}
			$totalrows ++;
		}
		$converted = 1;
		$rs->Movenext();
	}
	$rs->close();
?>