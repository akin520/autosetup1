<?php
	if($start <= 1) {
		truncatetable_uc('pms');
		validid('id', 'message');
	}

	$query = "SELECT * FROM {$source_tablepre}message WHERE id BETWEEN $start AND $end";
	$rs = $db['source']->execute($query);

	$fieldarray = array('sender', 'incept', 'title', 'content', 'flag', 'sendtime', 'delr', 'dels', 'issend');
	while (!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$pms[$field] = daddslashes($rs->fields[$field]->value);
		}

		if($msgtoid = getuid($pms['incept'])) {
			//pms
			$msgfrom	=	$pms['sender'];
			$msgfromid	=	getuid($msgfrom);
			$folder		=	$pms['issend'] ? 'inbox' : 'outbox';
			$new		=	$pms['flag'] ? 0 : 1;
			$subject	=	cutstr(@strip_tags(trim($pms['title'])),70);
			$subject	=	str_replace('\'','',$subject);
			$subject	=	str_replace('\\','',$subject);
			$dateline	=	timetounix($pms['sendtime']);
			$dateline	=	$dateline > $timestamp ? $timestamp : $dateline;
			$message	=	@strip_tags(trim($pms['content']));
			$delstatus	=	$pms['dels'] ? 2 : 0;
			$related	=	0;
			$fromappid	=	1;
			
			if($msgfromid){
				$checkfirstsql_1 = "SELECT count(*) FROM {$uc_tablepre}pms WHERE msgfromid='$msgfromid' AND msgtoid='$msgtoid' AND related='0'";
				$is_first_1 = $db['uc']->result($db['uc']->query($checkfirstsql_1), 0);
				$checkfirstsql_2 = "SELECT count(*) FROM {$uc_tablepre}pms WHERE msgfromid='$msgtoid' AND msgtoid='$msgfromid' AND related='0'";
				$is_first_2 = $db['uc']->result($db['uc']->query($checkfirstsql_2), 0);
				
				if(!$is_first_1 || !$is_first_2){
					if(!$is_first_1){
						$db['uc']->query("INSERT INTO {$uc_tablepre}pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus, related, fromappid) VALUES ('$msgfrom', '$msgfromid', '$msgtoid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus', '$related', '$fromappid')");
					}
					if(!$is_first_2){
						$db['uc']->query("INSERT INTO {$uc_tablepre}pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus, related, fromappid) VALUES ('$msgfrom', '$msgtoid', '$msgfromid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus', '$related', '$fromappid')");
					}
				}else{
					$db['uc']->query("UPDATE {$uc_tablepre}pms SET subject='$subject', dateline='$dateline' AND message='$message' WHERE msgfrom='$msgfromid' AND msgtoid='$msgtoid' AND related='0'");
				}
				$related	=	1;	
			}

			$fields = array('msgfrom','msgfromid','msgtoid','folder','new','subject','dateline','message','delstatus','related','fromappid');
			$sql = getinsertsql("{$uc_tablepre}pms", $fields);

			if($db['uc']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������Ϣ $subject");
			}
			$totalrows ++;
		}
		$converted = 1;
		$rs->Movenext();
	}
	$rs->close();
?>