<?php
	if($start <= 1) {
		truncatetable_uc('friends');
		validid('f_id', 'friend');
	}

	$query = "SELECT * FROM {$source_tablepre}friend WHERE f_id BETWEEN $start AND $end";
	
	$rs = $db['source']->execute($query);
	$friendarray = array("f_userid", "f_friend");
	while(!$rs->EOF) {
		foreach($friendarray AS $content) {
			$friend[$content] = daddslashes($rs->fields[$content]->value);
		}
		$uid = $friend['f_userid'];
		if($friendid = getuid($friend['f_friend'])) {
			$direction	= 0;
			$related	= 0;
			$delstatus	= 0;
			$comment	= '';

			$sql = getinsertsql("{$uc_tablepre}friends", array('uid', 'friendid', 'direction', 'version', 'delstatus', 'comment'));
			
			if($db['uc']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת����̳�������� uid = $uid friendid = $friendid <br>".$sql."<br>".mysqlerror());
			}
			$totalrows ++;
		}
		$converted = 1;
		$rs->Movenext();
	}
	$rs->close();
?>