<?php
	if($start <= 1) {
		truncatetable('threads');
		truncatetable('polls');
		truncatetable('polloptions');
		validid('topicid', 'topic');
	}

	$query = "SELECT * FROM {$source_tablepre}topic WHERE topicid BETWEEN $start AND $end";
	$rs = $db['source']->execute($query);

	$fieldarray = array('topicid', 'title', 'child', 'boardid', 'postusername', 'postuserid', 'dateandtime', 'hits', 'lastpost', 'istop', 'lastposttime', 'isbest', 'pollid', 'mode');
	while (!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$t[$field] = daddslashes($rs->fields[$field]->value);
		}

		$lp		=	explode('$', $t['lastpost']);

		$tid			=	$t['topicid'];
		$fid			=	$t['boardid'];
		$iconid			=	0;
		$typeid			=	$t['mode'];
		$readperm		=	0;
		$price			=	0;
		$author			=	cutstr(htmlspecialchars(trim($t['postusername'])), 15);
		$authorid		= 	$t['postuserid'];
		$subject		=	cutstr(htmlspecialchars(trim(@strip_tags($t['title']))), 78);
		$subject		=	$subject ? $subject : 'no subject';
		$dateline		=	timetounix($t['dateandtime']);
		$dateline		=	$dateline > $timestamp ? $timestamp : $dateline;
		$lastpost		=	timetounix($t['lastposttime']);
		$lastpost		=	$lastpost > $timestamp ? $timestamp : $lastpost;
		$lastposter		=	cutstr(htmlspecialchars(trim($lp[0])), 15);
		$views			=	$t['hits'];
		$replies		=	$t['child'];
		$displayorder		=	$t['istop'];
		$highlight		=	0;
		$digest			=	$t['isbest'];
		$rate			=	0;
		$poll			=	$t['pollid'] > 0 ? 1 : 0;
		$attachment		=	0;
		//$subscribed	=	0;//7.1��û������ֶ���by lionel
		$moderated		=	0;
		$closed			=	0;
		$recommends     =  ''; //7.1���ӵ��ֶ�
		$recommend_add  =  ''; //7.1���ӵ��ֶ�
		$recommend_sub  =  ''; //7.1���ӵ��ֶ�
		$heats          =   0; //7.1���ӵ��ֶ�

		$sql1 = "INSERT INTO {$discuz_tablepre}threads (
			`tid` , `fid` , `iconid` , `typeid`, `readperm`, `price`,`author` , `authorid` , `subject` , `dateline` , `lastpost` , `lastposter` , `views` , `replies` , `displayorder` , `highlight` , `digest` , `rate` , `special` , `attachment` , `moderated` , `closed`,`recommends`,`recommend_add`,`recommend_sub`,`heats`
			) VALUES(
			'$tid', '$fid', '$iconid', '$typeid', '$readperm', '$price', '$author', '$authorid', '$subject', '$dateline', '$lastpost', '$lastposter', '$views', '$replies', '$displayorder', '$highlight', '$digest', '$rate', '$poll', '$attachment',  '$moderated', '$closed','$recommends','$recommend_add','$recommend_sub','$heats');";

		if($db['discuz']->query($sql1)){

			if($poll) {
				$rs2 = $db['source']->execute("SELECT * FROM {$source_tablepre}vote WHERE voteid=$t[pollid]");
				$fieldarray2 = array('voteid', 'vote', 'votenum', 'votetype', 'lockvote', 'voters', 'timeout');

				while(!$rs2->EOF) {
					foreach($fieldarray2 AS $field) {
						$v[$field] = daddslashes($rs2->fields[$field]->value);
					}
					$rs2->Movenext();
				}
				$rs2->close();

				if(!$v['voteid']) {
					$db['discuz']->query("UPDATE {$discuz_tablepre}threads SET special=0 WHERE tid='$tid'");
				} else {
					$multiple = $v['votetype'];
					$maxchoices = $multiple ? 0 : 1;
					$expiration = timetounix($v['timeout']);
					$db['discuz']->query("INSERT INTO {$discuz_tablepre}polls (tid, multiple, maxchoices, expiration) VALUES('$tid', '$multiple', '$maxchoices', '$expiration');");
					$polloptions = explode('|', $v['vote']);
					$votenums = explode('|', $v['votenum']);
					foreach($polloptions AS $key => $polloption) {
						$rs3 = $db['source']->execute("SELECT * FROM {$source_tablepre}voteuser WHERE voteid=$v[voteid] AND (voteoption='$key' OR LEFT(voteoption, 2)='$key,' OR LEFT(voteoption, 3)='$key,' OR INSTR(',$key,', voteoption) OR RIGHT(voteoption, 2)=',$key' OR RIGHT(voteoption, 3)=',$key')");
						$voterids = $comma = '';
						while(!$rs3->EOF) {
							$voterids .= $comma.$rs3->fields[userid]->value;
							$comma = "\t";
							$rs3->Movenext();
						}
						$rs3->close();

						$votes = $votenums[$key];
						$db['discuz']->query("INSERT INTO {$discuz_tablepre}polloptions (tid, votes, displayorder, polloption, voterids) VALUES('$tid', '$votes', '$displayorder', '$polloption', '$voterids');");
					}
				}
			}
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ tid = $tid subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql1."</textarea>");
		}
		$converted = 1;
		$totalrows ++;
		$rs->Movenext();

	}
	$rs->close();

	if(!$converted || $end >= $maxid) {
		altertable('threads', 'tid');
		altertable('polls', 'tid');
		altertable('polloptions', 'tid');
	}

?>