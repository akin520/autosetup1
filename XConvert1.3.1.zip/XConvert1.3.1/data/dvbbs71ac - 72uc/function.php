<?php

function addbbcode(){
	global $db, $discuz_tablepre;

	$flashplayer ='<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,0,0" width="{1}" height="{2}"><param name="allowScriptAccess" value="sameDomain"><param name="movie" value="{3}"><param name="quality" value="high"><param name="bgcolor" value="#ffffff"><embed src="{3}" quality="high" bgcolor="#ffffff" width="{1}" height="{2}" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object>';
	$flashexplanation = 'Ƕ�� flash����';
	$flashprompt = "������flash�����Ŀ���:\t������flash�����ĸ߶�:\t������flash�����ĵ�ַ(URL): ";
	$flashexample = '[flash=500,350]http://your.com/example.swf[/flash]';

	$db['discuz']->query("UPDATE {$discuz_tablepre}bbcodes SET replacement = '$flashplayer', example = '$flashexample', prompt ='$flashprompt', params =3, available =1 WHERE tag ='flash'");

}

function ctspecialgroup() {

	global $db, $source_tablepre, $discuz_tablepre;

	$db['discuz']->query("DELETE FROM {$discuz_tablepre}usergroups WHERE groupid > 15");

	$sql = "SELECT usergroupid, usertitle FROM {$source_tablepre}usergroups WHERE parentgid =2";
	$rs = $db['source']->execute($sql);

	$fieldarray = array('usergroupid', 'usertitle');
	while (!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$g[$field] = $rs->fields[$field]->value;
		}

		$g		=	daddslashes($g);
		$groupid	=	$g['usergroupid'] + 15;
		$grouptitle	=	$g['usertitle'];
		$gsql		=	"REPLACE INTO {$discuz_tablepre}usergroups (groupid, radminid, type, system, grouptitle, creditshigher, creditslower, stars, color, groupavatar, readaccess, allowvisit, allowpost, allowreply, allowpostpoll, allowpostreward, allowposttrade, allowpostactivity, allowdirectpost, allowgetattach, allowpostattach, allowvote, allowmultigroups, allowsearch, allowcstatus, allowuseblog, allowinvisible, allowtransfer, allowsetreadperm, allowsetattachperm, allowhidecode, allowhtml, allowcusbbcode, allowanonymous, allownickname, allowsigbbcode, allowsigimgcode, allowviewpro, allowviewstats, disableperiodctrl, reasonpm, maxprice, maxsigsize, maxattachsize, maxsizeperday, maxpostsperhour, attachextensions, raterange, mintradeprice, maxtradeprice, minrewardprice, maxrewardprice, magicsdiscount, allowmagics, maxmagicsweight, allowbiobbcode, allowbioimgcode, maxbiosize, tradestick, exempt,maxattachnum,allowposturl,allowrecommend, edittimelimit, allowpostrushreply) VALUES ('$groupid', 0, 'special', 'private', '$grouptitle', 50, 200, 2, '', '', 20, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 100, 0, 0, 0, 'chm, pdf, zip, rar, tar, gz, bzip2, gif, jpg, jpeg, png', '', 1, 0, 1, 0, 0, 1, 60, 0, 0, 0, 5, 0,0,3,1, 0, 0)";
		$db['discuz']->query($gsql);

		$rs->movenext();
	}

	$rs->close();
}




function convertbbcode($message) {
	global $p, $source_bbsurl;
	$pregfind = array(
		"/\[uploadimage\](\d+),.*\[\/uploadimage\]/is",
		"/\[uploadfile\](\d+),.*\[\/uploadfile\]/is",
		"/\[upload=([a-z]+)\].*viewFile.asp?.*ID=(\d+).*\[\/upload\]/is",
		"/\[upload=([a-z]+),.*?\]viewFile\.asp\?ID=(\d+)\[\/upload\]/is",
		"/\[upload=(jpg|gif|bmp|png)\]\s*UploadFile\/([a-zA-Z0-9_\-\/\.]+)\s*\[\/upload\]/eis",
		"/\[upload=([a-z]+)\]\s*UploadFile\/([a-zA-Z0-9_\-\/\.]+)\s*\[\/upload\]/eis",
		"/\[(\w{2})=(\d{1,4}),(\d{1,4}),(true|false|0|1)\]\s*([^\[\<\r\n]+?)\s*\[\/\\1\]/ies",
		"/\[sound\]\s*([^\[\<\r\n]+?)\s*\[\/sound\]/is",
		"/\[qt=(\d{1,4}),(\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\qt\]/is",
		"/\[(center|left|right)\]/i",
		"/\[\/(center|left|right)\]/i",
		"/\[face/i",
		"/\[\/face\]/i",
		"/<div class=\"quote\">/i",

	);
	$pregreplace = array(
		"[attach]\\1[/attach]",
		"[attach]\\1[/attach]",
		"[attach]\\2[/attach]",
		"[attach]\\2[/attach]",
		"parseattach('\\2', $p[announceid], $p[isupload], 1)",
		"parseattach('\\2', $p[announceid], $p[isupload])",
		"parsemedia('\\2', '\\3', '\\4', '\\5')",
		"[media=wma,200,64,0]\\1[/media]",
		"[media=rm,\\1,\\2,0]\\3[/media]",
		"[align=\\1]",
		"[/align]",
		"[font",
		"[/font]",
		"<div class=\"msgheader\">QUOTE:</div><div class=\"msgborder\">",
	);

	$bbsurl = str_replace(' ', '', $source_bbsurl);//ȥ���ո�
	if($bbsurl){
		$bbsurl = substr($bbsurl, 0, 1) == '|' ? substr($bbsurl, 1) : $bbsurl;//ȥ����ͷ��|
		$bbsurl = substr($bbsurl, -1) == '|' ? substr($bbsurl, 0, -1) : $bbsurl;//ȥ��β����|
		$bbsurltemp = str_replace(array('/', '.'), array('\/', '\.'), $bbsurl);//ת��
		$urlfind = array(
			"/($bbsurltemp)\/index.asp\?boardid=(\d+)/is",
			"/($bbsurltemp)\/list.asp\?boardid=(\d+)/is",
			"/($bbsurltemp)\/dispbbs.asp\?(boardid=\d+)&amp;id=(\d+)(&amp;star=(\d+))(&amp;page=\d{0,}){0,1}/is",
			"/($bbsurltemp)\/dispbbs.asp\?(boardid=\d+)&amp;id=(\d+)(&amp;page=\d{0,}){0,1}/is",
			"/($bbsurltemp)\/dispbbs.asp\?(boardid=\d+)(&amp;page=\d{0,}){0,1}&amp;id=(\d+)(&amp;star=(\d+))/is",
			"/($bbsurltemp)\/dispbbs.asp\?(boardid=\d+)(&amp;page=\d{0,}){0,1}&amp;id=(\d+)/is",
		);
		$urlreplace = array(
			"\\1/forumdisplay.php?fid=\\2",
			"\\1/forumdisplay.php?fid=\\2",
			"\\1/viewthread.php?tid=\\3&extra=&page=\\5",
			"\\1/viewthread.php?tid=\\3",
			"\\1/viewthread.php?tid=\\4&extra=&page=\\6",
			"\\1/viewthread.php?tid=\\4",
		);
		$pregfind = array_merge($pregfind, $urlfind);
		$pregreplace = array_merge($pregreplace, $urlreplace);
	}

	return daddslashes(str_replace(array('[replyview]', '[/replyview]', '[B]', '[/B]'), array('[hide]', '[/hide]', '[b]', '[/b]'), preg_replace($pregfind, $pregreplace, stripslashes($message))));
}

function parsemedia($width, $height, $autostart, $url) {
	if($autostart == 'true' || $autostart == '1') {
		$autostart = '1';
	} else {
		$autostart = '0';
	}
	return '[media=wmv,'.$width.','.$height.','.$autostart.']'.$url.'[/media]';
}



function parseattach($filename, $pid, $haveattach, $isimage = 0) {
	global $db, $discuz_tablepre;
	$filename = 'dvbbs/'.$filename;
	if($haveattach && ($aid = $db['discuz']->result($db['discuz']->query("SELECT aid FROM {$discuz_tablepre}attachments WHERE pid='$pid' AND attachment='$filename'"), 0))) {
		return '[attach]'.$aid.'[/attach]';
	} else {
		if($isimage) {
			return "<img src=\"attachments/$filename\" border=\"0\" onclick=\"zoom(this)\" onload=\"if(this.width>document.body.clientWidth*0.5) {this.resized=true;this.width=document.body.clientWidth*0.5;this.style.cursor='pointer';} else {this.onclick=null}\" alt=\"\" />";
		} else {
			return "<a href=\"attachments/$filename\" target=\"_blank\">�򿪸���</a>";
		}
	}
}

function random($length, $numeric = 0) {
	mt_srand((double)microtime() * 1000000);
	if($numeric) {
		$hash = sprintf('%0'.$length.'d', mt_rand(0, pow(10, $length) - 1));
	} else {
		$hash = '';
		$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
		$max = strlen($chars) - 1;
		for($i = 0; $i < $length; $i++) {
			$hash .= $chars[mt_rand(0, $max)];
		}
	}
	return $hash;
}

?>