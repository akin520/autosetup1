<?php

/*
	[DISCUZ!] convertinc/config.php - basically configuration for DvBBS 7.x Access => Discuz!5.5.0
	This is NOT a freeware, use is subject to license terms
*/

	$extcredits = Array
		(
		1 => Array
			(
			'title' => '����',
			'unit' => '��',
			'available' => 1
			),
		2 => Array
			(
			'title' => '����',
			'showinthread' => '1',
			'unit' => '��',
			'available' => 1
			),
		3 => Array
			(
			'title' => '��Ǯ',
			'unit' => '��',
			'available' => 1
			),
		4 => Array
			(
			'title' => '����',
			'available' => 1
			),
		5 => Array
			(
			'title' => '��ȯ',
			'unit' => '��',
			'available' => 1
			),
		6 => Array
			(
			'title' => '���',
			'available' => 1
			)
		);

?>