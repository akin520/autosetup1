<?php

/*
	[DISCUZ!] convertinc/config.php - basically configuration for DvBBS 7.x Access => Discuz!5.5.0
	This is NOT a freeware, use is subject to license terms
*/

	$extcredits = Array
		(
		1 => Array
			(
			'title' => '经验',
			'unit' => '点',
			'available' => 1
			),
		2 => Array
			(
			'title' => '威望',
			'showinthread' => '1',
			'unit' => '点',
			'available' => 1
			),
		3 => Array
			(
			'title' => '金钱',
			'unit' => '￥',
			'available' => 1
			),
		4 => Array
			(
			'title' => '魅力',
			'available' => 1
			),
		5 => Array
			(
			'title' => '点券',
			'unit' => '￥',
			'available' => 1
			),
		6 => Array
			(
			'title' => '金币',
			'available' => 1
			)
		);

?>