<?php
	$sql = "SELECT * FROM {$source_tablepre}admin";
	$rs = $db['source']->execute($sql);

	$str = '';
	$fieldarray = array('flag', 'adduser');
	while (!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$admin[$field] = daddslashes($rs->fields[$field]->value);
		}
		if($admin['flag'] == '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37') {
			if($db['discuz']->result($db['discuz']->query("SELECT COUNT(*) FROM {$discuz_tablepre}members WHERE username='$admin[adduser]' AND adminid='1' AND groupid='1'"), 0)) {
				$str .= $admin[adduser].'������Ϊ����Ա<br>';
				$convertedrows ++;
				$totalrows ++;
			} else {
				$db['discuz']->query("UPDATE {$discuz_tablepre}members SET adminid='1', groupid='1' WHERE username='$admin[adduser]' LIMIT 1;");
				if($db['discuz']->affected_rows()) {
					$str .= $admin[adduser].'������Ϊ����Ա<br>';
					$convertedrows ++;
					$totalrows ++;
				}
			}
		}
		$rs->Movenext();
	}
	$rs->close();

	if($str == '') {
		$str = 'û���ҵ�����Ա�ʺţ����ֶ����ӹ���Ա';
	}
?>