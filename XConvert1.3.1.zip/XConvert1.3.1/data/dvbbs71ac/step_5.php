<?php
	$dv_posttbl = isset($_GET['dv_posttbl']) ? $_GET['dv_posttbl'] : '';
	$tableid = isset($_GET['tableid']) ? $_GET['tableid'] : 1;//ת����ʱ��������һ��,��ʼʱû�ط���ȡtableid,����ȡĬ��ֵΪ1---------��ѩ
	if($start <= 1 && $dv_posttbl == '') {
		$dv_posttbl = $comma = '';
		$tablesql = "SELECT TableName FROM {$source_tablepre}TableList";
		$rs = $db['source']->execute($tablesql);
		while(!$rs->EOF){
			$dv_posttbl .= $comma.$rs->fields[TableName]->value;
			$comma = ',';
			$rs->movenext();
		}
		$rs->Close();
	}
	$tablearray = explode(',', $dv_posttbl);
	$tablecount = count($tablearray);
	$posttable = $tablearray[$tableid - 1];

	if($start <= 1 && $tableid == 1) {
		truncatetable('posts');
		validid('announceid', $tablearray[0], '');
	}

	$sql = "SELECT * FROM $posttable WHERE (announceid BETWEEN $start AND $end)";
	$rs = $db['source']->execute($sql);
	$fieldarray = array('announceid', 'parentid', 'boardid', 'username', 'postuserid', 'topic', 'body', 'dateandtime', 'rootid', 'ip', 'locktopic', 'isupload');
	while (!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$p[$field] = daddslashes($rs->fields[$field]->value);
		}

		$tid			=	$p['rootid'];
		$fid			=	$p['boardid'];
		$first			=	$p['parentid'] == 0 ? 1 : 0;
		$subject		=	cutstr(@strip_tags(trim($p['topic'])), 78);
		$author			=	$p['username'];
		$authorid		=	$p['postuserid'];
		$dateline		=	timetounix($p['dateandtime']);
		$p['isupload']		=	intval($p['isupload']);
		$message		=	convertbbcode($p['body']);
		$useip			=	$p['ip'];
		$attachment		=	$p['isupload'];
		$usesig			=	1;
		$bbcodeoff		=	0;
		$smileyoff		=	0;
		$parseurloff		=	0;
		$htmlon			=	@strip_tags($message) == $message ? 0 : 1;
		$rate			=	0;
		$ratetimes		=	0;
		$status			=	$p['locktopic'] == 2 ? 1 : 0;

		$sql = "INSERT INTO {$discuz_tablepre}posts (fid, tid, first, author, authorid, subject, dateline, message, useip, attachment, usesig, bbcodeoff, smileyoff, parseurloff, htmlon, rate, ratetimes, status) ".
			"VALUES ('$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$attachment','$usesig', '$bbcodeoff', '$smileyoff', '$parseurloff', '$htmlon', '$rate', '$ratetimes', '$status')";

		if($db['discuz']->query($sql)){
			$pid = $db['discuz']->insert_id();
			$db['discuz']->query("UPDATE {$discuz_tablepre}attachments set pid='$pid' WHERE tid='$tid' AND pid='$p[announceid]'");
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
		}
		$converted = 1;
		$totalrows ++;
		$rs->movenext();
	}

	$rs->Close();

	if($converted || $end < $maxid) {
		showmessage("<b>��ǰ������ $step / $steps �� => ת�� $operation ����</b><br><br>���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid."&tableid=$tableid&dv_posttbl=$dv_posttbl");
	} elseif($tableid < $tablecount) {
		validid('announceid', $tablearray[$tableid], '');
		$end = $start - 1;
		showmessage("<b>��ǰ������ $step / $steps �� => ת�� $operation ����</b><br><br>���ڴ����� $tableid ���ֱ�,�� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid."&tableid=".($tableid + 1)."&dv_posttbl=$dv_posttbl");
	}

?>