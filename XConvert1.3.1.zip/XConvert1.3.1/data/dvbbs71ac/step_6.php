<?php
	if($start <= 1) {
		truncatetable('forumlinks');
	}

	$query = "SELECT * FROM {$source_tablepre}bbslink WHERE (id BETWEEN $start AND $end)";//�ֽ�ʱ������where�Ӿ�---��ѩ.
	$rs = $db['source']->execute($query);

	$fieldarray = array('boardname', 'readme', 'url', 'logo');
	while (!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$l[$field] = daddslashes($rs->fields[$field]->value);
		}

		$name = cutstr(@strip_tags(trim($l['boardname'])), 100);
		$url = cutstr(@strip_tags(trim($l['url'])), 100);
		$description = cutstr(@strip_tags(trim($forumlink['readme'])), 200);
		$logo = cutstr(@strip_tags(trim($l['logo'])), 100);

		$sql = "INSERT INTO {$discuz_tablepre}forumlinks (name, url, description, logo) VALUES ('$name', '$url', '$description', '$logo');";

		if($db['discuz']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת��������̳ $name");
		}
		$totalrows ++;

		$converted = 1;
		$rs->Movenext();
	}
	$rs->close();


?>