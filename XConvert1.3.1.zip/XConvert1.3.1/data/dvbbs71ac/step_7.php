<?php
	if($start <= 1) {
		truncatetable('pms');
		validid('id', 'message');
	}

	$query = "SELECT * FROM {$source_tablepre}message WHERE id BETWEEN $start AND $end";
	$rs = $db['source']->execute($query);

	$fieldarray = array('sender', 'incept', 'title', 'content', 'sendtime');
	while (!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$m[$field] = daddslashes($rs->fields[$field]->value);
		}

		if($msgtoid = getuid($m['incept'])) {

			$msgfrom	=	$m['sender'];
			$msgfromid	=	getuid($msgfrom);
			$folder		=	'inbox';
			$new		=	0;
			$subject	=	$m['title'];
			$dateline	=	timetounix($m['sendtime']);
			$message	=	@strip_tags(trim($m['content']));
			$delstatus	=	0;//byСˮˮ

			$sql = "INSERT INTO {$discuz_tablepre}pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus) VALUES ('$msgfrom', '$msgfromid', '$msgtoid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus');";

			if($db['discuz']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������Ϣ $subject");
			}
			$totalrows ++;
		}
		$converted = 1;
		$rs->Movenext();
	}
	$rs->close();
?>