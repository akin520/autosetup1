<?php
	if($start <= 1) {
		truncatetable('buddys');
		validid('f_id', 'friend');
	}

	$query = "SELECT * FROM {$source_tablepre}friend WHERE f_id BETWEEN $start AND $end";
	$rs = $db['source']->execute($query);
	$buddyarray = array("f_userid" => "f_userid", "f_friend" => "f_friend");
	while(!$rs->EOF) {
		foreach($buddyarray AS $var => $content) {
			$buddy[$var] = daddslashes($rs->fields[$content]->value);
		}
		$uid = $buddy['f_userid'];
		$dateline = timetounix($buddy['f_addtime']);
		if($buddyid = getuid($buddy['f_friend'])) {
			$sql = "INSERT INTO {$discuz_tablepre}buddys ( uid , buddyid, dateline) VALUES ('$uid', '$buddyid', '$dateline');";

			if($db['discuz']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת����̳�������� uid = $uid buddyid = $buddyid <br>".$sql."<br>".mysqlerror());
			}
			$totalrows ++;
		}
		$converted = 1;
		$rs->Movenext();
	}
	$rs->close();
?>