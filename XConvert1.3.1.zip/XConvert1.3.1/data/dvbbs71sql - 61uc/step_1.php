<?php
	if($start <= 1) {
		truncatetable('members');
		truncatetable('memberfields');
		truncatetable_uc('members');
		truncatetable_uc('memberfields');
		validid('userid', 'user');

		if($discuz_charset == 'utf8'){
			include './data/'.$child.'/exts_utf8.php';
		}else {
			include './data/'.$child.'/exts_gbk.php';
		}
		$extcredits = addslashes(serialize($extcreditsarray));
		$db['discuz']->query("UPDATE {$discuz_tablepre}settings SET value='$extcredits' WHERE variable='extcredits'");//��������
		ctspecialgroup(); //�����û���
		addbbcode(); //����&�޸� bbcode
	}

	$query = $db['source']->query("SELECT usergroupid FROM {$source_tablepre}UserGroups WHERE parentgid =2");
	$specialgids = array();
	while ($g = $db['source']->fetch_array($query)) {
		$specialgids[] = $g['usergroupid'];
	}//������gids
	
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}user WHERE (UserID BETWEEN $start AND $end)") or dexit("�������ݱ� '{$source_tablepre}user' ����<br>�뽫�û��� '{$source_tablepre}user' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');

	while ($user = $db['source']->fetch_array($query)) {

		$user =	array_change_key_case($user);
		$uid = $user['userid'];
		$username = trim($user['username']);

		if(!$username || $username != htmlspecialchars(daddslashes($username))) {
			reportlog("�Ƿ��û��� <b><font color='red'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
		} elseif(strlen($username) > 15) {
			reportlog("�û��� <b><font color='orange'>$username</font></b> ���ȴ��� 15�����ܱ�ת����uid = $uid ��<br>\r\n");
		} elseif(getuid($username)) {
        		reportlog("�ظ��û��� <b><font color='blue'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
		} else {
			$user = daddslashes($user);

			//uc members
			$ucpw		=	convertucpw($user['userpassword']);
			$password		=	$ucpw['password'];
			$email			=	cutstr($user['useremail'], 32);
			$myid			=	'';
			$myidkey		=	'';
			$regip			=	$user['userlastip'];
			$regdate		=	timetounix($user['joindate']);
			$lastloginip	=	$user['userlastip'];
			$lastlogintime	=	timetounix($user['joindate']);
			$salt			=	$ucpw['salt'];
			//uc memberfields
			$blacklist		=	'';
			//dz members
			//$password		=	strtolower($user['userpassword']);
			$secques		=	'';
			$gender			=	$user['usersex']==1 ? 1 : 2;

			if(in_array($user['usergroupid'], array('1', '2', '3'))) {
				$adminid = $groupid = $user['usergroupid']; //������
			} elseif($user['lockuser'] == 2) {//����
				$adminid	=	-1;
				$groupid	=	4; //��ֹ����
			} elseif($user['lockuser'] == 1) {//����
				$adminid	=	-1;
				$groupid	=	5; //��ֹ����
			}elseif(in_array($user['usergroupid'], $specialgids)) { //�����Ѿ���ѯ��gids
				$adminid	=	-1;
				$groupid	=	$user['usergroupid'] + 15; //�����û���
			} else {
        		$adminid	=	0;
        		$groupid	=	10; //������·
			}

			$groupexpiry	=	0;
			$extgroupids	=	'';
			$regip			=	$user['userlastip'];
			$regdate		=	timetounix($user['joindate'] ? $user['joindate'] : ($user['adddate'] ? $user['adddate'] : $timestamp));
			$lastip			=	$user['userlastip'];
			$lastvisit		=	$user['lastlogin'] ? timetounix($user['lastlogin']) : $regdate;
			$lastactivity	=	$lastvisit;
			$lastpost		=	$lastvisit;
			$posts			=	isset($user['userpost']) ? $user['userpost'] : 0;
			$digestposts	=	0;
			$oltime			=	0;
			$pageviews		=	0;
			$credits		=	$user['userep'];		//����
			$extcredits1	=	$user['userep'];		//����ֵ
			$extcredits2	=	$user['userpower'];		//����
			$extcredits3	=	$user['userwealth'];	//��Ǯ
			$extcredits4	=	$user['usercp'];		//����
			$extcredits5	=	$user['userticket'];	//��ȯ
			$extcredits6	=	$user['usermoney'];		//���
			$extcredits7	=	0;
			$extcredits8	=	0;
			$email			=	cutstr($user['useremail'],40);
			$bday			=	$user['userbirthday'] ? $user['userbirthday'] : '0000-00-00';
				$signature	=	@strip_tags($user['usersign']);
        		$sigstatus		=	$signature ? 1 : 0;
			$tpp			=	'0';
			$ppp			=	'0';
			$styleid		=	'0';
			$dateformat		=	'0';
			$timeformat		=	'0';
			$pmsound		=	'0';
			$showemail		=	'0';
			$newsletter		=	'1';
			$invisible		=	'0';
			$timeoffset		=	'9999';
			$newpm			=	0;
			$accessmasks	=	0;
			$editormode		=	2;
			$customshow		=	26;
			$xspacestatus	=	0;

			//dz memberfields
				$userfinfo	=	explode('|||',$user['userim']);
			$nickname		=	'';
			$site			=	parsesite($userfinfo[0]);
			$alipay			=	'';
			$icq			=	'';
			$qq				=	parseqqicq($userfinfo[1]);
			$yahoo			=	'';
			$msn			=	$userfinfo[3] ? htmlspecialchars($userfinfo[3]) : '';
			$taobao			=	'';
			$location		=	'';
			$customstatus	=	$user['usertitle'] ? cutstr(@strip_tags($user['usertitle']),30) : '';
			$medals			=	'';

			$biasArray = explode('|', $user['userface']);
			$user['userface'] = count($biasArray) == 2 ? $biasArray[1] : $user['userface'];

			if($user['userface'] && $user['userface'] != 'http://') {
				$user['userface'] = trim($user['userface']);
				if(substr($user['userface'], 0, 7) == 'http://') {
					$avatar = $user['userface'];
				} else {
					if(strtolower(substr($user['userface'], 0, 16)) == 'images/userface/') {
						$avatar = 'images/avatars/dvbbs/'.substr($user['userface'], 16);
					} elseif(strtolower(substr($user['userface'], 0, 11)) == 'uploadface/') {
						$avatar = 'customavatars/dvbbs/'.substr($user['userface'], 11);
					}
				}
				$avatarwidth = $user['userwidth'] > 0 && $user['userwidth'] <= 120 ? $user['userwidth'] : 83;
				$avatarheight = $user['userheight'] > 0 && $user['userheight'] <= 120 ? $user['userheight'] : 94;
			} else {
				$avatar = '';
				$avatarwidth = 0;
				$avatarheight = 0;
			}

			$bio			=	'';
			$sightml		=	parsesign($user['usersign']);
			$ignorepm		=	'';
			$groupterms		=	'';
			$authstr		=	'';
			$spacename		=	'';
			$buyercredit	=	'';
			$sellercredit	=	'';
			
			$fields1 = array('uid', 'username', 'password', 'email', 'myid', 'myidkey', 'regip', 'regdate', 'lastloginip', 'lastlogintime', 'salt');
			$query1 = getinsertsql("{$uc_tablepre}members", $fields1);

			$fields2 = array('uid', 'blacklist');
			$query2 = getinsertsql("{$uc_tablepre}memberfields", $fields2);

			$fields3 = array('uid', 'username', 'password', 'secques', 'gender', 'adminid', 'groupid', 'groupexpiry', 'extgroupids', 'regip', 'regdate', 'lastip', 'lastvisit', 'lastactivity', 'lastpost', 'posts', 'digestposts', 'oltime', 'pageviews', 'credits', 'extcredits1', 'extcredits2', 'extcredits3', 'extcredits4', 'extcredits5', 'extcredits6', 'extcredits7', 'extcredits8', 'email', 'bday', 'sigstatus', 'tpp', 'ppp', 'styleid', 'dateformat', 'timeformat', 'pmsound', 'showemail', 'newsletter', 'invisible', 'timeoffset', 'newpm', 'accessmasks', 'editormode', 'customshow', 'xspacestatus');
			$query3 = getinsertsql("{$discuz_tablepre}members", $fields3);

			$fields4 = array('uid','nickname','site','alipay','icq','qq','yahoo','msn','taobao','location','customstatus','medals','avatar','avatarwidth','avatarheight','bio','sightml','ignorepm','groupterms','authstr','spacename','buyercredit','sellercredit');
			$query4 = getinsertsql("{$discuz_tablepre}memberfields", $fields4);

			if ($db['uc']->query($query1)) {
				if ($db['uc']->query($query2)) {
					$password = strtolower($user['userpassword']);
					if ($db['discuz']->query($query3)) {
						if ($db['discuz']->query($query4)) {
							$convertedrows ++;
						} else {
							$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
							$db['uc']->query("DELETE FROM {$uc_tablepre}memberfields WHERE uid='$uid' LIMIT 1;");
							$db['discuz']->query("DELETE FROM {$discuz_tablepre}members WHERE uid='$uid' LIMIT 1;");
							reportlog("���� DZ ��Ա��չ��Ϣ���ݳ��� uid = $uid username = $username");
						}
					} else {
						$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
						$db['uc']->query("DELETE FROM {$uc_tablepre}memberfields WHERE uid='$uid' LIMIT 1;");
						reportlog("���� DZ ��Ա�������ݳ��� uid = $uid username = $username");
					}
				} else {
					$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
					reportlog("���� UC ��Ա��չ��Ϣ���ݳ��� uid = $uid username = $username");
				}
			} else {
				reportlog("�� UC �����Ա�������ݳ��� uid = $uid username = $username");
			}
		}
		$converted = 1;
		$totalrows ++;
	}

	if($converted || $end < $maxid) {
		altertable('members', 'uid');
		altertable('memberfields', 'uid');
		altertable_uc('members', 'uid');
		altertable_uc('memberfields', 'uid');
	}

?>