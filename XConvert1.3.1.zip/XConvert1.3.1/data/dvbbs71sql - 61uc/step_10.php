<?php
	$str = '';
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}admin") or dexit("�������ݱ� '{$source_tablepre}admin' ����<br>�뽫���ݱ� '{$source_tablepre}admin' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while($admin = $db['source']->fetch_assoc($query)) {
		$admin = array_change_key_case($admin);
		$admin = daddslashes($admin);
		if($admin['flag'] == '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37') {


			if($db['discuz']->result($db['discuz']->query("SELECT COUNT(*) FROM {$discuz_tablepre}members WHERE username='$admin[adduser]' AND adminid='1' AND groupid='1'"), 0)) {
				$str .= $admin[adduser].'������Ϊ����Ա<br>';
				$convertedrows ++;
			} else {
				$db['discuz']->query("UPDATE {$discuz_tablepre}members SET adminid='1', groupid='1' WHERE username='$admin[adduser]' LIMIT 1;");
				if($db['discuz']->affected_rows()) {
					$str .= $admin[adduser].'������Ϊ����Ա<br>';
					$convertedrows ++;
				}
			}
			$totalrows ++;
		}
	}
?>