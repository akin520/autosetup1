<?php
	truncatetable('forums');
	truncatetable('forumfields');
	truncatetable('moderators');

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}board ORDER BY boardid") or dexit("�������ݱ� '{$source_tablepre}board' ����<br>�뽫���� '{$source_tablepre}board' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while($forum = mssql_fetch_array($query)) {

		$forum = array_change_key_case(daddslashes($forum));

		$fid			=	$forum['boardid'];
		$fup			=	$forum['parentid'];
		if(isset($forum['depth']) && $forum['depth'] == 0) {
			$forumnum	=	$db['source']->result($db['source']->query("SELECT COUNT(*) AS num FROM {$source_tablepre}board WHERE parentid = $fid"), 0, num);
			$type		=	$forumnum ? 'group' : 'forum';
		} elseif ($forum['depth'] == 1) {
			$type		=	'forum';
		} else {
			$type		=	'sub';
		}
		$name			=	cutstr(htmlspecialchars(trim(@strip_tags($forum['boardtype']))), 50);
		$displayorder		=	$forum['orders'];
		$styleid		=	0;
		$threads		=	$forum['topicnum'];
		$posts			=	$forum['postnum'];
		$todayposts		=	0;
		$lastpost		=	'';
		$status			=	1;
		$allowsmilies		=	1;
		$allowhtml		=	0;
		$allowbbcode		=	$allowsmilies;
		$allowimgcode		=	$allowsmilies;
		$modnewposts		=	0;
		$allowshare		=	$allowsmilies;
		$allowpostspecial	=	3;
		$allowspecialonly	=	0;//5.5����ֶ�,byСˮˮ
		$alloweditrules		=	0;
		$recyclebin		=	0;
		$jammer			=	0;
		$disablewatermark	=	0;
		$inheritedmod		=	0;
		$autoclose		=	0;
		$description		=	$forum['readme'];
		$password		=	'';
		$icon			=	'';
		$postcredits		=	'';
		$replycredits		=	'';
		$redirect		=	'';
		$attachextensions	=	'';
		$moderators		=	addmoderators(explode('|', $forum['boardmaster']), $fid);
		$rules			=	'';
		$threadtypes	=	'';
		$viewperm		=	'';
		$postperm		=	'';
		$replyperm		=	'';
		$getattachperm		=	'';
		$postattachperm		=	'';
		$alloweditpost		=	1;//5.5����ֶ�,byСˮˮ
		$simple			=	0;//5.5����ֶ�,byСˮˮ

		// BEGIN ת���������,By Blue Ted
		$settings 		=	explode(',', $forum['board_setting']); 
		if (!empty($settings[48])) {
			$threadtypes_arr = explode('$$', $settings[48]);
			$st_sum = count($threadtypes_arr);
			unset($threadtypes_arr[$st_sum-1]);
			$types_str = '';
			$other_str1 = '';
			$other_str2 = '';		
			foreach ($threadtypes_arr as $key => $value) {
				$typeid			=	$key + 1;
				$displayorder	=	0;
				$name			=	$value;
				$description	=	'';
				$special		=	0;
				$modelid		=	0;
				$expiration		=	0;
				$template 		=	'';
				$sql = "INSERT INTO {$discuz_tablepre}threadtypes (`typeid`, `displayorder`, `name`, `description`, `special`, `modelid`, `expiration`, `template`) VALUES ('$typeid', '$displayorder','$name','$description','$special','$modelid','$expiration','$template')";
				$db['discuz']->query($sql) or reportlog("�������������Ϣ���ݳ��� name = $name");
				
				$types_str .= 'i:'.$typeid.';s:'.strlen($name).':"'.$name.'";';
				$other_str1 .= 'i:'.$typeid.';s:1:"0";';
				$other_str2 .= 'i:'.$typeid.';i:0;';
			}
			$threadtypes = 'a:10:{s:8:"required";b:1;s:8:"listable";b:1;s:6:"prefix";b:1;s:5:"types";a:'.$st_sum.':{'.$types_str.'}s:9:"selectbox";a:'.$st_sum.':{'.$types_str.'}s:4:"flat";N;s:7:"special";a:'.$st_sum.':{'.$other_str1.'}s:4:"show";a:'.$st_sum.':{'.$other_str2.'}s:10:"expiration";a:'.$st_sum.':{'.$other_str1.'}s:7:"modelid";a:'.$st_sum.':{'.$other_str1.'}}';
		}
		// END ת���������,By Blue Ted	

		$query1	=	"INSERT INTO {$discuz_tablepre}forums ( `fid` , `fup` , `type` , `name` , `status` , `displayorder` , `styleid` , `threads` , `posts` , `todayposts` , `lastpost` , `allowsmilies` , `allowhtml` , `allowbbcode` , `allowimgcode` , `allowshare` , `allowpostspecial` , `allowspecialonly` , `alloweditrules` , `recyclebin` , `modnewposts` , `jammer` , `disablewatermark` , `inheritedmod` , `autoclose` , `alloweditpost` , `simple` ) VALUES ('$fid','$fup','$type','$name','$status','$displayorder','$styleid','$threads','$posts','$todayposts','$lastpost','$allowsmilies','$allowhtml','$allowbbcode','$allowimgcode','$allowshare','$allowpostspecial','$allowspecialonly','$alloweditrules','$recyclebin','$modnewposts','$jammer','$disablewatermark','$inheritedmod','$autoclose','$alloweditpost','$simple');";//����simple,alloweditpost,allowspecialonly�����ֶ�,byСˮˮ

		$query2	=	"INSERT INTO {$discuz_tablepre}forumfields ( `fid` , `description` , `password` , `icon` , `postcredits` , `replycredits` , `redirect` , `attachextensions` , `moderators` , `rules` , `threadtypes` , `viewperm` , `postperm` , `replyperm` , `getattachperm` , `postattachperm` ) VALUES ('$fid','$description','$password','$icon','$postcredits','$replycredits','$redirect','$attachextensions','$moderators','$rules','$threadtypes','$viewperm','$postperm','$replyperm','$getattachperm','$postattachperm');";

		$query3	=	"DELETE FROM {$discuz_tablepre}moderators WHERE `fid`='$fid';";

		if($db['discuz']->query($query1)) {
			if($db['discuz']->query($query2)) {
				$convertedrows ++;
			} else {
				$db['discuz']->query($query3);
				$db['discuz']->query("DELETE FROM {$discuz_tablepre}forums WHERE `fid`='$fid' LIMIT 1;");
				reportlog("���������չ��Ϣ���ݳ��� fid = $fid name = $name");
			}
		} else {
			$db['discuz']->query($query3);
			reportlog("��������������ݳ��� fid = $fid name = $name");
		}
		$totalrows ++;
	}

	altertable('forums', 'fid');
	altertable('forumfields', 'fid');
	altertable('moderators', 'fid');
?>