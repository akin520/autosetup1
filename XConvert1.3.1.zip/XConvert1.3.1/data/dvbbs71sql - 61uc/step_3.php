<?php
if($start <= 1) {
		truncatetable('threads');
		truncatetable('threadtags');
		truncatetable('tags');
		truncatetable('polls');
		truncatetable('polloptions');
		validid('topicid', 'topic');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Topic WHERE TopicID BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}Topic' ����<br>�뽫����� '{$source_tablepre}Topic' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');

	while($t = mssql_fetch_assoc($query)) {

		$t = array_change_key_case(daddslashes($t));

		$lp			=	explode('$', $t['lastpost']);

		$tid			=	$t['topicid'];
		$fid			=	$t['boardid'];
		$iconid			=	0;
		$typeid			=	$t['mode'];
		$readperm		=	0;
		$price			=	0;
		$author			=	cutstr(htmlspecialchars(trim($t['postusername'])), 15);
		$authorid		= 	$t['postuserid'];
		$subject		=	cutstr(htmlspecialchars(trim(@strip_tags($t['title']))), 78);
		$subject		=	$subject ? $subject : 'no subject';
		$dateline		=	timetounix($t['dateandtime']);
		$dateline		=	$dateline > $timestamp ? $timestamp : $dateline;
		$lastpost		=	timetounix($t['lastposttime']);
		$lastpost		=	$lastpost > $timestamp ? $timestamp : $lastpost;
		$lastposter		=	cutstr(htmlspecialchars(trim($lp[0])), 15);
		$views			=	$t['hits'];
		$replies		=	$t['child'];
		$displayorder		=	$t['istop'];
		$highlight		=	0;
		$digest			=	$t['isbest'];
		$rate			=	0;
		$blog			=	0;
		$poll			=	$t['pollid'] > 0 ? 1 : 0;
		$attachment	=	0;
		$subscribed		=	0;
		$moderated		=	0;
		$closed		=	0;
		$tag			=	trim($t['keyword']);
		if (!empty($tag)) {
			$db['discuz']->query("INSERT INTO {$discuz_tablepre}threadtags (`tagname`, `tid`) VALUES ('$tag', '$tid')");
			//$sql_ins = "INSERT INTO {$discuz_tablepre}tags (tagname,closed,total) VALUES ('$tag', '0', '1');";
			//$sql_upd = "UPDATE {$discuz_tablepre}tags SET `total`=`total`+1 WHERE tagname='$tag';";
			//if (!$db['discuz']->query($sql_ins))
				//$db['discuz']->query($sql_upd);
		}

		$sql1 = "INSERT INTO {$discuz_tablepre}threads (
			`tid` , `fid` , `iconid` , `typeid`, `readperm`, `price`,`author` , `authorid` , `subject` , `dateline` , `lastpost` , `lastposter` , `views` , `replies` , `displayorder` , `highlight` , `digest` , `rate` , `blog` , `special` , `attachment` , `subscribed`, `moderated` , `closed`
			) VALUES(
			'$tid', '$fid', '$iconid', '$typeid', '$readperm', '$price', '$author', '$authorid', '$subject', '$dateline', '$lastpost', '$lastposter', '$views', '$replies', '$displayorder', '$highlight', '$digest', '$rate', '$blog', '$poll', '$attachment', '$subscribed', '$moderated', '$closed');";

		if($db['discuz']->query($sql1)){
			if($poll) {
				$query2 = $db['source']->query("SELECT voteid, vote, votenum, votetype, lockvote, voters, timeout FROM {$source_tablepre}vote WHERE voteid=$t[pollid]");
				$v = daddslashes(mssql_fetch_assoc($query2));

				if(!$v['voteid']) {
					$db['discuz']->query("UPDATE {$discuz_tablepre}threads SET special=0 WHERE tid='$tid'");
				} else {
					$multiple = $v['votetype'];
					$maxchoices = $multiple ? 0 : 1;
					$expiration = timetounix($v['timeout']);
					$db['discuz']->query("INSERT INTO {$discuz_tablepre}polls (`tid`, `multiple`, `maxchoices`, `expiration`) VALUES('$tid', '$multiple', '$maxchoices', '$expiration');");
					$polloptions = explode('|', $v['vote']);
					$votenums = explode('|', $v['votenum']);
					foreach($polloptions AS $key => $polloption) {
						$query3 = $db['source']->query("SELECT userid FROM {$source_tablepre}voteuser WHERE voteid=$v[voteid] AND (voteoption='$key' OR LEFT(voteoption, 2)='$key,' OR LEFT(voteoption, 3)='$key,' OR CHARINDEX(',$key,', voteoption)>0 OR RIGHT(voteoption, 2)=',$key' OR RIGHT(voteoption, 3)=',$key')");
						$voterids = $comma = '';
						while($u = $db['source']->fetch_assoc($query3)) {
							$voterids .= $comma.$u['userid'];
							$comma = "\t";
						}

						$votes = $votenums[$key];
						$db['discuz']->query("INSERT INTO {$discuz_tablepre}polloptions (`tid`, `votes`, `polloption`, `voterids`) VALUES('$tid', '$votes', '$polloption', '$voterids');");
					}
				}
			}
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ tid = $tid subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql1."</textarea>");
		}
		$converted = 1;
		$totalrows ++;
	}

	if($converted || $end < $maxid) {
		altertable('threads', 'tid');
		altertable('polls', 'tid');
		altertable('polloptions', 'tid');
	} else {
		$sql = "SELECT tagname, COUNT(tagname) as total FROM {$discuz_tablepre}threadtags GROUP BY tagname";
		$rs = $db['discuz']->query($sql);
		while ($row = $db['discuz']->fetch_array($rs)) {
			$tagname = $row['tagname'];
			$closed = 0;
			$total = $row['total'];
			$sql_ins = "INSERT INTO {$discuz_tablepre}tags (`tagname`, `closed`, `total`) VALUES ('$tagname', '$closed', '$total')";
			$db['discuz']->query($sql_ins);
		}
	}

?>