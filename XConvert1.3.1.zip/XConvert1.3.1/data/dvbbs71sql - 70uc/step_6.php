<?php
	truncatetable('forumlinks');
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}bbslink ORDER BY id");

	while($fl = $db['source']->fetch_assoc($query)) {
		$fl	= array_change_key_case($fl);
		$fl	= daddslashes($fl);
		$name	= cutstr(@strip_tags(trim($fl['boardname'])),100);
		$url	= cutstr(@strip_tags(trim($fl['url'])),100);
		$description	= cutstr(@strip_tags(trim($fl['readme'])),200);
		$logo	= cutstr(@strip_tags(trim($fl['logo'])),100);
		$sql	= "INSERT INTO $discuz_tablepre"."forumlinks (`name` , `url` , `description` , `logo` ) VALUES ('$name', '$url', '$description', '$logo');";
		if($db['discuz']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת��������̳ $name");
		}
		$totalrows ++;
	}

?>