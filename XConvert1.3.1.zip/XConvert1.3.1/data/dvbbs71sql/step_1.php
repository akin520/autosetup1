<?php
	if($start <= 1) {
		truncatetable('members');
		truncatetable('memberfields');
		validid('userid', 'user');

		if($discuz_charset == 'utf8'){
			include './data/'.$child.'/exts_utf8.php';
		}else {
			include './data/'.$child.'/exts_gbk.php';
		}
		$extcredits = addslashes(serialize($extcreditsarray));
		$db['discuz']->query("UPDATE {$discuz_tablepre}settings SET value='$extcredits' WHERE variable='extcredits'");//��������
		ctspecialgroup(); //�����û���
		addbbcode(); //����&�޸� bbcode
	}

	$query = $db['source']->query("SELECT usergroupid FROM {$source_tablepre}UserGroups WHERE parentgid =2");
	$specialgids = array();
	while ($g = $db['source']->fetch_array($query)) {
		$specialgids[] = $g['usergroupid'];
	}//������gids
	
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}user WHERE (UserID BETWEEN $start AND $end)") or dexit("�������ݱ� '{$source_tablepre}user' ����<br>�뽫�û��� '{$source_tablepre}user' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');

	while ($user = $db['source']->fetch_array($query)) {

		$user =	array_change_key_case($user);
		$uid = $user['userid'];
		$username = trim($user['username']);

		if(!$username || $username != htmlspecialchars(daddslashes($username))) {
			reportlog("�Ƿ��û��� <b><font color='red'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
		} elseif(strlen($username) > 15) {
			reportlog("�û��� <b><font color='orange'>$username</font></b> ���ȴ��� 15�����ܱ�ת����uid = $uid ��<br>\r\n");
		} elseif(getuid($username)) {
        		reportlog("�ظ��û��� <b><font color='blue'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
		} else {
			$user = daddslashes($user);

			$password	=	strtolower($user['userpassword']);
			$gender		=	$user['usersex']==1 ? 1 : 2;

			if(in_array($user['usergroupid'], array('1', '2', '3'))) {
				$adminid = $groupid = $user['usergroupid']; //������
			} elseif($user['lockuser'] == 2) {//����
				$adminid	=	-1;
				$groupid	=	4; //��ֹ����
			} elseif($user['lockuser'] == 1) {//����
				$adminid	=	-1;
				$groupid	=	5; //��ֹ����
			}elseif(in_array($user['usergroupid'], $specialgids)) { //�����Ѿ���ѯ��gids
				$adminid	=	-1;
				$groupid	=	$user['usergroupid'] + 15; //�����û���
			} else {
        			$adminid	=	0;
        			$groupid	=	10; //������·
			}

			$groupexpiry	=	0;
			$regip		=	$user['userlastip'];
			$regdate	=	timetounix($user['joindate'] ? $user['joindate'] : ($user['adddate'] ? $user['adddate'] : $timestamp));
			$lastip		=	$user['userlastip'];
			$lastvisit	=	$user['lastlogin'] ? timetounix($user['lastlogin']) : $regdate;
			$lastactivity	=	$lastvisit;
			$lastpost	=	$lastvisit;
			$posts		=	isset($user['userpost']) ? $user['userpost'] : 0;
			$credits	=	$user['userep'];		//����
			$extcredits1	=	$user['userep'];		//����ֵ
			$extcredits2	=	$user['userpower'];		//����
			$extcredits3	=	$user['userwealth'];		//��Ǯ
			$extcredits4	=	$user['usercp'];		//����
			$extcredits5	=	$user['userticket'];		//��ȯ
			$extcredits6	=	$user['usermoney'];		//���
			$extcredits7	=	0;
			$extcredits8	=	0;
			$email		=	cutstr($user['useremail'],40);
			$bday		=	isset($user['userbirthday']) ? $user['userbirthday'] : (isset($user['birthday']) ? $user['birthday'] : '0000-00-00');
			$tpp		=	'0';
			$ppp		=	'0';
			$styleid	=	'0';
			$dateformat	=	'0';
			$timeformat	=	'0';
			$pmsound	=	'0';
			$showemail	=	'0';
			$newsletter	=	'1';
			$invisible	=	'0';
			$timeoffset	=	'9999';

			$userfinfo	=	explode('|||',$user['userim']);

			$site		=	parsesite($userfinfo[0]);
			$icq		=	'';
			$qq		=	parseqqicq($userfinfo[1], 5, 12);
			$yahoo		=	'';
			$msn		=	$userfinfo[3] ? htmlspecialchars($userfinfo[3]) : '';
			$location	=	'';
			$customstatus	=	$user['usertitle'] ? cutstr(@strip_tags($user['usertitle']),30) : '';

        		$biasArray = explode('|', $user['userface']);
        		$user['userface'] = count($biasArray) == 2 ? $biasArray[1] : $user['userface'];

        		if($user['userface'] && $user['userface'] != 'http://') {
        			$user['userface'] = trim($user['userface']);
        			if(substr($user['userface'], 0, 7) == 'http://') {
        				$avatar = $user['userface'];
        			} else {
                			if(strtolower(substr($user['userface'], 0, 16)) == 'images/userface/') {
                				$avatar = 'images/avatars/dvbbs/'.substr($user['userface'], 16);
					} elseif(strtolower(substr($user['userface'], 0, 11)) == 'uploadface/') {
                				$avatar = 'customavatars/dvbbs/'.substr($user['userface'], 11);
					}
        			}
				$avatarwidth = $user['userwidth'] > 0 && $user['userwidth'] <= 120 ? $user['userwidth'] : 83;
				$avatarheight = $user['userheight'] > 0 && $user['userheight'] <= 120 ? $user['userheight'] : 94;
        		} else {
        			$avatar = '';
        			$avatarwidth = 0;
        			$avatarheight = 0;
        		}

			$bio		=	'';

        		$signature	= @strip_tags($user['usersign']);
        		$sigstatus	= $signature ? 1 : 0;
        		$sightml	= parsesign($user['usersign']);

			$nickname	=	'';
			$authstr	=	'';
			$secques	=	'';

			$query1		=	"INSERT INTO {$discuz_tablepre}members
						(uid,username, password, secques, gender, adminid, groupid, regip, regdate, lastvisit, lastactivity, posts, credits, extcredits1, extcredits2, extcredits3, extcredits4, extcredits5, extcredits6, extcredits7, extcredits8, email, bday, sigstatus, tpp, ppp, styleid, dateformat, timeformat, pmsound, showemail, newsletter, invisible, timeoffset, lastpost, lastip) VALUES
						('$uid','$username', '$password', '$secques', '$gender', '$adminid', '$groupid', '$regip', '$regdate', '$lastvisit', '$lastactivity', '$posts', '$credits','$extcredits1', '$extcredits2', '$extcredits3', '$extcredits4', '$extcredits5', '$extcredits6', '$extcredits7', '$extcredits8', '$email', '$bday', '$sigstatus', '$tpp', '$ppp', '$styleid', '$dateformat', '$timeformat', '$pmsound', '$showemail', '$newsletter', '$invisible', '$timeoffset','$lastpost','$lastip');
						";

			$query2		=	"INSERT INTO {$discuz_tablepre}memberfields
						(uid, nickname, site, icq, qq, yahoo, msn, taobao, location, customstatus, medals, avatar, avatarwidth, avatarheight, bio, sightml, authstr) VALUES
						('$uid', '$nickname', '$site', '$icq', '$qq', '$yahoo', '$msn', '' ,'$location', '$customstatus', '', '$avatar', '$avatarwidth', '$avatarheight','$bio', '$sightml', '$authstr');
						";
			if ($db['discuz']->query($query1)) {
				if ($db['discuz']->query($query2)) {
					$convertedrows ++;
				} else {
					$db['discuz']->query("DELETE FROM {$discuz_tablepre}members WHERE uid='$uid' LIMIT 1;");
					reportlog("�����Ա��չ��Ϣ���ݳ��� uid = $uid username = $username");
				}
			} else {
				reportlog("�����Ա�������ݳ��� uid = $uid username = $username");
			}
		}
		$converted = 1;
		$totalrows ++;
	}

	if($converted || $end < $maxid) {
		altertable('members', 'uid');
		altertable('memberfields', 'uid');
	}

?>