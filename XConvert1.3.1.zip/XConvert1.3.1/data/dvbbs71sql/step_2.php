<?php
truncatetable('forums');
	truncatetable('forumfields');
	truncatetable('moderators');

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}board ORDER BY boardid") or dexit("�������ݱ� '{$source_tablepre}board' ����<br>�뽫���� '{$source_tablepre}board' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while($forum = mssql_fetch_array($query)) {

		$forum = array_change_key_case(daddslashes($forum));

		$fid			=	$forum['boardid'];
		$fup			=	$forum['parentid'];
		if(isset($forum['depth']) && $forum['depth'] == 0) {
			$forumnum	=	$db['source']->result($db['source']->query("SELECT COUNT(*) AS num FROM {$source_tablepre}board WHERE parentid = $fid"), 0, num);
			$type		=	$forumnum ? 'group' : 'forum';
		} elseif ($forum['depth'] == 1) {
			$type		=	'forum';
		} else {
			$type		=	'sub';
		}
		$name			=	cutstr(htmlspecialchars(trim(@strip_tags($forum['boardtype']))), 50);
		$displayorder		=	$forum['orders'];
		$styleid		=	0;
		$threads		=	$forum['topicnum'];
		$posts			=	$forum['postnum'];
		$todayposts		=	0;
		$lastpost		=	'';
		$status			=	1;
		$allowsmilies		=	1;
		$allowhtml		=	0;
		$allowbbcode		=	$allowsmilies;
		$allowimgcode		=	$allowsmilies;
		$modnewposts		=	0;
		$allowshare		=	$allowsmilies;
		$allowpostspecial	=	3;
		$allowspecialonly	=	0;//5.5����ֶ�,byСˮˮ
		$alloweditrules		=	0;
		$recyclebin		=	0;
		$jammer			=	0;
		$disablewatermark	=	0;
		$inheritedmod		=	0;
		$autoclose		=	0;
		$description		=	$forum['readme'];
		$password		=	'';
		$icon			=	'';
		$postcredits		=	'';
		$replycredits		=	'';
		$redirect		=	'';
		$attachextensions	=	'';
		$moderators		=	addmoderators(explode('|', $forum['boardmaster']), $fid);
		$rules			=	'';
		$threadtypes		=	'';
		$viewperm		=	'';
		$postperm		=	'';
		$replyperm		=	'';
		$getattachperm		=	'';
		$postattachperm		=	'';
		$alloweditpost		=	1;//5.5����ֶ�,byСˮˮ
		$simple			=	0;//5.5����ֶ�,byСˮˮ

		$query1	=	"INSERT INTO {$discuz_tablepre}forums ( `fid` , `fup` , `type` , `name` , `status` , `displayorder` , `styleid` , `threads` , `posts` , `todayposts` , `lastpost` , `allowsmilies` , `allowhtml` , `allowbbcode` , `allowimgcode` , `allowshare` , `allowpostspecial` , `allowspecialonly` , `alloweditrules` , `recyclebin` , `modnewposts` , `jammer` , `disablewatermark` , `inheritedmod` , `autoclose` , `alloweditpost` , `simple` ) VALUES ('$fid','$fup','$type','$name','$status','$displayorder','$styleid','$threads','$posts','$todayposts','$lastpost','$allowsmilies','$allowhtml','$allowbbcode','$allowimgcode','$allowshare','$allowpostspecial','$allowspecialonly','$alloweditrules','$recyclebin','$modnewposts','$jammer','$disablewatermark','$inheritedmod','$autoclose','$alloweditpost','$simple');";//����simple,alloweditpost,allowspecialonly�����ֶ�,byСˮˮ

		$query2	=	"INSERT INTO {$discuz_tablepre}forumfields ( `fid` , `description` , `password` , `icon` , `postcredits` , `replycredits` , `redirect` , `attachextensions` , `moderators` , `rules` , `threadtypes` , `viewperm` , `postperm` , `replyperm` , `getattachperm` , `postattachperm` ) VALUES ('$fid','$description','$password','$icon','$postcredits','$replycredits','$redirect','$attachextensions','$moderators','$rules','$threadtypes','$viewperm','$postperm','$replyperm','$getattachperm','$postattachperm');";

		$query3	=	"DELETE FROM {$discuz_tablepre}moderators WHERE `fid`='$fid';";

		if($db['discuz']->query($query1)) {
			if($db['discuz']->query($query2)) {
				$convertedrows ++;
			} else {
				$db['discuz']->query($query3);
				$db['discuz']->query("DELETE FROM {$discuz_tablepre}forums WHERE `fid`='$fid' LIMIT 1;");
				reportlog("���������չ��Ϣ���ݳ��� fid = $fid name = $name");
			}
		} else {
			$db['discuz']->query($query3);
			reportlog("��������������ݳ��� fid = $fid name = $name");
		}
		$totalrows ++;
	}

	altertable('forums', 'fid');
	altertable('forumfields', 'fid');
	altertable('moderators', 'fid');
?>