<?php
	$dv_posttbl = isset($_GET['dv_posttbl']) ? $_GET['dv_posttbl'] : '';
	$tableid = isset($_GET['tableid']) ? $_GET['tableid'] : 1;
	if($start <= 1 && $dv_posttbl == '') {
		$dv_posttbl = $comma = '';
		$tablequery = $db['source']->query("SELECT TableName FROM {$source_tablepre}TableList");
		while ($tb = $db['source']->fetch_assoc($tablequery)){
			$dv_posttbl .= $comma.$tb['TableName'];
			$comma = ',';
		}		
	}
	$tablearray = explode(',', $dv_posttbl);
	$tablecount = count($tablearray);
	$posttable = $tablearray[$tableid - 1];

	if($start <= 1 && $tableid == 1) {
		truncatetable('posts');
		validid('announceid', $tablearray[0], '');
	}

	$query = $db['source']->query("SELECT AnnounceID,ParentID,BoardID,RootID,UserName,PostUserid,Topic, isupload,DateAndTime,ip,locktopic,signflag,cast(Body AS TEXT) AS Body FROM $posttable WHERE AnnounceID BETWEEN $start AND $end") or dexit("�������ݱ� '$posttable' ����<br>�뽫���ӱ� '$posttable' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while ($p = $db['source']->fetch_assoc($query)) {
		$p = array_change_key_case(daddslashes($p));

		//$pid			=	$p['announceid'];
		$p['isupload']		=	intval($p['isupload']);
		$tid			=	$p['rootid'];
		$fid			=	$p['boardid'];
		$first			=	$p['parentid'] == 0 ? 1 : 0;
		$subject		=	cutstr(@strip_tags(trim($p['topic'])), 78);
		$author			=	$p['username'];
		$authorid		=	$p['postuserid'];
		$dateline		=	timetounix($p['dateandtime']);
		$message		=	convertbbcode($p['body']);
		$useip			=	$p['ip'];
		$attachment		=	$p['isupload'];
		$usesig			=	1;
		$bbcodeoff		=	0;
		$smileyoff		=	0;
		$parseurloff		=	0;
		$htmlon			=	@strip_tags($message) == $message ? 0 : 1;
		$rate			=	0;
		$ratetimes		=	0;
		$status			=	$p['locktopic'] == 2 ? 1 : 0;
		$sql = "INSERT INTO {$discuz_tablepre}posts (fid, tid, first, author, authorid, subject, dateline, message, useip, attachment, usesig, bbcodeoff, smileyoff, parseurloff, htmlon, rate, ratetimes, status) ".
			"VALUES ('$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$attachment','$usesig', '$bbcodeoff', '$smileyoff', '$parseurloff', '$htmlon', '$rate', '$ratetimes', '$status')";
			
		if($db['discuz']->query($sql)){
			$pid = $db['discuz']->insert_id();
			$db['discuz']->query("UPDATE {$discuz_tablepre}attachments set pid='$pid' WHERE tid='$tid' AND pid='$p[announceid]'");
			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
		}

		$converted = 1;
		$totalrows ++;
	}
	if($converted || $end < $maxid) {
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid."&tableid=$tableid&dv_posttbl=$dv_posttbl");
	} elseif($tableid < $tablecount) {
		validid('announceid', $tablearray[$tableid], '');
		$end = $start - 1;
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.($tableid + 1)."&dv_posttbl=$dv_posttbl");
	}

?>