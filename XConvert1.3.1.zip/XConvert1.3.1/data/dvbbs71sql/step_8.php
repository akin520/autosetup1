<?php
	if($start <= 1) {
		truncatetable('buddys');
		validid('f_id', 'friend');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Friend WHERE F_id BETWEEN $start AND $end");
	while($buddy = $db['source']->fetch_assoc($query)) {
		$buddy		= array_change_key_case(daddslashes($buddy));
		$uid		= $buddy['f_userid'];
		$dateline	= timetounix($buddy['f_addtime']);
		if($buddyid = getuid($buddy['f_friend'])) {
			$sql = "INSERT INTO $discuz_tablepre"."buddys ( `uid` , `buddyid`, `dateline`) VALUES ('$uid', '$buddyid', '$dateline');";
			if($db['discuz']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת����̳�������� uid = $uid buddyid = $buddyid");
			}
			$totalrows ++;
		}
		$converted = 1;
	}
?>