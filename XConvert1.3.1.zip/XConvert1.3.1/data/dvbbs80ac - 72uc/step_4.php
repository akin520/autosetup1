<?php
	if($start <= 1) {
		truncatetable('attachments');
		truncatetable('attachmentfields');
		validid('f_id', 'upfile');
	}

	$query = "SELECT * FROM {$source_tablepre}upfile WHERE (f_id BETWEEN $start AND $end)";
	$rs = $db['source']->execute($query);

	$fieldarray = array('f_id', 'f_announceid', 'f_boardid', 'f_userid', 'f_filename', 'f_filetype', 'f_filesize', 'f_readme', 'f_downnum', 'f_addtime');
	while (!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$att[$field] = daddslashes($rs->fields[$field]->value);
		}

		if($att['f_announceid']) {
			$aid		= $att['f_id'];
			$temp		= explode('|', $att['f_announceid']);
			$tid		= intval($temp[0]);
			$pid		= intval($temp[1]);
			if($tid && $pid) {
				$dateline	= timetounix($att['f_addtime']);
				$price		= 0;// byСˮˮ
				$filename	= random(8).".".$att['f_filetype'];
				$filetype	= getfiletype($filename);
				$filesize	= $att['f_filesize'];
				$attachment	= 'dvbbs/'.$att['f_filename'];
				$downloads	= $att['f_downnum'];
				$description	= cutstr(htmlspecialchars($att['f_readme']), 90);
				$isimage	= in_array($filetype, array('image/pjpeg', 'image/gif', 'image/bmp', 'image/png')) ? 1 : 0;
				$uid		= $att['f_userid'];
				$thumb		= 0;// byСˮˮ
				$remote		= 0;// byСˮˮ

				$sql1fields =  array('aid', 'tid', 'pid', 'dateline', 'readperm', 'price', 'filename', 'filetype', 'filesize', 'attachment', 'downloads', 'isimage', 'uid', 'thumb', 'remote');
				$sql1 = getinsertsql("{$discuz_tablepre}attachments", $sql1fields);

				$sql2 = "UPDATE {$discuz_tablepre}threads SET attachment=1 WHERE tid='$tid'";
				$sql3 = "insert into {$discuz_tablepre}attachmentfields
						(`aid`,`tid`,`pid`,`uid`,`description`) values  
						('$aid','$tid','$pid','$uid','$description')";

				if($db['discuz']->query($sql1)) {
					$db['discuz']->query($sql2);
					 $db['discuz']->query($sql3);
					$convertedrows ++;
				} else {
					reportlog("�޷�ת������ $filename ");
				}
				$totalrows ++;
			}
		}

		$converted = 1;
		$rs->Movenext();
	}
	$rs->close();

	if(!$converted && $end >= $maxid) {
		altertable('attachments', 'aid');
	}

?>