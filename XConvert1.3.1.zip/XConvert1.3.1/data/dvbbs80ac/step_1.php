<?php
	if($start <= 1) {

		truncatetable('members');
		truncatetable('memberfields');
		validid('userid', 'user');

		if($discuz_charset == 'utf8'){
			require_once XCONVERT_ROOT.'./data/'.$child.'/extcredits_utf8.php';
		}else {
			require_once XCONVERT_ROOT.'./data/'.$child.'/extcredits_gbk.php';
		}
		$extcredits = addslashes(serialize($extcredits));
		$db['discuz']->query("UPDATE {$discuz_tablepre}settings SET value='$extcredits' WHERE variable='extcredits'");//��������

		ctspecialgroup(); //�����û���

		addbbcode(); //����/�޸� bbcode
		$dv_versql = "SELECT Forum_Version FROM {$source_tablepre}Setup";
		$rs = $db['source']->execute($dv_versql);
		!$rs->EOF && $dv_ver = $rs->fields[Forum_Version]->value;
		$rs->close();
	}
	$dv_ver = isset($dv_ver) ? $dv_ver : $_GET['dv_ver'];
	$sql = "SELECT usergroupid FROM {$source_tablepre}usergroups WHERE parentgid =2";
	$rs = $db['source']->execute($sql);
	$fieldarray = array('usergroupid');
	$specialgids = $g = array();
	while (!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$g[$field] = $rs->fields[$field]->value;
		}
		$specialgids[] = $g['usergroupid'];
		$rs->movenext();
	}
	$rs->close();


	$sql = "SELECT * FROM {$source_tablepre}user WHERE (userid BETWEEN $start AND $end)";
	$rs = $db['source']->execute($sql);

	$fieldarray = array('userid', 'username', 'userpassword', 'useremail', 'userpost', 'usertopic', 'usersign', 'usersex', 'userface', 'userwidth', 'userheight', 'userim', 'joindate', 'lastlogin', 'userviews', 'userclass', 'userwealth', 'userep', 'usercp', 'userpower', 'userbirthday', 'userlastip', 'userinfo', 'userticket', 'usermoney', 'lockuser', 'usergroupid');
	if ($dv_ver == '7.0.0') {
		$fieldarray = array('userid', 'username', 'userpassword', 'useremail', 'userpost', 'usertopic', 'usersign', 'usersex', 'userface', 'userwidth', 'userheight', 'userim', 'joindate', 'lastlogin', 'userviews', 'userclass', 'userwealth', 'userep', 'usercp', 'userpower', 'userbirthday', 'userlastip', 'userinfo', 'lockuser', 'usergroupid');
	}

	while (!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$user[$field] = $rs->fields[$field]->value;
		}

		$uid = $user['userid'];
		$username = trim($user['username']);

		if(!$username || $username != htmlspecialchars(daddslashes($username))) {
			reportlog("�Ƿ��û��� <b><font color='red'>$username</font></b> ���ܱ�ת����uid = $uid ��");
		} elseif(strlen($username) > 15) {
			reportlog("�û��� <b><font color='orange'>$username</font></b> ���ȴ��� 15�����ܱ�ת����uid = $uid ��");
		} elseif(getuid($username)) {
        		reportlog("�ظ��û��� <b><font color='blue'>$username</font></b> ���ܱ�ת����uid = $uid ��");
		} else {

			$user = daddslashes($user);

        		$password	= strtolower($user['userpassword']);
			$gender		=	$user['usersex']==1 ? 1 : 2;
        		$groupexpiry	= 0;
        		$regip		= $user['userlastip'];
        		$regdate	= timetounix($user['joindate']);

        		$lastip		= $user['userlastip'];
        		$lastvisit	= timetounix($user['lastlogin']);
        		$lastactivity	= $lastvisit;
        		$lastpost	= $lastvisit;
        		$posts		= isset($user['userpost']) ? $user['userpost'] : 0;
			$credits	= $user['userep'];		//����
			$extcredits1	= $user['userep'];		//����ֵ
			$extcredits2	= $user['userpower'];		//����
			$extcredits3	= $user['userwealth'];		//��Ǯ
			$extcredits4	= $user['usercp'];		//����
			$extcredits5	= $user['userticket'];		//��ȯ
			$extcredits6	= $user['usermoney'];		//���
        		$extcredits7	= 0;
        		$extcredits8	= 0;

			if(in_array($user['usergroupid'], array('1', '2', '3'))) {
				$adminid = $groupid = $user['usergroupid']; //������
			} elseif($user['lockuser'] == 2) {//����
				$adminid	=	-1;
				$groupid	=	4; //��ֹ����
			} elseif($user['lockuser'] == 1) {//����
				$adminid	=	-1;
				$groupid	=	5; //��ֹ����
			}elseif(in_array($user['usergroupid'], $specialgids)) { //�����Ѿ���ѯ��gids
				$adminid	=	-1;
				$groupid	=	$user['usergroupid'] + 15; //�����û���
			} else {
        		$adminid	=	0;
        		$groupid	=	10; //������·
			}

        		$email		= cutstr($user['useremail'],40);
        		$bday		= $user['userbirthday'] ? $user['userbirthday'] : '0000-00-00';

        		$tpp		= 0;
        		$ppp		= 0;
        		$styleid	= 0;
        		$dateformat	= 0;
        		$timeformat	= 0;
        		$pmsound	= 0;
        		$showemail	= 0;
        		$newsletter	= '1';
        		$invisible	= 0;
        		$timeoffset	= '9999';

        		$site		= $userfinfo[0] ? (htmlspecialchars(trim(str_replace('http://', '', $userfinfo[0])))) : '';;
        		$icq		= '';
        		$qq		= parseqqicq($userfinfo[1]);
        		$yahoo		= '';
        		$msn		= $userfinfo[3] ? htmlspecialchars($userfinfo[3]) : '';
        		$location	= '';
        		$customstatus	= $user['usertitle'] ? cutstr(@strip_tags($user['usertitle']),30) : '';

        		$bio		= '';

//        		$signature	= @strip_tags($user['usersign']);//5.5�汾�Ѿ�ȥ�����ֶ�,byСˮˮ
//        		$sigstatus	= $signature ? 1 : 0;
        		$sightml	= parsesign($user['usersign']);
        		$nickname	= '';
        		$authstr	= '';
        		$secques	= '';
        		$ignorepm	= '';
        		$groupterms	= '';

        		$biasArray = explode('|', $user['userface']);
        		$user['userface'] = count($biasArray) == 2 ? $biasArray[1] : $user['userface'];

        		if($user['userface'] && $user['userface'] != 'http://') {
        			$user['userface'] = trim($user['userface']);
        			if(substr($user['userface'], 0, 7) == 'http://') {
        				$avatar = $user['userface'];
        			} else {
                			if(strtolower(substr($user['userface'], 0, 16)) == 'images/userface/') {
                				$avatar = 'images/avatars/dvbbs/'.substr($user['userface'], 16);
					} elseif(strtolower(substr($user['userface'], 0, 11)) == 'uploadface/') {
                				$avatar = 'customavatars/dvbbs/'.substr($user['userface'], 11);
					}
        			}
				$avatarwidth = $user['userwidth'] > 0 && $user['userwidth'] <= 120 ? $user['userwidth'] : 83;
				$avatarheight = $user['userheight'] > 0 && $user['userheight'] <= 120 ? $user['userheight'] : 94;
        		} else {
        			$avatar = '';
        			$avatarwidth = 0;
        			$avatarheight = 0;
        		}

			$fields1 = array('uid', 'username', 'password', 'secques', 'gender', 'adminid', 'groupid', 'regip', 'regdate', 'lastvisit', 'lastactivity', 'posts', 'credits', 'extcredits1', 'extcredits2', 'extcredits3', 'extcredits4', 'extcredits5', 'extcredits6', 'extcredits7', 'extcredits8', 'email', 'bday', 'sigstatus', 'tpp', 'ppp', 'styleid', 'dateformat', 'timeformat', 'pmsound', 'showemail', 'newsletter', 'invisible', 'timeoffset', 'lastpost', 'lastip');
			$query1 = getinsertsql("{$discuz_tablepre}members", $fields1);

			$fields2 = array('uid', 'nickname', 'site', 'icq', 'qq', 'yahoo', 'msn', 'taobao', 'location', 'customstatus', 'medals', 'avatar', 'avatarwidth', 'avatarheight', 'bio', 'sightml', 'ignorepm', 'groupterms', 'authstr');
			$query2 = getinsertsql("{$discuz_tablepre}memberfields", $fields2);

			if ($db['discuz']->query($query1)) {
				if ($db['discuz']->query($query2)) {
					$convertedrows ++;
				} else {
					$db['discuz']->query("DELETE FROM {$discuz_tablepre}members WHERE uid='$uid' LIMIT 1;");
					reportlog("�����Ա��չ��Ϣ���ݳ��� uid = $uid username = $username");
				}
			} else {
				reportlog("�����Ա�������ݳ��� uid = $uid username = $username");
			}

		}
	    	$converted = 1;
		$totalrows ++;
	    	$rs->movenext();
	}
	$rs->close();

	if($converted || $end < $maxid) {
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&dv_ver='.$dv_ver);
	} else {
		altertable('members', 'uid');
		altertable('memberfields', 'uid');
	}
?>