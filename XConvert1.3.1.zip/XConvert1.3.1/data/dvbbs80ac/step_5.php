<?php
	$dv_posttbl = isset($_GET['dv_posttbl']) ? $_GET['dv_posttbl'] : '';
	$tableid = isset($_GET['tableid']) ? $_GET['tableid'] : 1;
	if($start <= 1 && $dv_posttbl == '') {
		$dv_posttbl = $comma = '';
		$tablesql = "SELECT TableName FROM {$source_tablepre}TableList";
		$rs = $db['source']->execute($tablesql);
		while(!$rs->EOF){
			$dv_posttbl .= $comma.$rs->fields[TableName]->value;
			$comma = ',';
			$rs->movenext();
		}
		$rs->Close();
	}
	$tablearray = explode(',', $dv_posttbl);
	$tablecount = count($tablearray);
	$posttable = $tablearray[$tableid - 1];

	if($start <= 1 && $tableid == 1) {
		truncatetable('posts');
		truncatetable('trades');
		validid('announceid', $tablearray[0], '');
	}

	$sql = "SELECT b.*,t.issmstopic FROM $posttable b LEFT OUTER JOIN {$source_tablepre}Topic t ON b.rootid=t.topicid WHERE (b.announceid BETWEEN $start AND $end)";
	
	$rs = $db['source']->execute($sql);
	
	$fieldarray = array('announceid', 'parentid', 'boardid', 'username', 'postuserid', 'topic', 'body', 'dateandtime', 'rootid', 'ip', 'locktopic', 'isupload', 'issmstopic');
	
	while (!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$p[$field] = daddslashes($rs->fields[$field]->value);
		}

		$tid			=	$p['rootid'];
		$fid			=	$p['boardid'];
		$first			=	$p['parentid'] == 0 ? 1 : 0;
		$subject		=	cutstr(@strip_tags(trim($p['topic'])), 78);
		$author			=	$p['username'];
		$authorid		=	$p['postuserid'];
		$dateline		=	timetounix($p['dateandtime']);
		$p['isupload']		=	intval($p['isupload']);
		$message		=	convertbbcode($p['body']);
		$useip			=	$p['ip'];
		$attachment		=	$p['isupload'];
		$usesig			=	1;
		$bbcodeoff		=	0;
		$smileyoff		=	0;
		$parseurloff		=	0;
		$htmlon			=	@strip_tags($message) == $message ? 0 : 1;
		$rate			=	0;
		$ratetimes		=	0;
		$status			=	$p['locktopic'] == 2 ? 1 : 0;

		$sqlfields = array('fid', 'tid', 'first', 'author', 'authorid', 'subject', 'dateline', 'message', 'useip', 'attachment', 'usesig', 'bbcodeoff', 'smileyoff', 'parseurloff', 'htmlon', 'rate', 'ratetimes', 'status');
		//echo "announceid = ".$p['announceid']." , parentid = ".$p['parentid']." , issmstopic = ".$p['issmstopic']."<br>";
		if ($p['parentid'] == 0 && $p['issmstopic'] == 2) {
			//���뽻��
			preg_match_all('|\(([^\)]+)\)(.*)\(/([^\)]+)\)|U', trim($p['body']), $info);
			$body = array();
			foreach ($info[0] as $value) {
				preg_match('|\(([^\)]+)\)(.*)\(/([^\)]+)\)|U', trim($value), $a);
				if (!empty($a[1]) && strtolower($a[1]) == strtolower($a[3])) {
					$body[strtolower($a[1])] = $a[2];
				}			
			}
			
			preg_match_all('|\[upload(.*)\](.*)\[/upload\]|U', $body['body'], $array);

			$att_array = array();
			
			for ($i = 1; $i <= count($array[0]); $i++) {
				$att_array[] = "[attachimg]".$i."[/attachimg]";
				//$array[0][$i-1] = '/'.addcslashes($array[0][$i-1], '[]./=,').'/';
			}
			
			$att_array[count($array[0])-1] = "";
			//$body['body'] = str_replace($array[0], $att_array, $body['body']);	
					
			$body['body'] = convertbbcode($body['body']);
			
			$tid = $tid;
			$pid = $p['announceid'];
			$typeid = 0;
			$sellerid = $authorid;
			$seller = $author;
			$account = '';
			$subject = $body['subject'];
			$price = $body['price'];
			$amount = 1;
			$quality = 1;
			$locus = '';
			$transport = $body['transport'];
			$ordinaryfee = $body['mail'];
			$expressfee = $body['express'];
			$emsfee = '';
			$itemtype = 1;
			$dateline = $dateline;
			$expiration = '1202486400';
			$lastbuyer = '';
			$lastupdate = $dateline;
			$totalitems = '';
			$tradesum = '';
			$closed = '';
			$aid = '';
			$displayorder = '';
			$costprice = '';

			$trade_sql = "INSERT INTO {$discuz_tablepre}trades (tid, pid, typeid, sellerid, seller, account, subject, price, amount, quality, locus, transport, ordinaryfee, expressfee, emsfee, itemtype, dateline, expiration, lastbuyer, lastupdate, totalitems, tradesum, closed, aid, displayorder, costprice) VALUES ('$tid', '$pid', '$typeid', '$sellerid', '$seller', '$account', '$subject', '$price', '$amount', '$quality', '$locus', '$transport', '$ordinaryfee', '$expressfee', '$emsfee', '$itemtype', '$dateline', '$expiration', '$lastbuyer', '$lastupdate', '$totalitems', '$tradesum', '$closed', '$aid', '$displayorder', '$costprice');";

			$db['discuz']->query($trade_sql);
			//���뽻�� end

			$first = 1;
			$message = '';
			$attachment = 0;
			$sql = getinsertsql("{$discuz_tablepre}posts", $sqlfields);
			$db['discuz']->query($sql);

			$first = 0;
			$message = $body['body'];
			$attachment = $p['isupload'];
		}

		$sql = getinsertsql("{$discuz_tablepre}posts", $sqlfields);
		
		if($db['discuz']->query($sql)){			
			$pid = $db['discuz']->insert_id();
			$db['discuz']->query("UPDATE {$discuz_tablepre}attachments set pid='$pid' WHERE tid='$tid' AND pid='$p[announceid]'");

			$a_rs = $db['discuz']->query("SELECT aid FROM {$discuz_tablepre}attachments WHERE pid='$pid'");
			if (!empty($a_rs)) {
				$row = $db['discuz']->fetch_array($a_rs);
				$aid = $row['aid'];
			}
			$db['discuz']->query("UPDATE {$discuz_tablepre}trades set pid='$pid',aid='$aid' WHERE tid='$tid' AND pid='$p[announceid]'");

			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
		}
		$converted = 1;
		$totalrows ++;
		$rs->movenext();
	}

	$rs->Close();

	if($converted || $end < $maxid) {
		showmessage("<b>��ǰ������ $step / $steps �� => ת�� $operation ����</b><br><br>���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid."&tableid=$tableid&dv_posttbl=$dv_posttbl");
	} elseif($tableid < $tablecount) {
		validid('announceid', $tablearray[$tableid], '');
		$end = $start - 1;
		showmessage("<b>��ǰ������ $step / $steps �� => ת�� $operation ����</b><br><br>���ڴ����� $tableid ���ֱ�,�� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid."&tableid=".($tableid + 1)."&dv_posttbl=$dv_posttbl");
	}
?>