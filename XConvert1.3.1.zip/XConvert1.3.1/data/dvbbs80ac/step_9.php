<?php
	truncatetable('threadtypes');

	$query = "SELECT boardid, board_setting FROM {$source_tablepre}board ORDER BY boardid";
	$rs = $db['source']->execute($query);
	$fieldarray = array('boardid', 'board_setting');
	while(!$rs->EOF) {
		foreach($fieldarray AS $field) {
			$forum[$field] = daddslashes($rs->fields[$field]->value);
		}
		$fid		=	$forum['boardid'];
		$ftemp		=	explode(',', $forum['board_setting']);
		$ftmp		=	$ftemp[48];
		$tmp		=	explode('$$', $ftmp);
		$typearray = array();
		$types = array();
		foreach($tmp AS $k => $v) {
			if(!empty($v)) {
				$typearray[$k + 1] = $v;
			}
		}
		if(count($typearray)) {
			foreach($typearray AS $typeid => $typename) {
				$typename = trim($typename);
				if($typename) {
					$threadtypeid = $db['discuz']->result($db['discuz']->query("SELECT typeid FROM {$discuz_tablepre}threadtypes WHERE name='$typename' LIMIT 1"), 0);
					if(!$threadtypeid) {
						$name = $typename;
						$db['discuz']->query(getinsertsql("{$discuz_tablepre}threadtypes", 'name'));
						$threadtypeid = mysql_insert_id();
					}
					$types[$threadtypeid] = $typename;
					$db['discuz']->query("UPDATE {$discuz_tablepre}threads SET typeid='$threadtypeid' WHERE fid='$fid' AND typeid='$typeid'");
					$convertedrows ++;
					$totalrows ++;
				}
			}
			$threadtypes = daddslashes(serialize(array
					(
					'status' => 1,
					'required' => 1,
					'listable' => 1,
					'prefix' => 1,
					'types' => $types,
					'flat' => $types
					)));
			$db['discuz']->query("UPDATE {$discuz_tablepre}forumfields SET threadtypes='$threadtypes' WHERE fid='$fid'");
		}
		$rs->Movenext();
	}
	$rs->close();

?>