<?php
	if($start <= 1) {
		truncatetable_uc('pms');
		validid('id', 'message');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Message WHERE id BETWEEN $start AND $end") or dexit("�������ݱ� '{$source_tablepre}Message' ����<br>�뽫����Ϣ�� '{$source_tablepre}Message' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while($pms = $db['source']->fetch_assoc($query)) {
		$pms = array_change_key_case(daddslashes($pms));

		if($msgtoid = getuid($pms['incept'])) {
			//pms
			$msgfrom	=	$pms['sender'];
			$msgfromid	=	getuid($msgfrom);
			$folder		=	$pms['issend'] ? 'inbox' : 'outbox';
			$new		=	$pms['flag'] ? 0 : 1;
			$subject	=	cutstr(@strip_tags(trim($pms['title'])),70);
			$subject	=	str_replace('\'','',$subject);
			$subject	=	str_replace('\\','',$subject);
			$dateline	=	timetounix($pms['sendtime']);
			$dateline	=	$dateline > $timestamp ? $timestamp : $dateline;
			$message	=	@strip_tags(trim($pms['content']));
			$delstatus	=	$pms['dels'] ? 2 : 0;
			$related	=	0;

			$fields = array('msgfrom','msgfromid','msgtoid','folder','new','subject','dateline','message','delstatus','related');
			$sql = getinsertsql("{$uc_tablepre}pms", $fields);

			if($db['uc']->query($sql)) {
				$convertedrows ++;
			} else {
				reportlog("�޷�ת������Ϣ $subject");
			}
			$totalrows ++;
		}

		$converted = 1;
	}
?>