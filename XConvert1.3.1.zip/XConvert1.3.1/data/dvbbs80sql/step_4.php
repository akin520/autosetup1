<?php
	if($start <= 1) {
		truncatetable('attachments');
		validid('f_id', 'upfile');
	}

	$query = $db['source']->query("SELECT * FROM {$source_tablepre}Upfile WHERE (F_ID BETWEEN $start AND $end)");
	while ($att =  $db['source']->fetch_assoc($query)) {
		$att = array_change_key_case(daddslashes($att));

		if($att['f_announceid']) {
			$aid		= $att['f_id'];
			$temp		= explode('|', $att['f_announceid']);
			$tid		= $temp[0];
			$pid		= $temp[1];
			if($tid && $pid) {
				$dateline	= timetounix($att['f_addtime']);
				$price		= 0;// byСˮˮ
				$filename	= random(8).".".$att['f_filetype'];
				$filetype	= getfiletype($filename);
				$filesize	= $att['f_filesize'];
				$attachment	= 'dvbbs/'.$att['f_filename'];
				$downloads	= $att['f_downnum'];
				$description	= cutstr(htmlspecialchars(strip_tags($att['f_readme'])), 90);;
				$isimage	= in_array($filetype, array('image/pjpeg', 'image/gif', 'image/bmp', 'image/png')) ? 1 : 0;
				$uid		= $att['f_userid'];
				$thumb		= 0;// byСˮˮ
				$remote		= 0;// byСˮˮ

				$sql1 = "INSERT INTO {$discuz_tablepre}attachments (`aid`, `tid`, `pid`, `dateline`,`readperm`,`price`,`filename`, `filetype`, `filesize`, `attachment`, `downloads`,`description`, `isimage`, `uid`, `thumb`, `remote`)
					VALUES ('$aid', '$tid', '$pid', '$dateline', '$readperm', '$price', '$filename', '$filetype', '$filesize', '$attachment', '$downloads', '$description', '$isimage', '$uid', '$thumb', '$remote');";//���������ֶ� byСˮˮ

				$sql2 = "UPDATE {$discuz_tablepre}threads SET attachment=1 WHERE tid='$tid'";

				if( $db['discuz']->query($sql1)) {
					 $db['discuz']->query($sql2);
					$convertedrows ++;
				} else {
					reportlog("�޷�ת������ $filename ");
				}
				$totalrows ++;
			}
		}
		$converted = 1;
	}

	if($converted || $end < $maxid) {
		altertable('attachments', 'aid');
	}

?>