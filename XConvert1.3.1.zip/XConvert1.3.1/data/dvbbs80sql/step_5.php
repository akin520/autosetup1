<?php
	$dv_posttbl = isset($_GET['dv_posttbl']) ? $_GET['dv_posttbl'] : '';
	$tableid = isset($_GET['tableid']) ? $_GET['tableid'] : 1;
	if($start <= 1 && $dv_posttbl == '') {
		$dv_posttbl = $comma = '';
		$tablequery = $db['source']->query("SELECT TableName FROM {$source_tablepre}TableList");
		while ($tb = $db['source']->fetch_assoc($tablequery)){
			$dv_posttbl .= $comma.$tb['TableName'];
			$comma = ',';
		}		
	}
	$tablearray = explode(',', $dv_posttbl);
	$tablecount = count($tablearray);
	$posttable = $tablearray[$tableid - 1];

	if($start <= 1 && $tableid == 1) {
		truncatetable('posts');
		truncatetable('trades');
		validid('announceid', $tablearray[0], '');
	}

	$query = $db['source']->query("SELECT b.AnnounceID,b.ParentID,b.BoardID,b.RootID,b.UserName,b.PostUserid,b.Topic, b.isupload,b.DateAndTime,b.ip,b.locktopic,b.signflag,cast(b.Body AS TEXT) AS Body,t.issmstopic FROM $posttable b LEFT OUTER JOIN {$source_tablepre}Topic t ON t.TopicID=b.RootID WHERE b.AnnounceID BETWEEN $start AND $end;") or dexit("�������ݱ� '$posttable' ����<br>�뽫���ӱ� '$posttable' �ֶ�����Ϊ nText �ĸ�Ϊ Text ���͡�", 'mssql');
	while ($p = $db['source']->fetch_assoc($query)) {
		$p = array_change_key_case(daddslashes($p));

		//$pid			=	$p['announceid'];
		$p['isupload']		=	intval($p['isupload']);
		$tid			=	$p['rootid'];
		$fid			=	$p['boardid'];
		$first			=	$p['parentid'] == 0 ? 1 : 0;
		$subject		=	cutstr(@strip_tags(trim($p['topic'])), 78);
		$author			=	$p['username'];
		$authorid		=	$p['postuserid'];
		$dateline		=	timetounix($p['dateandtime']);
		$message		=	convertbbcode($p['body']);
		$useip			=	$p['ip'];
		$attachment		=	$p['isupload'];
		$usesig			=	1;
		$bbcodeoff		=	0;
		$smileyoff		=	0;
		$parseurloff		=	0;
		$htmlon			=	@strip_tags($message) == $message ? 0 : 1;
		$rate			=	0;
		$ratetimes		=	0;
		$status			=	$p['locktopic'] == 2 ? 1 : 0;

		if ($p['parentid'] == 0 && $p['issmstopic'] == 2) {
			//���뽻��
			preg_match_all('|\(([^\)]+)\)(.*)\(/([^\)]+)\)|U', trim($p['body']), $info);
			$body = array();
			foreach ($info[0] as $value) {
				preg_match('|\(([^\)]+)\)(.*)\(/([^\)]+)\)|U', trim($value), $a);
				if (!empty($a[1]) && strtolower($a[1]) == strtolower($a[3])) {
					$body[strtolower($a[1])] = $a[2];
				}			
			}
			
			preg_match_all('|\[upload(.*)\](.*)\[/upload\]|U', $body['body'], $array);

			$att_array = array();
			
			for ($i = 1; $i <= count($array[0]); $i++) {
				$att_array[] = "[attachimg]".$i."[/attachimg]";
				//$array[0][$i-1] = '/'.addcslashes($array[0][$i-1], '[]./=,').'/';
			}
			
			$att_array[count($array[0])-1] = "";
			//$body['body'] = str_replace($array[0], $att_array, $body['body']);	
					
			$body['body'] = convertbbcode($body['body']);
			
			$tid = $tid;
			$pid = $p['announceid'];
			$typeid = 0;
			$sellerid = $authorid;
			$seller = $author;
			$account = '';
			$subject = $body['subject'];
			$price = $body['price'];
			$amount = 1;
			$quality = 1;
			$locus = '';
			$transport = $body['transport'];
			$ordinaryfee = $body['mail'];
			$expressfee = $body['express'];
			$emsfee = '';
			$itemtype = 1;
			$dateline = $dateline;
			$expiration = '1202486400';
			$lastbuyer = '';
			$lastupdate = $dateline;
			$totalitems = '';
			$tradesum = '';
			$closed = '';
			$aid = '';
			$displayorder = '';
			$costprice = '';

			$trade_sql = "INSERT INTO {$discuz_tablepre}trades (tid, pid, typeid, sellerid, seller, account, subject, price, amount, quality, locus, transport, ordinaryfee, expressfee, emsfee, itemtype, dateline, expiration, lastbuyer, lastupdate, totalitems, tradesum, closed, aid, displayorder, costprice) VALUES ('$tid', '$pid', '$typeid', '$sellerid', '$seller', '$account', '$subject', '$price', '$amount', '$quality', '$locus', '$transport', '$ordinaryfee', '$expressfee', '$emsfee', '$itemtype', '$dateline', '$expiration', '$lastbuyer', '$lastupdate', '$totalitems', '$tradesum', '$closed', '$aid', '$displayorder', '$costprice');";

			$db['discuz']->query($trade_sql);
			//���뽻�� end

			$first = 1;
			$message = '';
			$attachment = 0;

			$sql = "INSERT INTO {$discuz_tablepre}posts (fid, tid, first, author, authorid, subject, dateline, message, useip, attachment, usesig, bbcodeoff, smileyoff, parseurloff, htmlon, rate, ratetimes, status) ".
			"VALUES ('$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$attachment','$usesig', '$bbcodeoff', '$smileyoff', '$parseurloff', '$htmlon', '$rate', '$ratetimes', '$status')";

			$db['discuz']->query($sql);

			$first = 0;
			$message = $body['body'];
			$attachment = $p['isupload'];
		}
		
		$sql = "INSERT INTO {$discuz_tablepre}posts (fid, tid, first, author, authorid, subject, dateline, message, useip, attachment, usesig, bbcodeoff, smileyoff, parseurloff, htmlon, rate, ratetimes, status) ".
			"VALUES ('$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$attachment','$usesig', '$bbcodeoff', '$smileyoff', '$parseurloff', '$htmlon', '$rate', '$ratetimes', '$status')";

		if($db['discuz']->query($sql)){
			$pid = $db['discuz']->insert_id();
			$db['discuz']->query("UPDATE {$discuz_tablepre}attachments set pid='$pid' WHERE tid='$tid' AND pid='$p[announceid]'");

			$a_rs = $db['discuz']->query("SELECT aid FROM {$discuz_tablepre}attachments WHERE pid='$pid'");
			if (!empty($a_rs)) {
				$row = $db['discuz']->fetch_array($a_rs);
				$aid = $row['aid'];
			}
			$db['discuz']->query("UPDATE {$discuz_tablepre}trades set pid='$pid',aid='$aid' WHERE tid='$tid' AND pid='$p[announceid]'");

			$convertedrows ++;
		} else {
			reportlog("�޷�ת������ subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
		}

		$converted = 1;
		$totalrows ++;
	}
	if($converted || $end < $maxid) {
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid."&tableid=$tableid&dv_posttbl=$dv_posttbl");
	} elseif($tableid < $tablecount) {
		validid('announceid', $tablearray[$tableid], '');
		$end = $start - 1;
		showmessage("���ڴ����� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.($tableid + 1)."&dv_posttbl=$dv_posttbl");
	}

?>