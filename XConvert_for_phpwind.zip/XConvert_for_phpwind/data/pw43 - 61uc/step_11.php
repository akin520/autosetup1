<?php
//����
truncatetable('announcements');

//setnames($source_charset);
$query = $db['source']->query("SELECT * FROM {$source_tablepre}announce ORDER BY aid ASC") or dexit();
while ($a = $db['source']->fetch_array($query)) {
	$a		=	daddslashes($a);

	$author		=	$a['author'];
	$subject	=	cutstr(htmlspecialchars(trim(@strip_tags($a['subject']))), 250);
	$type		=	0;
	$displayorder	=	$a['vieworder'];
	$starttime	=	$a['startdate'];
	$endtime	=	$a['enddate'];
	$message	=	$a['content'];
	$groups		=	'';

	$sql = "INSERT INTO {$discuz_tablepre}announcements (author, subject, type, displayorder, starttime, endtime, message, groups) VALUES ('$author', '$subject', '$type', '$displayorder', '$starttime', '$endtime', '$message', '$groups');";

	if ($db['discuz']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog();
	}
	$totalrows ++;
}
?>