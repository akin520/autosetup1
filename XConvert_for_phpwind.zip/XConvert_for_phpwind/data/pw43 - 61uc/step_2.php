<?php
//��������
if($start <= 1) {
	$query = $db['source']->query("SELECT * FROM {$source_tablepre}credits LIMIT 5") or dexit();
	$i = 4;
	$ce = array();
	while($credit = $db['source']->fetch_array($query)) {
		$extcreditsarray[$i] = array
		(
			'title'	=> htmlspecialchars(stripslashes($credit['name'])),
			'unit' => htmlspecialchars(stripslashes($credit['unit'])),
			'ratio' => 0,
			'available' => 1,
			'lowerlimit' => 0,
			'showinthread' => 0,
			'allowexchangein' => 1,
			'allowexchangeout' => 1
		);
		$ce[$credit[cid]] = $i;
		$i++;
	}
	$extcreditsarray[1] = array
	(
		'title'	=> '����',
		'unit' => '��',
		'ratio' => 0,
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1,
		'allowexchangein' => 1,
		'allowexchangeout' => 1
	);
	$extcreditsarray[2] = array
	(
		'title'	=> '��Ǯ',
		'unit' => 'RMB',
		'ratio' => 0,
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1,
		'allowexchangein' => 1,
		'allowexchangeout' => 1
	);
	$extcreditsarray[3] = array
	(
		'title'	=> '����ֵ',
		'unit' => '��',
		'ratio' => 0,
		'available' => 1,
		'lowerlimit' => 0,
		'showinthread' => 1,
		'allowexchangein' => 1,
		'allowexchangeout' => 1
	);
	$extcredits = addslashes(serialize($extcreditsarray));
	$db['discuz']->query("UPDATE {$discuz_tablepre}settings SET value='$extcredits' WHERE variable='extcredits'");
	$ce = serialize($ce);
}

if($ce) {
	$ce = unserialize($ce);
	$maxuserid = $db['source']->result($db['source']->query("SELECT max(uid) FROM {$source_tablepre}members"), 0);
	if($start < $maxuserid){
		$converted = 1;
	}
	$query = $db['source']->query("SELECT uid FROM {$source_tablepre}members WHERE uid >= $start AND uid < $start + $rpp") or dexit();
	while($user	= $db['source']->fetch_array($query)) {
		$creditquery = $db['source']->query("SELECT * FROM {$source_tablepre}membercredit WHERE uid='$user[uid]'") or dexit();
		$update = $comma = '';
		while($cresit = $db['source']->fetch_array($creditquery)) {
			if(isset($ce[$cresit[cid]])) {
				$update .= $comma.'extcredits'.$ce[$cresit[cid]].'='.$cresit[value];
				$comma = ',';
			}
		}
		if($update) {
			if ($db['discuz']->query("UPDATE {$discuz_tablepre}members SET $update WHERE uid='$user[uid]'")) {
				$convertedrows ++;
			} else {
				reportlog();
			}
			$converted = 1;
			$totalrows ++;
		}
	}
}
?>