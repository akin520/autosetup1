<?php
//ת����
if($start <= 1) {
	truncatetable('threads');
	truncatetable('polls');
	truncatetable('polloptions');
}
$maxtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}threads"), 0);
if($start < $maxtid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}threads WHERE tid >= $start AND tid <$start + $rpp") or dexit();

while ($thread = $db['source']->fetch_array($query)) {

	$thread			=	daddslashes($thread);

	$tid			=	$thread['tid'];
	$fid			=	$thread['fid'];
	$iconid			=	0;
	$typeid			=	$thread['type'];
	$readperm		=	0;
	$price			=	0;
	$author			=	cutstr(htmlspecialchars(trim($thread['author'])), 15);
	$authorid		=	$thread['authorid'];
	$subject		=	formatstr(cutstr(htmlspecialchars(trim(@strip_tags($thread['subject']))), 78));
	$dateline		=	$thread['postdate'] > $timestamp ? $timestamp : $thread['postdate'];
	$lastpost		=	$thread['lastpost'] > $timestamp ? $timestamp : $thread['lastpost'];
	$lastposter		=	cutstr(htmlspecialchars(trim($thread['lastposter'])), 15);
	$views			=	$thread['hits'];
	$replies		=	$thread['replies'];
	$displayorder	=	in_array($thread['topped'],array(0,1,2,3)) ? $thread['topped'] : 0;
	$highlight		=	$thread['titlefont'] ? gethighlightid($thread['titlefont']) : 0;
	$digest			=	in_array($thread['digest'],array(0,1,2,3)) ? $thread['digest'] : 0;
	$rate			=	0;
	
	$special		=	0;
	$attachment		=	$thread['ifupload'] ? 1 : 0;
	$moderated		=	0;
	$closed			=	$thread['locked'] ? 1 : 0;
	$itemid			=	0;
	$supe_pushstatus	=	1;
	$recommends		=	0;
	$recommend_add	=	0;
	$recommend_sub	=	0;
	$heats			=	0;
	$status			=	0;

	if($thread['pollid'] > 0) {
		$query_1 = $db['source']->query("SELECT * FROM {$source_tablepre}polls WHERE pollid='".$thread['pollid']."'");
		$pollresult = $db['source']->fetch_array($query_1);
		$tPolls = unserialize($pollresult['voteopts']);
		if(isset($tPolls['options'])) {
			$special = 1;
			$visible = 1;
			$multiple = $tPolls['multiple'][0];
			$maxchoices = $tPolls['multiple'][1];
			$expiration = 0;
			$db['discuz']->query("INSERT INTO {$discuz_tablepre}polls (tid, multiple, visible, maxchoices, expiration) VALUES('$tid', '$multiple', '$visible', '$maxchoices', '$expiration');");
			foreach ($tPolls['options'] AS $key => $pollopts) {
				$polloption = daddslashes($pollopts[0]);
				$voterids = $comma = '';
				if(is_array($pollopts[2])) {
					foreach($pollopts[2] AS $username) {
						$username = daddslashes($username);
						if($uid = getuid($username)) {
							$voterids .= $comma.$uid;
							$comma = "\t";
						}
					}
				}
				$votes = $pollopts[1];
				$db['discuz']->query("INSERT INTO {$discuz_tablepre}polloptions (tid, votes, polloption, voterids) VALUES('$tid', '$votes', '$polloption', '$voterids');");
			}
		} else {
			$special = 0;
		}
	}


	$sql	=	"INSERT INTO {$discuz_tablepre}threads (tid, fid, iconid, typeid, readperm, price, author, authorid, subject, dateline, lastpost, lastposter, views, replies, displayorder, highlight, digest, rate,special, attachment, moderated, closed, itemid, supe_pushstatus, sgid, recommends, recommend_add, recommend_sub, heats, status) VALUES ('$tid', '$fid', '$iconid', '$typeid', '$readperm', '$price', '$author', '$authorid', '$subject', '$dateline', '$lastpost', '$lastposter', '$views', '$replies', '$displayorder', '$highlight', '$digest', '$rate', '$special', '$attachment', '$moderated', '$closed', '$itemid', '$supe_pushstatus', '$sgid', '$recommends', '$recommend_add', '$recommend_sub', '$heats', '$status');";

	if ($db['discuz']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת������ tid = $tid subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>