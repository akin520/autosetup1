<?php
//����
truncatetable_uc('friends');

$query = $db['source']->query("SELECT * FROM {$source_tablepre}friends ORDER BY uid ASC") or dexit();
while ($friends = $db['source']->fetch_array($query)) {
	$friends		=	daddslashes($friends);
	$uid			=	$friends['uid'];
	$friendid		=	$friends['friendid'];
	$direction		=	0;
	$related		=	0;
	$delstatus		=	0;
	$comment		=	$friends['descrip'];

	$sql = getinsertsql("{$uc_tablepre}friends", array('uid', 'friendid', 'direction', 'version', 'delstatus', 'comment'));

	if ($db['uc']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת����̳�������� uid = $uid friendid = $friendid");
	}
	$totalrows ++;
}
?>