<?php
//������
if($start <= 1 && $tableid == 0) {
	$ttblquery = $db['source']->query("SELECT db_value FROM {$source_tablepre}config WHERE db_name = 'db_tlist'");
	$ttablelist = unserialize($db['source']->result($ttblquery));
	$maxtableid = is_array($ttablelist) ? count($ttablelist) : 0;
}
$tableid = isset($tableid) ? $tableid : 0;
$maxtableid = isset($maxtableid) ? $maxtableid : 0;
$tnum = $tableid == 0 ? '' : $tableid;
$maxtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}tmsgs{$tnum}"), 0);
if($start < $maxtid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}tmsgs{$tnum} m LEFT JOIN {$source_tablepre}threads t ON t.tid = m.tid WHERE m.tid >= $start AND m.tid < $start + $rpp;");
while ($post = $db['source']->fetch_array($query)) {
	$post			=	daddslashes($post);

	$fid			=	$post['fid'];
	$tid			=	$post['tid'];
	$first			=	1;
	$author			=	cutstr(htmlspecialchars(trim($post['author'])), 15);
	$authorid		=	$post['authorid'];
	$subject		=	formatstr(cutstr(htmlspecialchars(trim(@strip_tags($post['subject']))), 78));
	$dateline		=	$post['postdate'];
	if(empty($tid)){
		$converted = 1;
		continue;
	}
	$message		=	convertbbcode($post['content'] ? $post['content'] : htmlspecialchars(trim($post['subject'])));
	$useip			=	$post['userip'];
	$invisible		=	0;
	$usesig			=	$post['ifsign']%2 == 0 ? 0 : 1;
	$htmlon			=	$post['ifsign'] < 2 ? 0 : 1;
	$bbcodeoff		=	0;
	$smileyoff		=	0;
	$parseurloff		=	0;
	$attachment		=	$post['ifupload'] ? 1 : 0;
	$rate			=	0;
	$ratetimes		=	0;
	$anonymous		=	$post['anonymous'];

	$attachs		=	unserialize(stripslashes($post['aid']));

	$sql = "INSERT INTO {$discuz_tablepre}posts (fid, tid, first, author, authorid, subject, dateline, message, useip, invisible, anonymous, usesig, htmlon, bbcodeoff, smileyoff, parseurloff, attachment, rate, ratetimes ) VALUES ('$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$invisible', '$anonymous', '$usesig', '$htmlon', '$bbcodeoff', '$smileyoff', '$parseurloff', '$attachment', '$rate', '$ratetimes');";

	if ($db['discuz']->query($sql)) {
		$pid = $db['discuz']->insert_id();
		if (is_array($attachs)) {
			foreach ($attachs as $at) {
				$aid		=	$resetaid ? '' : $at['aid'];
				$readperm	=	0;
				$filename	=	cutstr(htmlspecialchars(trim($at['name'])), 100);
				$description	=	cutstr(htmlspecialchars(trim($at['desc'])), 100);
				$filetype	=	getfiletype($at['name']);
				$filesize	=	intval($at['size']) * 1024;
				$attachment	=	$source_name ? $source_name.'/'.$at['attachurl'] : $at['attachurl'];
				$downloads	=	$at['hits'];
				$isimage	=	in_array($filetype, array('image/pjpeg', 'image/gif', 'image/bmp', 'image/png')) ? 1 : 0;
				$uid		=	$authorid;
				$atsql		=	"INSERT INTO {$discuz_tablepre}attachments (aid, tid, pid, dateline, readperm, filename, description, filetype, filesize, attachment, downloads, isimage, uid) VALUES ('$aid', '$tid', '$pid', '$dateline', '$readperm', '$filename', '$description', '$filetype', '$filesize', '$attachment', '$downloads', '$isimage', '$uid');";
				if ($db['discuz']->query($atsql)) {
					if ($resetaid) {
						$newaid = $db['discuz']->insert_id();
						$db['discuz']->query("UPDATE {$discuz_tablepre}posts SET message = replace(message, '[attach]".$at['aid']."[/attach]', '[attach]".$newaid."[/attach]') WHERE pid = '$pid'");
					}
				}
			}
		}
		$convertedrows ++;
	} else {
		reportlog();
	}
	$converted = 1;
	$totalrows ++;
}
if($converted || $end < $maxid) {
	$nowtableid = $tableid + 1;
	showmessage("���ڴ����� $nowtableid �ֱ��ĵ� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.$tableid.'&maxtableid='.$maxtableid);
} elseif($tableid < $maxtableid) {
        $nextid = $tableid + 1;
	$nexttableid = $tableid + 2;
        unset($start);
        unset($end);
	showmessage("�� $nextid �ֱ����ݴ������, ��������� $nexttableid �ֱ���ת��", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.$nextid.'&maxtableid='.$maxtableid);
}
?>