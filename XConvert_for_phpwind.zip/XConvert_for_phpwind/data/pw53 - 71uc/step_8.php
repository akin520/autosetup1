<?php
//����Ϣ
if($start <= 1) {
	truncatetable_uc('pms');
}
$maxmid = $db['source']->result($db['source']->query("SELECT max(mid) FROM {$source_tablepre}msg"), 0);
if($start < $maxmid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}msg WHERE mid >= $start AND mid < $start + $rpp") or dexit();
while ($pms = $db['source']->fetch_array($query)) {

	$pms		=	array_change_key_case(daddslashes($pms));

	$msgfrom	=	$pms['username'];
	$msgfromid	=	$pms['fromuid'];
	$msgtoid	=	$pms['touid'];
	$folder		=	$pms['type'] == 'rebox' ? 'inbox' : 'outbox';
	$new		=	$pms['ifnew'];
	$subject	=	formatstr(cutstr(htmlspecialchars(trim(@strip_tags($pms['title']))), 70));
	$dateline	=	$pms['mdate'];
	$dateline	=	$dateline > $timestamp ? $timestamp : $dateline;
	$message	=	@strip_tags(trim($pms['content']));
	$delstatus	=	0;
	$related	=	0;
	$fromappid	=	1;
	
	
	if($msgfromid && $msgtoid){
		$checkfirstsql_1 = "SELECT count(*) FROM {$uc_tablepre}pms WHERE msgfromid='$msgfromid' AND msgtoid='$msgtoid' AND related='0'";
		$is_first_1 = $db['uc']->result($db['uc']->query($checkfirstsql_1), 0);

		$checkfirstsql_2 = "SELECT count(*) FROM {$uc_tablepre}pms WHERE msgfromid='$msgtoid' AND msgtoid='$msgfromid' AND related='0'";
		$is_first_2 = $db['uc']->result($db['uc']->query($checkfirstsql_2), 0);

		if(!$is_first_1 || !$is_first_2){
			if(!$is_first_1){
				$db['uc']->query("INSERT INTO {$uc_tablepre}pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus, related, fromappid) VALUES ('$msgfrom', '$msgfromid', '$msgtoid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus', '$related', '$fromappid')");
			}
			if(!$is_first_2){
				$db['uc']->query("INSERT INTO {$uc_tablepre}pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus, related, fromappid) VALUES ('$msgfrom', '$msgtoid', '$msgfromid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus', '$related', '$fromappid')");
			}
		}else{
			$db['uc']->query("UPDATE {$uc_tablepre}pms SET subject='$subject', dateline='$dateline' AND message='$message' WHERE msgfrom='$msgfromid' AND msgtoid='$msgtoid' AND related='0'");
		}
		$related	=	1;
	}elseif($msgfromid && !$msgtoid){
		$converted = 1;
		$totalrows ++;
		continue;
	}

	$fields = array('msgfrom','msgfromid','msgtoid','folder','new','subject','dateline','message','delstatus','related','fromappid');
	$sql = getinsertsql("{$uc_tablepre}pms", $fields);

	if ($db['uc']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת������Ϣ $subject");
	}
	$converted = 1;
	$totalrows ++;
}
?>