<?php
//ת���
truncatetable('forums');
truncatetable('forumfields');
truncatetable('moderators');

$query = $db['source']->query("SELECT f.*, fd.* FROM {$source_tablepre}forums f
			LEFT JOIN {$source_tablepre}forumdata fd ON f.fid=fd.fid 
			ORDER BY f.fid ASC") or dexit();

while($forum = $db['source']->fetch_array($query)) {
	$forum = daddslashes($forum);
	switch(strtolower($forum['type'])) {
		case 'category':
			$forum['type']	=	'group';
			break;
		case 'forum':
			$forum['type']	=	'forum';
			break;
		case 'sub':
			$forum['type']	=	'sub';
			break;
		default:
			$forum['type']	=	'forum';
			break;
	}
	if($forum['type'] == 'sub' && $db['source']->result($db['source']->query("SELECT type FROM {$source_tablepre}forums WHERE fid='$forum[fup]'")) == 'sub') {
		$forum['type'] = 'forum';
		$forum['fup'] = 0;
	}

	$fid				=	$forum['fid'];
	$fup				=	$forum['fup'];
	$type				=	$forum['type'];
	$name				=	cutstr(htmlspecialchars(trim(@strip_tags($forum['name']))), 50);
	$status				=	1;
	$displayorder			=	$forum['vieworder'];
	$styleid			=	0;
	$threads			=	$type != 'group' ? $forum['topic'] : 0;
	$posts				=	$type != 'group' ? $forum['article'] : 0;
	$todayposts			=	0;
	$lastpost			=	0;
	$allowsmilies			=	$type != 'group' ? 1 : 0;
	$allowhtml			=	0;
	$allowbbcode			=	$allowsmilies;
	$allowimgcode			=	$allowsmilies;
	$allowshare			=	$allowsmilies;
	$allowpostspecial		=	$type != 'group' ? 15 : 0;
	$alloweditrules			=	0;
	$recyclebin			=	0;
	$modnewposts			=	0;
	$jammer				=	0;
	$disablewatermark		=	0;
	$inheritedmod			=	0;
	$autoclose			=	0;
	$alloweditpost			=	1;
	$simple				=	$forum['childid'] ? $forum['viewsub'] : 0;
	$allowspecialonly		=	0;

	$description			=	$forum['descrip'];
	$password			=	'';
	$icon				=	$forum['logo'];
	$postcredits			=	'';
	$replycredits			=	'';
	$redirect			=	'';
	$attachextensions		=	'';
	$moderators			=	addmoderators(explode(',', $forum['forumadmin']), $fid);
	$rules				=	'';
	$threadtypes			=	'';
	$viewperm			=	'';
	$postperm			=	'';
	$replyperm			=	'';
	$getattachperm			=	'';
	$postattachperm			=	'';
	$threadplugin		=	'';
	$extra				=	'';

	$query1	=	"INSERT INTO {$discuz_tablepre}forums ( fid, fup, type, name, status, displayorder, styleid, threads, posts, todayposts, lastpost, allowsmilies, allowhtml, allowbbcode, allowimgcode, allowshare, allowpostspecial, allowspecialonly, alloweditrules, recyclebin, modnewposts, jammer, disablewatermark, inheritedmod, autoclose, alloweditpost, simple) VALUES ('$fid', '$fup', '$type', '$name', '$status', '$displayorder', '$styleid', '$threads', '$posts', '$todayposts', '$lastpost', '$allowsmilies', '$allowhtml', '$allowbbcode', '$allowimgcode', '$allowshare', '$allowpostspecial', '$allowspecialonly', '$alloweditrules', '$recyclebin', '$modnewposts', '$jammer', '$disablewatermark', '$inheritedmod', '$autoclose', 'alloweditpost', '$simple');";

	$query2	=	"INSERT INTO {$discuz_tablepre}forumfields ( fid, description, password, icon, postcredits, replycredits, redirect, attachextensions, moderators, rules, threadtypes, viewperm, postperm, replyperm, getattachperm, postattachperm, threadplugin, extra) VALUES ('$fid', '$description', '$password', '$icon', '$postcredits', '$replycredits', '$redirect', '$attachextensions', '$moderators', '$rules', '$threadtypes', '$viewperm', '$postperm', '$replyperm', '$getattachperm', '$postattachperm', '$threadplugin', '$extra');";

	$query3	=	"DELETE FROM {$discuz_tablepre}moderators WHERE fid='$fid';";

	if ($db['discuz']->query($query1)) {
		if ($db['discuz']->query($query2)) {
			$convertedrows ++;
		} else {
			$db['discuz']->query($query3);
			$db['discuz']->query("DELETE FROM {$discuz_tablepre}forumfields WHERE fid='$fid' LIMIT 1;");
			reportlog("���������չ��Ϣ���ݳ��� fid = $fid name = $name");
		}
	} else {
		$db['discuz']->query($query3);
		reportlog("��������������ݳ��� fid = $fid name = $name");
	}
	$totalrows ++;
}
?>