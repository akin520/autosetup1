<?php
//�������
truncatetable('threadtypes');
$query = $db['source']->query("SELECT fid, t_type FROM {$source_tablepre}forums WHERE t_type != '' ORDER BY fid ASC") or dexit();

while($forum = $db['source']->fetch_array($query)) {

	$forum			=	daddslashes($forum);

	$fid = $forum['fid'];
	$tmp = explode("\t", $forum['t_type']);
	array_shift($tmp);
	$typearray = array();
	$types = array();
	foreach($tmp AS $k => $v) {
		if(!empty($v)) {
			$typearray[$k + 1] = $v;
		}
	}
	if(count($typearray)) {
		foreach($typearray AS $typeid => $typename) {
			$typename = trim($typename);
			if($typename) {
				$db['discuz']->query("INSERT INTO {$discuz_tablepre}threadtypes (name) VALUES ('$typename')");
				$threadtypeid = mysql_insert_id();
				$types[$threadtypeid] = $typename;
				$db['discuz']->query("UPDATE {$discuz_tablepre}threads SET typeid='$threadtypeid' WHERE fid='$fid' AND typeid='$typeid'");
				$convertedrows ++;
				$totalrows ++;
			}
		}
		$threadtypes = daddslashes(serialize(array
		(
		'status' => 1,
		'required' => 1,
		'listable' => 1,
		'prefix' => 1,
		'types' => $types,
		'flat' => $types
		)));
		$db['discuz']->query("UPDATE {$discuz_tablepre}forumfields SET threadtypes='$threadtypes' WHERE fid='$fid'");
	}

}

?>