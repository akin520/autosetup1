<?php
//�ղؼ�
if($start <= 1) {
	truncatetable('favorites');
}
$maxuid = $db['source']->result($db['source']->query("SELECT max(uid) FROM {$source_tablepre}favors"), 0);
if($start < $maxuid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}favors WHERE uid >= $start AND uid < $start + $rpp") or dexit();
while ($favorite = $db['source']->fetch_array($query)) {

	$favorite	=	daddslashes($favorite);

	$uid		=	$favorite['uid'];
	$tids		=	explode(',', $favorite['tids']);

	$sql = "INSERT INTO {$discuz_tablepre}favorites ( uid , tid) VALUES ";
	$sqladd = $comma = '';
	foreach($tids AS $tid) {
		$tid = intval($tid);
		if($tid) {
			$sqladd .= "$comma ('$uid', '$tid')";
			$comma = ',';
		}
	}

	if(!$sqladd) {
		continue;
	} else {
		$sql = $sql.$sqladd;
	}

	if ($db['discuz']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog();
	}
	$converted = 1;
	$totalrows ++;
}
?>