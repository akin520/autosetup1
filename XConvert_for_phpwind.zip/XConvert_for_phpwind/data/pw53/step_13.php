<?php
//����
truncatetable('buddys');

$query = $db['source']->query("SELECT * FROM {$source_tablepre}friends ORDER BY uid ASC") or dexit();
while ($buddys = $db['source']->fetch_array($query)) {
	$uid			=	$buddys['uid'];
	$buddyid		=	$buddys['friendid'];
	$dateline		=	$buddys['joindate'];
	$description		=	$buddys['descrip'];

	$sql	=	"INSERT INTO {$discuz_tablepre}buddys (uid, buddyid, dateline, description) VALUES ('$uid', '$buddyid', '$dateline', '$description');";

	if ($db['discuz']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog();
	}
	$totalrows ++;
}
?>