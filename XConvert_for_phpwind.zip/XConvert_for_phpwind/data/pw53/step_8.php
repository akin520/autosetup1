<?php
//����Ϣ
if($start <= 1) {
	truncatetable('pms');
}
$maxmid = $db['source']->result($db['source']->query("SELECT max(mid) FROM {$source_tablepre}msg"), 0);
if($start < $maxmid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}msg WHERE mid >= $start AND mid < $start + $rpp") or dexit();
while ($pm = $db['source']->fetch_array($query)) {

	$pm		=	daddslashes($pm);

	$msgfrom	=	$pm['username'];
	$msgfromid	=	$pm['fromuid'];
	$msgtoid	=	$pm['touid'];
	$folder		=	$pm['type'] == 'rebox' ? 'inbox' : 'outbox';
	$new		=	$pm['ifnew'];
	$subject	=	cutstr(htmlspecialchars(trim(@strip_tags($pm['title']))), 78);
	$dateline	=	$pm['mdate'];
	$message	=	$pm['content'];

	$sql		=	"INSERT INTO {$discuz_tablepre}pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message) VALUES ('$msgfrom', '$msgfromid', '$msgtoid', '$folder', '$new', '$subject', '$dateline', '$message');";


	if ($db['discuz']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog();
	}
	$converted = 1;
	$totalrows ++;
}
?>