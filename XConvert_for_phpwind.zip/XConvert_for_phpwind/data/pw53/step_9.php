<?php
//������̳
truncatetable('forumlinks');
$query = $db['source']->query("SELECT * FROM {$source_tablepre}sharelinks ORDER BY sid ASC") or dexit();
while ($forumlink = $db['source']->fetch_array($query)) {
	$forumlink		=	daddslashes($forumlink);

	$displayorder		=	$forumlink['threadorder'];
	$name			=	cutstr(htmlspecialchars(@strip_tags(trim($forumlink['name']))), 98);
	$url			=	$forumlink['url'];
	$logo			=	$forumlink['logo'];

	$sql	=	"INSERT INTO {$discuz_tablepre}forumlinks (displayorder, name, url, logo) VALUES ('$displayorder', '$name', '$url', '$logo');";

	if ($db['discuz']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog();
	}
	$totalrows ++;
}
?>