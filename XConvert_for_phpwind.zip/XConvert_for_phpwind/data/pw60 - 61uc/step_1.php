<?php
if($start <= 1) {
	truncatetable('members');
	truncatetable('memberfields');
	truncatetable_uc('members');
	truncatetable_uc('memberfields');
	truncatetable('onlinetime');
	ctspecialgroup("{$source_tablepre}usergroups", "$discuz_tablepre");
	addmedals();
}
$maxuserid = $db['source']->result($db['source']->query("SELECT max(uid) FROM {$source_tablepre}members"), 0);
if($start < $maxuserid){
	$converted = 1;
}
$query = $db['source']->query("SELECT m.*, m.uid as muid, md.*, g.gid, g.gptype, g.grouptitle FROM {$source_tablepre}members m LEFT JOIN {$source_tablepre}memberdata md ON md.uid=m.uid LEFT JOIN {$source_tablepre}usergroups g ON g.gid=m.groupid WHERE m.uid>=$start AND m.uid<$start+$rpp") or dexit();
while($user = $db['source']->fetch_array($query)) {
	
	$user =	array_change_key_case($user);
	$uid = $user['muid'];
	$username = trim($user['username']);

	if(!$username || $username != htmlspecialchars(daddslashes($username))) {
		reportlog("�Ƿ��û��� <b><font color='red'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
	} elseif(strlen($username) > 15) {
		reportlog("�û��� <b><font color='orange'>$username</font></b> ���ȴ��� 15�����ܱ�ת����uid = $uid ��<br>\r\n");
	} elseif(getuid($username)) {
			reportlog("�ظ��û��� <b><font color='blue'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
	} else {

		$user = daddslashes($user);

		$visitip		=	explode('|',$user['onlineip']);

		//uc members
			$ucpw		=	convertucpw($user['password']);
		$password		=	$ucpw['password'];
		$email			=	cutstr($user['email'], 32);
		$myid			=	'';
		$myidkey		=	'';
		$regip			=	substr($visitip[0], -1) == '*' ? trim(substr($visitip[0], 0, -1)) : $visitip[0];
		$regdate		=	$user['regdate'];
		$lastloginip	=	$regip;
		$lastlogintime	=	$visitip[1] ? $visitip[1] : ($user['lastvisit'] ? $user['lastvisit'] : $timestamp);
		$salt			=	$ucpw['salt'];

		//uc memberfields
		$blacklist		=	'';

		//dz members
		//$password		=	$user['password'];
		$secques		=	'';
		$gender			=	$user['gender'];
		if($user['groupid'] == 3) {
			$adminid	=	$groupid = 1;
		} elseif($user['groupid'] == 4) {
			$adminid	=	$groupid = 2;
		} elseif($user['groupid'] == 5) {
			$adminid	=	$groupid = 3;
		} elseif($user['groupid'] == 6) {
			$adminid	=	-1;
			$groupid	=	4;
		} elseif($user['groupid'] == 7) {
			$adminid	=	0;
			$groupid	=	8;
		} elseif($user['gptype'] == 'special' || $user['gptype'] == 'system') {
			$adminid	=	0;
			$groupid	=	$user['groupid'] + 15;
		} else {
			$adminid	=	0;
			$groupid	=	10;
		}
		$groupexpiry	=	0;
		$extgroupids	=	'';
		$regip			=	substr($visitip[0], -1) == '*' ? trim(substr($visitip[0], 0, -1)) : $visitip[0];
		$regdate		=	$user['regdate'];
		$lastip			=	$regip;
		$lastvisit		=	$visitip[1] ? $visitip[1] : ($user['lastvisit'] ? $user['lastvisit'] : $timestamp);
		$lastactivity	=	$user['thisvisit'];
		$lastpost		=	$user['lastpost'];
		$posts			=	$user['postnum'];
		$digestposts	=	$user['digests'];
		$oltime			=	$user['onlinetime'] < 0 ? 0 : round($user['onlinetime'] / 3600);
		$thismonth		=	$user['monoltime'] < 0 ? 0 : round($user['monoltime'] / 60);
		$pageviews		=	$posts;
		$credits		=	(isset($user['rvrc']) && $user['rvrc']) ? floor($user['rvrc']/10) : 0;
		$extcredits1	=	$credits;
		$extcredits2	=	(isset($user['money']) && $user['money']) ? $user['money'] : 0;
		$extcredits3	=	$user['credit'];	//����ֵ
		$extcredits4	=	0;
		$extcredits5	=	0;
		$extcredits6	=	0;
		$extcredits7	=	0;
		$extcredits8	=	0;
		$email			=	cutstr($user['email'], 40);
		$bday			=	$user['bday'];
			$signature	=	$user['signature'] ? @strip_tags($user['signature']) : '';
		$sigstatus		=	$signature ? 1 : 0;
		$tpp			=	0;
		$ppp			=	0;
		$styleid		=	0;
		$dateformat		=	0;
		$timeformat		=	0;
		$pmsound		=	0;
		$showemail		=	1;
		$newsletter		=	1;
		$invisible		=	0;
		$timeoffset		=	'9999';
		$newpm			=	0;
		$accessmasks	=	0;
		$editormode		=	2;
		$customshow		=	26;
		$xspacestatus	=	0;

		//dz memberfields
		$nickname		=	'';
		$site			=	parsesite($user['site']);
		$alipay			=	'';
		$icq			=	parseqqicq($user['icq']);
		$qq				=	parseqqicq($user['oicq']);
		$yahoo			=	$user['yahoo'] ? htmlspecialchars(cutstr($user['yahoo'], 40)) : '';
		$msn			=	$user['msn'] ? htmlspecialchars(cutstr($user['msn'], 40)) : '';
		$taobao			=	'';
		$location		=	$user['location'] ? cutstr(htmlspecialchars(trim(@strip_tags($user['location']))), 30) : '';
		$customstatus	=	$user['honor'] ? cutstr(htmlspecialchars(trim(@strip_tags($user['honor']))), 30) : '';

		$medalcomma = $medals = $mdvar = '';
		if ($user['medals']) {
			$medalarray	=	explode(',', $user['medals']);
			foreach($medalarray as $mdvar) {
				$medals	.=	$medalcomma.(intval($mdvar) + 10);
				$medalcomma	= "\t";
			}
		}

		$avatarinfo	= explode('|', $user['icon']);
		($avatarinfo[1] !=2 && $avatarinfo[1] != 3) && $avatarinfo[1] = 1;
		if($avatarinfo[1] == 2 || $avatarinfo[1] == 3) {
			$avatar			=	$avatarinfo[1] == 2 ? $avatarinfo[0] : 'customavatars/upload/'.$avatarinfo[0];
			$avatarwidth	=	$avatarinfo[2] > 0 && $avatarinfo[2] < 120 ? $avatarinfo[2] : 82;
			$avatarheight	=	$avatarinfo[3] > 0 && $avatarinfo[3] < 120 ? $avatarinfo[3] : 90;
		} elseif($avatarinfo[1] == 1 && $avatarinfo[0]) {
			$avatar			=	'images/avatars/face/'.$avatarinfo[0];
			$avatarwidth	=	82;
			$avatarheight	=	90;
		} else {
			$avatar			=	'';
			$avatarwidth	= $avatarheight = 0;
		}

		$bio			=	$user['introduce'] ? @strip_tags($user['introduce']) : '';
		$sightml		=	parsesign($user['signature']);
		$ignorepm		=	'';
		$groupterms		=	'';
		$authstr		=	'';
		$spacename		=	'';
		$buyercredit	=	'';
		$sellercredit	=	'';

		$total			= $oltime * 60;
		$lastupdate		= time();

		$fields1 = array('uid', 'username', 'password', 'email', 'myid', 'myidkey', 'regip', 'regdate', 'lastloginip', 'lastlogintime', 'salt');
		$query1 = getinsertsql("{$uc_tablepre}members", $fields1);

		$fields2 = array('uid', 'blacklist');
		$query2 = getinsertsql("{$uc_tablepre}memberfields", $fields2);

		$fields3 = array('uid', 'username', 'password', 'secques', 'gender', 'adminid', 'groupid', 'groupexpiry', 'extgroupids', 'regip', 'regdate', 'lastip', 'lastvisit', 'lastactivity', 'lastpost', 'posts', 'digestposts', 'oltime', 'pageviews', 'credits', 'extcredits1', 'extcredits2', 'extcredits3', 'extcredits4', 'extcredits5', 'extcredits6', 'extcredits7', 'extcredits8', 'email', 'bday', 'sigstatus', 'tpp', 'ppp', 'styleid', 'dateformat', 'timeformat', 'pmsound', 'showemail', 'newsletter', 'invisible', 'timeoffset', 'newpm', 'accessmasks', 'editormode', 'customshow', 'xspacestatus');
		$query3 = getinsertsql("{$discuz_tablepre}members", $fields3);

		$fields4 = array('uid','nickname','site','alipay','icq','qq','yahoo','msn','taobao','location','customstatus','medals','avatar','avatarwidth','avatarheight','bio','sightml','ignorepm','groupterms','authstr','spacename','buyercredit','sellercredit');
		$query4 = getinsertsql("{$discuz_tablepre}memberfields", $fields4);

		$fields5 	= array('uid', 'thismonth', 'total', 'lastupdate');
		$query5 	= getinsertsql("{$discuz_tablepre}onlinetime", $fields5);

		if ($db['uc']->query($query1)) {
			if ($db['uc']->query($query2)) {
				$password = strtolower($user['password']);
				if ($db['discuz']->query($query3)) {
					if ($db['discuz']->query($query4)) {
						if($db['discuz']->query($query5)) {
							$convertedrows ++;
						} else {
							$convertedrows ++;
							reportlog("���� DZ ��Ա����ʱ�����ݳ��� uid = $uid username = $username");
						}
					} else {
						$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
						$db['uc']->query("DELETE FROM {$uc_tablepre}memberfields WHERE uid='$uid' LIMIT 1;");
						$db['discuz']->query("DELETE FROM {$discuz_tablepre}members WHERE uid='$uid' LIMIT 1;");
						reportlog("���� DZ ��Ա��չ��Ϣ���ݳ��� uid = $uid username = $username");
					}
				} else {
					$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
					$db['uc']->query("DELETE FROM {$uc_tablepre}memberfields WHERE uid='$uid' LIMIT 1;");
					reportlog("���� DZ ��Ա�������ݳ��� uid = $uid username = $username");
				}
			} else {
				$db['uc']->query("DELETE FROM {$uc_tablepre}members WHERE uid='$uid' LIMIT 1;");
				reportlog("���� UC ��Ա��չ��Ϣ���ݳ��� uid = $uid username = $username");
			}
		} else {
			reportlog("�� UC �����Ա�������ݳ��� uid = $uid username = $username");
		}
	}
	$converted = 1;
	$totalrows ++;
}

if($converted) {
	altertable('members', 'uid');
	altertable('memberfields', 'uid');
	altertable_uc('members', 'uid');
	altertable_uc('memberfields', 'uid');
}
?>