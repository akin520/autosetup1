<?php
//��������

if($start <= 1) {
	truncatetable('debates');
	truncatetable('debateposts');
	$tids = $comma = '';
	$query = $db['discuz']->query("SELECT tid FROM {$discuz_tablepre}threads WHERE special='5'");
	while($thread = $db['discuz']->fetch_array($query)) {
		$tids .= $comma."'$thread[tid]'";
		$comma = ', ';
	}
	$tids = $tids ? $tids : "''";
	$db['discuz']->query("DELETE FROM {$discuz_tablepre}threads WHERE special='5'");
	$db['discuz']->query("DELETE FROM {$discuz_tablepre}posts WHERE tid IN($tids)");
}

$fid = $db['discuz']->result($db['discuz']->query("SELECT MIN(fid) FROM {$discuz_tablepre}forums WHERE type ='forum'"), 0);

$query = $db['source']->query("SELECT * FROM {$source_tablepre}debatethreads LIMIT $limit_start, $rpp") or dexit();
while($debate = $db['source']->fetch_array($query)) {

	$totalrows ++;
	$did = $debate['did'];
	$readperm = 0;
	$price = 0;
	$iconid = 0;
	$typeid = 0;
	$author = addslashes($debate['author']);
	$authorid = $debate['authorid'];
	$subject = addslashes($debate['title']);
	$dateline = $debate['dateline'];
	$lastpost = $debate['dateline'];
	$lastposter = addslashes($debate['author']);
	$displayorder = $debate['isvisible'] ? 0 : -2;
	$digest = 0;
	$special = 5;
	$attachment = 0;
	$subscribed = 0;
	$moderated = 0;
	$supe_pushstatus = 0;
	$views = $debate['views'];
	$replies = $db['source']->result($db['source']->query("SELECT COUNT(*) FROM {$source_tablepre}debatereplys WHERE did='$did'"), 0);

	$db['discuz']->query("INSERT INTO {$discuz_tablepre}threads (fid, readperm, price, iconid, typeid, author, authorid, subject, dateline, lastpost, lastposter, displayorder, digest, special, attachment, subscribed, moderated, supe_pushstatus, views, replies)
		VALUES ('$fid', '$readperm', '$price', '$iconid', '$typeid', '$author', '$authorid', '$subject', '$dateline', '$lastpost', '$lastposter', '$displayorder', '$digest', '$special', '$attachment', '$subscribed', '$moderated', '$supe_pushstatus', '$views', '$replies')");

	$tid = $db['discuz']->insert_id();
	$uid = $authorid;
	$starttime = $debate['dateline'];
	$endtime = $debate['endtime'];
	$affirmdebaters = $db['source']->result($db['source']->query("SELECT COUNT(DISTINCT authorid) FROM {$source_tablepre}debatereplys WHERE did='$did' AND debatetype='1'"), 0);
	$negadebaters = $db['source']->result($db['source']->query("SELECT COUNT(DISTINCT authorid) FROM {$source_tablepre}debatereplys WHERE did='$did' AND debatetype='2'"), 0);
	$affirmvotes = $debate['obvote'];
	$negavotes = $debate['revote'];
	$umpire = addslashes($debate['judgment']);
	$winner = $debat['judg'] == '������ʤ' ? 1 : ($debat['judg'] == '������ʤ' ?  2: 3);
	$bestdebater = '';
	$affirmpoint = addslashes($debate['obtitle']);
	$negapoint = addslashes($debate['retitle']);
	$umpirepoint = addslashes($debate['judgcontent']);

	$affirmvoterids = $negavoterids = '';
	$affirmids = $negaids = array();
	$affirmquery = $db['source']->query("SELECT DISTINCT authorid FROM {$source_tablepre}debatereplys WHERE did='$did' AND debatetype='1'");
	while($affirm = $db['source']->fetch_array($affirmquery)) {
		$affirmids[] = $affirm['authorid'];
	}
	$voteuid = explode(',', $debate['voteuid']);
	$negaids = array_diff($voteuid, $affirmids);
	$affirmvoterids = implode("\t", $affirmids);
	$negavoterids = implode("\t", $negaids);

	$affirmreplies = $db['source']->result($db['source']->query("SELECT COUNT(*) FROM {$source_tablepre}debatereplys WHERE did='$did' AND debatetype='1'"), 0);
	$negareplies = $db['source']->result($db['source']->query("SELECT COUNT(*) FROM {$source_tablepre}debatereplys WHERE did='$did' AND debatetype='2'"), 0);

	$db['discuz']->query("INSERT INTO {$discuz_tablepre}debates (tid, uid, starttime, endtime, affirmdebaters, negadebaters, affirmvotes, negavotes, umpire, winner, bestdebater, affirmpoint, negapoint, umpirepoint, affirmvoterids, negavoterids, affirmreplies, negareplies)
			VALUES ('$tid', '$uid', '$starttime', '$endtime', '$affirmdebaters', '$negadebaters', '$affirmvotes', '$negavotes', '$umpire', '$winner', '$bestdebater', '$affirmpoint', '$negapoint', '$umpirepoint', '$affirmvoterids', '$negavoterids', '$affirmreplies', '$negareplies')");

	$first = 1;
	$message = addslashes($debate['content']);
	$useip = $debate['ip'];
	$invisible = $displayorder;
	$anonymous = 0;
	$usesig = 0;
	$htmlon = 0;
	$bbcodeoff = -1;
	$smileyoff = -1;
	$parseurloff = 0;


	$db['discuz']->query("INSERT INTO {$discuz_tablepre}posts (fid, tid, first, author, authorid, subject, dateline, message, useip, invisible, anonymous, usesig, htmlon, bbcodeoff, smileyoff, parseurloff, attachment)
		VALUES ('$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$invisible', '$anonymous', '$usesig', '$htmlon', '$bbcodeoff', '$smileyoff', '$parseurloff', '$attachment')");
	$pid = $db['discuz']->insert_id();

	$postquery = $db['source']->query("SELECT * FROM {$source_tablepre}debatereplys WHERE did='$did'");
	while($post = $db['source']->fetch_array($postquery)) {

		$first = 0;
		$author = addslashes($post['author']);
		$authorid = $post['authorid'];
		$subject = addslashes($post['title']);
		$dateline = $debate['dateline'];
		$message = addslashes($post['content']);
		$useip = $post['ip'];
		$invisible = $displayorder;

		$db['discuz']->query("INSERT INTO {$discuz_tablepre}posts (fid, tid, first, author, authorid, subject, dateline, message, useip, invisible, anonymous, usesig, htmlon, bbcodeoff, smileyoff, parseurloff, attachment)
		VALUES ('$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$invisible', '$anonymous', '$usesig', '$htmlon', '$bbcodeoff', '$smileyoff', '$parseurloff', '$attachment')");

		$stand = $post['debatetype'] == 3 ?  0 : $post['debatetype'];
		$uid = $authorid;
		$voters = $post['vote'];
		$voterids = '';
		$pid = $db['discuz']->insert_id();

		$db['discuz']->query("INSERT INTO {$discuz_tablepre}debateposts (pid, tid, stand, uid, dateline, voters, voterids)
		VALUES ('$pid', '$tid', '$stand', '$uid', '$dateline', '$voters', '$voterids')");
	}
	$convertedrows ++;
}
?>