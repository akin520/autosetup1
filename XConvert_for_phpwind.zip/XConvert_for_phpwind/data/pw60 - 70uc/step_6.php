<?php
//�ظ���
if($start <= 1 && $tableid == 0) {
	truncatetable('posts');
	truncatetable('attachments');
	$ptblquery = $db['source']->query("SELECT db_value FROM {$source_tablepre}config WHERE db_name = 'db_plist'");
	$tablelist = ','.$db['source']->result($ptblquery);
	$maxtableid = substr($tablelist, (strrpos($tablelist, ',') + 1));
}
$tableid = isset($tableid) ? $tableid : 0;
$maxtableid = isset($maxtableid) ? $maxtableid : 0;
$tnum = $tableid == 0 ? '' : $tableid;
$maxpid = $db['source']->result($db['source']->query("SELECT max(pid) FROM {$source_tablepre}posts{$tnum}"), 0);
if($start <= $maxpid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}posts{$tnum} WHERE pid >= $start AND pid < $start + $rpp;") or dexit();
while ($post = $db['source']->fetch_array($query)) {

	$post			=	daddslashes($post);

	$pid			=	$post['pid'];
	$fid			=	$post['fid'];
	$tid			=	$post['tid'];
	$first			=	0;
	$author			=	cutstr(htmlspecialchars(trim($post['author'])), 15);
	$authorid		=	$post['authorid'];
	$subject		=	
	formatstr(cutstr(htmlspecialchars(trim(@strip_tags($post['subject']))), 78));

	if($post['ifreward'] == 2) {
		$query_s	= 	$db['source']->query("SELECT postdate FROM {$source_tablepre}threads WHERE tid='$tid'");
		$threaddate	= 	$db['source']->result($query_s, 0);
		$dateline 	=	$threaddate + 1;
	} else {
		$dateline	=	$post['postdate'];
	}
	$message		=	convertbbcode($post['content']);
	$useip			=	$post['userip'];
	$invisible		=	0;
	$usesig			=	$post['ifsign']%2 == 0 ? 0 : 1;
	$htmlon			=	$post['ifsign'] < 2 ? 0 : 1;
	$bbcodeoff		=	0;
	$smileyoff		=	0;
	$parseurloff		=	0;
	$status			=	$post['ifshield'];
	$rate			=	0;
	$ratetimes		=	0;
	$anonymous		=	$post['anonymous'];

	$attachs		=	unserialize(stripslashes($post['aid']));
	$attachment		=	is_array($attachs) ? 1 : 0;

	$sql	=	"INSERT INTO {$discuz_tablepre}posts (pid, fid, tid, first, author, authorid, subject, dateline, message, useip, invisible, anonymous, usesig, htmlon, bbcodeoff, smileyoff, parseurloff, attachment, rate, ratetimes, status) VALUES ('$pid', '$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$invisible', '$anonymous', '$usesig', '$htmlon', '$bbcodeoff', '$smileyoff', '$parseurloff', '$attachment', '$rate', '$ratetimes', '$status');";

	if ($db['discuz']->query($sql)) {
		if (is_array($attachs)) {
			foreach ($attachs as $at) {
				$aid		=	$resetaid ? '' : $at['aid'];
				$readperm	=	0;
				$filename	=	cutstr(htmlspecialchars(trim($at['name'])), 100);
				$description	=	cutstr(htmlspecialchars(trim($at['desc'])), 100);
				$filetype	=	getfiletype($at['name']);
				$filesize	=	intval($at['size']) * 1024;
				$attachment	=	$source_name ? $source_name.'/'.$at['attachurl'] : $at['attachurl'];
				$downloads	=	$at['hits'];
				$isimage	=	in_array($filetype, array('image/pjpeg', 'image/gif', 'image/bmp', 'image/png')) ? 1 : 0;
				$uid		=	$authorid;
				$atsql		=	"INSERT INTO {$discuz_tablepre}attachments (aid, tid, pid, dateline, readperm, filename, description, filetype, filesize, attachment, downloads, isimage, uid) VALUES ('$aid', '$tid', '$pid', '$dateline', '$readperm', '$filename', '$description', '$filetype', '$filesize', '$attachment', '$downloads', '$isimage', '$uid');";
				if ($db['discuz']->query($atsql)) {
					if ($resetaid) {
						$newaid = $db['discuz']->insert_id();
						$db['discuz']->query("UPDATE {$discuz_tablepre}posts SET message = replace(message, '[attach]".$at['aid']."[/attach]', '[attach]".$newaid."[/attach]') WHERE pid = '$pid'");
					}
				}
			}
		}
		$convertedrows ++;
	} else {
		reportlog("�޷�ת������ pid = $pid subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}

if($converted || $end < $maxid) {
	$nowtableid = $tableid + 1;
	showmessage("���ڴ����� $nowtableid �ֱ��ĵ� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.$tableid.'&maxtableid='.$maxtableid);
} elseif($tableid < $maxtableid) {
	$nextid = $tableid + 1;
	$nexttableid = $tableid + 2;
	unset($start);
	unset($end);
	showmessage("�� $nextid �ֱ����ݴ������, ��������� $nexttableid �ֱ���ת��", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.$nextid.'&maxtableid='.$maxtableid);
}
?>