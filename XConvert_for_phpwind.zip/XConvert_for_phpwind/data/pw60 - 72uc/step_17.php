<?php
//��̳����

if($start <= 1) {
	$db['discuz']->query("DELETE FROM {$discuz_tablepre}smilies WHERE typeid !='1' AND typeid !='0'");
	$db['discuz']->query("DELETE FROM {$discuz_tablepre}imagetypes WHERE directory !='default'");
}

$maxid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}smiles"), 0);
if($start < $maxid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}smiles  WHERE id >= $start AND id < $start + $rpp") or dexit();
while($pwsmile = $db['source']->fetch_array($query)) {

	if(!$pwsmile['type']) {
		if($pwsmile['path']) {
			$name = $pwsmile['path'] == 'default' ? 'pwĬ�ϱ���' : addslashes($pwsmile['name']);
			$pwsmile['path'] = $pwsmile['path'] == 'default' ?  'pw_default' : $pwsmile['path'];
			$typeid = $pwsmile['id'] + 1;
			$type = 'smiley';
			$displayorder = $pwsmile['vieworder'];
			$directory =  addslashes($pwsmile['path']);
			$db['discuz']->query("INSERT INTO {$discuz_tablepre}imagetypes (typeid, name, type, displayorder, directory) VALUES ('$typeid', '$name', '$type', '$displayorder', '$directory')");
		}
		continue;
	}

	$totalrows ++;

	$type = 'smiley';
	$typeid = intval($pwsmile['type'] + 1);
	$displayorder = $pwsmile['vieworder'];
	$code = '[s:'.$pwsmile['id'].']';
	$url = addslashes($pwsmile['path']);

	$db['discuz']->query("INSERT INTO {$discuz_tablepre}smilies (type, typeid, displayorder, code, url)
				VALUES ('$type', '$typeid', '$displayorder', '$code', '$url')");

	$convertedrows ++;
}
?>