<?php
if($start <= 1) {
	truncatetable('members');
	truncatetable('memberfields');
	truncatetable('onlinetime');
	copytable('members', 'members_temp');
	copytable('memberfields', 'memberfields_temp');
	$db['discuz']->query("ALTER TABLE {$discuz_tablepre}members_temp CHANGE username username CHAR( 50 ) NOT NULL");
	ctspecialgroup("{$source_tablepre}usergroups", "$discuz_tablepre");
	addmedals();
}
$maxuserid = $db['source']->result($db['source']->query("SELECT max(uid) FROM {$source_tablepre}members"), 0);
if($start < $maxuserid){
	$converted = 1;
}
$query = $db['source']->query("SELECT m.*, m.uid as muid, md.*, g.gid, g.gptype, g.grouptitle FROM {$source_tablepre}members m LEFT JOIN {$source_tablepre}memberdata md ON md.uid=m.uid LEFT JOIN {$source_tablepre}usergroups g ON g.gid=m.groupid WHERE m.uid>=$start AND m.uid<$start+$rpp") or dexit();
while($user = $db['source']->fetch_array($query)) {
	$uid = $user['muid'];
	$_username = trim($user['username']);

	$user = daddslashes($user);
	$username = trim($user['username']);

	$visitip		=	explode('|',$user['onlineip']);

	$password		=	$user['password'];
	$secques		=	'';
	$gender			=	$user['gender'];
	if($user['groupid'] == 3) {
		$adminid = $groupid = 1;
	} elseif($user['groupid'] == 4) {
		$adminid = $groupid = 2;
	} elseif($user['groupid'] == 5) {
		$adminid = $groupid = 3;
	} elseif($user['groupid'] == 6) {
		$adminid	=	-1;
		$groupid	=	4;
	} elseif($user['groupid'] == 7) {
		$adminid	=	0;
		$groupid	=	8;
	} elseif($user['gptype'] == 'special' || $user['gptype'] == 'system') {
		$adminid	=	0;
		$groupid	=	$user['groupid'] + 15;
	} else {
		$adminid	=	0;
		$groupid	=	10;
	}

	$groupexpiry		=	0;
	$extgroupids		=	'';
	$regip			=	substr($visitip[0], -1) == '*' ? trim(substr($visitip[0], 0, -1)) : $visitip[0];
	$regdate		=	$user['regdate'];
	$lastip			=	$regip;
	$lastvisit		=	$visitip[1] ? $visitip[1] : ($user['lastvisit'] ? $user['lastvisit'] : $timestamp);
	$lastactivity		=	$user['thisvisit'];
	$lastpost		=	$user['lastpost'];
	$posts			=	$user['postnum'];
	$digestposts		=	$user['digests'];
	$oltime			=	$user['onlinetime'] < 0 ? 0 : round($user['onlinetime'] / 3600);
	$thismonth		=	$user['monoltime'];
	$pageviews		=	$posts;
	$credits		=	(isset($user['rvrc']) && $user['rvrc']) ? floor($user['rvrc']/10) : 0;
	$extcredits1		=	$credits;
	$extcredits2		=	(isset($user['money']) && $user['money']) ? $user['money'] : 0;
	$extcredits3		=	$user['credit'];	//����ֵ
	$extcredits4		=	0;
	$extcredits5		=	0;
	$extcredits6		=	0;
	$extcredits7		=	0;
	$extcredits8		=	0;
	$email			=	cutstr($user['email'], 40);
	$bday			=	$user['bday'];

	$tpp			=	0;
	$ppp			=	0;
	$styleid		=	0;
	$dateformat		=	0;
	$timeformat		=	0;
	$pmsound		=	0;
	$showemail		=	0;
	$newsletter		=	1;
	$invisible		=	0;
	$timeoffset		=	9999;
	$newpm			=	0;
	$accessmasks		=	0;
	$nickname		=	'';
	$site			=	parsesite($user['site']);
	$alipay			=	'';
	$icq			=	parseqqicq($user['icq']);
	$qq			=	parseqqicq($user['oicq']);
	$yahoo			=	$user['yahoo'] ? htmlspecialchars(cutstr($user['yahoo'], 40)) : '';
	$msn			=	$user['msn'] ? htmlspecialchars(cutstr($user['msn'], 40)) : '';
	$taobao			=	'';
	$location		=	$user['location'] ? cutstr(htmlspecialchars(trim(@strip_tags($user['location']))), 30) : '';
	$customstatus		=	$user['honor'] ? cutstr(htmlspecialchars(trim(@strip_tags($user['honor']))), 30) : '';

	$medalcomma = $medals = $mdvar = '';
	if ($user['medals']) {
		$medalarray	=	explode(',', $user['medals']);
		foreach($medalarray as $mdvar) {
			$medals	.=	$medalcomma.(intval($mdvar) + 10);
			$medalcomma	=	"\t";
		}
	}

	//fixed at 2007-11-12
	$avatarinfo	= explode('|', $user['icon']);
	($avatarinfo[1] !=2 && $avatarinfo[1] != 3) && $avatarinfo[1] = 1;
	if($avatarinfo[1] == 2 || $avatarinfo[1] == 3) {
		$avatar		=	$avatarinfo[1] == 2 ? $avatarinfo[0] : 'customavatars/upload/'.$avatarinfo[0];
		$avatarwidth	=	$avatarinfo[2] > 0 && $avatarinfo[2] < 120 ? $avatarinfo[2] : 82;
		$avatarheight	=	$avatarinfo[3] > 0 && $avatarinfo[3] < 120 ? $avatarinfo[3] : 90;
	} elseif($avatarinfo[1] == 1 && $avatarinfo[0]) {
		$avatar		=	'images/avatars/face/'.$avatarinfo[0];
		$avatarwidth	=	82;
		$avatarheight	=	90;
	} else {
		$avatar		=	'';
		$avatarwidth = $avatarheight = 0;
	}

	$bio			=	$user['introduce'] ? @strip_tags($user['introduce']) : '';

	$signature		=	$user['signature'] ? @strip_tags($user['signature']) : '';
	$sigstatus		=	$signature ? 1 : 0;
	$sightml		=	parsesign($user['signature']);

	$ignorepm		=	'';
	$groupterms		=	'';
	$authstr		=	'';
	$total			=	$oltime * 60;
	$thismonth		=	$thismonth / 60;
	$lastupdate		=	$lastactivity;

	if(!$username || strlen($_username) > 15 || getuid($username)) {
		$mtable		=	'members_temp';
		$mftable	=	'memberfields_temp';
	} else {
		$mtable		=	'members';
		$mftable	=	'memberfields';
	}

	$query1			=	"INSERT INTO {$discuz_tablepre}$mtable ( uid, username, password, secques, gender, adminid, groupid, groupexpiry, extgroupids, regip, regdate, lastip, lastvisit, lastactivity, lastpost, posts, digestposts, oltime, pageviews, credits, extcredits1, extcredits2, extcredits3, extcredits4, extcredits5, extcredits6, extcredits7, extcredits8, email, bday, sigstatus, tpp, ppp, styleid, dateformat, timeformat, pmsound, showemail, newsletter, invisible, timeoffset, newpm, accessmasks ) VALUES ('$uid', '$username', '$password', '$secques', '$gender', '$adminid', '$groupid', '$groupexpiry', '$extgroupids', '$regip', '$regdate', '$lastip', '$lastvisit', '$lastactivity', '$lastpost', '$posts', '$digestposts', '$oltime', '$pageviews', '$credits', '$extcredits1', '$extcredits2', '$extcredits3', '$extcredits4', '$extcredits5', '$extcredits6', '$extcredits7', '$extcredits8', '$email', '$bday', '$sigstatus', '$tpp', '$ppp', '$styleid', '$dateformat', '$timeformat', '$pmsound', '$showemail', '$newsletter', '$invisible', '$timeoffset', '$newpm', '$accessmasks');";

	$query2			=	"INSERT INTO {$discuz_tablepre}$mftable ( uid, nickname, site, alipay, icq, qq, yahoo, msn, taobao, location, customstatus, medals, avatar, avatarwidth, avatarheight, bio, sightml, ignorepm, groupterms, authstr ) VALUES('$uid', '$nickname', '$site', '$alipay', '$icq', '$qq', '$yahoo', '$msn', '$taobao', '$location', '$customstatus', '$medals', '$avatar', '$avatarwidth', '$avatarheight', '$bio', '$sightml', '$ignorepm', '$groupterms', '$authstr');";

	$query3			=	"INSERT INTO {$discuz_tablepre}onlinetime (uid, thismonth, total, lastupdate) VALUES ('$uid', '$thismonth', '$total', '$lastupdate');";

	if ($db['discuz']->query($query1)) {
		if ($db['discuz']->query($query2)) {
			$db['discuz']->query($query3);
			$convertedrows ++;
		} else {
			$db['discuz']->query("INSERT INTO {$discuz_tablepre}$mftable (uid) VALUES ('$uid')");
		}
	} else {
		reportlog("�����Ա�������ݳ��� uid = $uid username = $username");
	}
	$converted = 1;
	$totalrows ++;
}
?>