<?php
// tag
if($start <= 1) {
	truncatetable('tags');
	truncatetable('threadtags');
}
$maxtagid = $db['source']->result($db['source']->query("SELECT max(tagid) FROM {$source_tablepre}tags"), 0);
if($start < $maxtagid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}tags WHERE tagid >= $start AND tagid < $start + $rpp") or dexit();
while($t = $db['source']->fetch_array($query)) {
	$t = daddslashes($t);
	$tagid = $t['tagid'];
	$tagname = $t['tagname'];
	$closed = 0;
	$total = $t['num'];
	$tids = $comma = '';
	$query2 = $db['source']->query("SELECT tid FROM {$source_tablepre}tagdata WHERE tagid = '$tagid'");
	while($td = $db['source']->fetch_array($query2)) {
		$tids .= $comma.' (\''.$tagname.'\', \''.$td['tid'].'\')';
		$comma = ',';
	}
	$sql1 = "INSERT INTO {$discuz_tablepre}tags (tagname, closed, total) VALUES ('$tagname', '$closed', '$total')";
	$sql2 = "INSERT INTO {$discuz_tablepre}threadtags (tagname, tid) VALUES $tids";
	if ($db['discuz']->query($sql1)) {
		$convertedrows ++;
		if ($tids) {
			$db['discuz']->query($sql2);
		}
	} else {
		reportlog("���� tag ���ݳ���, tagname = $tagname");
	}
	$totalrows ++;
}

?>