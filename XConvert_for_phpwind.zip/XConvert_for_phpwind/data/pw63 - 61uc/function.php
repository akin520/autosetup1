<?php
//�Զ��庯����
function convertbbcode($message) {//ת����ubb����
	global $source_bbsurl, $source_name, $tid, $first;
	$pregfind = array(
		"/\[post\]/i",
		"/\[\/post\]/i",
		"/\[attachment=(\d+)\]/is",
		"/\[p_w_upload=(\d+)\]/is",
		"/&nbsp;/i"
	);
	$pregreplace = array(
		"[hide]",
		"[/hide]",
		"[attach]\\1[/attach]",
		"[attach]\\1[/attach]",
		''
	);

	if ($first) {
		$sellfind = array("/\[sell=(\d+)\](.+)\[\/sell\]/ies");
		$sellreplace = array("parsesell('\\1', '\\2', $tid)");
		$pregfind = array_merge($pregfind, $sellfind);
		$pregreplace = array_merge($pregreplace, $sellreplace);
	}

	$bbsurl = str_replace(' ', '', $source_bbsurl);//ȥ���ո�
	if($bbsurl){
		$bbsurl = substr($bbsurl, 0, 1) == '|' ? substr($bbsurl, 1) : $bbsurl;//ȥ����ͷ��|
		$bbsurl = substr($bbsurl, -1) == '|' ? substr($bbsurl, 0, -1) : $bbsurl;//ȥ��β����|
		$bbsurltemp = str_replace(array('/', '.'), array('\/', '\.'), $bbsurl);//ת��
		$sourcename = $source_name ? $source_name.'/' : $source_name;//��������Ŀ¼
		$urlfind = array(
			"/($bbsurltemp)\/index\.php\?cateid=(\d+)/is",
			"/($bbsurltemp)\/index-htm-cateid-(\d+)\.html/is",
			"/($bbsurltemp)\/thread\.php\?fid=(\d+)/is",
			"/($bbsurltemp)\/thread-htm-fid-(\d+)\.html/is",
			"/($bbsurltemp)\/read\.php\?tid=(\d+)&page=(\d+)&fpage=\d/is",
			"/($bbsurltemp)\/read\.php\?tid=(\d+)&fpage=\d+&toread=&page=(\d+)/is",
			"/($bbsurltemp)\/read-htm-tid-(\d+)-page-(\d+)-fpage-\d+\.html/is",
			"/($bbsurltemp)\/read\.php\?tid=(\d+)&page=e&#a/is",
			"/($bbsurltemp)\/read\.php\?tid=(\d+)/is",
			"/($bbsurltemp)\/read-htm-tid-(\d+)\.html/is",
			"/($bbsurltemp)\/p_w_upload\//is",
			"/($bbsurltemp)\/attachment\//is"
		);
		$urlreplace = array(
			"\\1/index.php?gid=\\2",
			"\\1/index.php?gid=\\2",
			"\\1/forumdisplay.php?fid=\\2",
			"\\1/forum-\\2-1.html",
			"\\1/viewthread.php?tid=\\2&extra=page%3D1&page=\\3",
			"\\1/viewthread.php?tid=\\2&extra=page%3D1&page=\\3",
			"\\1/thread-\\2-\\3-1.html",
			"\\1/viewthread.php?tid=\\2",
			"\\1/viewthread.php?tid=\\2",
			"\\1/thread-\\2-1-1.html",
			"\\1/attachments/$sourcename",
			"\\1/attachments/$sourcename"
		);
		$pregfind = array_merge($pregfind, $urlfind);
		$pregreplace = array_merge($pregreplace, $urlreplace);
	}

	return daddslashes(html_entity_decode(preg_replace($pregfind, $pregreplace, stripslashes($message))));
}

function parsesell($price, $msg, $tid) {
	global $db, $discuz_tablepre;
	
	$db['discuz']->query("UPDATE {$discuz_tablepre}threads SET price = '$price' WHERE tid = '$tid'");
	return $msg;
}


function ctspecialgroup($sourcetable, $discuz_tablepre){//ת�����û���
	global $db, $discuz_tablepre;
	$db['discuz']->query("DELETE FROM {$discuz_tablepre}usergroups WHERE groupid > 15");
	$gquery = $db['source']->query("SELECT gid, grouptitle FROM $sourcetable WHERE gptype ='special' or (gptype = 'system' and gid > 7) ORDER BY gid ASC") or dexit();
	while($g = $db['source']->fetch_array($gquery)) {
		$g		=	daddslashes($g);
		$groupid	=	$g['gid'] + 15;
		$grouptitle	=	$g['grouptitle'];
		$gsql		=	"REPLACE INTO {$discuz_tablepre}usergroups (groupid, radminid, type, system, grouptitle, creditshigher, creditslower, stars, color, groupavatar, readaccess, allowvisit, allowpost, allowreply, allowpostpoll, allowpostreward, allowposttrade, allowpostactivity, allowdirectpost, allowgetattach, allowpostattach, allowvote, allowmultigroups, allowsearch, allowavatar, allowcstatus, allowuseblog, allowinvisible, allowtransfer, allowsetreadperm, allowsetattachperm, allowhidecode, allowhtml, allowcusbbcode, allowanonymous, allownickname, allowsigbbcode, allowsigimgcode, allowviewpro, allowviewstats, disableperiodctrl, reasonpm, maxprice, maxsigsize, maxattachsize, maxsizeperday, maxpostsperhour, attachextensions, raterange, mintradeprice, maxtradeprice, minrewardprice, maxrewardprice, magicsdiscount, allowmagics, maxmagicsweight, allowbiobbcode, allowbioimgcode, maxbiosize) VALUES ('$groupid', 0, 'special', 'private', '$grouptitle', 50, 200, 2, '', '', 20, 1, 1, 1, 1, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 100, 0, 0, 0, 'chm, pdf, zip, rar, tar, gz, bzip2, gif, jpg, jpeg, png', '', 1, 0, 1, 0, 0, 1, 60, 0, 0, 0)";
		$db['discuz']->query($gsql);
	}
}

function gethighlightid($string) {//ȡ�ø���id
	$highlightlist	= array(''=>'0','red'=>'1','orange'=>'2','yellow'=>'3','green'=>'4','cyan'=>'5','blue'=>'6','purple'=>'7','gray'=>'8');
	$threadstitlefont = explode('~',$string);
	$stylebin = '';
	$highlight_color = 0;
	for($i = 1; $i <= 3; $i++) {
		$stylebin .= empty($threadstitlefont[$i]) ? '0' : '1';
	}
	$highlight_style = bindec($stylebin);
	if (!empty($threadstitlefont[0])) {
		$titlefont = strtolower($threadstitlefont[0]);
		$highlight_color = isset($highlightlist[$titlefont]) ? $highlightlist[$titlefont] : 0;
	}

	return "$highlight_style$highlight_color";
}

function addmedals() {
	global $db, $source_tablepre, $discuz_tablepre;
	$medalquery = $db['source']->query("SELECT * FROM {$source_tablepre}medalinfo") or dexit();
	while($medal = $db['source']->fetch_array($medalquery)) {
		$medal		=	daddslashes($medal);
		$medalid	=	$medal['id'] + 10;
		$name		=	$medal['name'];
		$available	=	1;
		$image		=	substr($medal['picurl'], strrpos('/'.$medal['picurl'], '/'));
		$medalsql	=	"REPLACE INTO {$discuz_tablepre}medals (medalid, name, available, image) VALUES ('$medalid', '$name', '$available', '$image')";
		$db['discuz']->query($medalsql);
	}
}

?>