<?php
//����Ϣ
if($start <= 1) {
	truncatetable_uc('pms');
}
$maxmid = $db['source']->result($db['source']->query("SELECT max(mid) FROM {$source_tablepre}msg"), 0);
if($start < $maxmid){
	$converted = 1;
}
$query = $db['source']->query("SELECT g.*,c.title,c.content FROM {$source_tablepre}msg g LEFT JOIN  {$source_tablepre}msgc c ON c.mid=g.mid WHERE g.mid >= $start AND g.mid < $start + $rpp") or dexit();
while ($pms = $db['source']->fetch_array($query)) {

	$pms		=	array_change_key_case(daddslashes($pms));

	$msgfrom	=	$pms['username'];
	$msgfromid	=	$pms['fromuid'];
	$msgtoid	=	$pms['touid'];
	$folder		=	$pms['type'] == 'rebox' ? 'inbox' : 'outbox';
	$new		=	$pms['ifnew'];
	$subject	=	cutstr(htmlspecialchars(trim(@strip_tags($pms['title']))), 78);
	$dateline	=	$pms['mdate'];
	$dateline	=	$dateline > $timestamp ? $timestamp : $dateline;
	$message	=	@strip_tags(trim($pms['content']));
	$delstatus	=	0;
	$related	=	0;

	$fields = array('msgfrom','msgfromid','msgtoid','folder','new','subject','dateline','message','delstatus','related');
	$sql = getinsertsql("{$uc_tablepre}pms", $fields);

	if ($db['uc']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת������Ϣ $subject");
	}
	$converted = 1;
	$totalrows ++;
}
?>