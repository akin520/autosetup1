<?php
//�����Ƽ�����

if($start <= 1) {
	truncatetable('forumrecommend');
}
$maxfid = $db['source']->result($db['source']->query("SELECT max(fid) FROM {$source_tablepre}forumsextra"), 0);
if($start < $maxfid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}forumsextra WHERE fid >= $start AND fid < $start + $rpp") or dexit();
while($f = $db['source']->fetch_array($query)) {

	$fset = unserialize($f['forumset']);
	$forumrecommend = unserialize($f['commend']);
	$fid = $f['fid'];
	$modrecommendnew = array(
		'open' => intval($fset['commend']),
		'sort' => ($fset['autocommend'] > 0 ? 2 : 0),
		'orderby' => ($fset['autocommend'] > 1 ? intval($fset['autocommend'] - 1) : 0),
		'num' => ($fset['commendnum'] ? intval($fset['commendnum']) : 10),
		'maxlength' => ($fset['commendlength'] ? intval($fset['commendlength']) : 0),
		'cachelife' => ($fset['commendtime'] ? intval($fset['commendtime']) : 0),
		'dateline' => 0
	);

	$modrecommendnew = $modrecommendnew && is_array($modrecommendnew) ? addslashes(serialize($modrecommendnew)) : '';

	$db['discuz']->query("UPDATE {$discuz_tablepre}forumfields SET modrecommend = '$modrecommendnew' WHERE fid = '$fid'");

	foreach ($forumrecommend as $rc) {

		$tid = $rc['tid'];
		$displayorder = 0;
		$subject = addslashes(cutstr($rc['subject'], 80));
		$author = addslashes($rc['author']);
		$authorid = $rc['authorid'];
		$moderatorid = 0;
		$expiration = $timestamp + 31536000;

		$sql = "INSERT INTO {$discuz_tablepre}forumrecommend  (fid, tid, displayorder, subject, author, authorid, moderatorid, expiration) VALUES ('$fid', '$tid', '$displayorder', '$subject', '$author', '$authorid', '$moderatorid', '$expiration')";
		if($db['discuz']->query($sql)) {
			$convertedrows ++;
		} else {
			reportlog("���� �����Ƽ����� ���ݳ���, ���� = $subject , tid = $tid");
		}
		$totalrows ++;
	}

}

?>