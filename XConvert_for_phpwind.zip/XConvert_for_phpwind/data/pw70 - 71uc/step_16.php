<?php
//��������

if($start <= 1) {
	truncatetable('debates');
	truncatetable('debateposts');
	$tids = $comma = '';
	$query = $db['discuz']->query("SELECT tid FROM {$discuz_tablepre}threads WHERE special='5'");
	while($thread = $db['discuz']->fetch_array($query)) {
		$tids .= $comma."'$thread[tid]'";
		$comma = ', ';
	}
	$tids = $tids ? $tids : "''";
	$db['discuz']->query("DELETE FROM {$discuz_tablepre}threads WHERE special='5'");
	$db['discuz']->query("DELETE FROM {$discuz_tablepre}posts WHERE tid IN($tids)");
}

$maxtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}threads"), 0);
if($start < $maxtid){
	$converted = 1;
}

$query = $db['source']->query("SELECT a.*, b.* FROM {$source_tablepre}threads a LEFT JOIN {$source_tablepre}tmsgs b ON a.tid=b.tid WHERE special = '5' AND a.tid >= $start AND a.tid < $start + $rpp") or dexit();
while($debate = $db['source']->fetch_array($query)) {

	$totalrows ++;
	$oldtid = $debate['tid'];
	$fid = $debate['fid'];
	$readperm = 0;
	$price = 0;
	$iconid = 0;
	$typeid = 0;
	$author = addslashes($debate['author']);
	$authorid = $debate['authorid'];
	$subject = addslashes($debate['subject']);
	$dateline = $debate['postdate'];
	$lastpost = $debate['lastpost'];
	$lastposter = addslashes($debate['lastposter']);
	$displayorder = 0;
	$digest = 0;
	$special = 5;
	$attachment = $debate['aid'];
	$subscribed = 0;
	$moderated = 0;
	$supe_pushstatus = 0;
	$views = $debate['hits'];
	$replies = $debate['replies'];

	$db['discuz']->query("INSERT INTO {$discuz_tablepre}threads (fid, readperm, price, iconid, typeid, author, authorid, subject, dateline, lastpost, lastposter, displayorder, digest, special, attachment, moderated, supe_pushstatus, views, replies)
		VALUES ('$fid', '$readperm', '$price', '$iconid', '$typeid', '$author', '$authorid', '$subject', '$dateline', '$lastpost', '$lastposter', '$displayorder', '$digest', '$special', '$attachment', '$moderated', '$supe_pushstatus', '$views', '$replies')");

	$tid = $db['discuz']->insert_id();
	$query_1 = $db['source']->query("SELECT * FROM {$source_tablepre}debates WHERE tid = '$oldtid'") or dexit();
	$debdata = $db['source']->fetch_array($query_1);

	$uid = $debdata['authorid'];
	$starttime = $debdata['postdate'];
	$endtime = $debdata['endtime'];
	$affirmdebaters = $db['source']->result($db['source']->query("SELECT COUNT(DISTINCT authorid) FROM {$source_tablepre}debatedata WHERE tid='$oldtid' AND standpoint='1'"), 0);
	$negadebaters = $db['source']->result($db['source']->query("SELECT COUNT(DISTINCT authorid) FROM {$source_tablepre}debatedata WHERE tid='$oldtid' AND standpoint='2'"), 0);
	$affirmvotes = $debate['obvote'];
	$negavotes = $debate['revote'];
	$umpire = addslashes($debate['umpire']);
	$winner = $debate['judge'];
	$bestdebater = $debate['debater'];
	$affirmpoint = addslashes($debate['obtitle']);
	$negapoint = addslashes($debate['retitle']);
	$umpirepoint = addslashes($debate['judgcontent']);

	$affirmvoterids = $negavoterids = '';
	$affirmids = $negaids = array();
	$affirmquery = $db['source']->query("SELECT DISTINCT authorid FROM {$source_tablepre}debatedata WHERE tid='$oldtid' AND standpoint='1'");
	while($affirm = $db['source']->fetch_array($affirmquery)) {
		$affirmids[] = $affirm['authorid'];
	}
	$negaquery = $db['source']->query("SELECT DISTINCT authorid FROM {$source_tablepre}debatedata WHERE tid='$oldtid' AND standpoint='2'");
	while($nega = $db['source']->fetch_array($negaquery)) {
		$negaids[] = $nega['authorid'];
	}
	
	$affirmvoterids = implode("\t", $affirmids);
	$negavoterids = implode("\t", $negaids);

	$affirmreplies = $db['source']->result($db['source']->query("SELECT COUNT(*) FROM {$source_tablepre}debatedata WHERE tid='$oldtid' AND postdate='1' AND pid > '0'"), 0);
	$negareplies = $db['source']->result($db['source']->query("SELECT COUNT(*) FROM {$source_tablepre}debatedata WHERE tid='$oldtid' AND postdate='2' AND pid > '0'"), 0);

	$db['discuz']->query("INSERT INTO {$discuz_tablepre}debates (tid, uid, starttime, endtime, affirmdebaters, negadebaters, affirmvotes, negavotes, umpire, winner, bestdebater, affirmpoint, negapoint, umpirepoint, affirmvoterids, negavoterids, affirmreplies, negareplies)
			VALUES ('$tid', '$uid', '$starttime', '$endtime', '$affirmdebaters', '$negadebaters', '$affirmvotes', '$negavotes', '$umpire', '$winner', '$bestdebater', '$affirmpoint', '$negapoint', '$umpirepoint', '$affirmvoterids', '$negavoterids', '$affirmreplies', '$negareplies')");

	$first = 1;
	$message = addslashes($debate['content']);
	$useip = '';                                                     //$debate['ip'];
	$invisible = $displayorder;
	$anonymous = 0;
	$usesig = 0;
	$htmlon = 0;
	$bbcodeoff = -1;
	$smileyoff = -1;
	$parseurloff = 0;


	$db['discuz']->query("INSERT INTO {$discuz_tablepre}posts (fid, tid, first, author, authorid, subject, dateline, message, useip, invisible, anonymous, usesig, htmlon, bbcodeoff, smileyoff, parseurloff, attachment)
		VALUES ('$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$invisible', '$anonymous', '$usesig', '$htmlon', '$bbcodeoff', '$smileyoff', '$parseurloff', '$attachment')");
	$pid = $db['discuz']->insert_id();

	$postquery = $db['source']->query("SELECT d.* , p.* FROM {$source_tablepre}debatedata d LEFT JOIN {$source_tablepre}posts p ON d.pid = p.pid WHERE d.tid='$oldtid' and d.pid > '0'");
	while($post = $db['source']->fetch_array($postquery)) {

		$first = 0;
		$author = addslashes($post['author']);
		$authorid = $post['authorid'];
		$subject = '';
		$dateline = $debate['postdate'];
		$message = addslashes($post['content']);
		$useip = $post['userip'];
		$invisible = $displayorder;

		$db['discuz']->query("INSERT INTO {$discuz_tablepre}posts (fid, tid, first, author, authorid, subject, dateline, message, useip, invisible, anonymous, usesig, htmlon, bbcodeoff, smileyoff, parseurloff, attachment)
		VALUES ('$fid', '$tid', '$first', '$author', '$authorid', '$subject', '$dateline', '$message', '$useip', '$invisible', '$anonymous', '$usesig', '$htmlon', '$bbcodeoff', '$smileyoff', '$parseurloff', '$attachment')");

		$stand = $post['standpoint'] == 3 ?  0 : $post['standpoint'];
		$uid = $authorid;
		$voters = $post['vote'];
		$voterids = '';
		$pid = $db['discuz']->insert_id();

		$db['discuz']->query("INSERT INTO {$discuz_tablepre}debateposts (pid, tid, stand, uid, dateline, voters, voterids)
		VALUES ('$pid', '$tid', '$stand', '$uid', '$dateline', '$voters', '$voterids')");
	}
	$convertedrows ++;
}
?>