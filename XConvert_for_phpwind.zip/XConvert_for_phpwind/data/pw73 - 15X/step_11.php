<?php
/*
ͶƱ��Ա����pre_forum_pollvoter
*/
if($start <= 1){
	truncatetable('forum_pollvoter');
}

$maxcount = $db['source']->result($db['source']->query("SELECT count(*) FROM {$source_tablepre}voter"), 0);

if($start < $maxcount){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}voter limit $start,$rpp") or dexit();
while ($pwvoter =	$db['source']->fetch_array($query)) {
	//pre_forum_pollvoter
	$tid		=	$pwvoter['tid'];
	$uid		=	$pwvoter['uid'];
	$username	=	daddslashes($pwvoter['username']);
	
	//����ȡͶƱѡ���ID
	$vote		=	$pwvoter['vote'];
	$nvote		=	$vote+1;
	$options	=	$db['discuz']->result($db['discuz']->query("SELECT polloptionid FROM {$discuz_tablepre}forum_polloption WHERE tid='$tid' limit $vote,$nvote"), 0);
	
	$dateline	=	$pwvoter['dateline'];

	$field1	=	array('tid','uid','username','options','dateline');
	$query1	=	getinsertsql("{$discuz_tablepre}forum_pollvoter", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת��ͶƱ��Ա id = $cid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>