<?php
/*
ͶƱ��Ʒ������pre_forum_trade
�������۱���pre_forum_tradecomment
���׼�¼����pre_forum_tradelog
*/

if($start <= 1){
	truncatetable('forum_trade');
}

$maxtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}trade"), 0);

if($start < $maxtid){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}trade WHERE tid >= $start AND tid <$start + $rpp") or dexit();
while ($pwtrade =	$db['source']->fetch_array($query)) {
	$pwtrade		=	daddslashes($pwtrade);

	$tid			=	$pwtrade['tid'];

	$p_query		=	$db['discuz']->query("SELECT * FROM {$discuz_tablepre}forum_post WHERE tid=$tid AND first=1");
	if($dzpost = $db['discuz']->fetch_array($p_query)){
		//pre_forum_post
		//$pid			=	'';
		$fid			=	$dzpost['fid'];
		$tid			=	$dzpost['tid'];
		$first			=	0;
		$author			=	$dzpost['author'];
		$authorid		=	$dzpost['authorid'];
		$subject		=	$dzpost['subject'];
		$dateline		=	$dzpost['dateline'];
		$message		=	$dzpost['message'];
		$useip			=	$dzpost['userip'];
		$invisible		=	$dzpost['invisible'];
		$anonymous		=	$dzpost['anonymous'];
		$usesig			=	$dzpost['usesig'];
		$htmlon			=	$dzpost['htmlon'];
		$bbcodeoff		=	$dzpost['bbcodeoff'];
		$smileyoff		=	$dzpost['smileyoff'];
		$parseurloff	=	$dzpost['parseurloff'];
		$attachment		=	$dzpost['attachment'];
		$rate			=	$dzpost['rate'];
		$ratetimes		=	$dzpost['ratetimes'];
		$status			=	$dzpost['status'];
		$tags			=	$dzpost['tags'];
		$comment		=	$dzpost['comment'];

		$field1 = array('pid');
		$query1 = getinsertsql("{$discuz_tablepre}forum_post_tableid", $field1);

		if($db['discuz']->query($query1)) {
			$pid = $db['discuz']->insert_id();
			$field2 = array('pid','fid','tid','first','author','authorid','subject','dateline','message','useip','invisible','anonymous','usesig','htmlon','bbcodeoff','smileyoff','parseurloff','attachment','rate','ratetimes','status','tags','comment');
			$query2 = getinsertsql("{$discuz_tablepre}forum_post", $field2);

			if($db['discuz']->query($query2)){
				//$pid			=	"";									//����ID������
				$typeid			=	$pwtrade['type'];					//�������ID
				$sellerid		=	$pwtrade['uid'];					//
				$seller			=	getusername($sellerid);				//��������
				$account		=	"";									//����֧�����˺�
				$subject		=	$pwtrade['name'];					//����
				$price			=	$pwtrade['price'];
				$amount			=	$pwtrade['num'];					//����
				$quality		=	0;
				$locus			=	$pwtrade['locus'];
				$transport		=	$pwtrade['transport'];
				$ordinaryfee	=	$pwtrade['mailfee'];
				$expressfee		=	$pwtrade['expressfee'];
				$emsfee			=	$pwtrade['emsfee'];
				$itemtype		=	1;									//��Ʒ����
				$dateline		=	$pwtrade['deadline'];
				$expiration		=	"";
				$lastbuyer		=	"";
				$lastupdate		=	0;
				$totalitems		=	"0.00";
				$tradesum		=	$pwtrade['salenum'];
				$closed			=	0;
				$aid			=	0;
				if($pwtrade['icon']) {
					$aid = $db['source']->result($db['source']->query("SELECT aid FROM {$source_tablepre}attachs WHERE attachurl='{$pwtrade['icon']}' LIMIT 1"));
					$db['discuz']->query("UPDATE {$discuz_tablepre}forum_attachment SET pid='{$pid}', width='466' WHERE aid='{$aid}' LIMIT 1");
				}
				$displayorder	=	0;
				$costprice		=	$pwtrade['costprice'];
				$credit			=	0;
				$costcredit		=	0;
				$credittradesum	=	0;

				$field3	=	array('tid','pid','typeid','sellerid','seller','account','subject','price','amount','quality','locus','transport','ordinaryfee','expressfee','emsfee','itemtype','dateline','expiration','lastbuyer','lastupdate','totalitems','tradesum','closed','aid','displayorder','costprice','credit','costcredit','credittradesum');
				$query3	=	getinsertsql("{$discuz_tablepre}forum_trade", $field3);

				if($db['discuz']->query($query3)) {
					$convertedrows ++;
					unset($pid);
				} else {
					reportlog("�޷�ת����Ʒ���� tid = $tid pid = $pid��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query3."</textarea>");
				}
			} else {
				reportlog("�������ӱ� tid = $tid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query2."</textarea>");
			}
		}else{
			reportlog("��������pid��¼������ pid = $pid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
		}
	}
	$converted = 1;
	$totalrows ++;
}
?>