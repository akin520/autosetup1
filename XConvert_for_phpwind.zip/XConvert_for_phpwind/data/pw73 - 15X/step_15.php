<?php
/*
���׼�¼������pre_forum_tradelog
*/

if($start <= 1){
	truncatetable('forum_tradelog');
}

$maxoid = $db['source']->result($db['source']->query("SELECT max(oid) FROM {$source_tablepre}tradeorder"), 0);

if($start < $maxoid){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}tradeorder WHERE oid>$start AND oid<$start+$rpp") or dexit();
while ($pwtradeorder =	$db['source']->fetch_array($query)) {
	$pwtradeorder = daddslashes($pwtradeorder);

	//pre_forum_tradelog
	$tid			=	$pwtradeorder['tid'];

	$dz_dateline	=	$db['discuz']->result($db['discuz']->query("SELECT dateline FROM {$discuz_tablepre}forum_post WHERE tid='$tid' AND first=1"), 0);
	$pid			=	$db['discuz']->result($db['discuz']->query("SELECT pid FROM {$discuz_tablepre}forum_post WHERE dateline='$dz_dateline' AND first=1"), 0);
	//$pid			=	"";								//��ʱΪ��

	$orderid		=	gmdate('YmdHis', $pwtradeorder['buydate']).random(18);
	$tradeno		=	$pwtradeorder['order_no'];
	$subject		=	$pwtradeorder['subject'];
	$price			=	$pwtradeorder['price'];
	$quality		=	0;
	$itemtype		=	"";
	$number			=	$pwtradeorder['quantity'];
	$tax			=	"";
	$locus			=	$pwtradeorder['address'];
	$seller			=	$pwtradeorder['seller'];
	$sellerid		=	getuid($seller);
	$selleraccount	=	"";
	$buyerid		=	$pwtradeorder['buyer'];
	$buyer			=	getusername($buyerid);			//��ʵ�����ƣ�$pwtradeorder['consignee'];
	$buyercontact	=	"";
	$buyercredits	=	0;
	$buyermsg		=	$pwtradeorder['descrip'];
	$status			=	0;
	$lastupdate		=	$pwtradeorder['tradedate'];
	$offline		=	"";
	$buyername		=	"";
	$buyerzip		=	$pwtradeorder['zip'];
	$buyerphone		=	"";
	$buyermobile	=	$pwtradeorder['tel'];
	$transport		=	3;
	$transportfee	=	$pwtradeorder['transportfee'];
	$baseprice		=	$pwtradeorder['price'];
	$discount		=	0;
	$ratestatus		=	0;
	$message		=	"";
	$credit			=	"";
	$basecredit		=	"";

	$field1	=	array('tid','pid','orderid','tradeno','subject','price','quality','itemtype','number','tax','locus','sellerid','seller','selleraccount','buyerid','buyer','buyercontact','buyercredits','buyermsg','status','lastupdate','offline','buyername','buyerzip','buyerphone','buyermobile','transport','transportfee','baseprice','discount','ratestatus','message','credit','basecredit');
	$query1	=	getinsertsql("{$discuz_tablepre}forum_tradelog", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת�����׼�¼ tid = $tid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
	}
	
	$converted = 1;
	$totalrows ++;
}
?>