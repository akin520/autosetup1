<?php
/*
�������pre_forum_activity
��μӱ���pre_forum_activityapply
*/

if($start <= 1){
	truncatetable('forum_activity');
}

$maxtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}activity"), 0);

if($start < $maxtid){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}activity WHERE tid >= $start AND tid <$start + $rpp") or dexit();
while ($pwactivity 	=	$db['source']->fetch_array($query)) {
	$pwactivity		=	daddslashes($pwactivity);

	//pre_forum_activity
	$tid			=	$pwactivity['tid'];
	$uid			=	$pwactivity['admin'];
	$aid			=	0;
	$cost			=	$pwactivity['costs'];
	$starttimefrom	=	$pwactivity['starttime'];
	$starttimeto	=	$pwactivity['endtime '];
	$place			=	$pwactivity['location'];
	$class			=	'';
	$gender			=	$pwactivity['sexneed'];
	$number			=	$pwactivity['num'];
	$applynumber	=	$db['source']->result($db['source']->query("SELECT COUNT(*) FROM {$source_tablepre}actmember WHERE actid=$tid AND state='1'"), 0);		//���¼���μ�����
	$expiration		=	$starttimefrom;

	$field1	=	array('tid','uid','aid','cost','starttimefrom','starttimeto','place','class','gender','number','applynumber','expiration');
	$query1	=	getinsertsql("{$discuz_tablepre}forum_activity", $field1);

	if ($db['discuz']->query($query1)) {
		$db['discuz']->query("UPDATE {$discuz_tablepre}forum_thread SET special='4' WHERE tid='$tid'");
		$convertedrows ++;
	} else {
		reportlog("�޷�ת������� pollid = $pollid tid = $tid��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>