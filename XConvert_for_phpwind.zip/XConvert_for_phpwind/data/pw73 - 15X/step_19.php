<?php
/*
ת��Ⱥ��
pre_forum_forum
pre_forum_forumfield
*/

if($start <= 1){//�˲����ɴ�
	//truncatetable('forum_forum');
	//truncatetable('forum_forumfield');
	//truncatetable('forum_grouplevel');
}

$maxmtagid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}colonys"), 0);
if($start < $maxmtagid){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}colonys WHERE id >= $start AND id < $start + $rpp") or dexit();
while ($pwcolony = $db['source']->fetch_array($query)) {
	$pwcolony			=	daddslashes($pwcolony);

	//pre_forum_forum
	//$fid				=	$pwcolony['fid'];
	$t_name	= $db['source']->result($db['source']->query("SELECT cname FROM {$source_tablepre}cnclass WHERE cid='$pwcolony[classid]'"), 0);
	$fup = $db['discuz']->result($db['discuz']->query("SELECT fid FROM {$discuz_tablepre}forum_forum WHERE name='$t_name' AND type='forum' AND status='3' limit 1"), 0);

	$type				=	'sub';		//����(group:���� forum:��ͨ��̳ sub:����̳)
	$name				=	$pwcolony['cname'];
	$status				=	3;
	$displayorder		=	0;
	$styleid			=	0;
	$threads			=	0;
	$posts				=	0;
	$todayposts			=	0;
	$lastpost			=	'';
	$allowsmilies		=	0;
	$allowhtml			=	0;
	$allowbbcode		=	0;
	$allowimgcode		=	0;
	$allowmediacode		=	0;
	$allowanonymous		=	0;
	//$allowshare		=	0;				//beta�����Ѿ��޴��ֶ�
	$allowpostspecial	=	0;
	$allowspecialonly	=	0;
	$alloweditrules		=	0;
	$allowfeed			=	1;
	$allowside			=	1;
	$recyclebin			=	0;
	$modnewposts		=	0;
	$jammer				=	0;
	$disablewatermark	=	0;
	$inheritedmod		=	0;
	$autoclose			=	0;
	$forumcolumns		=	0;
	$threadcaches		=	0;
	$alloweditpost		=	1;
	$simple				=	0;
	$modworks			=	0;
	$allowtag			=	1;
	$allowglobalstick	=	1;
	$level				=	0;
	$commoncredits		=	0;
	$archive			=	0;
	$recommend			=	0;

	//pre_forum_forumfield
	//$fid				=	$pwcolony['fid'];
	$description		=	$pwcolony['annouce'];
	$password			=	'';
	$icon				=	$pwcolony['cnimg'];
	$redirect			=	'';
	$attachextensions	=	'';
	$creditspolicy		=	'';
	$formulaperm		=	'';
	$moderators			=	'';
	$rules				=	'';
	$threadtypes		=	'';
	$threadsorts		=	'';
	$viewperm			=	'';
	$postperm			=	'';
	$replyperm			=	'';
	$getattachperm		=	'';
	$postattachperm		=	'';
	$postimageperm		=	'';
	$keywords			=	'';
	$supe_pushsetting	=	'';
	$modrecommend		=	'';
	$threadplugin		=	'';
	$extra				=	'';
	$jointype			=	$pwcolony['ifcheck']==0 ? -1 : ($pwcolony['ifcheck']==1 ? 0 : 2);	//����Ⱥ�鷽ʽ -1Ϊ�رգ�0Ϊ������ 2����
	$gviewperm			=	0;				//Ⱥ�����Ȩ�� 0:����Ա 1:�����û�
	$membernum			=	$pwcolony['members'];
	$dateline			=	$pwcolony['createtime'];			//Ⱥ�鴴��ʱ��
	$lastupdate			=	$pwcolony['createtime'];			//Ⱥ��������ʱ��
	$activity			=	0;									//Ⱥ���Ծ��
	$founderuid			=	getuid($pwcolony['admin']);			//Ⱥ�鴴ʼ��UID
	$foundername		=	$pwcolony['admin'];					//Ⱥ�鴴ʼ������
	$banner				=	$pwcolony['banner'];				//Ⱥ��ͷͼƬ
	$groupnum			=	0;					//�����µ�Ⱥ������
	$commentitem		=	'';

	$field1		=	array('fup','type','name','status','displayorder','styleid','threads','posts','todayposts','lastpost','allowsmilies','allowhtml','allowbbcode','allowimgcode','allowmediacode','allowanonymous','allowpostspecial','allowspecialonly','alloweditrules','allowfeed','allowside','recyclebin','modnewposts','jammer','disablewatermark','inheritedmod','autoclose','forumcolumns','threadcaches','alloweditpost','simple','modworks','allowtag','allowglobalstick','level','commoncredits','archive','recommend');
	$query1		=	getinsertsql("{$discuz_tablepre}forum_forum", $field1);

	if($db['discuz']->query($query1)) {
		$fid = $db['discuz']->insert_id();
		$field2 = array('fid','description','password','icon','redirect','attachextensions','creditspolicy','formulaperm','moderators','rules','threadtypes','threadsorts','viewperm','postperm','replyperm','getattachperm','postattachperm','postimageperm','keywords','supe_pushsetting','modrecommend','threadplugin','extra','jointype','gviewperm','membernum','dateline','lastupdate','activity','founderuid','foundername','banner','groupnum','commentitem');
		$query2	= getinsertsql("{$discuz_tablepre}forum_forumfield", $field2);
		if($db['discuz']->query($query2) && $db['discuz']->query("UPDATE {$discuz_tablepre}forum_forumfield SET groupnum=groupnum+1 WHERE fid='$fup'")) {
			$convertedrows ++;
		} else {
			$db['discuz']->query("DELETE FROM {$discuz_tablepre}forum_forum WHERE fid='$fid'");
			reportlog("�޷�ת��Ⱥ����չ��Ϣ fid = $fid");
		}
	} else {
		reportlog("�޷�ת��Ⱥ�� fid = $fid");
	}
	$converted = 1;
	$totalrows ++;
}
?>