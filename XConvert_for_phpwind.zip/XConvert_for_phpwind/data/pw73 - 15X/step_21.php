<?php
/*
ת��Ⱥ������

*/

if($start <= 1){
	$forxgrouptid = $db['discuz']->result($db['discuz']->query("SELECT max(tid)+1 FROM {$discuz_tablepre}forum_thread LIMIT 1"), 0);
	$db['discuz']->query("REPLACE INTO {$discuz_tablepre}common_setting (`skey`, `svalue`) VALUES ('forxgrouptid', '{$forxgrouptid}')");
} else {
	$forxgrouptid = $db['discuz']->result($db['discuz']->query("SELECT svalue FROM {$discuz_tablepre}common_setting WHERE skey = 'forxgrouptid'"), 0);
}

$maxtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}argument"), 0);
if($start < $maxtid){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}argument a LEFT JOIN {$source_tablepre}colonys c ON a.gid=c.id WHERE tid >= $start AND tid < $start + $rpp") or dexit();
while ($pwargument = $db['source']->fetch_array($query)) {
	$pwargument	= daddslashes($pwargument);
	//$pid
	$fid			=	$db['discuz']->result($db['discuz']->query("SELECT fid FROM {$discuz_tablepre}forum_forum WHERE name='{$pwargument['cname']}' AND type='sub' LIMIT 1"));
	$tid			=	$forxgrouptid + $pwargument['tpcid'];
	$first			=	$pwargument['tpcid'] ? 0 : 1;
	$author			=	$pwargument['author'];
	$authorid		=	$pwargument['authorid'];
	$subject		=	$pwargument['subject'];
	$dateline		=	daddslashes(cutstr(htmlspecialchars(trim(@strip_tags($pwargument['postdate']))), 78));
	$message		=	convertbbcode($pwargument['content']);
	$useip			=	'';
	$invisible		=	0;
	$anonymous		=	0;
	$usesig			=	1;
	$htmlon			=	0;
	$bbcodeoff		=	'-1';
	$smileyoff		=	'-1';
	$parseurloff	=	0;
	$attachment		=	0;
	$rate			=	0;
	$ratetimes		=	0;
	$status			=	0;
	$tags			=	0;
	$comment		=	0;

	if(!$pwargument['tpcid']) {
		$tid				=	$forxgrouptid + $pwargument['tid'];
		$posttableid		=	0;
		$typeid				=	0;
		$sortid				=	0;
		$readperm			=	0;
		$price				=	0;
		$lastpost			=	$pwargument['lastpost'];
		$lastposter			=	$db['source']->result($db['source']->query("SELECT author FROM {$source_tablepre}argument WHERE tpcid='{$pwargument['tid']}' ORDER BY tid DESC LIMIT 1"), 0);
		$lastposter			=	$lastposter ? $lastposter : $author;
		$views				=	0;
		$replies			=	0;
		$displayorder		=	0;
		$highlight			=	0;
		$digest				=	0;
		$rate				=	0;
		$special			=	0;
		$attachment			=	0;
		$moderated			=	0;
		$closed				=	0;
		$stickreply			=	0;
		$recommends			=	0;
		$recommend_add		=	0;
		$recommend_sub		=	0;
		$heats				=	0;
		$status				=	0;
		$isgroup			=	1;
		$favtimes			=	0;
		$sharetimes			=	0;
		$stamp				=	0;
		$icon				=	0;
		$pushedaid			=	0;
		$field4 = array('tid','fid','posttableid','typeid','sortid','readperm','price','author','authorid','subject','dateline','lastpost','lastposter','views','replies','displayorder','highlight','digest','rate','special','attachment','moderated','closed','stickreply','recommends','recommend_add','recommend_sub','heats','status','isgroup');
		$query4 = getinsertsql("{$discuz_tablepre}forum_thread", $field4);
		$db['discuz']->query($query4);
	}
	$field1 = array('pid');
	$query1 = getinsertsql("{$discuz_tablepre}forum_post_tableid", $field1);

	$field3 = array('pid','fid','tid','first','author','authorid','subject','dateline','message','useip','invisible','anonymous','usesig','htmlon','bbcodeoff','smileyoff','parseurloff','attachment','rate','ratetimes','status','tags','comment');

	if($db['discuz']->query($query1)){
		$pid = $db['discuz']->insert_id();
		$query3 = getinsertsql("{$discuz_tablepre}forum_post", $field3);
		if ($db['discuz']->query($query3)) {
			$convertedrows ++;
			unset($pid);
		} else {
			$db['discuz']->query("DELETE FROM {$discuz_tablepre}forum_post_tableid WHERE pid='$pid'");
			reportlog("����Ⱥ���������SQL��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query2."</textarea>");
		}
	} else {
		reportlog("����Ⱥ���������SQL��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query3."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>