<?php
/*
ͼƬ���ͣ�pre_forum_imagetype
�������pre_common_smiley
*/

if($start <= 1) {
	$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_smiley WHERE typeid !='1' AND typeid !='0'");
	$db['discuz']->query("DELETE FROM {$discuz_tablepre}forum_imagetype WHERE directory !='default'");
}

$maxid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}smiles"), 0);
if($start < $maxid){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}smiles  WHERE id >= $start AND id < $start + $rpp") or dexit();
while($pwsmile = $db['source']->fetch_array($query)) {
	if(!$pwsmile['type']) {
		if($pwsmile['path']) {
			$pwsmile['path']	=	$pwsmile['path'] == 'default' ?  'pw_default' : $pwsmile['path'];
			$typeid			=	$pwsmile['id'] + 1;
			$available		=	'1';
			$name			=	$pwsmile['path'] == 'default' ? 'pwĬ�ϱ���' : addslashes($pwsmile['name']);
			$type			=	'smiley';
			$displayorder	=	$pwsmile['vieworder'];
			$directory		=	addslashes($pwsmile['path']);
			
			$field1			=	array('typeid', 'available', 'name', 'type', 'displayorder', 'directory');
			$query1			=	getinsertsql("{$discuz_tablepre}forum_imagetype", $field1);
			
			$db['discuz']->query($query1);
		}
		continue;
	}

	$totalrows ++;

	$typeid			=	intval($pwsmile['type'] + 1);
	$displayorder	=	$pwsmile['vieworder'];
	$type			=	'smiley';
	$code			=	'[s:'.$pwsmile['id'].']';
	$url			=	addslashes($pwsmile['path']);
	
	$field2			=	array('id','typeid','displayorder','type','code','url');
	$query2			=	getinsertsql("{$discuz_tablepre}common_smiley", $field2);
	
	$db['discuz']->query($query2);
	$convertedrows ++;
}
?>