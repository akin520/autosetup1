<?php
/*
pre_home_blog
pre_home_blogfield
*/

if($start <= 1){
	truncatetable('home_blog');
	truncatetable('home_blogfield');
}

$maxdid = $db['source']->result($db['source']->query("SELECT max(did) FROM {$source_tablepre}diary"), 0);
if($start < $maxdid) $converted = 1;

$query = $db['source']->query("SELECT * FROM {$source_tablepre}diary WHERE did >= $start AND did < $start + $rpp") or dexit();
while ($pwdiary = $db['source']->fetch_array($query)) {
	$pwdiary = daddslashes($pwdiary);

	$blogid	= $pwdiary['did'];
	$uid = $pwdiary['uid'];
	$username =	$pwdiary['username'];
	$subject = $pwdiary['subject'];
	$classid = $pwdiary['dtid'];
	$catid	=	'0';
	$viewnum = $pwdiary['r_num'];
	$replynum = $pwdiary['c_num'];
	$hot = 0;
	$dateline = $pwdiary['postdate'];
	$picflag = 1;
	$noreply = 0;
	$friend	= $pwdiary['privacy'] == 2 ? 3 : $pwdiary['privacy'];
	$password = '';
	$click1 = 0;
	$click2 = 0;
	$click3 = 0;
	$click4 = 0;
	$click5 = 0;
	$click6 = 0;
	$click7 = 0;
	$click8 = 0;

	$pic	= '';
	if($pwdiary['aid']) {
		$pic_arr =	unserialize(stripslashes($pwdiary['aid']));
		foreach($pic_arr as $t_pic){
			$pwdiary['content'] .= '<div class="uchome-message-pic"><img src="'.$discuz_url.'/data/attachment/forum/pw/diary/'.$t_pic['attachurl'].'"><p></p></div>';		//�˲��������� URL �̶�����Ϊ���ٸ���һ�ݸ���
			$pic = $t_pic['name'];
			//$picflag = 1;
		}
	}

	//pre_home_blogfield
	//$blogid = '';
	//$uid = '';
	//$pic = '';
	$tag = '';

		//��������
	if(strpos($pwdiary['content'], '[s:') !== false) {
		$smile_query = $db['source']->query("SELECT a.*, b.path AS bpath FROM {$source_tablepre}smiles a LEFT JOIN {$source_tablepre}smiles b ON a.type=b.id");
		while($smile_arr = $db['source']->fetch_array($smile_query)) {
			if($smile_arr['bpath']) {
				$search_str = '[s:'.$smile_arr['id'].']';
				$replace_str = '<img src="static/image/smiley/'.($smile_arr['bpath'] == 'default' ? 'pw_default' : $smile_arr['bpath']).'/'.$smile_arr['path'].'">';
				$pwdiary['content'] = str_replace($search_str, $replace_str, $pwdiary['content']);
			}
		}
	}
	$message	=	str_replace("\n", '<br />', $pwdiary['content']);

	$postip		=	'';
	$related	=	'a:0:{}';
	$relatedtime =	empty($pwdiary['postdate']) ? 0 : $pwdiary['postdate'];
	$target_ids	=	'';
	$hotuser	=	'';
	$magiccolor	=	0;
	$magicpaper	=	0;

	$field1	= array('blogid','uid','username','subject','classid','catid','viewnum','replynum','hot','dateline','picflag','noreply','friend','password','click1','click2','click3','click4','click5','click6','click7','click8');
	$query1 = getinsertsql("{$discuz_tablepre}home_blog", $field1);

	$field2 = array('blogid','uid','pic','tag','message','postip','related','relatedtime','target_ids','hotuser','magiccolor','magicpaper');
	$query2 = getinsertsql("{$discuz_tablepre}home_blogfield", $field2);

	if ($db['discuz']->query($query1)) {
		if ($db['discuz']->query($query2)) {
			$convertedrows ++;
		}else{
			reportlog("�޷�ת����־�������� id = $blogid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
		}
	} else {
		reportlog("�޷�ת����־ id = $blogid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query2."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>