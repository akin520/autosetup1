<?php
/*
�ռ��¼����pre_home_doing
*/
if($start <= 1){
	truncatetable('home_doing');
}

$maxrid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}owritedata"), 0);

if($start < $maxrid){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}owritedata WHERE id >= $start AND id < $start + $rpp") or dexit();
while ($record	=	$db['source']->fetch_array($query)) {
	$record		=	daddslashes($record);

	$doid		=	$record['id'];
	$uid		=	$record['uid'];
	$username	=	getusername($uid);
	$from		=	'';
	$dateline	=	$record['postdate'];
	$message	=	formatstr(convertbbcode($record['content']));
	$ip			=	'';
	$replynum	=	$record['c_num'];

	$field1		=	array('doid','uid','username','`from`','dateline','message','ip','replynum');
	$query1		=	getinsertsql("{$discuz_tablepre}home_doing", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת���ռ��¼ id = $doid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>