<?php
/*
��¼�ظ���pre_home_docomment
*/
if($start <= 1){
	truncatetable('home_docomment'); 
}

$maxcid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}comment"), 0);
if($start < $maxcid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}comment WHERE type = 'write' AND id >= $start AND id < $start + $rpp") or dexit();
while ($comment = $db['source']->fetch_array($query)) {
	$comment	=	daddslashes($comment);

	$id			=	$comment['id'];
	$upid		=	$comment['upid'];
	$doid		=	$comment['typeid'];
	$uid		=	$comment['uid'];
	$username	=	$comment['username'];
	$dateline	=	$comment['postdate'];
	$message	=	formatstr(convertbbcode($comment['title']));
	$ip			=	'';
	$grade		=	$comment['upid'] == '0' ? 1 : 2;

	$field1		=	array('id','upid','doid','uid','username','dateline','message','ip','grade');
	$query1		=	getinsertsql("{$discuz_tablepre}home_docomment", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת���ռ��¼�ظ� id = $id ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>