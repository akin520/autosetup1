<?php
/*
��᣺pre_home_album
*/
if($start <= 1) truncatetable('home_album');

$maxaid = $db['source']->result($db['source']->query("SELECT max(aid) FROM {$source_tablepre}cnalbum"), 0);
if($start < $maxaid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}cnalbum WHERE aid >= $start AND aid < $start + $rpp") or dexit();
while ($pwalbum = $db['source']->fetch_array($query)) {
	$pwalbum	=	daddslashes($pwalbum);

	$albumid	=	$pwalbum['aid'];
	$albumname	=	$pwalbum['aname'];
	$catid		=	'';
	$uid		=	$pwalbum['ownerid'];
	$username	=	$pwalbum['owner'];
	$dateline	=	$pwalbum['crtime'];
	$updatetime	=	$pwalbum['lasttime'];
	$picnum		=	$pwalbum['photonum'];
	$pic		=	$pwalbum['lastphoto'];
	$picflag	=	$pwalbum > 0 ? 1 : 0;
	$friend		=	$pwalbum['privacy'] == 2 ? 3 : $pwalbum['privacy'];
	$password	=	'';
	$target_ids	=	'';

	$field1 = array('albumid','albumname','catid','uid','username','dateline','updatetime','picnum','pic','picflag','friend','password','target_ids');
	$query1 = getinsertsql("{$discuz_tablepre}home_album", $field1);
	
	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת����� id = $albumid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>