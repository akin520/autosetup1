<?php
/*
��԰���ۣ�pre_home_comment
*/
if($start <= 1) truncatetable('home_comment');

$maxcomid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}comment"), 0);
if($start < $maxcomid) $converted = 1;

$query = $db['source']->query("SELECT * FROM {$source_tablepre}comment WHERE type != 'write' AND id >= $start AND id < $start + $rpp") or dexit();
while ($pwcomment = $db['source']->fetch_array($query)) {
	$pwcomment		=	daddslashes($pwcomment);

	$cid			=	$pwcomment['id'];
	$uid			=	$pwcomment['uid'];
	$id				=	$pwcomment['typeid'];
	switch($pwcomment['type']) {
		case 'diary':
			$idtype = 'blogid';
			break;
		case 'photo':
			$idtype = 'picid';
			break;
		case 'share':
			$idtype = 'sid';
	}
	$authorid		=	$pwcomment['uid'];
	$author			=	$pwcomment['username'];
	$ip				=	'';
	$dateline		=	$pwcomment['postdate'];
	$message		=	$pwcomment['title'];
	$magicflicker	=	0;

	$field1 = array('cid','uid','id','idtype','authorid','author','ip','dateline','message','magicflicker');
	$query1 = getinsertsql("{$discuz_tablepre}home_comment", $field1);
	
	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת������ id = $cid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>