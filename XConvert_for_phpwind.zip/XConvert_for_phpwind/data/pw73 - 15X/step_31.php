<?php
/*
ucenter����Ϣ����pre_ucenter_pms
*/
if($start <= 1) truncatetable('ucenter_pms');

$maxmid = $db['source']->result($db['source']->query("SELECT max(mid) FROM {$source_tablepre}msg"), 0);
if($start < $maxmid) $converted = 1;

$query = $db['source']->query("SELECT g.*, c.title, c.content FROM {$source_tablepre}msg g LEFT JOIN {$source_tablepre}msgc c ON g.mid = c.mid WHERE g.mid >= $start AND g.mid < $start + $rpp") or dexit();
while ($pms = $db['source']->fetch_array($query)) {
	$pms		=	array_change_key_case(daddslashes($pms));

	//$pmid			=	'';
	$msgfrom	=	$pms['username'];
	$msgfromid	=	$pms['fromuid'];
	$msgtoid	=	$pms['touid'];
	$folder		=	$pms['type'] == 'rebox' ? 'inbox' : 'outbox';
	$new		=	$pms['ifnew'];
	$subject	=	formatstr(cutstr(htmlspecialchars(trim(@strip_tags($pms['title']))), 78));

	$dateline	=	$pms['mdate'];
	$dateline	=	$dateline > $timestamp ? $timestamp : $dateline;

	$message	=	formatstr(@strip_tags(trim($pms['content'])));
	$delstatus	=	0;
	$related	=	0;
	$fromappid	=	1;

	if($subject == "�������±�����"){
		$msgfromid	= 0;
		$msgfrom	= '';
	}

	if($msgfromid && $msgtoid){
		$is_first_1 = $db['discuz']->result($db['discuz']->query("SELECT count(*) FROM {$discuz_tablepre}ucenter_pms WHERE msgfromid='$msgfromid' AND msgtoid='$msgtoid' AND related='0'"), 0);

		$is_first_2 = $db['discuz']->result($db['discuz']->query("SELECT count(*) FROM {$discuz_tablepre}ucenter_pms WHERE msgfromid='$msgtoid' AND msgtoid='$msgfromid' AND related='0'"), 0);

		if(!$is_first_1 || !$is_first_2){
			if(!$is_first_1){
				$db['discuz']->query("INSERT INTO {$discuz_tablepre}ucenter_pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus, related, fromappid) VALUES ('$msgfrom', '$msgfromid', '$msgtoid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus', '$related', '$fromappid')");
			}
			if(!$is_first_2){
				$db['discuz']->query("INSERT INTO {$discuz_tablepre}ucenter_pms (msgfrom, msgfromid, msgtoid, folder, new, subject, dateline, message, delstatus, related, fromappid) VALUES ('$msgfrom', '$msgtoid', '$msgfromid', '$folder', '$new', '$subject', '$dateline', '$message', '$delstatus', '$related', '$fromappid')");
			}
		}else{
			$db['discuz']->query("UPDATE {$discuz_tablepre}ucenter_pms SET subject='$subject', dateline='$dateline' AND message='$message' WHERE msgfrom='$msgfromid' AND msgtoid='$msgtoid' AND related='0'");
		}
		$related	=	1;
	}elseif($msgfromid && !$msgtoid){
		$converted = 1;
		$totalrows ++;
		continue;
	}

	$field1 = array('msgfrom','msgfromid','msgtoid','folder','new','subject','dateline','message','delstatus','related','fromappid');
	$query1 = getinsertsql("{$discuz_tablepre}ucenter_pms", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת������Ϣ $subject");
	}

	$converted = 1;
	$totalrows ++;
}
?>