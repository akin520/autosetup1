<?php
/*
�������ӱ���pre_common_friendlink
*/
if($start<=1) {
	truncatetable('common_friendlink');
}

$query	=	$db['source']->query("SELECT * FROM {$source_tablepre}sharelinks ORDER BY sid ASC") or dexit();
while ($pwsharelinks 	= $db['source']->fetch_array($query)) {
	$forumlink		=	daddslashes($pwsharelinks);
	
	//$id			=	0;
	$displayorder	=	$pwsharelinks['threadorder'];
	$name			=	cutstr(htmlspecialchars(@strip_tags(trim($pwsharelinks['name']))), 98);
	$url			=	$pwsharelinks['url'];
	$description	=	($pwsharelinks['ifcheck'] && $pwsharelinks['ifcheck'] < 0) ? $pwsharelinks['descrip'] : '';
	$logo			=	$pwsharelinks['logo'];
	$type			=	2;

	$field1			=	array('displayorder','name','url','description','logo','type');
	$query1			=	getinsertsql("{$discuz_tablepre}common_friendlink", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog();
	}
	$totalrows ++;
}
?>