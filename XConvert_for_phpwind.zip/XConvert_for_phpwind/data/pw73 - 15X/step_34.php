<?php
/*
�ղؼб���pre_home_favorite
*/
if($start <= 1) truncatetable('home_favorite');

$maxuid = $db['source']->result($db['source']->query("SELECT max(uid) FROM {$source_tablepre}favors"), 0);
if($start < $maxuid) $converted = 1;

$query = $db['source']->query("SELECT * FROM {$source_tablepre}favors WHERE uid >= $start AND uid < $start + $rpp") or dexit();
while ($favorite = $db['source']->fetch_array($query)) {
	$favorite	=	daddslashes($favorite);
	
	//pre_home_favorite
	//$favid	=	'';
	$uid	=	$favorite['uid'];
	$tids	=	explode(',', $favorite['tids']);
	//$idtype	=	'';
	$spaceuid	=	'';
	//$title	=	'';
	//$description	=	'';
	//$dateline	=	0;


	$query1 = "INSERT INTO {$discuz_tablepre}home_favorite (uid,id,spaceuid) VALUES ";
	$sqladd = $comma = '';
	foreach($tids AS $tid) {
		$tid = intval($tid);
		if($tid) {
			$spaceuid	=	$db['discuz']->result($db['discuz']->query("SELECT authorid FROM {$discuz_tablepre}forum_thread WHERE tid='$tid'"));
			$sqladd .= "$comma ('$uid', '$tid', '$spaceuid')";
			$comma = ',';
		}
	}

	if(!$sqladd) {
		continue;
	} else {
		$query1 = $query1.$sqladd;
	}

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("ת���ղؼг�����SQL��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>