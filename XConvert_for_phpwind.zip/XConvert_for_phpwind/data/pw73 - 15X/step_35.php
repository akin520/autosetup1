<?php
/*
tag����pre_ucenter_tags
*/
if($start <= 1) {
	truncatetable('ucenter_tags');
}
$maxtagid = $db['source']->result($db['source']->query("SELECT max(tagid) FROM {$source_tablepre}tags"), 0);
if($start < $maxtagid){
	$converted = 1;
}

$query 		= $db['source']->query("SELECT * FROM {$source_tablepre}tags WHERE tagid >= $start AND tagid < $start + $rpp") or dexit();
while($t 	= $db['source']->fetch_array($query)) {
	$tags 		= daddslashes($tags);
	//pre_uc_tags
	$tagname 	=	$tags['tagname'];
	$appid		=	'';
	$data		=	'';
	$expiration	=	'';

	$field1		=	array('tagname','appid','data','expiration');
	$query1		=	getinsertsql("{$discuz_tablepre}ucenter_tags", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows++;
	} else {
		reportlog("���� UC tag ���ݳ���, tagname = $tagname");
	}
	$totalrows ++;
}
?>