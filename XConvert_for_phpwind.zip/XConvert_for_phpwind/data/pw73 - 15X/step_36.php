<?php
/*
��̳���棺pre_forum_announcement
*/
truncatetable('forum_announcement');

$query = $db['source']->query("SELECT * FROM {$source_tablepre}announce WHERE fid<0 ORDER BY aid ASC") or dexit();
while ($pwannounce 	= $db['source']->fetch_array($query)) {
	$pwannounce		=	daddslashes($pwannounce);

	//$id			=	'';
	$author			=	$pwannounce['author'];
	$subject		=	cutstr(htmlspecialchars(trim(@strip_tags($pwannounce['subject']))), 250);
	$type			=	$pwannounce['url'] ? 1 : 0;
	$displayorder	=	$pwannounce['vieworder'];
	$starttime		=	$pwannounce['startdate'];
	$endtime		=	$pwannounce['enddate'];
	$message		=	$type == '1' ? $pwannounce['url'] : $pwannounce['content'];
	$groups			=	'';

	$field1			=	array('author','subject','type','displayorder','starttime','endtime','message','groups');
	$query1			=	getinsertsql("{$discuz_tablepre}forum_announcement", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("ת����̳������� subject=$subject");
	}
	$totalrows ++;
}
?>