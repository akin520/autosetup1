<?php
/*
��������Ա
pre_common_admincp_group
pre_common_admincp_member
*/

truncatetable('common_admincp_member');

$query = $db['discuz']->query("SELECT uid FROM {$discuz_tablepre}common_member WHERE adminid=1 and groupid=1") or dexit();
while ($dzmember 	= $db['discuz']->fetch_array($query)) {
	$uid	=	$dzmember['uid'];
	$cpgroupid	= '0';
	$customperm	= '';
	if($uid == '1'){
		continue;
	}
	$field1	=	array('uid','cpgroupid','customperm');
	$query1	=	getinsertsql("{$discuz_tablepre}common_admincp_member", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("��������Ա���� uid=$uid");
	}
	$totalrows ++;
}
?>