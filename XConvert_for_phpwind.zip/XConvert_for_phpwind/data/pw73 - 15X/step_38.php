<?php
/*
�������
*/

$query = $db['source']->query("select fid,url,content from {$source_tablepre}announce group by fid order by startdate DESC") or dexit();
while ($pwannounce 	= $db['source']->fetch_array($query)) {
	$pwannounce		=	daddslashes($pwannounce);

	$fid	=	$pwannounce['fid'];
	$type	=	$pwannounce['url'] ? 1 : 0;
	$rules	=	$type == '1' ? $pwannounce['url'] : daddslashes(nl2br(@strip_tags(convertbbcode($pwannounce['content']))));

	$query1	=	"UPDATE {$discuz_tablepre}forum_forumfield set rules='$rules' WHERE fid='$fid'";

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("���������� fid=$fid");
	}
	$totalrows ++;
}
?>