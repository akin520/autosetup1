<?php
/*
����������pre_forum_threadclass
*/
truncatetable('forum_threadclass');

$typeid = 0;
$query = $db['source']->query("SELECT fid, t_type FROM {$source_tablepre}forums WHERE t_type <> '' ORDER BY fid ASC") or dexit();
while($pwforums = $db['source']->fetch_array($query)) {
	$typearray = $t_type = array();
	$pwforums				=	daddslashes($pwforums);

	$fid				=	$pwforums['fid'];
	$t_type				=	daddslashes(array_filter(explode("\t", $pwforums['t_type'])));
	$typearray			=	array();

	$typearray['status'] = $t_type[0] == 0 ? 0 : 1;
	$typearray['required'] = $t_type[0] == 2 ? 1 : 0;
	$typearray['listable'] = 1;
	$typearray['prefix'] = 1;
	unset($t_type[0]);

	$i = 0;
	foreach($t_type as $pwtype) {
		//pre_forum_threadclass
		$typeid = $typeid+1;
		$typearray['types'][$typeid] = $pwtype;
		$typearray['icons'][$typeid] = '';

		$name = $pwtype;
		$displayorder = ++$i;
		$icon = '';

		$field1	= array('typeid','fid','name','displayorder','icon');
		$query1	= getinsertsql("{$discuz_tablepre}forum_threadclass", $field1);

		if($db['discuz']->query($query1)){
			$convertedrows ++;
		}
		$totalrows ++;
	}


	$threadtypes 			=	daddslashes(serialize($typearray));
	$db['discuz']->query("UPDATE {$discuz_tablepre}forum_forumfield SET threadtypes='$threadtypes' WHERE fid='$fid'");
}
?>