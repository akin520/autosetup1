<?php
/*
�������pre_forum_thread
*/
if($start <= 1) {
	truncatetable('forum_thread');
}

$maxtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}threads"), 0);
if($start < $maxtid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}threads WHERE tid >= $start AND tid <$start + $rpp") or dexit();

while ($pwthread = $db['source']->fetch_array($query)) {
	$pwthread			=	daddslashes($pwthread);

	//��������
	//pre_forum_thread
	$tid				=	$pwthread['tid'];
	$fid				=	$pwthread['fid'];
	$posttableid		=	0;
	$typeid				=	$db['discuz']->result($db['discuz']->query("SELECT typeid FROM {$discuz_tablepre}forum_threadclass WHERE fid='{$fid}' AND displayorder='{$pwthread['type']}' LIMIT 1"));
	$sortid				=	'';					//������ϢID
	$readperm			=	0;					//�Ķ�Ȩ��
	$price				=	0;					//���ۼ۸�
	$author				=	cutstr(htmlspecialchars(trim($pwthread['author'])), 15);
	$authorid			=	$pwthread['authorid'];
	$subject			=	formatstr(cutstr(trim(@strip_tags($pwthread['subject'])), 78));//formatstrȥ���ַ�����β��'\'
	$dateline			=	$pwthread['postdate'] > $timestamp ? $timestamp : $pwthread['postdate'];
	$lastpost			=	$pwthread['lastpost'] > $timestamp ? $timestamp : $pwthread['lastpost'];
	$lastposter			=	cutstr(htmlspecialchars(trim($pwthread['lastposter'])), 15);
	$views				=	$pwthread['hits'];
	$replies			=	$pwthread['replies'];
	$displayorder		=	in_array($pwthread['topped'],array(0,1,2,3)) ? $pwthread['topped'] : 0;
	$highlight			=	$pwthread['titlefont'] ? gethighlightid($pwthread['titlefont']) : 0;
	$digest				=	in_array($pwthread['digest'],array(0,1,2,3)) ? $pwthread['digest'] : 0;
	$rate				=	0;
	switch ($pwthread['special']) {
		case 0:			//��ͨ
			$special = 0;
			break;
		case 1:			//ͶƱ
			$special = 1;
			break;
		case 22:			//�-----
			$special = 4;
			break;
		case 3:			//����
			$special = 3;
			break;
		case 4:			//��Ʒ
			$special = 2;
			break;
		case 5:			//����
			$special = 5;
			break;
	}
	$attachment			=	$pwthread['ifupload'] ? 1 : 0;
	$moderated			=	0;
	$closed				=	$pwthread['locked'] ? 1 : 0;
	$stickreply			=	0;
	$recommends			=	0;
	$recommend_add		=	0;
	$recommend_sub		=	0;
	$heats				=	0;
	$status				=	0;
	$isgroup			=	0;

	if($special == 1) {
	} elseif($special == 2) {
	} elseif($special == 3) {
		$query_3 = $db['source']->query("SELECT cbtype FROM {$source_tablepre}reward WHERE tid='$tid'");
		if($cbtypeprice = $db['source']->result($query_3, 0)) {
			$price = $cbtypeprice;
		} else {
			$price = 0;
		}

	} elseif($special == 4) {
	} elseif($special == 5) {
	}

	$field1				=	array('tid','fid','posttableid','typeid','sortid','readperm','price','author','authorid','subject','dateline','lastpost','lastposter','views','replies','displayorder','highlight','digest','rate','special','attachment','moderated','closed','stickreply','recommends','recommend_add','recommend_sub','heats','status','isgroup');
	$query1				=	getinsertsql("{$discuz_tablepre}forum_thread", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת������ tid = $tid subject = '$subject'��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}

	$totalrows ++;
}
?>