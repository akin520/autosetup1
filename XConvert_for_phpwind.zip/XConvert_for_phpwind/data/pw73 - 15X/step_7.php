<?php
/*
ת���ظ�������
pre_forum_post
pre_forum_postcomment
pre_forum_ratelog
*/

if($start <= 1 && $tableid == 0) {
	truncatetable('forum_post_tableid');
	truncatetable('forum_post');
	truncatetable('forum_ratelog');
	truncatetable('forum_attachment');
	truncatetable('forum_attachmentfield');
	$ptblquery = $db['source']->query("SELECT db_value FROM {$source_tablepre}config WHERE db_name = 'db_plist'");
	$t_result = $db['source']->result($ptblquery);
	$t_list = unserialize($t_result);
	if(empty($t_list)){
		$tablelist = ','.$t_result;
		$maxtableid = substr($tablelist, (strrpos($tablelist, ',') + 1));
	} else {
		$tablelist = $t_list;
		$maxtableid = is_array($tablelist) ? (count($tablelist)-1) : 0;
	}
}

$tableid = isset($tableid) ? $tableid : 0;
$maxtableid = isset($maxtableid) ? $maxtableid : 0;
$tnum = $tableid == 0 ? '' : $tableid;
$maxpid = $db['source']->result($db['source']->query("SELECT max(pid) FROM {$source_tablepre}posts{$tnum}"), 0);
if($start < $maxpid){
	$converted = 1;
}

$pwcredits = array();
$cquery = $db['source']->query("SELECT db_value, db_name FROM {$source_tablepre}config WHERE db_name IN ('db_moneyname', 'db_rvrcname', 'db_creditname', 'db_currencyname')");
$ci = 1;
while($thecredits = $db['source']->fetch_array($cquery)) {
	$ci++;
	switch($thecredits['db_name']) {
		case 'db_moneyname':
			$pwcredits[$thecredits['db_value']] = 2;
			break;
		case 'db_rvrcname':
			$pwcredits[$thecredits['db_value']] = 1;
			break;
		case 'db_creditname':
			$pwcredits[$thecredits['db_value']] = 3;
			break;
		case 'db_currencyname':
			$pwcredits[$thecredits['db_value']] = 4;
			break;
	}

}
$cquery = $db['source']->query("SELECT name FROM {$source_tablepre}credits");
while($thecredits = $db['source']->fetch_array($cquery)) {
	$pwcredits[$thecredits['name']] = $ci++;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}posts{$tnum} WHERE pid >= $start AND pid < $start + $rpp") or dexit();
while ($pwpost = $db['source']->fetch_array($query)) {
	$pwpost			=	daddslashes($pwpost);

	//pre_forum_post
	$pid			=	$pwpost['pid'];
	$fid			=	$pwpost['fid'];
	$tid			=	$pwpost['tid'];
	$first			=	0;
	$author			=	cutstr(htmlspecialchars(trim($pwpost['author'])), 15);
	$authorid		=	$pwpost['authorid'];
	$subject		=	daddslashes(cutstr(htmlspecialchars(trim(@strip_tags($pwpost['subject']))), 78));//formatstrȥ���ַ�����β��'\'
	$dateline		=	$pwpost['postdate'];
	$message		=	daddslashes(convertbbcode($pwpost['content'] ? $pwpost['content'] : htmlspecialchars(trim($pwpost['subject']))));//formatstrȥ���ַ�����β��'\'
	$useip			=	$pwpost['userip'];
	$invisible		=	0;
	$anonymous		=	$pwpost['anonymous'];
	$usesig			=	$pwpost['ifsign']%2 == 0 ? 0 : 1;
	$htmlon			=	$pwpost['ifsign'] < 2 ? 0 : 1;
	$bbcodeoff		=	0;
	$smileyoff		=	0;
	$parseurloff	=	0;
	$attachment		=	$pwpost['aid'] ? 1 : 0;
	$rate			=	0;
	$ratetimes		=	0;
	$status			=	$pwpost['ifshield'];
	$tags			=	'';
	$comment		=	0;

	if($pwpost['ifmark'] != ''){
		//pre_forum_ratelog
		//$pid			=	'';
		$uid			=	0;
		$element		=	array();
		$ifmarkarr		=	explode("\t", $pwpost['ifmark']);
		foreach($ifmarkarr as $ifmark){
			preg_match_all("/(.+?):[+-](\d+?)\((.+)\)(.*)/is", $ifmark, $element);
			$rate += $element['2']['0'];
			$username = $element['3']['0'];
			$extcredits = $pwcredits[$element['1']['0']] ? $pwcredits[$element['1']['0']] : 1;
			$score = $element['2']['0'];
			$reason = $element['4']['0'];
			$uid = getuid($username);
			$field3	= array('pid','uid','username','extcredits','dateline','score','reason');
			$query3	= getinsertsql("{$discuz_tablepre}forum_ratelog", $field3);
			$db['discuz']->query($query3);
		}
		$ratetimes = $rate;
		$uid = 0;
	}

	$field1 = array('pid');
	$query1 = getinsertsql("{$discuz_tablepre}forum_post_tableid", $field1);

	$field2 = array('pid','fid','tid','first','author','authorid','subject','dateline','message','useip','invisible','anonymous','usesig','htmlon','bbcodeoff','smileyoff','parseurloff','attachment','rate','ratetimes','status','tags','comment');
	$query2 = getinsertsql("{$discuz_tablepre}forum_post", $field2);

	$field3	= array('pid','uid','username','extcredits','dateline','score','reason');
	$query3	= getinsertsql("{$discuz_tablepre}forum_ratelog", $field3);

	if($db['discuz']->query($query1)) {
		if ($db['discuz']->query($query2)) {
			if($attachment) {
				$query_att = $db['source']->query("SELECT * FROM {$source_tablepre}attachs WHERE tid = '$tid' AND pid = '$pid'");
				while ($att = $db['source']->fetch_array($query_att)) {
					//pre_forum_attachment
					$aid			=	$att['aid'];
					//$tid			=	'';
					//$pid			=	'';
					$width			=	0;
					$dateline		=	$att['uploadtime'];
					$readperm		=	0;
					$price			=	0;
					$filename		=	daddslashes(cutstr(htmlspecialchars(trim($att['name'])), 100));
					$filetype		=	getfiletype($att['name']);
					$filesize		=	intval($att['size']) * 1024;
					$attachment		=	'pw/'.$att['attachurl'];
					$downloads		=	$att['hits'];
					$isimage		=	in_array($filetype, array('image/pjpeg', 'image/gif', 'image/bmp', 'image/png')) ? 1 : 0;
					$uid			=	$authorid;
					$thumb			=	0;
					$remote			=	0;

					//pre_forum_attachmentfield
					//$aid			=	'';
					//$tid			=	'';
					//$pid			=	'';
					//$uid			=	'';
					$description	=	daddslashes(cutstr(htmlspecialchars(trim($att['descrip'])), 100));

					$field4			=	array('aid','tid','pid','width','dateline','readperm','price','filename','filetype','filesize','attachment','downloads','isimage','uid','thumb','remote');
					$query4			=	getinsertsql("{$discuz_tablepre}forum_attachment", $field4);

					$field5			=	array('aid','tid','pid','uid','description');
					$query5			=	getinsertsql("{$discuz_tablepre}forum_attachmentfield", $field5);

					$db['discuz']->query($query4);
					$db['discuz']->query($query5);
				}
			}
			$convertedrows++;
		} else {
			$db['discuz']->query("DELETE FROM {$discuz_tablepre}forum_post_tableid WHERE pid='$pid'");
			reportlog("�޷�ת������ pid = $pid subject = '$subject'");
		}
	} else {
		reportlog("ת������ʱ���� pid=$pid");
	}
	$converted = 1;
	$totalrows ++;
}

if($converted || $end < $maxid) {
	$nowtableid = $tableid + 1;
	showmessage("���ڴ����� $nowtableid �ֱ��ĵ� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.$tableid.'&maxtableid='.$maxtableid);
} elseif($tableid < $maxtableid) {
	$nextid = $tableid + 1;
	$nexttableid = $tableid + 2;
	unset($start);
	unset($end);
	showmessage("�� $nextid �ֱ����ݴ������, ��������� $nexttableid �ֱ���ת��", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.$nextid.'&maxtableid='.$maxtableid);
}
?>