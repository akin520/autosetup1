<?php
/*
ת��������������������������ӱ��Ƿֿ���
pre_forum_post
pre_forum_ratelog
pre_forum_attachment
pre_forum_attachmentfield
*/

if($start <= 1 && $tableid == 0) {
	$ttblquery = $db['source']->query("SELECT db_value FROM {$source_tablepre}config WHERE db_name = 'db_tlist'");
	$ttablelist = unserialize($db['source']->result($ttblquery));
	if(isset($ttablelist[0])) {
		$maxtableid = is_array($ttablelist) ? count($ttablelist)-1 : 0;
	} else {
		$maxtableid = is_array($ttablelist) ? count($ttablelist) : 0;
	}
}

$pwcredits = array();
$cquery = $db['source']->query("SELECT db_value, db_name FROM {$source_tablepre}config WHERE db_name IN ('db_moneyname', 'db_rvrcname', 'db_creditname', 'db_currencyname')");
$ci = 1;
while($thecredits = $db['source']->fetch_array($cquery)) {
	$ci++;
	switch($thecredits['db_name']) {
		case 'db_moneyname':
			$pwcredits[$thecredits['db_value']] = 2;
			break;
		case 'db_rvrcname':
			$pwcredits[$thecredits['db_value']] = 1;
			break;
		case 'db_creditname':
			$pwcredits[$thecredits['db_value']] = 3;
			break;
		case 'db_currencyname':
			$pwcredits[$thecredits['db_value']] = 4;
			break;
	}

}
$cquery = $db['source']->query("SELECT name FROM {$source_tablepre}credits");
while($thecredits = $db['source']->fetch_array($cquery)) {
	$pwcredits[$thecredits['name']] = $ci++;
}

$tableid = isset($tableid) ? $tableid : 0;
$maxtableid = isset($maxtableid) ? $maxtableid : 0;
$tnum = $tableid == 0 ? '' : $tableid;
$maxtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}tmsgs{$tnum}"), 0);
if($start < $maxtid){
	$converted = 1;
}

$query = $db['source']->query("SELECT m.*, m.ifmark as tifmark, t.* FROM {$source_tablepre}tmsgs{$tnum} m LEFT JOIN {$source_tablepre}threads t ON t.tid = m.tid WHERE m.tid >= $start AND m.tid < $start + $rpp");

while ($pwtmsgs = $db['source']->fetch_array($query)) {
	$pwtmsgs		=	daddslashes($pwtmsgs);

	//pre_forum_post
	//$pid			=	$pwtmsgs['pid'];
	$opid			=	$pwtmsgs['pid'];
	$fid			=	$pwtmsgs['fid'];
	$tid			=	$pwtmsgs['tid'];
	$first			=	1;
	$author			=	cutstr(htmlspecialchars(trim($pwtmsgs['author'])), 15);
	$authorid		=	$pwtmsgs['authorid'];
	$subject		=	daddslashes(cutstr(htmlspecialchars(trim(@strip_tags($pwtmsgs['subject']))), 78));//formatstrȥ���ַ�����β��'\'
	$dateline		=	$pwtmsgs['postdate'];
	if(strpos($pwtmsgs['content'], '[sell=') !== false) {
		if(preg_match('/\[sell=(\d+)(,money)*\]/i', $pwtmsgs['content'], $match)) {
			$db['discuz']->query("UPDATE {$discuz_tablepre}forum_thread SET price='{$match[1]}' WHERE tid='{$tid}' LIMIT 1");
			$pwtmsgs['content'] = '[free]'.$pwtmsgs['content'].'[/free]';
		}
	}
	$message		=	convertbbcode($pwtmsgs['content'] ? $pwtmsgs['content'] : htmlspecialchars(trim($pwtmsgs['subject'])));
	$useip			=	$pwtmsgs['userip'];
	$invisible		=	0;
	$anonymous		=	$pwtmsgs['anonymous'];
	$usesig			=	$pwtmsgs['ifsign']%2 == 0 ? 0 : 1;
	$htmlon			=	$pwtmsgs['ifsign'] < 2 ? 0 : 1;
	$bbcodeoff		=	0;
	$smileyoff		=	0;
	$parseurloff	=	0;
	$attachment		=	$pwtmsgs['aid'] ? 1 : 0;
	$rate			=	0;
	$ratetimes		=	0;
	$status			=	0;
	$tags			=	'';
	$comment		=	0;

	$field1 = array('pid');
	$query1 = getinsertsql("{$discuz_tablepre}forum_post_tableid", $field1);

	if($db['discuz']->query($query1)){	//
		$pid = $db['discuz']->insert_id();
		if($pwtmsgs['tifmark'] != '') {
			//pre_forum_ratelog
			$uid			=	0;
			$element		=	array();
			$ifmarkarr		=	explode("\t", $pwtmsgs['tifmark']);
			foreach($ifmarkarr as $ifmark){
				preg_match_all("/(.+?):[+-](\d+?)\((.+)\)(.*)/is", $ifmark, $element);
				$rate += $element['2']['0'];
				$username = $element['3']['0'];
				$extcredits = $pwcredits[$element['1']['0']] ? $pwcredits[$element['1']['0']] : 1;
				$score = $element['2']['0'];
				$reason = $element['4']['0'];
				$uid = getuid($username);
				$field3	= array('pid','uid','username','extcredits','dateline','score','reason');
				$query3	= getinsertsql("{$discuz_tablepre}forum_ratelog", $field3);
				$db['discuz']->query($query3);
			}
			$db['discuz']->query("UPDATE {$discuz_tablepre}forum_thread SET rate='1' WHERE tid='{$tid}' LIMIT 1");
			$ratetimes = $rate;
			$uid = 0;
		}
		$field2	 =	array('pid','fid','tid','first','author','authorid','subject','dateline','message','useip','invisible','anonymous','usesig','htmlon','bbcodeoff','smileyoff','parseurloff','attachment','rate','ratetimes','status','tags','comment');
		$query2	 =	getinsertsql("{$discuz_tablepre}forum_post", $field2);
		if ($db['discuz']->query($query2)) {
			if($attachment) {
				$query_att = $db['source']->query("SELECT * FROM {$source_tablepre}attachs WHERE tid = '$tid' AND pid = '0'");
				while ($att = $db['source']->fetch_array($query_att)) {
					//pre_forum_attachment
					$aid			=	$att['aid'];
					//$tid			=	'';
					//$pid			=	'';
					$width			=	0;
					$dateline		=	$att['uploadtime'];
					$readperm		=	0;
					$price			=	0;
					$filename		=	daddslashes(cutstr(htmlspecialchars(trim($att['name'])), 100));
					$filetype		=	getfiletype($att['name']);
					$filesize		=	intval($att['size']) * 1024;
					$attachment		=	'pw/'.$att['attachurl'];
					$downloads		=	$att['hits'];
					$isimage		=	in_array($filetype, array('image/pjpeg', 'image/gif', 'image/bmp', 'image/png')) ? 1 : 0;
					$uid			=	$authorid;
					$thumb			=	0;
					$remote			=	0;

					//pre_forum_attachmentfield
					//$aid			=	'';
					//$tid			=	'';
					//$pid			=	'';
					//$uid			=	'';
					$description	=	daddslashes(cutstr(htmlspecialchars(trim($att['descrip'])), 100));

					$field4			=	array('aid','tid','pid','width','dateline','readperm','price','filename','filetype','filesize','attachment','downloads','isimage','uid','thumb','remote');
					$query4			=	getinsertsql("{$discuz_tablepre}forum_attachment", $field4, 0);

					$field5			=	array('aid','tid','pid','uid','description');
					$query5			=	getinsertsql("{$discuz_tablepre}forum_attachmentfield", $field5, 0);

					$db['discuz']->query($query4);
					$db['discuz']->query($query5);
				}
			}
			$convertedrows ++;
			unset($pid);
		} else {
			$db['discuz']->query("DELETE FROM {$discuz_tablepre}forum_post_tableid WHERE pid='$pid'");
			reportlog("ת������������ tid=$tid pid=$pid ");
		}
	} else {
		reportlog("ת������������ pid=$pid ");
	}
	$converted = 1;
	$totalrows ++;
}

if($converted) {
	$nowtableid = $tableid + 1;
	showmessage("���ڴ����� $nowtableid �ֱ��ĵ� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.$tableid.'&maxtableid='.$maxtableid);
} elseif($tableid < $maxtableid) {
	$nextid = $tableid + 1;
	$nexttableid = $tableid + 2;
	unset($start);
	unset($end);
	showmessage("�� $nextid �ֱ����ݴ������, ��������� $nexttableid �ֱ���ת��", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.$nextid.'&maxtableid='.$maxtableid);
}
?>