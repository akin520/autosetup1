<?php
/*
pre_common_member
pre_common_member_magic
pre_common_member_count
pre_common_member_field_forum
pre_common_member_field_home
pre_common_member_status
*/
if($start <= 1) {
	truncatetable('ucenter_members');
	truncatetable('ucenter_memberfields');

	truncatetable('common_member');
	truncatetable('common_member_count');
	truncatetable('common_member_field_forum');
	truncatetable('common_member_field_home');
	truncatetable('common_member_profile');
	truncatetable('common_member_status');

	//Ϊ��ת��ͷ�񲢽����û�ת��ʱ�Ĳ����Ѷȣ����� pre_common_member ���ݿ�������һ���ֶΣ�
	$co_query	=	$db['discuz']->query("show columns from {$discuz_tablepre}common_member like 'avatar'");
	$avatar_arr =	$db['discuz']->fetch_array($co_query);
	if(!$avatar_arr['Field'] == 'avatar') {
		if(!$db['discuz']->query("ALTER TABLE {$discuz_tablepre}common_member ADD avatar VARCHAR(255) NOT NULL DEFAULT '' COMMENT '��Ϊת��ͷ������ӵ��ֶΣ�ͷ��ת�������󣬴��ֶο�ɾ��'")) {
			reportlog("�����û�ͷ���ֶ�ʧ�ܣ�ת����ɺ������û�ͷ�񽫱���ΪϵͳĬ��ͷ��");
		}
	}
	addmedals();//ת��ѫ��
}
$maxuserid = $db['source']->result($db['source']->query("SELECT max(uid) FROM {$source_tablepre}members"), 0);

if($start < $maxuserid){
	$converted = 1;
}
$query = $db['source']->query("SELECT m.*, m.uid as muid, md.*, g.gid, g.gptype, g.grouptitle FROM {$source_tablepre}members m LEFT JOIN {$source_tablepre}memberdata md ON md.uid=m.uid LEFT JOIN {$source_tablepre}usergroups g ON g.gid=m.groupid WHERE m.uid>=$start AND m.uid<$start+$rpp") or dexit();
while($pwmember = $db['source']->fetch_array($query)) {
	$pwmember =	daddslashes(array_change_key_case($pwmember));
	
	$uid = $pwmember['uid'];
	if(empty($uid)){
		continue;
	}
	$username = trim(stripslashes($pwmember['username']));
	
	if(!$username || $username != htmlspecialchars(daddslashes($username))) {
		reportlog("�Ƿ��û��� <b><font color='red'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
	} elseif(strlen($username) > 15) {
		reportlog("�û��� <b><font color='orange'>$username</font></b> ���ȴ��� 15�����ܱ�ת����uid = $uid ��<br>\r\n");
	} elseif(getuid($username)) {
			reportlog("�ظ��û��� <b><font color='blue'>$username</font></b> ���ܱ�ת����uid = $uid ��<br>\r\n");
	} else {
		
		//uc members
		$ucpw			=	convertucpw($pwmember['password']);
		$password		=	$ucpw['password'];
		$email			=	cutstr($pwmember['email'], 32);
		$myid			=	'';
		$myidkey		=	'';

		$t_r			=	gexplode($pwmember['onlineip'], 0, '|');
		$regip			=	substr($t_r, -1) == '*' ? trim(substr($t_r, 0, -1)) : $t_r;

		$regdate		=	$pwmember['regdate'];
		$lastloginip	=	$regip;

		$t_lt	=	gexplode($pwmember['onlineip'], 1, '|');
		$lastlogintime	=	$t_lt ? $t_lt : ($pwmember['lastvisit'] ? $pwmember['lastvisit'] : $timestamp);

		$salt			=	$ucpw['salt'];
        $secques        =    '';

		//uc memberfields
		$blacklist		=	'';

		//pre_common_member
		//$uid				=	'';
		//$email				=	'';
		//$username			=	'';
		//$password			=	'';

		//Ϊ�˷���ת��ͷ�����������ݿ������Ӵ��ֶ�
		$avatarinfo	= explode('|', $pwmember['icon']);
		($avatarinfo[1] !=2 && $avatarinfo[1] != 3) && $avatarinfo[1] = 1;		//1��ϵͳͷ��  2��Զ��ͼƬ  3���ϴ�ͷ��
		if($avatarinfo[1] == 2 || $avatarinfo[1] == 3) {
			$avatar	=	$avatarinfo[1] == 2 ? $avatarinfo[0] : 'customavatars/data/attachment/forum/pw/upload/'.$avatarinfo[0];
		} elseif($avatarinfo[1] == 1 && $avatarinfo[0]) {
			$avatar	=	'images/data/avatar/face/'.$avatarinfo[0];
		} else {
			$avatar	=	'';
		}

		$status				=	$pwmember['userstatus'];
		$emailstatus		=	$pwmember['userstatus']	== '192' ? 1 : 0;
		$avatarstatus		=	0;
		$videophotostatus	=	0;
		$adminid			=	$pwmember['groupid'];
		$groupid			=	$pwmember['memberid'];
		if($pwmember['groupid'] == 3) {
			$adminid	=	$groupid = 1;
		} elseif($pwmember['groupid'] == 4) {
			$adminid	=	$groupid = 2;
		} elseif($pwmember['groupid'] == 5) {
			$adminid	=	$groupid = 3;
		} elseif($pwmember['groupid'] == 6) {
			$adminid	=	-1;
			$groupid	=	4;
		} elseif($pwmember['groupid'] == 7) {
			$adminid	=	0;
			$groupid	=	8;
		} elseif($pwmember['gptype'] == 'special' || $pwmember['gptype'] == 'system') {
			$adminid	=	0;
			$groupid	=	20;
		} else {
			$adminid	=	0;
			$groupid	=	10;
		}
		$groupexpiry	=	0;
		$extgroupids	=	'';
		$regdate		=	$pwmember['regdate'];
		$credits		=	(isset($pwmember['rvrc']) && $pwmember['rvrc']) ? floor($pwmember['rvrc']/10) : 0;		//����
		$notifysound	=	0;
		$timeoffset		=	empty($pwmember['timedf']) ? '8': $pwmember['timedf'];
		$newpm			=	$pwmember['newpm'];
		$newprompt		=	0;
		$accessmasks	=	0;
		$allowadmincp	=	0;

		//pre_common_member_count
		//$uid				=	'';
		$extcredits1		=	$pwmember['rvrc'];			//����
		$extcredits2		=	$pwmember['money'];			//ͭ��
		$extcredits3		=	$pwmember['credit'];		//����ֵ
		$extcredits4		=	0;
		$extcredits5		=	0;
		$extcredits6		=	0;
		$extcredits7		=	0;
		$extcredits8		=	0;
		$friends			=	0;
		$posts				=	$pwmember['postnum'];
		$threads			=	0;
		$digestposts		=	$pwmember['digests'];
		$doings				=	0;
		$blogs				=	0;
		$albums				=	0;
		$sharings			=	0;
		$attachsize			=	0;
		$views				=	0;

		//pre_common_member_field_forum
		//$uid				=	'';
		$publishfeed		=	0;
		$customshow			=	26;
		$customstatus		=	'';

		//ѫ��
		$medalcomma = $medals = $mdvar = '';
		if ($pwmember['medals']) {
			$medalarray	=	explode(',', $pwmember['medals']);
			foreach($medalarray as $mdvar) {
				$medals	.=	$medalcomma.(intval($mdvar) + 10);
				$medalcomma	= "\t";
			}
		}

		$sightml			=	$pwmember['honor'];
		$groupterms			=	'';
		$authstr			=	'';
		$groups				=	'';
		$attentiongroup		=	'';

		//pre_common_member_field_home
		//$uid				=	'';
		$videophoto			=	'';
		$spacename			=	'';
		$spacedescription	=	'';
		$domain				=	'';
		$addsize			=	0;
		$addfriend			=	0;
		$theme				=	'';
		$spacecss			=	'';
		$blockposition		=	'';
		$recentnote			=	'';
		$spacenote			=	'';
		$privacy			=	'';
		$feedfriend			=	'';
		$acceptemail		=	'';

		//pre_common_member_profile
		//$uid				=	'';
		$gender				=	$pwmember['gender'];
		$birthyear			=	gexplode($pwmember['bday'], 0);
		$birthmonth			=	gexplode($pwmember['bday'], 1);
		$birthday			=	gexplode($pwmember['bday'], 2);
		$constellation		=	'';
		$zodiac				=	'';
		$telephone			=	'';
		$mobile				=	'';
		$idcardtype			=	'';
		$idcard				=	'';
		$address			=	$pwmember['location'];
		$zipcode			=	'';
		$nationality		=	'';
		$birthprovince		=	'';
		$birthcity			=	'';
		$resideprovince		=	'';
		$residecity			=	'';
		$residedist			=	'';
		$residecommunity	=	'';
		$residesuite		=	'';
		$graduateschool		=	'';
		$company			=	'';
		$education			=	'';
		$occupation			=	'';
		$position			=	'';
		$revenue			=	'';
		$affectivestatus	=	'';
		$lookingfor			=	'';
		$bloodtype			=	'';
		$height				=	'';
		$weight				=	'';
		$alipay				=	'';
		$icq				=	$pwmember['icq'];
		$qq					=	'';
		$yahoo				=	$pwmember['yahoo'];
		$msn				=	$pwmember['msn'];
		$taobao				=	'';
		$site				=	$pwmember['site'];
		$bio				=	$pwmember['introduce'];
		$interest			=	$pwmember['signature'];
		$field1				=	'';
		$field2				=	'';
		$field3				=	'';
		$field4				=	'';
		$field5				=	'';
		$field6				=	'';
		$field7				=	'';
		$field8				=	'';

		//pre_common_member_status
		//$uid				=	'';
		//$regip			=	'';
		$lastip				=	$lastloginip;
		$lastvisit			=	$lastlogintime;
		$lastactivity		=	$lastlogintime;
		$lastpost			=	$pwmember['lastpost'];
		$lastsendmail		=	0;
		$notifications		=	0;
		$groupinvitations	=	0;
		$activityinvitations=	0;
		$myinvitations		=	0;
		$pokes				=	0;
		$pendingfriends		=	0;
		$invisible			=	0;
		$buyercredit		=	0;
		$sellercredit		=	0;

		$fields1	= array('uid', 'username', 'password', 'email', 'myid', 'myidkey', 'regip', 'regdate', 'lastloginip', 'lastlogintime', 'salt','secques');
		$query1		= getinsertsql("{$discuz_tablepre}ucenter_members", $fields1);

		$fields2 	= array('uid', 'blacklist');
		$query2  	= getinsertsql("{$discuz_tablepre}ucenter_memberfields", $fields2);

		$fields3 	= array('uid','email','username','password','status','emailstatus','avatarstatus','videophotostatus','adminid','groupid','groupexpiry','extgroupids','regdate','credits','notifysound','timeoffset','newpm','newprompt','accessmasks','allowadmincp','avatar');		//avatar�ֶ�Ϊת��ͷ�����ӵ��ֶ�
		$query3 	= getinsertsql("{$discuz_tablepre}common_member", $fields3);

		$fields4 	= array('uid','extcredits1','extcredits2','extcredits3','extcredits4','extcredits5','extcredits6','extcredits7','extcredits8','friends','posts','threads','digestposts','doings','blogs','albums','sharings','attachsize','views');
		$query4 	= getinsertsql("{$discuz_tablepre}common_member_count", $fields4);

		$fields5 	= array('uid','publishfeed','customshow','customstatus','medals','sightml','groupterms','authstr','groups','attentiongroup');
		$query5 	= getinsertsql("{$discuz_tablepre}common_member_field_forum", $fields5);

		$fields6 	= array('uid','videophoto','spacename','spacedescription','domain','addsize','addfriend','theme','spacecss','blockposition','recentnote','spacenote','privacy','feedfriend','acceptemail');
		$query6 	= getinsertsql("{$discuz_tablepre}common_member_field_home", $fields6);

		$fields7 	= array('uid','gender','birthyear','birthmonth','birthday','constellation','zodiac','telephone','mobile','idcardtype','idcard','address','zipcode','nationality','birthprovince','birthcity','resideprovince','residecity','residedist','residecommunity','residesuite','graduateschool','company','education','occupation','position','revenue','affectivestatus','lookingfor','bloodtype','height','weight','alipay','icq','qq','yahoo','msn','taobao','site','bio','interest','field1','field2','field3','field4','field5','field6','field7','field8');
		$query7 	= getinsertsql("{$discuz_tablepre}common_member_profile", $fields7);

		$fields8 	= array('uid','regip','lastip','lastvisit','lastactivity','lastpost','lastsendmail','notifications','groupinvitations','activityinvitations','myinvitations','pokes','pendingfriends','invisible','buyercredit','sellercredit');
		$query8 	= getinsertsql("{$discuz_tablepre}common_member_status", $fields8);

		if ($db['discuz']->query($query1)) {
			if ($db['discuz']->query($query2)) {
				$password = strtolower($pwmember['password']);
				if ($db['discuz']->query($query3)) {
					if ($db['discuz']->query($query4)) {
						if($db['discuz']->query($query5)) {
							if($db['discuz']->query($query6)) {
								if($db['discuz']->query($query7)) {
									if($db['discuz']->query($query8)) {
										$convertedrows ++;
									} else {
										$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_members WHERE uid='$uid' LIMIT 1;");
										$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_memberfields WHERE uid='$uid' LIMIT 1;");
										$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member WHERE uid='$uid' LIMIT 1;");
										$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member_count WHERE uid='$uid' LIMIT 1;");
										$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member_field_forum WHERE uid='$uid' LIMIT 1;");
										$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member_field_home WHERE uid='$uid' LIMIT 1;");
										$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member_profile WHERE uid='$uid' LIMIT 1;");
										
										reportlog("ת���û�״̬������ uid=$uid, username=$username");
									}
								} else {
									$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_members WHERE uid='$uid' LIMIT 1;");
									$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_memberfields WHERE uid='$uid' LIMIT 1;");
									$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member WHERE uid='$uid' LIMIT 1;");
									$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member_count WHERE uid='$uid' LIMIT 1;");
									$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member_field_forum WHERE uid='$uid' LIMIT 1;");
									$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member_field_home WHERE uid='$uid' LIMIT 1;");
									
									reportlog("ת���û��Զ�����Ϣ������ uid=$uid, username=$username");
								}
							} else {
								$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_members WHERE uid='$uid' LIMIT 1;");
								$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_memberfields WHERE uid='$uid' LIMIT 1;");
								$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member WHERE uid='$uid' LIMIT 1;");
								$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member_count WHERE uid='$uid' LIMIT 1;");
								$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member_field_forum WHERE uid='$uid' LIMIT 1;");
								
								reportlog("ת���û���԰�ֶα����� uid=$uid, username=$username");
							}
						} else {
							$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_members WHERE uid='$uid' LIMIT 1;");
							$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_memberfields WHERE uid='$uid' LIMIT 1;");
							$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member WHERE uid='$uid' LIMIT 1;");
							$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member_count WHERE uid='$uid' LIMIT 1;");
							
							reportlog("ת���û���̳�ֶα����� uid=$uid, username=$username");
						}
					} else {
						$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_members WHERE uid='$uid' LIMIT 1;");
						$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_memberfields WHERE uid='$uid' LIMIT 1;");
						$db['discuz']->query("DELETE FROM {$discuz_tablepre}common_member WHERE uid='$uid' LIMIT 1;");
						
						reportlog("ת���û�ͳ�����ݱ����� uid=$uid, username=$username");
					}
				} else {
					$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_members WHERE uid='$uid' LIMIT 1;");
					$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_memberfields WHERE uid='$uid' LIMIT 1;");
					
					reportlog("ת��X�û���Ϣ�������� uid=$uid, username=$username");
				}
			} else {
				$db['uc']->query("DELETE FROM {$discuz_tablepre}uc_members WHERE uid='$uid' LIMIT 1;");
				
				reportlog("ת�� UCenter �û����ϱ����� uid=$uid, username=$username");
			}
		} else {
			reportlog("ת�� UCenter �û��������� uid=$uid, username=$username");
		}
	}
	$converted = 1;
	$totalrows ++;
}
?>