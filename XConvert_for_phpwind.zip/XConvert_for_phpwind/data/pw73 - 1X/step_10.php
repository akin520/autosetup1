<?php
/*
ͶƱ����������pre_forum_poll
ͶƱ����ѡ�����pre_forum_polloption
*/
if($start <= 1){
	truncatetable('forum_poll');
	truncatetable('forum_polloption');
}

$maxtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}polls"), 0);

if($start < $maxtid){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}polls WHERE tid >= $start AND tid <$start + $rpp") or dexit();
while ($pwpoll 	=	$db['source']->fetch_array($query)) {
	$pwpoll		=	daddslashes($pwpoll);
	$t_option	=	unserialize(stripslashes($pwpoll['voteopts']));

	//pre_forum_poll
	$tid			=	$pwpoll['tid'];
	$overt			=	0;
	$multiple		=	$pwpoll['multiple'];
	$visible		=	$pwpoll['previewable'];
	$maxchoices		=	$pwpoll['mostvotes'];
	$dateline		=	$db['discuz']->result($db['discuz']->query("SELECT dateline FROM {$discuz_tablepre}forum_thread WHERE tid='$tid'"), 0);
	$expiration		=	$pwpoll['timelimit'] ? ($pwpoll['timelimit'] * 86400 + $dateline) : 0;
	$pollpreview	=	'';
	$voters			=	0;
	if(!is_array($t_option)){
		$db['discuz']->query("UPDATE {$discuz_tablepre}forum_thread SET special=0  WHERE tid='$tid'");
		continue;
	}
	foreach($t_option as $key=>$option) {
		//pre_forum_polloption
		//$polloptionid	=	'';						//����
		//$tid			=	$tid;
		$votes			=	$option[1];
		$displayorder	=	0;
		$polloption		=	$option[0];
		$voterids		=	'';
		$uid_query	=	$db['source']->query("SELECT uid FROM {$source_tablepre}voter WHERE tid='$tid' and vote='$key'");
		while($uid = $db['source']->fetch_array($uid_query)) {
			$voterids	.=	"\t".$uid['uid'];
		}
		$voters			=	$voters+$option[1];
		
		$field1			=	array('tid','votes','displayorder','polloption','voterids');
		$query1			=	getinsertsql("{$discuz_tablepre}forum_polloption", $field1);
		if ($db['discuz']->query($query1)) {
		} else {
			reportlog("�޷�ת��ͶƱѡ��� tid = $tid��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
			continue;
		}
	}

	$field2	=	array('tid','overt','multiple','visible','maxchoices','expiration','pollpreview','voters');
	$query2	=	getinsertsql("{$discuz_tablepre}forum_poll", $field2);

	if ($db['discuz']->query($query2)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת��ͶƱ���� tid = $tid��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query2."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>