<?php
/*
�����������pre_forum_debate
*/
if($start <= 1){
	truncatetable('forum_debate');
}

$maxtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}debates"), 0);
if($start < $maxtid){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}debates WHERE tid >= $start AND tid < $start + $rpp") or dexit();
while ($pwdebate = $db['source']->fetch_array($query)) {
	$pwdebate		=	daddslashes($pwdebate);

	//pre_forum_debate
	$t_post			=	getdiscuztid($pwdebate['tid'], $pwdebate['postdate']);
	$tid			=	$t_post['tid'];
	if(empty($tid)){
		continue;
	}
	$uid			=	$pwdebate['authorid'];
	$starttime		=	$pwdebate['postdate'];
	$endtime		=	$pwdebate['endtime'];
	$affirmdebaters	=	$pwdebate['obposts'];
	$negadebaters	=	$pwdebate['reposts'];
	$affirmvotes	=	$pwdebate['obvote'];
	$negavotes		=	$pwdebate['revote'];
	$umpire			=	$pwdebate['umpire'];
	$winner			=	$pwdebate['judge'];
	$bestdebater	=	$pwdebate['debater'];
	$affirmpoint	=	$pwdebate['obtitle'];
	$negapoint		=	$pwdebate['retitle'];
	$umpirepoint	=	$pwdebate['umpirepoint'];
	
	$affirmvoterids	=	'';
	$aff_query	=	$db['source']->query("SELECT authorid FROM {$source_tablepre}debatedata WHERE tid='$tid' and standpoint='1' GROUP BY authorid");
	while($aff_uid = $db['source']->fetch_array($aff_query)) {
		$affirmvoterids	=	$aff_uid['authorid']."\t";
	}
	
	$negavoterids	=	'';
	$neg_query		=	$db['source']->query("SELECT authorid FROM {$source_tablepre}debatedata WHERE tid='$tid' and standpoint='2' GROUP BY authorid");
	while($neg_uid = $db['source']->fetch_array($neg_query)) {
		$negavoterids =	$neg_uid['authorid']."\t";
	}
	
	$affirmreplies	=	$pwdebate['obposts'];
	$negareplies	=	$pwdebate['reposts'];

	$field1	=	array('tid','uid','starttime','endtime','affirmdebaters','negadebaters','affirmvotes','negavotes','umpire','winner','bestdebater','affirmpoint','negapoint','umpirepoint','affirmvoterids','negavoterids','affirmreplies','negareplies');
	$query1	=	getinsertsql("{$discuz_tablepre}forum_debate", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת���������� tid = $tid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>