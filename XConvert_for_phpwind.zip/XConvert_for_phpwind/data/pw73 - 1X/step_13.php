<?php
/*
�������ӱ���pre_forum_debatepost
*/
if($start <= 1){
	truncatetable('forum_debatepost');
}

$maxcount = $db['source']->result($db['source']->query("SELECT COUNT(*) FROM {$source_tablepre}debatedata"), 0);
if($start < $maxcount){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}debatedata limit $limit_start,$end") or dexit();
while ($debatedata = $db['source']->fetch_array($query)) {
	$debatedata		=	daddslashes($debatedata);
	if($debatedata['pid'] == '0') continue;

	//pre_forum_debatepost
	$pid		=	$debatedata['pid'];
	$stand		=	$debatedata['standpoint'];
	$tid		=	$debatedata['tid'];
	$uid		=	$debatedata['authorid'];
	$dateline	=	$debatedata['postdate'];
	$voters		=	$debatedata['voters'];
	$voterids	=	$debatedata['voteids'];

	$field1	=	array('pid','stand','tid','uid','dateline','voters','voterids');
	$query1	=	getinsertsql("{$discuz_tablepre}forum_debatepost", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת������ tid = $tid pid=$pid��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>