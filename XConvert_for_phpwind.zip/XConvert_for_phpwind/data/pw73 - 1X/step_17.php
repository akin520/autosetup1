<?php
/*
���Ա����pre_forum_activityapply
*/
if($start <= 1) {
	truncatetable('forum_activityapply');
}

$maxcount = $db['source']->result($db['source']->query("SELECT count(*) FROM {$source_tablepre}actmember"), 0);

if($start < $maxcount){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}actmember limit $limit_start,$end") or dexit();
while ($pwactmember =	$db['source']->fetch_array($query)) {
	$pwactmember	=	daddslashes($pwactmember);

	//pre_forum_activityapply
	$applyid	=	$pwactmember['id'];
	$tid		=	$pwactmember['actid'];
	$username	=	$pwactmember['username'];
	$uid		=	$pwactmember['winduid'];
	$message	=	$pwactmember['message'];
	$verified	=	1;
	$dateline	=	$pwactmember['applydate'];
	$payment	=	-1;
	$contact	=	$pwactmember['contact'];

	$field1	=	array('applyid','tid','username','uid','message','verified','dateline','payment','contact');
	$query1	=	getinsertsql("{$discuz_tablepre}forum_activityapply", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת�����Ա tid = $tid username = $username��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>