<?php
/*
ת��Ⱥ�����
������pre_forum_forum
�����չ����pre_forum_forumfield
*/

if($start <= 1) {
	//truncatetable('forum_forum');
	//truncatetable('forum_forumfield');
}

$maxfid = $db['source']->result($db['source']->query("SELECT max(fid) FROM {$source_tablepre}cnclass"), 0);
if($start < $maxfid) {
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}cnclass WHERE fid >= $start AND fid < $start + $rpp") or dexit();
while ($pwcnclass = $db['source']->fetch_array($query)) {
	$pwcnclass			=	daddslashes($pwcnclass);

	//pre_forum_forum
	//$fid				=	$pwcnclass['fid'];
	$fup				=	0;
	$type				=	'group';		//����(group:���� forum:��ͨ��̳ sub:����̳)
	$name				=	$pwcnclass['cname'];
	$status				=	3;
	$displayorder		=	0;
	$styleid			=	0;
	$threads			=	0;
	$posts				=	0;
	$todayposts			=	0;
	$lastpost			=	'';
	$allowsmilies		=	0;
	$allowhtml			=	0;
	$allowbbcode		=	0;
	$allowimgcode		=	0;
	$allowmediacode		=	0;
	$allowanonymous		=	0;
	//$allowshare		=	0;			//beta�����Ѿ��޴��ֶ�
	$allowpostspecial	=	0;
	$allowspecialonly	=	0;
	$alloweditrules		=	0;
	$allowfeed			=	1;
	$allowside			=	1;
	$recyclebin			=	0;
	$modnewposts		=	0;
	$jammer				=	0;
	$disablewatermark	=	0;
	$inheritedmod		=	0;
	$autoclose			=	0;
	$forumcolumns		=	0;
	$threadcaches		=	0;
	$alloweditpost		=	1;
	$simple				=	0;
	$modworks			=	0;
	$allowtag			=	1;
	$allowglobalstick	=	1;
	$level				=	0;
	$commoncredits		=	0;
	$archive			=	0;
	$recommend			=	0;

	//pre_forum_forumfield
	//$fid				=	$pwcnclass['fid'];
	$description		=	'';
	$password			=	'';
	$icon				=	'';
	$redirect			=	'';
	$attachextensions	=	'';
	$creditspolicy		=	'';
	$formulaperm		=	'';
	$moderators			=	'';
	$rules				=	'';
	$threadtypes		=	'';
	$threadsorts		=	'';
	$viewperm			=	'';
	$postperm			=	'';
	$replyperm			=	'';
	$getattachperm		=	'';
	$postattachperm		=	'';
	$postimageperm		=	'';
	$keywords			=	'';
	$supe_pushsetting	=	'';
	$modrecommend		=	'';
	$threadplugin		=	'';
	$extra				=	'';
	$jointype			=	0;
	$gviewperm			=	0;
	$membernum			=	0;
	$dateline			=	0;
	$lastupdate			=	0;
	$activity			=	0;
	$founderuid			=	0;
	$foundername		=	'';
	$banner				=	'';
	$groupnum			=	0;
	$commentitem		=	'';

	$field1		=	array('fup','type','name','status','displayorder','styleid','threads','posts','todayposts','lastpost','allowsmilies','allowhtml','allowbbcode','allowimgcode','allowmediacode','allowanonymous','allowpostspecial','allowspecialonly','alloweditrules','allowfeed','allowside','recyclebin','modnewposts','jammer','disablewatermark','inheritedmod','autoclose','forumcolumns','threadcaches','alloweditpost','simple','modworks','allowtag','allowglobalstick','level','commoncredits','archive','recommend');
	$query1		=	getinsertsql("{$discuz_tablepre}forum_forum", $field1);

	if($db['discuz']->query($query1)) {
		$fid = $db['discuz']->insert_id();
		$field2 = array('fid','description','password','icon','redirect','attachextensions','creditspolicy','formulaperm','moderators','rules','threadtypes','threadsorts','viewperm','postperm','replyperm','getattachperm','postattachperm','postimageperm','keywords','supe_pushsetting','modrecommend','threadplugin','extra','jointype','gviewperm','membernum','dateline','lastupdate','activity','founderuid','foundername','banner','groupnum','commentitem');
		$query2	= getinsertsql("{$discuz_tablepre}forum_forumfield", $field2);
		if($db['discuz']->query($query2)) {
			
			$fup = $fid;
			unset($fid);
			$type = 'forum';
			$field3 = array('fup','type','name','status','displayorder','styleid','threads','posts','todayposts','lastpost','allowsmilies','allowhtml','allowbbcode','allowimgcode','allowmediacode','allowanonymous','allowpostspecial','allowspecialonly','alloweditrules','allowfeed','allowside','recyclebin','modnewposts','jammer','disablewatermark','inheritedmod','autoclose','forumcolumns','threadcaches','alloweditpost','simple','modworks','allowtag','allowglobalstick','level','commoncredits','archive','recommend');
			$query3 = getinsertsql("{$discuz_tablepre}forum_forum", $field3);
			
			if($db['discuz']->query($query3)) {
				$fid = $db['discuz']->insert_id();
				$field4 =	array('fid','description','password','icon','redirect','attachextensions','creditspolicy','formulaperm','moderators','rules','threadtypes','threadsorts','viewperm','postperm','replyperm','getattachperm','postattachperm','postimageperm','keywords','supe_pushsetting','modrecommend','threadplugin','extra','jointype','gviewperm','membernum','dateline','lastupdate','activity','founderuid','foundername','banner','groupnum','commentitem');
				$query4 =	getinsertsql("{$discuz_tablepre}forum_forumfield", $field4);
				if($db['discuz']->query($query4)) {
					$convertedrows ++;
				} else {
					$db['discuz']->query("DELETE FROM {$discuz_tablepre}forum_forum WHERE fid='$fup'");
					$db['discuz']->query("DELETE FROM {$discuz_tablepre}forum_forumfield WHERE fid='$fup'");
					$db['discuz']->query("DELETE FROM {$discuz_tablepre}forum_forum WHERE fid='$fid'");
					reportlog("�޷�ת��Ⱥ����չ��Ϣ fid = $fid");
				}
			} else {
				$db['discuz']->query("DELETE FROM {$discuz_tablepre}forum_forum WHERE fid='$fup'");
				$db['discuz']->query("DELETE FROM {$discuz_tablepre}forum_forumfield WHERE fid='$fup'");
				reportlog("�޷�ת��Ⱥ����չ��Ϣ fid = $fid");
			}
		} else {
			$db['discuz']->query("DELETE FROM {$discuz_tablepre}forum_forum WHERE fid='$fid'");
			reportlog("�޷�ת��Ⱥ����չ��Ϣ fid = $fid");
		}
	} else {
		reportlog("�޷�ת��Ⱥ�� fid = $fid");
	}
	$converted = 1;
	$totalrows ++;
}
?>