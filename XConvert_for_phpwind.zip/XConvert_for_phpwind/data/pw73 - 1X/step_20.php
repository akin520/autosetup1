<?php
/*
Ⱥ���Ա��pre_forum_groupuser
*/
if($start <= 1){
	truncatetable('forum_groupuser');
}
$maxmtagid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}cmembers"), 0);
if($start < $maxmtagid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}cmembers WHERE id >= $start AND id < $start + $rpp") or dexit();
while ($pwcmember = $db['source']->fetch_array($query)) {
	$pwcmember		=	daddslashes($pwcmember);

	$fid			=	$pwcmember['colonyid'];
	$uid			=	$pwcmember['uid'];
	$username		=	$pwcmember['username'];
	$level			=	4;
	$threads		=	0;
	$replies		=	0;
	$joindateline	=	time();
	$lastupdate		=	time();
	$privacy		=	0;

	$field1	=	array('fid','uid','username','level','threads','replies','joindateline','lastupdate','privacy');
	$query1	=	getinsertsql("{$discuz_tablepre}forum_groupuser", $field1);

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת��Ⱥ���Ա fid = $fid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>