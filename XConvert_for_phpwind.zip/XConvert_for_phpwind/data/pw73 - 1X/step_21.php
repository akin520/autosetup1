<?php
/*
pre_forum_thread
pre_forum_post
*/

if($start <= 1){
	//truncatetable('forum_thread');
	//truncatetable('forum_post');
}

$maxtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}argument"), 0);
if($start < $maxtid){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}argument WHERE tid >= $start AND tid < $start + $rpp") or dexit();
while ($pwargument = $db['source']->fetch_array($query)) {
	//��ȡԴ����
	$pwargument	= daddslashes($pwargument);
	$otid = $pwargument['tid'];
	//ͨ��Դ���ݻ�ȡԴ���ڵ�����ID
	$t_query = $db['discuz']->query("SELECT pid,fid,tid FROM {$discuz_tablepre}forum_post WHERE first='1' AND dateline='{$pwargument[postdate]}' limit 1");
	$post = $db['discuz']->fetch_array($t_query);
	$tid = $post['tid'];
	$pid = $post['pid'];

	//ͨ��Դ���ݻ�ȡԴȺ���ID
	$fid = $pwargument['cyid'];
	$t_name = $db['source']->result($db['source']->query("SELECT cname FROM {$source_tablepre}colonys WHERE id ='{$fid}' limit 1"), 0);
	$fid = $db['discuz']->result($db['discuz']->query("SELECT fid FROM {$discuz_tablepre}forum_forum WHERE name='{$t_name}' AND type='sub' limit 1"), 0);

	//if(empty($fid)) continue;
	$query1 = "UPDATE {$discuz_tablepre}forum_thread SET isgroup = 1, fid='$fid' WHERE tid='$tid'";
	$query2 = "UPDATE {$discuz_tablepre}forum_post SET fid='$fid',tid='$tid' WHERE tid='$otid'";
	$query3 = "UPDATE {$discuz_tablepre}forum_post SET fid='$fid' WHERE pid='$pid'";

	if ($db['discuz']->query($query1)) {
		if ($db['discuz']->query($query2)) {
			if ($db['discuz']->query($query3)) {
				$convertedrows ++;
			} else {
				reportlog("����Ⱥ���������SQL��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
			}
		} else {
			reportlog("����Ⱥ���������SQL��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query2."</textarea>");
		}
	} else {
		reportlog("����Ⱥ���������SQL��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query3."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>