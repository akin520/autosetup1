<?php
/*
ͼƬ����pre_home_pic
ͼƬ���ȵ��û���Ӧ����pre_home_picfield
*/
if($start <= 1){
	truncatetable('home_pic');
	truncatetable('home_picfield');
}

$maxpicid = $db['source']->result($db['source']->query("SELECT max(pid) FROM {$source_tablepre}cnphoto"), 0);
if($start < $maxpicid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}cnphoto WHERE pid >= $start AND pid < $start + $rpp") or dexit();
while ($pic = $db['source']->fetch_array($query)) {
	$pic			=	daddslashes($pic);

	//pre_home_pic
	$picid			=	$pic['pid'];
	$albumid		=	$pic['aid'];
	$username		=	$pic['uploader'];
	$uid			=	$db['discuz']->result($db['discuz']->query("select uid from {$discuz_tablepre}home_album where albumid = $albumid"), 0);
	$dateline		=	$pic['uptime'];
	$postip			=	'';
	$filename		=	substr(strrchr($pic['path'], "/"),1);
	$title			=	$pic['pintro'];
	$type			=	getfiletype($pic['path']);
	$size			=	'0';
	$filepath		=	$pic['path'];
	$thumb			=	'0';
	$remote			=	'0';
	$hot			=	0;
	$click1			=	0;
	$click2			=	0;
	$click3			=	0;
	$click4			=	0;
	$click5			=	0;
	$click6			=	0;
	$click7			=	0;
	$click8			=	0;
	$magicframe		=	0;

	//pre_home_picfield
	//$picid		=	$pic['pid'];
	$hotuser		=	'';

	$field1 = array('picid','albumid','uid','username','dateline','postip','filename','title','type','size','filepath','thumb','remote','hot','click1','click2','click3','click4','click5','click6','click7','click8','magicframe');
	$query1 = getinsertsql("{$discuz_tablepre}home_pic", $field1);

	$field2 = array('picid','hotuser');
	$query2 = getinsertsql("{$discuz_tablepre}home_picfield", $field2);

	if ($db['discuz']->query($query1)) {
		if ($db['discuz']->query($query2)) {
			$convertedrows ++;
		} else {
			$db['discuz']->query("DELETE FROM {$discuz_tablepre}home_pic WHERE picid='$picid'");
			reportlog("�޷�ת����Ƭ��չ��Ϣ id = $picid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
		}
	} else {
		reportlog("�޷�ת����Ƭ id = $picid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>