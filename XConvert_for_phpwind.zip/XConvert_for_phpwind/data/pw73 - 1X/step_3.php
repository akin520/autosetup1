<?php
/*
pre_common_member_count
*/
$query = $db['source']->query("SELECT hk_name, hk_value FROM {$source_tablepre}hack WHERE hk_name IN ('bk_drate', 'bk_rate', 'bk_ddate')") or dexit();

while($hk = $db['source']->fetch_array($query)) {
	$hack[$hk['hk_name']] = $hk['hk_value'];
}

$maxuserid = $db['source']->result($db['source']->query("SELECT max(uid) FROM {$source_tablepre}memberinfo"), 0);
if($start < $maxuserid){
	$converted = 1;
}

$query = $db['source']->query("SELECT uid, deposit, startdate, ddeposit, dstartdate FROM {$source_tablepre}memberinfo WHERE uid >= $start AND uid < $start + $rpp") or dexit();
while($user	=	$db['source']->fetch_array($query)) {
	//����Ϣ
	if($user['startdate'] && $timestamp > $user['startdate']){
		$accrual = round((floor(($timestamp - $user['startdate']) / 86400)) * $user['deposit'] * $hack[bk_rate] / 100);
	} else {
		$accrual = 0;
	}
	//����Ϣ
	$ddates = floor(($timestamp - $user['dstartdate']) / ($hack[bk_ddate] * 30 * 86400));
	if($user['dstartdate'] && $ddates){
		$daccrual = round($ddates * $hack[bk_ddate] * 30 * $user['ddeposit'] * $hack[bk_drate] / 100);
	} else {
		$daccrual = 0;
	}
	
	$deposit = $user['deposit'] + $accrual + $user['ddeposit'] + $daccrual;		//���д������

	$query1 = "UPDATE {$discuz_tablepre}common_member_count SET extcredits2=extcredits2+'$deposit' WHERE uid='$user[uid]'";

	if ($db['discuz']->query($query1)) {
		$convertedrows ++;
	} else {
		reportlog();
	}
	$converted = 1;
	$totalrows ++;
}
?>