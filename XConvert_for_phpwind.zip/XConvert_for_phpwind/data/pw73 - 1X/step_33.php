<?php
/*
ucenter ���ѱ���pre_ucenter_friends
��԰���ѱ���pre_home_friend
*/
if($start<=1){
	truncatetable('ucenter_friends');
	truncatetable('home_friend');
}

$maxcount	=	$db['source']->query("SELECT count(*) FROM {$source_tablepre}friends");
if($start<=$maxcount){
	$counted	=	1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}friends ORDER BY uid ASC") or dexit();
while ($friends = $db['source']->fetch_array($query)) {
	
	//pre_ucenter_friends
	$uid		=	$friends['uid'];
	$friendid	=	$friends['friendid'];
	$direction	=	0;
	$related	=	0;
	$delstatus	=	0;
	$comment	=	daddslashes($friends['descrip']);

	//pre_home_friend
	//$uid		=	$friends['uid'];
	$fuid		=	$friendid;
	$fusername	=	getusername($fuid);
	$gid		=	1;
	$num		=	0;
	$dateline	=	$friends['joindate'];
	$note		=	'';

	$field1			=	array('uid', 'friendid', 'direction', 'version', 'delstatus', 'comment');
	$query1			=	getinsertsql("{$discuz_tablepre}ucenter_friends", $field1);

	$field2			=	array('uid','fuid','fusername','gid','num','dateline');
	$query2			=	getinsertsql("{$discuz_tablepre}home_friend", $field2);

	if ($db['discuz']->query($query1)) {
		if($db['discuz']->query($query2)) {
			$convertedrows ++;
		} else {
			reportlog("�޷�ת���������� uid = $uid, friendid = $friendid");
		}
	} else {
		reportlog("�޷�ת���������� uid = $uid, friendid = $friendid");
	}
	$counted	=	1;
	$totalrows ++;
}
?>