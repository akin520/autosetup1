<?php
/*
�ղؼб���pre_home_favorite
*/
if($start <= 1) truncatetable('home_favorite');

$maxuid = $db['source']->result($db['source']->query("SELECT max(uid) FROM {$source_tablepre}favors"), 0);
if($start < $maxuid) $converted = 1;

$query = $db['source']->query("SELECT * FROM {$source_tablepre}favors WHERE uid >= $start AND uid < $start + $rpp") or dexit();
while ($favorite = $db['source']->fetch_array($query)) {
	$favorite	=	daddslashes($favorite);

	//pre_home_favorite
	$uid		=	$favorite['uid'];
	$id			=	explode(',', $favorite['tids']);
	$idtype		=	'';
	$dateline	=	time();

	$field1		=	array('uid','id','idtype','dateline');
	$query1		=	getinsertsql("{$discuz_tablepre}home_favorite", $field1);

	$sqladd = $comma = '';
	foreach($tids AS $tid) {
		$tid = intval($tid);
		if($tid) {
			$sqladd .= "$comma ('$uid', '$tid')";
			$comma = ',';
		}
	}

	if(!$sqladd) {
		continue;
	} else {
		$sql = $sql.$sqladd;
	}

	if ($db['discuz']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog();
	}
	$converted = 1;
	$totalrows ++;
}
?>