<?php
/*
��Ⱥ������pre_forum_forum
����ֶα���pre_forum_forumfield
*/

//�˴�ֻת��飬Ⱥ����ں���ת
//if($start<=1){
	truncatetable('forum_forum');
	truncatetable('forum_forumfield');
//}

$query = $db['source']->query("SELECT f.*, fd.* FROM {$source_tablepre}forums f	LEFT JOIN {$source_tablepre}forumdata fd ON f.fid=fd.fid ORDER BY f.fid ASC") or dexit();
while($pwforum = $db['source']->fetch_array($query)) {	
	$pwforum = daddslashes($pwforum);

	if(!empty($pwforum['fup'])){
		$t_query = $db['source']->query("SELECT * FROM {$source_tablepre}forumsextra WHERE fid=$pwforum[fid]");
		if($t_extra = $db['source']->fetch_array($t_query)) {
			$pwforum['set']	=	unserialize($t_extra['forumset']);
		}
	}
	
	//pre_forum_forum
	$fid				=	$pwforum['fid'];
	
	switch(strtolower($pwforum['type'])) {
		case 'category':
			$pwforum['type']	=	'group';
			break;
		case 'forum':
			$pwforum['type']	=	'forum';
			break;
		case 'sub':
			$pwforum['type']	=	'sub';
			break;
		default:
			$pwforum['type']	=	'forum';
			break;
	}
	if($pwforum['type'] == 'sub' && $db['source']->result($db['source']->query("SELECT type FROM {$source_tablepre}forums WHERE fid='$pwforum[fup]'")) == 'sub') {
		$pwforum['type'] = 'forum';
		$pwforum['fup'] = 0;
	}
	$type				=	$pwforum['type'];
	$fup				=	$type == 'category' ? 0 : $pwforum['fup'];
	$name				=	cutstr(htmlspecialchars(trim(@strip_tags($pwforum['name']))), 50);
	
	$status				=	strtolower($pwforum['f_type']) == 'hidden' ? 0 : 1;
	$displayorder		=	$pwforum['vieworder'];
	$styleid			=	0;
	$threads			=	$type != 'category' ? $pwforum['topic'] : 0;
	$posts				=	$type != 'category' ? $pwforum['article'] : 0;
	$todayposts			=	0;
	$lastpost			=	$pwforum['lastpost'];
	$allowsmilies		=	$type != 'category' ? 1 : 0;
	$allowhtml			=	0;
	$allowbbcode		=	$allowsmilies;
	$allowimgcode		=	$allowsmilies;
	$allowmediacode		=	$allowsmilies;
	$allowanonymous		=	0;
	
	$allowpostspecial	=	0;
	for($i=4;$i<=0;$i--) {
		$num = $forum['allowtype'] - pow(2, $i) > 0 ? $i : 0;
		if($num) {
			switch ($num) {
				case 4 :
					$j = 1;
					break;
				case 3 :
					$j = 2;
					break;
				case 2 :
					$j = 3;
					break;
				case 1 :
					$j = 0;
					break;
				default :
					$j = -1;
			}
			if($j >= 0) {
				$allowpostspecial += pow(2, $j);
			}
		}
	}
	$allowspecialonly	=	0;
	$alloweditrules		=	0;
	$allowfeed			=	1;
	$allowside			=	1;
	$recyclebin			=	0;
	$modnewposts		=	0;
	$jammer				=	0;
	$disablewatermark	=	0;
	$inheritedmod		=	0;
	$autoclose			=	0;
	$forumcolumns		=	0;
	$threadcaches		=	0;
	$alloweditpost		=	1;
	$simple				=	$pwforum['childid'] ? $pwforum['viewsub'] : 0;
	$modworks			=	0;
	$allowtag			=	1;
	$allowglobalstick	=	1;
	$level				=	0;
	$commoncredits		=	0;
	$archive			=	0;
	$recommend			=	0;

	//pre_forum_forumfield
	//$fid				=	'';
	$description		=	$pwforum['descrip'];
	$password			=	'';
	$icon				=	$pwforum['logo'];
	$redirect			=	$pwforum['set']['link'];
	$attachextensions	=	'';
	$creditspolicy		=	'';
	$formulaperm		=	'';
	$moderators			=	addmoderators(explode(',', $pwforum['forumadmin']), $fid);	//����
	$rules				=	'';
	$threadtypes		=	'';
	$threadsorts		=	'';
	$viewperm			=	'';
	$postperm			=	'';
	$replyperm			=	'';
	$getattachperm		=	'';
	$postattachperm		=	'';
	$postimageperm		=	'';
	$keywords			=	$forum['keywords'];
	$supe_pushsetting	=	'';
	$modrecommend		=	'';
	$threadplugin		=	'';
	$extra				=	'';
	$jointype			=	'';
	$gviewperm			=	'';
	$membernum			=	'';
	$dateline			=	'';
	$lastupdate			=	'';
	$activity			=	'';
	$founderuid			=	'';
	$foundername		=	'';
	$banner				=	'';
	$groupnum			=	'';
	$commentitem		=	'';

	$field1		=	array('fid','fup','type','name','status','displayorder','styleid','threads','posts','todayposts','lastpost','allowsmilies','allowhtml','allowbbcode','allowimgcode','allowmediacode','allowanonymous','allowpostspecial','allowspecialonly','alloweditrules','allowfeed','recyclebin','modnewposts','jammer','disablewatermark','inheritedmod','autoclose','forumcolumns','threadcaches','alloweditpost','simple','modworks','allowtag','allowglobalstick','level','commoncredits','archive');
	$query1		=	getinsertsql("{$discuz_tablepre}forum_forum", $field1);

	$field2		=	array('fid','description','password','icon','redirect','attachextensions','creditspolicy','formulaperm','moderators','rules','threadtypes','threadsorts','viewperm','postperm','replyperm','getattachperm','postattachperm','postimageperm','keywords','supe_pushsetting','modrecommend','threadplugin','extra','jointype','gviewperm','membernum','dateline','lastupdate','activity','founderuid','foundername','banner','groupnum');
	$query2		=	getinsertsql("{$discuz_tablepre}forum_forumfield", $field2);
	
	if ($db['discuz']->query($query1)) {
		if ($db['discuz']->query($query2)) {
			$convertedrows ++;
		} else {
			$db['discuz']->query($query3);
			$db['discuz']->query("DELETE FROM {$discuz_tablepre}forumfields WHERE fid='$fid' LIMIT 1;");
			reportlog("���������չ��Ϣ���ݳ��� fid = $fid, name = $name");
		}
	} else {
		$db['discuz']->query($query3);
		reportlog("��������������ݳ��� fid = $fid, name = $name");
	}
	$totalrows ++;
}

?>