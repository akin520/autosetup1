<?php
/*
����������pre_forum_threadclass
*/

truncatetable('forum_threadclass');

$query = $db['source']->query("SELECT fid, t_type FROM {$source_tablepre}forums WHERE t_type > 0 ORDER BY fid ASC") or dexit();
while($pwforums = $db['source']->fetch_array($query)) {
	$pwforums	=	daddslashes($pwforums);

	$fid	=	$pwforums['fid'];
	$t_type		=	$pwforums['t_type'];
	$typearray	=	array();

	$query_types	=	$db['source']->query("SELECT * FROM {$source_tablepre}topictype WHERE fid = $fid");
	while($pwtopictype	=	$db['source']->fetch_array($query_types)) {
		$pwtopictype	=	daddslashes($pwtopictype);

		//pre_forum_threadclass
		$typearray['types'][]	=	$pwtopictype['name'];
		$typearray['icons'][]	=	'';
		$typeid	=	$pwtopictype['id'];
		//$fid = '';
		$name	=	$pwtopictype['name'];
		$displayorder	=	$pwtopictype['vieworder'];
		$icon	=	'';

		$field1	=	array('typeid','fid','name','displayorder','icon');
		$query1	=	getinsertsql("{$discuz_tablepre}forum_threadclass", $field1);

		if($db['discuz']->query($query1)) {
			$convertedrows ++;
		} else {
			reportlog("���Ӱ������������ name = $name ,SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query1."</textarea>");
		}
		$totalrows ++;
	}

	$typearray['status'] = $t_type == 2 ? 1 : 0;
	$typearray['required'] = $t_type == 2 ? 1 : 0;
	$typearray['listable'] = 1;
	$typearray['prefix'] = 0;

	$threadtypes	=	serialize($typearray);
	$query2	=	"UPDATE {$discuz_tablepre}forum_forumfield SET threadtypes='$threadtypes' WHERE fid='$fid'";
	if(!$db['discuz']->query($query2)) {
		reportlog("���Ӱ������������ fid = $fid ,SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$query2."</textarea>");
	}
}
?>