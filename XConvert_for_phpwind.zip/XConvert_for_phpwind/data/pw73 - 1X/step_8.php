<?php
/*
����������pre_forum_post
�������ּ�¼����pre_forum_ratelog

����������pre_forum_attachment
������չ����pre_forum_attachmentfield
*/

if($start <= 1 && $tableid == 0) {
	$ttblquery = $db['source']->query("SELECT db_value FROM {$source_tablepre}config WHERE db_name = 'db_tlist'");
	$ttablelist = unserialize($db['source']->result($ttblquery));
	if(isset($ttablelist[0])) {
		$maxtableid = is_array($ttablelist) ? count($ttablelist)-1 : 0;	//����ID��1
	} else {
		$maxtableid = is_array($ttablelist) ? count($ttablelist) : 0;	//
	}
}

$tableid = isset($tableid) ? $tableid : 0;
$maxtableid = isset($maxtableid) ? $maxtableid : 0;
$tnum = $tableid == 0 ? '' : $tableid;
$maxtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}tmsgs{$tnum}"), 0);
if($start < $maxtid){
	$converted = 1;
}

$query = $db['source']->query("SELECT * FROM {$source_tablepre}tmsgs{$tnum} m LEFT JOIN {$source_tablepre}threads t ON t.tid = m.tid WHERE m.tid >= $start AND m.tid < $start + $rpp");

while ($pwtmsgs = $db['source']->fetch_array($query)) {
	$pwtmsgs		=	daddslashes($pwtmsgs);

	//pre_forum_post
	//$pid			=	$pwtmsgs['pid'];
	$opid			=	$pwtmsgs['pid'];
	$fid			=	$pwtmsgs['fid'];
	$tid			=	$pwtmsgs['tid'];
	$first			=	1;
	$author			=	cutstr(htmlspecialchars(trim($pwtmsgs['author'])), 15);
	$authorid		=	$pwtmsgs['authorid'];
	$subject		=	daddslashes(cutstr(htmlspecialchars(trim(@strip_tags($pwtmsgs['subject']))), 78));//formatstrȥ���ַ�����β��'\'
	$dateline		=	$pwtmsgs['postdate'];
	$message		=	daddslashes(convertbbcode($pwtmsgs['content'] ? $pwtmsgs['content'] : htmlspecialchars(trim($pwtmsgs['subject']))));//formatstrȥ���ַ�����β��'\' 
	$useip			=	$pwtmsgs['userip'];
	$invisible		=	0;
	$anonymous		=	$pwtmsgs['anonymous'];
	$usesig			=	$pwtmsgs['ifsign']%2 == 0 ? 0 : 1;
	$htmlon			=	$pwtmsgs['ifsign'] < 2 ? 0 : 1;
	$bbcodeoff		=	0;
	$smileyoff		=	0;
	$parseurloff	=	0;
	$attachment		=	$pwtmsgs['ifupload'] ? 1 : 0;
	$rate			=	0;
	$ratetimes		=	0;
	$status			=	0;
	$tags			=	'';
	$comment		=	0;
	
	if($post['ifmark'] != '') {
		//pre_forum_ratelog
		//$pid			=	'';
		$uid			=	0;
		$element		=	array();
		$ifmarkarr		=	explode("\t", $post['ifmark']);
		foreach($ifmarkarr as $ifmark){
			preg_match_all("/(.+?):[+-](\d+?)\((.+)\)(.*)/is", $ifmark, $element);
			$rate += $element['2']['0'];
			$username = $element['3']['0'];
			$extcredits = 1;
			$score = $element['2']['0'];
			$reason = $ifmark;
			$uid = getuid($username);
		}
		$ratetimes = $rate;
	}

	$field1 = array('pid');
	$query1 = getinsertsql("{$discuz_tablepre}forum_post_tableid", $field1);

	if($db['discuz']->query($query1)){	//
		$pid = $db['discuz']->insert_id();
		$field2	 =	array('pid','fid','tid','first','author','authorid','subject','dateline','message','useip','invisible','anonymous','usesig','htmlon','bbcodeoff','smileyoff','parseurloff','attachment','rate','ratetimes','status','tags','comment');
		$query2	 =	getinsertsql("{$discuz_tablepre}forum_post", $field2);
		if ($db['discuz']->query($query2)) {
			if($rate > 0){
				$field3	= array('pid','uid','username','extcredits','dateline','score','reason');
				$query3	= getinsertsql("{$discuz_tablepre}forum_ratelog", $field3);
				$db['discuz']->query($query3);
				$uid = 0;
			}

			if (is_array($attachs)) {
				foreach ($attachs as $att) {
					//pre_forum_attachment
					$aid			=	$att['aid'];
					//$tid			=	'';
					//$pid			=	'';
					$width			=	0;
					$dateline		=	$att['uploadtime'];
					$readperm		=	0;
					$price			=	0;
					$filename		=	daddslashes(cutstr(htmlspecialchars(trim($att['name'])), 100));
					$filetype		=	getfiletype($att['name']);
					$filesize		=	intval($att['size']) * 1024;
					$attachment		=	'pw/'.$att['attachurl'];
					$downloads		=	$att['hits'];
					$isimage		=	in_array($filetype, array('image/pjpeg', 'image/gif', 'image/bmp', 'image/png')) ? 1 : 0;
					$uid			=	$authorid;
					$thumb			=	0;
					$remote			=	0;

					//pre_forum_attachmentfield
					//$aid			=	'';
					//$tid			=	'';
					//$pid			=	'';
					//$uid			=	'';
					$description	=	daddslashes(cutstr(htmlspecialchars(trim($att['descrip'])), 100));

					$field4			=	array('aid','tid','pid','width','dateline','readperm','price','filename','filetype','filesize','attachment','downloads','isimage','uid','thumb','remote');
					$query4			=	getinsertsql("{$discuz_tablepre}forum_attachment", $field4, 0);

					$field5			=	array('aid','tid','pid','uid','description');
					$query5			=	getinsertsql("{$discuz_tablepre}forum_attachmentfield", $field5, 0);

					$db['discuz']->query($query4);
					$db['discuz']->query($query5);
				}
			}
			$convertedrows ++;
			unset($pid);
		} else {
			$db['discuz']->query("DELETE FROM {$discuz_tablepre}forum_post_tableid WHERE pid='$pid'");
			reportlog("ת������������ tid=$tid pid=$pid ");
		}
	} else {
		reportlog("ת������������ pid=$pid ");
	}
	$converted = 1;
	$totalrows ++;
}

if($converted) {
	$nowtableid = $tableid + 1;
	showmessage("���ڴ����� $nowtableid �ֱ��ĵ� $start - $end ������", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.$tableid.'&maxtableid='.$maxtableid);
} elseif($tableid < $maxtableid) {
	$nextid = $tableid + 1;
	$nexttableid = $tableid + 2;
	unset($start);
	unset($end);
	showmessage("�� $nextid �ֱ����ݴ������, ��������� $nexttableid �ֱ���ת��", 'index.php?action=convert&step='.$step.'&start='.($end + 1).'&stay='.$stay.'&totalrows='.$totalrows.'&convertedrows='.$convertedrows.'&maxid='.$maxid.'&tableid='.$nextid.'&maxtableid='.$maxtableid);
}
?>