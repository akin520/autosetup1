<?php
//��־
if($start <= 1){
	truncatetable_uch('blog');
	truncatetable_uch('blogfield');
}

$maxdid = $db['source']->result($db['source']->query("SELECT max(did) FROM {$source_tablepre}diary"), 0);
if($start < $maxdid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}diary WHERE did >= $start AND did < $start + $rpp") or dexit();
while ($diary = $db['source']->fetch_array($query)) {
	$arr			=	unserialize($diary['aid']);
	$diary		=	daddslashes($diary);

	$blogid			=	$diary['did'];
	$uid			=	$diary['uid'];
	$username		=	$diary['username'];
	$subject		=	$diary['subject'];
	$classid		=	$diary['dtid'];
	$viewnum		=	$diary['r_num'];
	$replynum		=	$diary['c_num'];
	$dateline		=	$diary['postdate'];
	$pic			=	'';
	$picflag		=	0;
	
	if($diary['aid']){
		foreach($arr as $attcharr){
			foreach($attcharr as $key => $value){
				if($key == 'name'){
					$pic = $value;
				}
				if($key == 'type'){
					$picflag = 1;
				}
			}
			if($picflag == 1 && $pic != ''){
				break;
			}
		}
	}
	$noreply		=	0;
	$friend			=	$diary['privacy'] == 2 ? 3 : $diary['privacy'];
	$password		=	'';

//blogfield
	$tag			=	'';
	$message		=	formatstr(convertbbcode($diary['content']));
	$postip			=	'';
	$related		=	'a:0:{}';
	$relatedtime	=	$diary['postdate'];
	$target_ids		=	'';
	
	$sql_1 = "INSERT INTO {$uch_tablepre}blog (blogid, uid, username, subject, classid, viewnum, replynum, dateline, pic, picflag, noreply, friend, password) VALUES ('$blogid', '$uid', '$username', '$subject', '$classid', '$viewnum', '$replynum', '$dateline', '$pic', '$picflag', '$noreply', '$friend', '$password');";
	$sql_2 = "INSERT INTO {$uch_tablepre}blogfield (blogid, uid, tag, message, postip, related, relatedtime, target_ids) VALUES ('$blogid', '$uid', '$tag', '$message', '$postip', '$related', '$relatedtime', '$target_ids')";

	if ($db['uchome']->query($sql_1)) {
		if ($db['uchome']->query($sql_2)) {
			$convertedrows ++;
		}else{
			reportlog("�޷�ת����־�������� id = $blogid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql_1."</textarea>");
		}
	} else {
		reportlog("�޷�ת����־ id = $blogid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql_2."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>