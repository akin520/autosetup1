<?php
//����
if($start <= 1){
	truncatetable_uch('share');
}

$maxsid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}share"), 0);
if($start < $maxsid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}share WHERE id >= $start AND id < $start + $rpp") or dexit();
while ($share = $db['source']->fetch_array($query)) {
	$content		=	$share['content'];
	$share			=	daddslashes($share);

	$sid			=	$share['id'];
	
	switch($share['type'])
	{
		case 'web' :
			$title_template	=	'������һ����ַ';
			$body_template	=	'{link}';
			$arr			=	unserialize($content);
			foreach($arr as $key => $value){
				${$key} = $value;
			}
			$data			=	$link;
			$link			=	"<a href=\"".$data."\" target=\"_blank\">".$data."</a>";
			$body_data		=	serialize(array("link" => $link, "data" => $data));
			$body_general	=	$descrip;
			$image			=	'';
			$image_link		=	'';
			$hash_data		=	md5($title_template."\t".$body_template."\t".$body_data);
			$type			=	'link';
			break;
		
		case 'group' :
			$title_template	=	'������һ��Ⱥ��';
			$body_template	=	'<b>{mtag}</b><br>{field}<br>���� {membernum} ����Ա';
			$arr			=	unserialize($content);
			foreach($arr as $key => $value){
				if(is_array($value)){
					foreach($value as $subkey => $subvalue){
						${$subkey} = $subvalue;
					}
				}else{
					${$key}		=	$value;
				}
			}
			$query_mtag = $db['source']->query("select id, members from {$source_tablepre}colonys where cname = '$name'");
			$detail			=	$db['source']->fetch_array($query_mtag);
			$membernum		=	$detail['members'];
			$tagid			=	$detail['id'];
			
			$mtag			=	"<a href=\"space.php?do=mtag&tagid=".$tagid."\">".$name."</a>";
			$field			=	"<a href=\"space.php?do=mtag&id=1\">��������</a>";
			$body_data		=	serialize(array("mtag" => $mtag, "field" => $field, "membernum" => $membernum));
			$body_general	=	$descrip;
			$image			=	'';
			$image_link		=	"space.php?do=mtag&tagid=".$tagid;
			$hash_data		=	md5($title_template."\t".$body_template."\t".$body_data);
			$type			=	'mtag';
			break;
		
		case 'photo' :
			$title_template	=	'������һ��ͼƬ';
			$body_template	=	'���: <b>{albumname}</b><br>{username}<br>{title}';
			$arr			=	unserialize($content);
			foreach($arr as $key => $value){
				if(is_array($value)){
					foreach($value as $subkey => $subvalue){
						${$subkey} = $subvalue;
					}
				}else{
					${$key}		=	$value;
				}
			}
			$query_photo = $db['source']->query("select a.aname, p.aid, p.pid from {$source_tablepre}cnphoto p, {$source_tablepre}cnalbum a where p.aid = a.aid and p.path = '$image'");
			$detail			=	$db['source']->fetch_array($query_photo);
			$albumname		=	$detail['aname'];
			$albumid		=	$detail['aid'];
			$picid			=	$detail['pid'];
			
			$albumname		=	"<a href=\"space.php?uid=".$uid."&do=album&id=".$albumid."\">".$albumname."</a>";
			$username		=	"<a href=\"space.php?uid=".$uid."\">".$username."</a>";
			$body_data		=	serialize(array("albumname" => $albumname, "username" => $username, "title" => ""));
			$body_general	=	$descrip;
			$image			=	$image;
			$image_link		=	"space.php?uid=".$uid."&do=album&picid=".$picid;
			$hash_data		=	md5($title_template."\t".$body_template."\t".$body_data);
			$type			=	'pic';
			break;

		case 'album' :
			$title_template	=	'������һ�����';
			$body_template	=	'<b>{albumname}</b><br>{username}';
			$arr			=	unserialize($content);
			foreach($arr as $key => $value){
				if(is_array($value)){
					foreach($value as $subkey => $subvalue){
						${$subkey} = $subvalue;
					}
				}else{
					${$key}		=	$value;
				}
			}
			$query_album = $db['source']->query("select p.aid, a.aname from {$source_tablepre}cnphoto p, {$source_tablepre}cnalbum a where p.aid=a.aid and p.path = '$image'");
			$detail			=	$db['source']->fetch_array($query_album);
			$aid			=	$detail['aid'];
			$name			=	$detail['aname'];

			$albumname		=	"<a href=\"space.php?uid=".$uid."&do=album&id=".$aid."\">".$name."</a>";
			$username		=	"<a href=\"space.php?uid=".$uid."\">".$username."</a>";
			
			$body_data		=	serialize(array("albumname" => $albumname, "username" => $username));
			$body_general	=	$descrip;
			$image			=	$image;
			$image_link		=	"space.php?uid=".$uid."&do=album&id=".$aid;
			$hash_data		=	md5($title_template."\t".$body_template."\t".$body_data);
			$type			=	'album';
			break;

		case 'diary' :
			$title_template	=	'������һƪ��־';
			$body_template	=	'<b>{subject}</b><br>{username}<br>{message}';
			$arr			=	unserialize($content);
			foreach($arr as $key => $value){
				if(is_array($value)){
					foreach($value as $subkey => $subvalue){
						${$subkey} = $subvalue;
					}
				}else{
					${$key}		=	$value;
				}
			}
			$query_diary = $db['source']->query("select did, uid, username, content from {$source_tablepre}diary where subject = '$subject'");
			$detail			=	$db['source']->fetch_array($query_diary);
			$did			=	$detail['did'];
			$uid			=	$detail['uid'];
			$username		=	$detail['username'];
			$content		=	$detail['content'];

			$subject		=	"<a href=\"space.php?uid=".$uid."&do=blog&id=".$did."\">".$subject."</a>";
			$username		=	"<a href=\"space.php?uid=".$uid."\">".$username."</a>";
			$message		=	$content;
			
			$body_data		=	serialize(array("subject" => $subject, "username" => $username, "message" => $content));
			$body_general	=	$descrip;
			$image			=	'';
			$image_link		=	'';
			$hash_data		=	md5($title_template."\t".$body_template."\t".$body_data);
			$type			=	'blog';
			break;

		case 'user' :
			$title_template	=	'������һ���û�';
			$body_template	=	'<b>{username}</b><br>{reside}<br>{spacenote}';
			$arr			=	unserialize($content);
			foreach($arr as $key => $value){
				if(is_array($value)){
					foreach($value as $subkey => $subvalue){
						${$subkey} = $subvalue;
					}
				}else{
					${$key}		=	$value;
				}
			}
			$uid = $db['source']->result($db['source']->query("select uid from {$source_tablepre}members where username = '$username'"), 0);
			
			$username		=	"<a href=\"space.php?uid=".$uid."\">".$username."</a>";
			
			$body_data		=	serialize(array("username" => $username, "reside" => "", "spacenote" => ""));
			$body_general	=	$descrip;
			$image			=	'';
			$image_link		=	'';
			$hash_data		=	md5($title_template."\t".$body_template."\t".$body_data);
			$type			=	'space';
			break;
	}

	$uid			=	$share['uid'];
	$username		=	$share['username'];
	$dateline		=	$share['postdate'];

	$sql = "INSERT INTO {$uch_tablepre}share (sid, type, uid, username, dateline, title_template, body_template, body_data, body_general, image, image_link) VALUES ('$sid', '$type', '$uid', '$username', '$dateline', '$title_template', '$body_template', '$body_data', '$body_general', '$image', '$image_link');";

	if ($db['uchome']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת������ id = $sid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>