<?php
//�ռ��¼
if($start <= 1){
	truncatetable_uch('doing');
}

$maxrid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}owritedata"), 0);
if($start < $maxrid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}owritedata WHERE id >= $start AND id < $start + $rpp") or dexit();
while ($record = $db['source']->fetch_array($query)) {
	$record		=	daddslashes($record);

	$doid		=	$record['id'];
	$uid		=	$record['uid'];
	$username	=	getusername($uid);
	$from		=	'';
	$dateline	=	$record['postdate'];
	$message	=	formatstr(convertbbcode($record['content']));
	$ip			=	'';
	$replynum	=	$record['c_num'];
	$mood		=	0;

	$sql = "INSERT INTO {$uch_tablepre}doing (`doid`, `uid`, `username`, `from`, `dateline`, `message`, `ip`, `replynum`, `mood`) VALUES ('$doid', '$uid', '$username', '$from', '$dateline', '$message', '$ip', '$replynum', '$mood');";

	if ($db['uchome']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת���ռ��¼ id = $doid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
	
}

?>