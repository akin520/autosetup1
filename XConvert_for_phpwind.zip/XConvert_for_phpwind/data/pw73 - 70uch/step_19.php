<?php
//�ռ��¼�ظ�
if($start <= 1){
	truncatetable_uch('docomment'); 
}

$maxcid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}comment"), 0);
if($start < $maxcid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}comment WHERE type = 'write' AND id >= $start AND id < $start + $rpp") or dexit();
while ($comment = $db['source']->fetch_array($query)) {
	$comment		=	daddslashes($comment);

	$id		=	$comment['id'];
	$upid		=	$comment['upid'];
	$doid	=	$comment['typeid'];
	$uid		=	$comment['uid'];
	$username	=	$comment['username'];
	$dateline	=	$comment['postdate'];
	$message		=	formatstr(convertbbcode($comment['title']));
	$ip	=	'';
	$grade		=	$comment['upid'] == '0' ? 1 : 2;

	$sql = "INSERT INTO {$uch_tablepre}docomment (id, upid, doid, uid, username, dateline, message, ip, grade) VALUES ('$id', '$upid', '$doid', '$uid', '$username', '$dateline', '$message', '$ip', '$grade');";

	if ($db['uchome']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת���ռ��¼�ظ� id = $id ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>