<?php
//��־����
if($start <= 1){
	truncatetable_uch('class');
}
$maxdtid = $db['source']->result($db['source']->query("SELECT max(dtid) FROM {$source_tablepre}diarytype"), 0);
if($start < $maxdtid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}diarytype WHERE dtid >= $start AND dtid < $start + $rpp") or dexit();
while ($dtype = $db['source']->fetch_array($query)) {
	$dtype		=	daddslashes($dtype);

	$classid		=	$dtype['dtid'];
	$classname		=	$dtype['name'];
	$uid			=	$dtype['uid'];
	$dateline		=	time();
	
	$sql = "INSERT INTO {$uch_tablepre}class (classid, classname, uid, dateline) VALUES ('$classid', '$classname', '$uid', '$dateline');";

	if ($db['uchome']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת���ռ��¼�ظ� id = $classid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>