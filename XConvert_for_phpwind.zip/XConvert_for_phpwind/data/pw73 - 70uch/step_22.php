<?php
//���
if($start <= 1){
	truncatetable_uch('album');
}


$maxaid = $db['source']->result($db['source']->query("SELECT max(aid) FROM {$source_tablepre}cnalbum"), 0);
if($start < $maxaid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}cnalbum WHERE aid >= $start AND aid < $start + $rpp") or dexit();
while ($album = $db['source']->fetch_array($query)) {
	$album		=	daddslashes($album);

	$albumid		=	$album['aid'];
	$albumname		=	$album['aname'];
	$uid			=	$album['ownerid'];
	$username		=	$album['owner'];
	$dateline		=	$album['crtime'];
	$updatetime		=	$album['lasttime'];
	$picnum			=	$album['photonum'];
	$pic			=	$album['lastphoto'];
	$picflag		=	$picnum > 0 ? 1 : 0;
	$friend			=	$album['privacy'] == 2 ? 3 : $album['privacy'];
	$password		=	'';
	$target_ids		=	'';
	
	
	$sql = "INSERT INTO {$uch_tablepre}album (albumid, albumname, uid, username, dateline, updatetime, picnum, pic, picflag, friend, password, target_ids) VALUES ('albumid', '$albumname', '$uid', '$username', '$dateline', '$updatetime', '$picnum', '$pic', '$picflag', '$friend', '$password', '$target_ids');";

	if ($db['uchome']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת����� id = $albumid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>