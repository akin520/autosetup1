<?php
//��Ƭ
if($start <= 1){
	truncatetable_uch('pic');
}

$maxpicid = $db['source']->result($db['source']->query("SELECT max(pid) FROM {$source_tablepre}cnphoto"), 0);
if($start < $maxpicid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}cnphoto WHERE pid >= $start AND pid < $start + $rpp") or dexit();
while ($pic = $db['source']->fetch_array($query)) {
	$pic			=	daddslashes($pic);

	$picid			=	$pic['pid'];
	$albumid		=	$pic['aid'];
	$username		=	$pic['uploader'];
	$uid			=	$db['uchome']->result($db['uchome']->query("select uid from {$uch_tablepre}album where albumid = $albumid"), 0);
	$dateline		=	$pic['uptime'];
	$postip			=	'';
	$filename		=	substr(strrchr($pic['path'], "/"),1);
	$title			=	$pic['pintro'];
	$type			=	getfiletype($pic['path']);
	$size			=	'0';
	$filepath		=	$pic['path'];
	$thumb			=	'0';
	$remote			=	'0';
	

	$sql = "INSERT INTO {$uch_tablepre}pic (picid, albumid, uid, dateline, postip, filename, title, type, size, filepath, thumb, remote) VALUES ('$picid', '$albumid', '$uid', '$dateline', '$postip', '$filename', '$title', '$type', '$size', '$filepath', '$thumb', '$remote');";

	if ($db['uchome']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת����Ƭ id = $picid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>