<?php
//Ⱥ��
if($start <= 1){
	truncatetable_uch('mtag');
}

$maxmtagid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}colonys"), 0);
if($start < $maxmtagid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}colonys WHERE id >= $start AND id < $start + $rpp") or dexit();
while ($mtag = $db['source']->fetch_array($query)) {
	$mtag			=	daddslashes($mtag);

	$tagid			=	$mtag['id'];
	$tagname		=	$mtag['cname'];
	$fieldid		=	'1';
	$membernum		=	$mtag['members'];
	$close			=	$mtag['ifopen'] > 0 ? 0 : 1;
	$announcement	=	$mtag['annouce'];
	$pic			=	$mtag['cnimg'];
	$closeapply		=	'0';
	$joinperm		=	$mtag['ifcheck']==0 ? 2 : ($mtag['ifcheck']==1 ? 1 : 0);
	$viewperm		=	'0';
	$moderator		=	'';

	
	$sql = "INSERT INTO {$uch_tablepre}mtag (tagid, tagname, fieldid, membernum, close, announcement, pic, closeapply, joinperm, viewperm, moderator) VALUES ('$tagid', '$tagname', '$fieldid', '$membernum', '$close', '$announcement', '$pic', '$closeapply', '$joinperm', '$viewperm', '$moderator');";

	if ($db['uchome']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת��Ⱥ�� id = $tagid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>