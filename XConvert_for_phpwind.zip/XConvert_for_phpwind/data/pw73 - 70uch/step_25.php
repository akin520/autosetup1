<?php
//Ⱥ���Ա
if($start <= 1){
	truncatetable_uch('tagspace');
}
$maxmtagid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}cmembers"), 0);
if($start < $maxmtagid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}cmembers WHERE id >= $start AND id < $start + $rpp") or dexit();
while ($mtager = $db['source']->fetch_array($query)) {
	$mtager			=	daddslashes($mtager);
	
	$id				=	$mtager['id'];
	$tagid			=	$mtager['colonyid'];
	$uid			=	$mtager['uid'];
	$username		=	$mtager['username'];
	$grade			=	$mtager['ifadmin'] == 1 ? 9 : 0;
	

	$sql = "INSERT INTO {$uch_tablepre}tagspace (tagid, uid, username, grade) VALUES ('$tagid', '$uid', '$username', '$grade');";

	if ($db['uchome']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת��Ⱥ���Ա id = $id ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>