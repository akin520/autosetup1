<?php
//Ⱥ�黰��
if($start <= 1){
	truncatetable_uch('thread');
	truncatetable_uch('post');
}
$maxmtid = $db['source']->result($db['source']->query("SELECT max(tid) FROM {$source_tablepre}argument"), 0);
if($start < $maxmtid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}argument WHERE tid >= $start AND tid < $start + $rpp") or dexit();
while ($thread = $db['source']->fetch_array($query)) {
	$thread			=	daddslashes($thread);
	
	$tid				=	$thread['tid'];
	$tagid				=	$thread['gid'];
	$subject			=	$thread['subject'];
	$uid				=	$thread['authorid'];
	$username			=	$thread['author'];
	$dateline			=	$thread['postdate'];
	$viewnum			=	'0';
	$replynum			=	'0';
	$lastpost			=	$thread['lastpost'];
	$lastauthor			=	'';
	$lastauthorid		=	'0';
	$displayorder		=	'0';
	$digest				=	'0';
	$tpcid				=	$thread['tpcid'];

	$ip					=	'';
	$mesage				=	$thread['content'];
	$pic				=	'';
	$isthread			=	$tpcid > 0 ? 0 : 1;
	
	
	if($isthread){
		$sql_1 = "INSERT INTO {$uch_tablepre}thread (tid, tagid, subject, uid, username, dateline, viewnum, replynum, lastpost, lastauthor, lastauthorid, displayorder, digest) VALUES ('$tid', '$tagid', '$subject', '$uid', '$username', '$dateline', '$viewnum', '$replynum', '$lastpost', '$lastauthor', '$lastauthorid', '$displayorder', '$digest');";

		if (!$db['uchome']->query($sql_1)) {
			reportlog("�޷�ת��Ⱥ�黰�� id = $tid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql_1."</textarea>");
		}
	}

	$pid				=	$thread['tid'];	
	$tid				=	$thread['tpcid'] > 0 ? $thread['tpcid'] : $tid;
	$sql_2 = "INSERT INTO {$uch_tablepre}post (pid, tagid, tid, uid, username, ip, dateline, message, pic, isthread) VALUES ('$pid', '$tagid', '$tid', '$uid', '$username', '$ip', '$dateline', '$message', '$pic', '$isthread');";

	if ($db['uchome']->query($sql_2)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת��Ⱥ�黰��ظ� id = $pid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql_2."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>