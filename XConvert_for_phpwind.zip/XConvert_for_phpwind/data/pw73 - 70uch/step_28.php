<?php
//����
if($start <= 1){
	truncatetable_uch('comment');
}

$maxcomid = $db['source']->result($db['source']->query("SELECT max(id) FROM {$source_tablepre}comment"), 0);
if($start < $maxcomid){
	$converted = 1;
}
$query = $db['source']->query("SELECT * FROM {$source_tablepre}comment WHERE type != 'write' AND id >= $start AND id < $start + $rpp") or dexit();
while ($comment = $db['source']->fetch_array($query)) {
	$comment			=	daddslashes($comment);

	$cid			=	$comment['id'];
	$uid			=	$comment['uid'];
	$id				=	$comment['typeid'];
	switch($comment['type'])
	{
		case 'diary':
			$idtype = 'blogid';
			break;
		case 'photo':
			$idtype = 'picid';
			break;
		case 'share':
			$idtype = 'sid';
	}
	$authorid		=	$comment['uid'];
	$author			=	$comment['username'];
	$ip				=	'';
	$dateline		=	$comment['postdate'];
	$message		=	$comment['title'];
	
	
	$sql = "INSERT INTO {$uch_tablepre}comment (cid, uid, id, idtype, authorid, author, ip, dateline, message) VALUES ('$cid', '$uid', '$id', '$idtype', '$authorid', '$author', '$ip', '$dateline', '$message');";

	if ($db['uchome']->query($sql)) {
		$convertedrows ++;
	} else {
		reportlog("�޷�ת������ id = $cid ��SQL ������� ��<br><textarea rows=\"3\" style=\"width: 100%;\">".$sql."</textarea>");
	}
	$converted = 1;
	$totalrows ++;
}
?>